<?php

use Illuminate\Database\Seeder;

class AppSettingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('app_settings')->delete();
        
        \DB::table('app_settings')->insert(array (
            0 => 
            array (
                'client_id' => 2,
                'created_at' => '2018-11-28 19:01:52',
                'header_image_id' => NULL,
                'id' => 2,
                'is_disaster_mode' => 1,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 2,
                'updated_at' => '2018-11-28 19:09:17',
            ),
            1 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-30 13:01:03',
                'header_image_id' => 158,
                'id' => 3,
                'is_disaster_mode' => 1,
                'policy_body' => '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"><div class="section">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="page-header">
<h4>せとまちナビ利用規約11111111111111111</h4>
</div>
<p>「せとまちナビ」（以下「本アプリ」といいます。）を利用されるにあたっては、以下の利用規約をお読み頂き、同意される場合にのみご利用下さい。なお、本アプリを利用する方は、利用規約に同意したものとみなされます。</p>
<p><strong>第１条</strong>　この規約は、本アプリを利用するために必要な事項を定めるものです。</p>
<p><strong>第２条</strong>　瀬戸市は、本アプリで収集した個人が特定され又は特定され得る情報（他の情報との照合により個人を特定することができる情報を含む）（以下「個人情報」といいます。）を、瀬戸市個人情報保護条例に基づき、適正に管理します。</p>
<p><strong>第３条</strong>　瀬戸市は、利用者の個人情報を以下の各号に定める目的のために利用します。
</p><ol>
<li>利用者の管理</li>
<li>投稿内容の確認（担当課等から連絡をすることがあります。）</li>
<li>本アプリの運用向上等に向けたレポート等データの集計・分析</li>
</ol>
<p></p>
<p><strong>第４条</strong>　瀬戸市は、本人の同意を得た場合や法令等に定めがある場合など瀬戸市個人情報保護条例に規定のある場合を除き、取得した個人情報を利用目的以外の目的で利用や提供をすることはありません。
</p>
<p><strong>第５条</strong>　本アプリにて取得する利用者に関する情報の項目、利用目的、取得方法は、以下のとおりです。
</p><ul>
<li>利用者の氏名、性別、生年月日、住所、電話番号、メールアドレス、職業<br>投稿機能における個人の特定やごみカレンダーのプッシュ通知に利用します。入力いただけない場合は、コンテンツによっては利用できないものもあります。</li>
<li>GPSによる端末の位置情報<br>マップ機能と投稿機能のために利用します（自動収集）。</li>
</ul>
<p></p>
<p>(2)本アプリ及び本サービスの利用に際して、メール等で問い合わせをされた場合、当該メール等に含まれる利用者情報を収集し、問い合わせに対応する目的で利用します。
</p>
<p><strong>第６条</strong>　利用者は、本アプリの利用にあたって、次の各号の行為を行ってはいけません。
</p><ol>
<li>本アプリの運営を妨害する行為</li>
<li>虚偽の情報を登録すること</li>
<li>重複登録又はなりすまし登録を行うこと</li>
<li>営利目的のために利用すること</li>
<li>その他瀬戸市が不適当と判断する行為</li>
</ol>
<p></p>
<p><strong>第７条</strong>　瀬戸市は、本アプリの全部又は一部を事前の通知することなく変更、廃止又は終了することができるものとします。</p>
<p><strong>第８条</strong>　瀬戸市は、事前の通知をすることなく本規約の変更を行う場合があります。なお、瀬戸市が当該変更を行った場合、瀬戸市ホームページ、本アプリ等を通じてお知らせします。</p>
<p><strong>第９条</strong>　瀬戸市は次の各号における一切の責任を負いません。
</p><ol>
<li>本アプリについて、これらに関連して利用者に損害が生じた場合。</li>
<li>本アプリについて、利用者の特定の利用目的への適合性、利用結果の完全性、有用性、正確性、的確性、信頼性、即時性、最新性等について何ら保証するものではなく、利用者が本アプリを利用することにより損害が生じた場合。</li>
<li>利用者が本サービスを利用することにより第三者との間で生じた紛争等に関すること。</li>
</ol>
<p></p>
<p><strong>第１０条</strong>　「瀬戸の魅力 再発見！」における投稿内容（ニックネーム、コメント・写真）は、原則公開とし、広報せとやＳＮＳ等で使用することがあります。ただし、瀬戸市が内容を確認し、不適切と認める場合等には、非公開とすることがあります。</p>
<p><strong>第１１条</strong>　投稿写真の著作権は、投稿者に留保されますが、投稿者は、誰に対しても無償で利用（複製、複写、改変その他のあらゆる利用を含む）する権利を許諾するものとします。</p><p>222222222</p>
</div>
</div>
</div>
</div>',
                'splash_id' => 565,
                'theme_div' => 2,
                'updated_at' => '2019-01-31 17:50:56',
            ),
            2 => 
            array (
                'client_id' => 39,
                'created_at' => '2018-11-30 13:20:31',
                'header_image_id' => NULL,
                'id' => 6,
                'is_disaster_mode' => 0,
                'policy_body' => 'ggg',
                'splash_id' => 231,
                'theme_div' => 1,
                'updated_at' => '2018-12-10 12:43:50',
            ),
            3 => 
            array (
                'client_id' => 40,
                'created_at' => '2018-11-30 13:21:42',
                'header_image_id' => 63,
                'id' => 7,
                'is_disaster_mode' => 0,
                'policy_body' => 'ddedede',
                'splash_id' => 235,
                'theme_div' => 2,
                'updated_at' => '2018-12-10 12:54:30',
            ),
            4 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-07 10:49:11',
                'header_image_id' => 150,
                'id' => 8,
                'is_disaster_mode' => 0,
                'policy_body' => 'gggg <span style="font-size: 13.3333px;">gggg</span><img src="/static/uploads/cleditor/1545298356-icon_20181207135800.png">',
                'splash_id' => 187,
                'theme_div' => 1,
                'updated_at' => '2019-01-30 17:46:25',
            ),
            5 => 
            array (
                'client_id' => 52,
                'created_at' => '2018-12-07 18:14:09',
                'header_image_id' => NULL,
                'id' => 9,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => 220,
                'theme_div' => 1,
                'updated_at' => '2018-12-10 11:48:59',
            ),
            6 => 
            array (
                'client_id' => 56,
                'created_at' => '2018-12-10 10:20:08',
                'header_image_id' => NULL,
                'id' => 10,
                'is_disaster_mode' => 0,
                'policy_body' => 'test fix bug client 56',
                'splash_id' => 237,
                'theme_div' => 1,
                'updated_at' => '2018-12-10 12:55:32',
            ),
            7 => 
            array (
                'client_id' => 70,
                'created_at' => '2018-12-10 10:56:06',
                'header_image_id' => NULL,
                'id' => 11,
                'is_disaster_mode' => 0,
                'policy_body' => 'l;lfff',
                'splash_id' => 248,
                'theme_div' => 0,
                'updated_at' => '2018-12-25 13:26:39',
            ),
            8 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:57:39',
                'header_image_id' => NULL,
                'id' => 12,
                'is_disaster_mode' => 0,
                'policy_body' => 'gggggggggg<img src="/static/uploads/cleditor/1544408222-anh-dep-ve-chau-au-thap-eiffel-cua-phap-5.jpg">',
                'splash_id' => 195,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:17:13',
            ),
            9 => 
            array (
                'client_id' => 75,
                'created_at' => '2018-12-10 11:01:49',
                'header_image_id' => NULL,
                'id' => 13,
                'is_disaster_mode' => 0,
                'policy_body' => 'test',
                'splash_id' => 239,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 13:14:26',
            ),
            10 => 
            array (
                'client_id' => 53,
                'created_at' => '2018-12-10 11:06:24',
                'header_image_id' => 308,
                'id' => 14,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => 199,
                'theme_div' => 1,
                'updated_at' => '2019-01-04 18:30:21',
            ),
            11 => 
            array (
                'client_id' => 12,
                'created_at' => '2018-12-10 11:13:29',
                'header_image_id' => NULL,
                'id' => 15,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:13:29',
            ),
            12 => 
            array (
                'client_id' => 254,
                'created_at' => '2018-12-10 11:21:51',
                'header_image_id' => NULL,
                'id' => 16,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:21:51',
            ),
            13 => 
            array (
                'client_id' => 24,
                'created_at' => '2018-12-10 11:21:54',
                'header_image_id' => NULL,
                'id' => 17,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:21:54',
            ),
            14 => 
            array (
                'client_id' => 34,
                'created_at' => '2018-12-10 11:25:25',
                'header_image_id' => NULL,
                'id' => 18,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:25:25',
            ),
            15 => 
            array (
                'client_id' => 77,
                'created_at' => '2018-12-10 11:30:23',
                'header_image_id' => 254,
                'id' => 19,
                'is_disaster_mode' => 0,
                'policy_body' => 'test',
                'splash_id' => 252,
                'theme_div' => 2,
                'updated_at' => '2018-12-10 15:47:29',
            ),
            16 => 
            array (
                'client_id' => 51,
                'created_at' => '2018-12-10 11:31:53',
                'header_image_id' => NULL,
                'id' => 20,
                'is_disaster_mode' => 0,
                'policy_body' => 'test',
                'splash_id' => 208,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:46:51',
            ),
            17 => 
            array (
                'client_id' => 47,
                'created_at' => '2018-12-10 11:32:14',
                'header_image_id' => NULL,
                'id' => 21,
                'is_disaster_mode' => 0,
                'policy_body' => 'jjjjjjjjjjj',
                'splash_id' => 202,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 12:23:09',
            ),
            18 => 
            array (
                'client_id' => 41,
                'created_at' => '2018-12-10 11:35:30',
                'header_image_id' => NULL,
                'id' => 22,
                'is_disaster_mode' => 0,
                'policy_body' => 'demo',
                'splash_id' => 216,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:43:48',
            ),
            19 => 
            array (
                'client_id' => 13,
                'created_at' => '2018-12-10 11:36:16',
                'header_image_id' => NULL,
                'id' => 23,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:36:16',
            ),
            20 => 
            array (
                'client_id' => 48,
                'created_at' => '2018-12-10 11:46:20',
                'header_image_id' => NULL,
                'id' => 24,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => 218,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:46:41',
            ),
            21 => 
            array (
                'client_id' => 49,
                'created_at' => '2018-12-10 11:47:38',
                'header_image_id' => NULL,
                'id' => 25,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => 225,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:54:49',
            ),
            22 => 
            array (
                'client_id' => 44,
                'created_at' => '2018-12-10 11:51:07',
                'header_image_id' => NULL,
                'id' => 26,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => 222,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:51:34',
            ),
            23 => 
            array (
                'client_id' => 45,
                'created_at' => '2018-12-10 11:52:04',
                'header_image_id' => NULL,
                'id' => 27,
                'is_disaster_mode' => 0,
                'policy_body' => 'hhhhhhhhhhh',
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 11:52:45',
            ),
            24 => 
            array (
                'client_id' => 73,
                'created_at' => '2018-12-10 11:56:10',
                'header_image_id' => NULL,
                'id' => 28,
                'is_disaster_mode' => 0,
                'policy_body' => '22222222222',
                'splash_id' => 229,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 12:22:42',
            ),
            25 => 
            array (
                'client_id' => 37,
                'created_at' => '2018-12-10 12:39:18',
                'header_image_id' => NULL,
                'id' => 29,
                'is_disaster_mode' => 0,
                'policy_body' => 'rferer',
                'splash_id' => 287,
                'theme_div' => 0,
                'updated_at' => '2019-01-03 12:27:43',
            ),
            26 => 
            array (
                'client_id' => 14,
                'created_at' => '2018-12-10 13:41:30',
                'header_image_id' => NULL,
                'id' => 30,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 13:41:30',
            ),
            27 => 
            array (
                'client_id' => 74,
                'created_at' => '2018-12-10 13:47:37',
                'header_image_id' => NULL,
                'id' => 31,
                'is_disaster_mode' => 0,
                'policy_body' => 'hello',
                'splash_id' => 241,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 15:13:17',
            ),
            28 => 
            array (
                'client_id' => 76,
                'created_at' => '2018-12-10 13:49:55',
                'header_image_id' => NULL,
                'id' => 32,
                'is_disaster_mode' => 0,
                'policy_body' => '<p>aaaaaaaaaaaa</p>',
                'splash_id' => 243,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 13:52:18',
            ),
            29 => 
            array (
                'client_id' => 20,
                'created_at' => '2018-12-10 13:57:29',
                'header_image_id' => NULL,
                'id' => 33,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 0,
                'updated_at' => '2018-12-10 13:57:29',
            ),
            30 => 
            array (
                'client_id' => 78,
                'created_at' => '2018-12-10 15:48:15',
                'header_image_id' => 258,
                'id' => 34,
                'is_disaster_mode' => 0,
                'policy_body' => '<span style="font-weight: bold; font-family: Georgia; font-size: xx-large;">gggggggggggggggg</span>',
                'splash_id' => 256,
                'theme_div' => 1,
                'updated_at' => '2018-12-10 18:44:35',
            ),
            31 => 
            array (
                'client_id' => 79,
                'created_at' => '2018-12-10 18:26:28',
                'header_image_id' => 260,
                'id' => 35,
                'is_disaster_mode' => 0,
                'policy_body' => 'Test',
                'splash_id' => 262,
                'theme_div' => 1,
                'updated_at' => '2018-12-25 13:48:17',
            ),
            32 => 
            array (
                'client_id' => 80,
                'created_at' => '2018-12-25 12:01:30',
                'header_image_id' => NULL,
                'id' => 36,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2018-12-25 12:01:30',
            ),
            33 => 
            array (
                'client_id' => 81,
                'created_at' => '2018-12-25 13:01:36',
                'header_image_id' => 268,
                'id' => 37,
                'is_disaster_mode' => 0,
                'policy_body' => '<h6 style=""><font color="#ffcc33" size="6"><a href="http://www.vinicorp.com.vn/page/2/about-us.html">Xin chào</a></font></h6><div><font color="#ffcc33" size="6"><br></font></div>',
                'splash_id' => 266,
                'theme_div' => 1,
                'updated_at' => '2018-12-26 12:57:26',
            ),
            34 => 
            array (
                'client_id' => 82,
                'created_at' => '2018-12-26 16:20:04',
                'header_image_id' => NULL,
                'id' => 38,
                'is_disaster_mode' => 0,
                'policy_body' => 'ddddd',
                'splash_id' => 302,
                'theme_div' => 1,
                'updated_at' => '2019-01-03 19:37:23',
            ),
            35 => 
            array (
                'client_id' => 83,
                'created_at' => '2019-01-05 12:51:15',
                'header_image_id' => NULL,
                'id' => 39,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-01-05 12:51:15',
            ),
            36 => 
            array (
                'client_id' => 84,
                'created_at' => '2019-01-09 12:59:41',
                'header_image_id' => NULL,
                'id' => 40,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-01-09 12:59:41',
            ),
            37 => 
            array (
                'client_id' => 85,
                'created_at' => '2019-01-14 13:30:35',
                'header_image_id' => NULL,
                'id' => 41,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-01-14 13:30:35',
            ),
            38 => 
            array (
                'client_id' => 86,
                'created_at' => '2019-01-14 13:49:06',
                'header_image_id' => 407,
                'id' => 42,
                'is_disaster_mode' => 0,
                'policy_body' => 'eeeeeeeeeeeeee<div>d</div><div>d</div><div>d</div><div>d</div><div><br></div><div>d</div><div>d</div><div>d</div><div>d</div><div>d</div><div><br></div><div>d</div><div>d</div><div>d</div><div>d</div><div><br></div>',
                'splash_id' => 408,
                'theme_div' => 1,
                'updated_at' => '2019-01-14 15:23:50',
            ),
            39 => 
            array (
                'client_id' => 88,
                'created_at' => '2019-01-14 15:40:18',
                'header_image_id' => NULL,
                'id' => 43,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-01-14 15:40:18',
            ),
            40 => 
            array (
                'client_id' => 10,
                'created_at' => '2019-01-14 16:24:16',
                'header_image_id' => NULL,
                'id' => 44,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-01-14 16:24:16',
            ),
            41 => 
            array (
                'client_id' => 89,
                'created_at' => '2019-01-16 17:42:42',
                'header_image_id' => NULL,
                'id' => 45,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-01-16 17:42:42',
            ),
            42 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-04-10 11:00:27',
                'header_image_id' => NULL,
                'id' => 66,
                'is_disaster_mode' => 0,
            'policy_body' => '<span style="font-size: 13.3333px;">せとまちナビ利用規約</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">「せとまちナビ」（以下「本アプリ」といいます。）を利用されるにあたっては、以下の利用規約をお読み頂き、同意される場合にのみご利用下さい。なお、本アプリを利用する方は、利用規約に同意したものとみなされます。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第１条　この規約は、本アプリを利用するために必要な事項を定めるものです。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第２条　瀬戸市は、本アプリで収集した個人が特定され又は特定され得る情報（他の情報との照合により個人を特定することができる情報を含む）（以下「個人情報」といいます。）を、瀬戸市個人情報保護条例に基づき、適正に管理します。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第３条　瀬戸市は、利用者の個人情報を以下の各号に定める目的のために利用します。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 利用者の管理</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 投稿内容の確認（担当課等から連絡をすることがあります。）</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 本アプリの運用向上等に向けたレポート等データの集計・分析</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第４条　瀬戸市は、本人の同意を得た場合や法令等に定めがある場合など瀬戸市個人情報保護条例に規定のある場合を除き、取得した個人情報を利用目的以外の目的で利用や提供をすることはありません。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第５条　本アプリにて取得する利用者に関する情報の項目、利用目的、取得方法は、以下のとおりです。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 利用者の氏名、性別、生年月日、住所、電話番号、メールアドレス、職業</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 投稿機能における個人の特定やごみカレンダーのプッシュ通知に利用します。入力いただけない場合は、コンテンツによっては利用できないものもあります。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; GPSによる端末の位置情報</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; マップ機能と投稿機能のために利用します（自動収集）。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">(2)本アプリ及び本サービスの利用に際して、メール等で問い合わせをされた場合、当該メール等に含まれる利用者情報を収集し、問い合わせに対応する目的で利用します。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第６条　利用者は、本アプリの利用にあたって、次の各号の行為を行ってはいけません。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 本アプリの運営を妨害する行為</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 虚偽の情報を登録すること</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 重複登録又はなりすまし登録を行うこと</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 営利目的のために利用すること</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; その他瀬戸市が不適当と判断する行為</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第７条　瀬戸市は、本アプリの全部又は一部を事前の通知することなく変更、廃止又は終了することができるものとします。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第８条　瀬戸市は、事前の通知をすることなく本規約の変更を行う場合があります。なお、瀬戸市が当該変更を行った場合、瀬戸市ホームページ、本アプリ等を通じてお知らせします。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第９条　瀬戸市は次の各号における一切の責任を負いません。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 本アプリについて、これらに関連して利用者に損害が生じた場合。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 本アプリについて、利用者の特定の利用目的への適合性、利用結果の完全性、有用性、正確性、的確性、信頼性、即時性、最新性等について何ら保証するものではなく、利用者が本アプリを利用することにより損害が生じた場合。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">&nbsp;&nbsp;&nbsp; 利用者が本サービスを利用することにより第三者との間で生じた紛争等に関すること。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第１０条　「瀬戸の魅力 再発見！」における投稿内容（ニックネーム、コメント・写真）は、原則公開とし、広報せとやＳＮＳ等で使用することがあります。ただし、瀬戸市が内容を確認し、不適切と認める場合等には、非公開とすることがあります。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">第１１条　投稿写真の著作権は、投稿者に留保されますが、投稿者は、誰に対しても無償で利用（複製、複写、改変その他のあらゆる利用を含む）する権利を許諾するものとします。</span><br style="font-size: 13.3333px;"><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">222222222</span>',
                'splash_id' => 2234,
                'theme_div' => 1,
                'updated_at' => '2019-06-03 15:51:03',
            ),
            43 => 
            array (
                'client_id' => 205,
                'created_at' => '2019-04-16 10:29:18',
                'header_image_id' => NULL,
                'id' => 67,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-04-16 10:29:18',
            ),
            44 => 
            array (
                'client_id' => 207,
                'created_at' => '2019-04-16 11:14:01',
                'header_image_id' => NULL,
                'id' => 68,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-04-16 11:14:01',
            ),
            45 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-20 10:57:57',
                'header_image_id' => NULL,
                'id' => 69,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-05-20 10:57:57',
            ),
            46 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 11:21:44',
                'header_image_id' => NULL,
                'id' => 70,
                'is_disaster_mode' => 0,
                'policy_body' => 'Sao ma kho the',
                'splash_id' => 3102,
                'theme_div' => 1,
                'updated_at' => '2019-05-20 11:25:52',
            ),
            47 => 
            array (
                'client_id' => 210,
                'created_at' => '2019-05-20 11:41:04',
                'header_image_id' => NULL,
                'id' => 71,
                'is_disaster_mode' => 0,
                'policy_body' => 'cfee',
                'splash_id' => 3106,
                'theme_div' => 1,
                'updated_at' => '2019-05-20 11:41:26',
            ),
            48 => 
            array (
                'client_id' => 212,
                'created_at' => '2019-05-23 16:01:57',
                'header_image_id' => NULL,
                'id' => 73,
                'is_disaster_mode' => 0,
                'policy_body' => NULL,
                'splash_id' => NULL,
                'theme_div' => 1,
                'updated_at' => '2019-05-23 16:01:57',
            ),
        ));
        
        
    }
}