<?php

use Illuminate\Database\Seeder;

class FailedJobsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('failed_jobs')->delete();
        
        \DB::table('failed_jobs')->insert(array (
            0 => 
            array (
                'connection' => 'database',
                'exception' => 'Illuminate\\Queue\\MaxAttemptsExceededException: App\\Jobs\\PushNotificationJob has been attempted too many times or run too long. The job may have previously timed out. in /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Queue/Worker.php:394
Stack trace:
#0 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(314): Illuminate\\Queue\\Worker->markJobAsFailedIfAlreadyExceedsMaxAttempts(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), 1)
#1 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(270): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))
#2 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(114): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))
#3 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(101): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))
#4 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(85): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')
#5 [internal function]: Illuminate\\Queue\\Console\\WorkCommand->handle()
#6 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(29): call_user_func_array(Array, Array)
#7 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(87): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()
#8 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(31): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(App\\Application), Array, Object(Closure))
#9 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Container/Container.php(549): Illuminate\\Container\\BoundMethod::call(Object(App\\Application), Array, Array, NULL)
#10 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Console/Command.php(183): Illuminate\\Container\\Container->call(Array)
#11 /opt/app/machiyell/vendor/symfony/console/Command/Command.php(255): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))
#12 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Console/Command.php(170): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))
#13 /opt/app/machiyell/vendor/symfony/console/Application.php(960): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))
#14 /opt/app/machiyell/vendor/symfony/console/Application.php(255): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))
#15 /opt/app/machiyell/vendor/symfony/console/Application.php(148): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))
#16 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Console/Application.php(88): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))
#17 /opt/app/machiyell/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(121): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))
#18 /opt/app/machiyell/artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))
#19 {main}',
                'failed_at' => '2019-05-02 19:08:28',
                'id' => 2,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:193;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
            ),
        ));
        
        
    }
}