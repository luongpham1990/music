<?php

use App\Eloquent\TranslationReplacement;
use App\Eloquent\TranslationReplacementTemplate;
use Illuminate\Database\Seeder;
use Machiyell\Visor\Support\Strings;

/**
 * 沼津向け初期データ
 *
 *
 */
class ClientNumazuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $client_id = $this->command->ask('Enter client_id');

        $areas = $this->safeAreaDatas();
        $refuges = $this->refugeArea();
        $cols = array_merge($this->splitCols($areas), $this->splitCols($refuges));
        foreach ($cols as $col) {
            try {
                TranslationReplacement::create([
                    'client_id' => $client_id,
                    'from_lang' => $col[0],
                    'from_word' => $col[1],
                    'to_lang' => $col[2],
                    'to_word' => $col[3],
                ]);
            } catch (Exception $e) {
                echo $e;
            }
        }

        $file = new SplFileObject(__DIR__ . '/numazu/numazu_messages.csv');
        $file->setFlags(SplFileObject::READ_CSV);
        foreach ($file as $line) {
            //終端の空行を除く処理　空行の場合に取れる値は後述
            if ($line[0] === null) {
                break;
            }

            var_dump($line);

            TranslationReplacementTemplate::create([
                'client_id' => $client_id,
                'category_name' => $line[0],
                'category_sub_name' => $line[1],
                'template_lang' => $line[2],
                'template_title' => $line[3],
                'template_sub_title' => $line[4],
                'template_body' => $line[5],
            ]);

        }


    }

    /**
     * @return string
     */
    private function safeAreaDatas()
    {
        // 下記のテキストはタブ区切り。Excelでペタっと貼り付けてね。
        // "\\172.30.60.212\share\クライアント\な行\ぬ_沼津市\2019‗マチエール\配信文言\マスタデータ\【沼津市】発令判断機能_避難所情報ヒアリングシート_バイザー向け.xlsx"
        $datas = <<<EOS
ja	第一小学校	*	DAIICHISHOGAKKO
ja	香貫小学校	*	KANUKISHOGAKKO
ja	第四小学校	*	DAIYONSHOGAKKO
ja	第五小学校	*	DAIGOSHOGAKKO
ja	開北小学校	*	KAIHOKUSHOGAKKO
ja	片浜小学校	*	KATAHAMASHOGAKKO
ja	金岡小学校	*	KANAOKASHOGAKKO
ja	沢田小学校	*	SAWADASHOGAKKO
ja	大岡小学校	*	OOKASHOGAKKO
ja	大岡南小学校	*	OOKAMINAMISHOGAKKO
ja	旧静浦西小学校	*	KYUSHIZURANISHISHOGAKKO
ja	愛鷹小学校	*	ASHITAKASHOGAKKO
ja	大平小学校	*	OHIRASHOGAKKO
ja	内浦小学校	*	UCHIURASHOGAKKO
ja	西浦小学校	*	NISHIURASHOGAKKO
ja	原小学校	*	HARASHOGAKKO
ja	原東小学校	*	HARAHIGASHISHOGAKKO
ja	浮島小学校	*	UKISHIMASHOGAKKO
ja	門池小学校	*	KADOIKESHOGAKKO
ja	今沢小学校	*	IMAZAWASHOGAKKO
ja	第一中学校	*	DAIICHICHUGAKKO
ja	第二中学校	*	DAINICHUGAKKO
ja	第三中学校	*	DAISANCHUGAKKO
ja	第五中学校	*	DAIGOCHUGAKKO
ja	片浜中学校	*	KATAHAMACHUGAKKO
ja	金岡中学校	*	KANAOKACHUGAKKO
ja	大岡中学校	*	OOKACHUGAKKO
ja	静浦小中一貫学校	*	SHIZURASHOCHUIKKANGAKKO
ja	大平中学校	*	OHIRACHUGAKKO
ja	長井崎中学校	*	NAGAISAKICHUGAKKO
ja	原中学校	*	HARACHUGAKKO
ja	門池中学校	*	KADOIKECHUGAKKO
ja	沼津市立高校・中等部	*	NUMAZUSHIRITUKOKO・CHUTOBU
ja	県立沼津西高校	*	KENRITSUNUMAZUNISHIKOKO
ja	県立沼津工業高校	*	KENRITSUNUMAZUKOGYOKOKO
ja	県立沼津東高校	*	KENRITSUNUMAZUHIGASHIKOKO
ja	沼津工業高等専門学校	*	NUMAZUKOGYOKOTOSEMMONGAKKO
ja	加藤学園高校	*	KATOGAKUENKOKO
ja	桐陽高校	*	TOYOKOKO
ja	誠恵高校	*	SEIKEIKOKO
ja	飛龍高校	*	HIRYUKOKO
ja	沼津中央高校	*	NUMAZUCHUOKOKO
ja	県立沼津視覚特別支援学校	*	KENRITSUNUMAZUSHIKAKUTOKUBETSUSHIENGAKKO
ja	県立沼津聴覚特別支援学校	*	KENRITSUNUMAZUCHOKAKUTOKUBETSUSHIENGAKKO
ja	我入道コミュニティ防災センター	*	GANYUDOKOMYUNITEIBOSAISENTA
ja	沼津市民文化センター	*	NUMAZUSHIMIMBUNKASENTA
ja	愛鷹地区センター	*	ASHITAKACHIKUSENTA
ja	戸田Ｂ＆Ｇ海洋センター	*	HEDABIANDOJIKAIYOSENTA
ja	戸田地区センター	*	HEDACHIKUSENTA
EOS;
        return $datas;
    }

    private function refugeArea()
    {
        $areas = <<<EOS
ja	上土町	*	AGETSUCHICHO
ja	末広町	*	SUEHIROCHO
ja	真砂町	*	MASAGOCHO
ja	八幡町	*	HACHIMANCHO
ja	町方町	*	MACHIKATAMACHI
ja	川廓町	*	KAWAGURUWACHO
ja	志多町	*	SHITAMACHI
ja	白銀町	*	SHIROGANECHO
ja	錦丸子町	*	NISHIKIMARUKOCHO
ja	西条町	*	SAIJOCHO
ja	添地町	*	SOECHICHO
ja	大手町	*	OTEMACHI
ja	上本通町	*	KAMIHONDORICHO
ja	本町一丁目	*	HONCHOITCHOME
ja	本町二丁目	*	HONCHONICHOME
ja	下河原西町	*	SHIMOGAWARANISHIMACHI
ja	下河原南部	*	SHIMOGAWARANAMBU
ja	下河原東部	*	SHIMOGAWARATOBU
ja	千本常盤町	*	SEMBONTOKIWACHO
ja	旭町	*	ASAHICHO
ja	千本緑町	*	SEMBOMMIDORICHO
ja	宮町	*	MIYACHO
ja	幸町	*	SAIWAICHO
ja	港湾区	*	KOWANKU
ja	下河原団地	*	SHIMOGAWARADANCHI
ja	市道町	*	ICHIMICHICHO
ja	松下町	*	MATSUSHITACHO
ja	東間門	*	HIGASHIMAKADO
ja	西浜町	*	NISHIHAMACHO
ja	西村町	*	NISHIMURACHO
ja	宮本町	*	MIYAMOTOCHO
ja	神明町	*	SHIMMEICHO
ja	馬場町	*	BAMBACHO
ja	第一宮脇	*	DAIICHIMIYAWAKI
ja	第二宮脇	*	DAINIMIYAWAKI
ja	石原	*	ISHIHARA
ja	楊原	*	YANAGIHARA
ja	塩満	*	SHIOMICHI
ja	木の宮	*	KINOMIYA
ja	西木の宮	*	NISHIKINOMIYA
ja	東桃郷	*	HIGASHITOGO
ja	八重	*	YAE
ja	八重坂	*	YAESAKA
ja	外原	*	SOTOBARA
ja	二瀬川町	*	FUTASEGAWACHO
ja	東八重	*	HIGASHIYAE
ja	藤井原町	*	FUJIIHARACHO
ja	香貫が丘	*	KANUKIGAOKA
ja	香貫台	*	KANUKIDAI
ja	塩場	*	SHOBA
ja	島郷	*	TOGO
ja	牛臥	*	USHIBUSE
ja	八間町	*	HAKKENCHO
ja	東八間町	*	HIGASHIHAKKENCHO
ja	西島町	*	NISHIJIMACHO
ja	三貫地	*	SANGANCHI
ja	江川町	*	EGAWACHO
ja	東町	*	HIGASHICHO
ja	一本松町	*	IPPOMMATSUCHO
ja	津島町	*	TSUSHIMACHO
ja	浜町	*	HAMACHO
ja	林町	*	HAYASHICHO
ja	稲荷町	*	INARICHO
ja	秋葉町	*	AKIBACHO
ja	南条寺町	*	NANJOJICHO
ja	中住町	*	NAKAZUMICHO
ja	住吉町	*	SUMIYOSHICHO
ja	中瀬町	*	NAKASECHO
ja	黒瀬町	*	KUROSECHO
ja	中原町	*	NAKAHARACHO
ja	東豊栄町	*	HIGASHITOYOSAKAECHO
ja	西豊栄町	*	NISHITOYOSAKAECHO
ja	南本郷町西	*	MINAMIHONGOCHONISHI
ja	南本郷町東	*	MINAMIHONGOCHOHIGASHI
ja	久保町	*	KUBOCHO
ja	山下町	*	YAMASHITACHO
ja	玉江町	*	TAMAECHO
ja	宮原町	*	MIYAHARACHO
ja	御幸町	*	MIYUKICHO
ja	三園町	*	MISONOCHO
ja	市場町	*	ICHIBACHO
ja	通吉田町	*	TORIYOSHIDACHO
ja	吉田町	*	YOSHIDACHO
ja	永代川瀬町	*	EITAIKAWASECHO
ja	槙島北町	*	MAKISHIMAKITACHO
ja	三枚橋町	*	SAMMAIBASHICHO
ja	平町一丁目	*	HIRAMACHIICCHOME
ja	平町二丁目	*	HIRAMACHINICHOME
ja	山王台	*	SANNODAI
ja	三芳町	*	MIYOSHICHO
ja	山王前	*	SANNOMAE
ja	富士見町	*	FUJIMICHO
ja	伝馬町	*	TEMMACHO
ja	シティコープ平町	*	SHITEIKOPUHIRAMACHI
ja	米山町	*	YONEYAMACHO
ja	日の出町	*	HINODECHO
ja	泉町	*	IZUMICHO
ja	泉町県職員住宅	*	IZUMICHOKENSHOKUINJUTAKU
ja	杉崎町	*	SUGIZAKICHO
ja	自由ケ丘一区	*	JIYUGAOKAIKKU
ja	弥生町	*	YAYOICHO
ja	自由ケ丘二区	*	JIYUGAOKANIKU
ja	自由ケ丘三区	*	JIYUGAOKASANKU
ja	竹ノ岬	*	TAKENOMISAKI
ja	コーポラス三枚橋	*	KOPORASUSAMMAIBASHI
ja	自由ケ丘四区	*	JIYUGAOKAYONKU
ja	自由ケ丘五区	*	JIYUGAOKAGOKU
ja	シティラック沼津	*	SHITEIRAKKUNUMAZU
ja	ファインスクエア沼津泉町	*	FUAINSUKUEANUMAZUIZUMICHO
ja	新宿町	*	SHINJUKUCHO
ja	庄栄町	*	SHOEICHO
ja	庄栄町北	*	SHOEICHOKITA
ja	庄栄町南	*	SHOEICHOMINAMI
ja	五月町	*	SATSUKICHO
ja	青葉町	*	AOBACHO
ja	高島町	*	TAKASHIMACHO
ja	高島町西	*	TAKASHIMACHONISHI
ja	高沢町	*	TAKAZAWACHO
ja	双葉町南	*	FUTABACHOMINAMI
ja	双葉町北	*	FUTABACHOKITA
ja	本田町	*	HONTAMACHI
ja	沼北町	*	NUMAKITACHO
ja	北新町	*	HOKUSHINCHO
ja	北高島町	*	KITATAKASHIMACHO
ja	高島本町西	*	TAKASHIMAHONCHONISHI
ja	竹の花	*	TAKENOHANA
ja	岡一色	*	OKAISSIKI
ja	岡宮	*	OKANOMIYA
ja	門池町	*	KADOIKECHO
ja	緑ヶ丘	*	MIDORIGAOKA
ja	池上町	*	IKEGAMICHO
ja	御堂林町	*	MIDOBAYASHICHO
ja	北園町	*	KITAZONOCHO
ja	花園町	*	HANAZONOCHO
ja	宮前町	*	MIYAMAECHO
ja	北小林	*	KITAKOBAYASHI
ja	南小林	*	MINAMIKOBAYASHI
ja	柏葉尾	*	KASHIBAO
ja	小林団地	*	KOBAYASHIDANCHI
ja	南小林団地	*	MINAMIKOBAYASHIDANCHI
ja	グランドール沼津	*	GURANDORUNUMAZU
ja	東熊堂	*	HIGASHIKUMANDO
ja	西熊堂	*	NISHIKUMANDO
ja	沢田町	*	SAWADACHO
ja	江原町	*	EBARACHO
ja	足高拓南	*	ASHITAKATAKUNAN
ja	寿町	*	KOTOBUKICHO
ja	明電町	*	MEIDENCHO
ja	柳町	*	YANAGICHO
ja	神田町	*	KANDACHO
ja	若葉町	*	WAKABACHO
ja	東名町	*	TOMEICHO
ja	高尾台	*	TAKAODAI
ja	豊町	*	YUTAKACHO
ja	松沢町	*	MATSUSAWACHO
ja	雲雀台	*	HIBARIDAI
ja	北神明町	*	KITASHIMMEICHO
ja	筒井町	*	TSUTSUICHO
ja	天神ヶ尾	*	TEJIGAO
ja	東沢田	*	HIGASHISAWADA
ja	中沢田	*	NAKASAWADA
ja	西沢田	*	NISHISAWADA
ja	長塚町	*	NAGATSUKACHO
ja	西沢田緑ヶ丘	*	NISHISAWADAMIDORIGAOKA
ja	大林	*	OBAYASHI
ja	新沢田町	*	SHINSAWADACHO
ja	駿河台	*	SURUGADAI
ja	ウィスティリア沢田	*	UISUTEIRIASAWADA
ja	大岡駅前町	*	OOKAEKIMAECHO
ja	日吉	*	HIYOSHI
ja	沼平町	*	NUMAHEICHO
ja	下石田	*	SHIMOISHIDA
ja	富士町	*	FUJICHO
ja	木瀬川	*	KISEGAWA
ja	平和郷	*	HEIWAKYO
ja	上石田	*	KAMIISHIDA
ja	中石田	*	NAKAISHIDA
ja	富岳町	*	FUGAKUCHO
ja	大岡高田	*	OOKATAKADA
ja	大岡造り道	*	OOKATSUKURIMICHI
ja	大岡団地	*	OOKADANCHI
ja	太田町	*	OTACHO
ja	小屋敷台	*	OYASHIKIDAI
ja	東椎路小屋敷	*	HIGASHISHIIJIOYASHIKI
ja	鷹根台	*	TAKANEDAI
ja	東椎路中東	*	HIGASHISHIIJINAKAHIGASHI
ja	椎の木	*	SIINOKI
ja	つばきケ丘	*	TSUBAKIGAOKA
ja	東椎路久保	*	HIGASHISHIIJIKUBO
ja	赤坂	*	AKASAKA
ja	東椎路中尾	*	HIGASHISHIIJINAKAO
ja	春ノ木	*	HARUNOKI
ja	芝原町	*	SIBAHARACHO
ja	松見台	*	MATSUMIDAI
ja	堤山	*	TSUTSUMIYAMA
ja	大久望町	*	OKUBOCHO
ja	愛鷹宮本	*	ASHITAKAMIYAMOTO
ja	西椎路	*	NISHISHIIJI
ja	目黒身	*	MEGUROMI
ja	エンゼルハイム西椎路	*	ENZERUHAIMUNISHISHIIJI
ja	東原	*	HIGASHIBARA
ja	東原ニュータウン	*	HIGASHIBARANYUTAUN
ja	鳥谷	*	TOYA
ja	柳沢	*	YANAGISAWA
ja	青野	*	ONO
ja	桜台	*	SAKURADAI
ja	西間門	*	NISHIMAKADO
ja	小諏訪	*	KOZUWA
ja	大諏訪	*	OZUWA
ja	松長	*	MATSUNAGA
ja	大諏訪線北	*	OZUWASEMBOKU
ja	今沢	*	IMAZAWA
ja	今沢市営団地	*	IMAZAWASHIEIDANCHI
ja	ビレッジハウス今沢	*	BIREJJIHAUSUIMAZAWA
ja	今沢県住	*	IMAZAWAKENJU
ja	中今沢	*	NAKAIMAZAWA
ja	北今沢	*	KITAIMAZAWA
ja	三本松	*	SAMBOMMATSU
ja	大平第一区	*	OHIRADAIIKKU
ja	大平第二区	*	OHIRADAINIKU
ja	大平第三区	*	OHIRADAISANKU
ja	大平第四区	*	OHIRADAIYONKU
ja	大平第五区	*	OHIRADAIGOKU
ja	大平第六区	*	OHIRADAIROKKU
ja	大平第七区	*	OHIRADAINANAKU
ja	大平第八区	*	OHIRADAIHAKKU
ja	大平第九区	*	OHIRADAIKYUKU
ja	大平第十区	*	OHIRADAIJUKKU
ja	大平第十一区	*	OHIRADAIJUIKKU
ja	志下	*	SHIGE
ja	馬込	*	MAGOME
ja	獅子浜	*	SHISHIHAMA
ja	江浦	*	ENOURA
ja	多比	*	TABI
ja	口野	*	KUCHINO
ja	重須	*	OMOSU
ja	長浜	*	NAGAHAMA
ja	三津	*	MITO
ja	小海	*	KOUMI
ja	重寺	*	SIGEDERA
ja	河内	*	KOUCHI
ja	木負	*	KISHO
ja	久連	*	KUZURA
ja	平沢	*	HIRASAWA
ja	立保	*	TACHIBO
ja	古宇	*	KO
ja	足保	*	ASHIBO
ja	久料	*	KURYO
ja	江梨	*	ENASHI
ja	大塚新田	*	OTSUKASINDEN
ja	大塚本田	*	OTSUKAHONDEN
ja	東町一区	*	HIGASHICHOIKKU
ja	東町二区	*	HIGASHICHONIKU
ja	東町三区	*	HIGASHICHOSANKU
ja	市営原団地	*	SHIEIHARADANCHI
ja	県営原団地	*	KEN EIHARADANCHI
ja	ビレッジハウス原	*	BIREJJIHAUSUHARA
ja	公団中央	*	KODANCHUO
ja	原東沖	*	HARAHIGASHIOKI
ja	西町一区	*	NISHICHOIKKU
ja	西町二区	*	NISICHONIKU
ja	六軒町	*	ROKKENCHO
ja	原新田	*	HARASINDEN
ja	一本松	*	IPPOMMATSU
ja	桃里	*	MOMOZATO
ja	植田	*	UEDA
ja	ニュータウン原	*	NYUTAUNHARA
ja	県営原町中団地	*	KEN EIHARAMACHINAKADANCHI
ja	市営原町中団地	*	SIEIHARAMACHINAKADANCHI
ja	原町中	*	HARAMACHINAKA
ja	根古屋	*	NEGOYA
ja	東井出	*	HIGASHIIDE
ja	西井出	*	NISHIIDE
ja	平沼	*	HIRANUMA
ja	石川	*	ISHIKAWA
ja	荒久	*	ARAKU
ja	鬼川	*	ONIKAWA
ja	小中島	*	KONAKAJIMA
ja	大中島	*	ONAKAJIMA
ja	一色	*	ISSIKI
ja	入浜	*	IRIHAMA
ja	口南	*	KUCHIMINAMI
ja	奥南	*	OKUMINAMI
ja	大浦	*	OURA
ja	御浜	*	MIHAMA
ja	小山田	*	OYAMADA
ja	上野	*	UENO
ja	大門	*	DAIMON
ja	中上	*	NAKAGAMI
ja	大上	*	OGAMI
ja	新田	*	SHINDEN
ja	平戸	*	HIRADO
ja	舟山	*	FUNAYAMA
ja	井田	*	ITA
EOS;
        return $areas;
    }

    /**
     * タブ区切りのTSVを配列に変換
     *
     * @param string $text
     * @return array
     */
    private function splitCols(string $text): array
    {
        $lines = Strings::splitLine($text);
        $cols = array_map(function ($item) {
            return explode("\t", $item);
        }, $lines);
        return $cols;
    }


}