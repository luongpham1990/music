<?php

use Illuminate\Database\Seeder;

class FilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('files')->delete();
        
        \DB::table('files')->insert(array (
            0 => 
            array (
                'content_id' => 175,
                'id' => 20,
                'lang' => 'en',
                'title' => 'file test finish',
            ),
            1 => 
            array (
                'content_id' => 282,
                'id' => 22,
                'lang' => 'en',
            'title' => 'Test title 2(en)',
            ),
            2 => 
            array (
                'content_id' => 283,
                'id' => 23,
                'lang' => 'en',
            'title' => 'Title (en)',
            ),
            3 => 
            array (
                'content_id' => 284,
                'id' => 24,
                'lang' => 'en',
                'title' => 'file 4 en',
            ),
            4 => 
            array (
                'content_id' => 295,
                'id' => 26,
                'lang' => 'ja',
                'title' => 'test offline mobile file 1 - ja',
            ),
            5 => 
            array (
                'content_id' => 296,
                'id' => 27,
                'lang' => 'ja',
                'title' => 'test offline moblie file 2 - ja',
            ),
            6 => 
            array (
                'content_id' => 298,
                'id' => 28,
                'lang' => 'ja',
                'title' => 'test mobile offline file 3 - ja',
            ),
            7 => 
            array (
                'content_id' => 300,
                'id' => 29,
                'lang' => 'ja',
                'title' => 'test offline file 4 -ja',
            ),
            8 => 
            array (
                'content_id' => 303,
                'id' => 30,
                'lang' => 'ja',
                'title' => 'test offline moblie file 5 - ja',
            ),
            9 => 
            array (
                'content_id' => 305,
                'id' => 32,
                'lang' => 'en',
                'title' => 'title file en',
            ),
            10 => 
            array (
                'content_id' => 331,
                'id' => 34,
                'lang' => 'ja',
                'title' => 'content offline 162 - ja - 2',
            ),
            11 => 
            array (
                'content_id' => 362,
                'id' => 38,
                'lang' => 'ja',
                'title' => 'content offline 162 - ja - 4',
            ),
            12 => 
            array (
                'content_id' => 517,
                'id' => 72,
                'lang' => 'ja',
                'title' => 'Doc ja',
            ),
            13 => 
            array (
                'content_id' => 518,
                'id' => 73,
                'lang' => 'ja',
                'title' => 'Docx ja',
            ),
            14 => 
            array (
                'content_id' => 519,
                'id' => 74,
                'lang' => 'ja',
                'title' => 'Xlsx ja',
            ),
            15 => 
            array (
                'content_id' => 520,
                'id' => 75,
                'lang' => 'ja',
                'title' => 'Pptx ja',
            ),
            16 => 
            array (
                'content_id' => 522,
                'id' => 76,
                'lang' => 'ja',
                'title' => 'Ppt ja',
            ),
            17 => 
            array (
                'content_id' => 523,
                'id' => 77,
                'lang' => 'ja',
                'title' => 'Rtf ja',
            ),
            18 => 
            array (
                'content_id' => 524,
                'id' => 78,
                'lang' => 'ja',
                'title' => 'Wav ja',
            ),
            19 => 
            array (
                'content_id' => 525,
                'id' => 79,
                'lang' => 'ja',
                'title' => 'Mp3 ja',
            ),
            20 => 
            array (
                'content_id' => 526,
                'id' => 80,
                'lang' => 'ja',
                'title' => 'Mp4 ja',
            ),
            21 => 
            array (
                'content_id' => 527,
                'id' => 81,
                'lang' => 'ja',
                'title' => 'txt ja',
            ),
            22 => 
            array (
                'content_id' => 528,
                'id' => 82,
                'lang' => 'ja',
                'title' => 'pdf ja',
            ),
            23 => 
            array (
                'content_id' => 570,
                'id' => 83,
                'lang' => 'ja',
                'title' => 'pdf ja',
            ),
            24 => 
            array (
                'content_id' => 599,
                'id' => 84,
                'lang' => 'ja',
                'title' => 'xls',
            ),
            25 => 
            array (
                'content_id' => 629,
                'id' => 85,
                'lang' => 'ja',
                'title' => 'file ja',
            ),
            26 => 
            array (
                'content_id' => 734,
                'id' => 86,
                'lang' => 'ja',
                'title' => 'anh 3',
            ),
            27 => 
            array (
                'content_id' => 740,
                'id' => 92,
                'lang' => 'ja',
                'title' => 'png4 ja',
            ),
            28 => 
            array (
                'content_id' => 742,
                'id' => 94,
                'lang' => 'ja',
                'title' => 'Vai',
            ),
            29 => 
            array (
                'content_id' => 744,
                'id' => 96,
                'lang' => 'ja',
                'title' => 'Anh Dao',
            ),
            30 => 
            array (
                'content_id' => 746,
                'id' => 97,
                'lang' => 'ja',
                'title' => 'pdf',
            ),
            31 => 
            array (
                'content_id' => 750,
                'id' => 99,
                'lang' => 'ja',
                'title' => 'hnbbbbbb',
            ),
            32 => 
            array (
                'content_id' => 3568,
                'id' => 137,
                'lang' => 'ja',
                'title' => 'eqweqwe',
            ),
        ));
        
        
    }
}