<?php

use App\Eloquent\Account;
use Illuminate\Database\Seeder;

/**
 * 初期アカウント
 */
class AccountSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // 本番・テスト環境では、パスワードを画面から変更すること！
        Account::create([
            'username' => 'visor',
            'password' => bcrypt('hoge'),
            'name' => 'バイザー',
            'email' => 'sgm@ml.visor.co.jp',
            'role_div' => \Machiyell\Enum\AccountRoleDiv::SUPER_USER
        ]);
    }
}
