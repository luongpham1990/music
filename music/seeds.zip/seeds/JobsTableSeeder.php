<?php

use Illuminate\Database\Seeder;

class JobsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('jobs')->delete();
        
        \DB::table('jobs')->insert(array (
            0 => 
            array (
                'attempts' => 0,
                'available_at' => 1557115430,
                'created_at' => 1557115430,
                'id' => 54,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:242;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            1 => 
            array (
                'attempts' => 0,
                'available_at' => 1557131429,
                'created_at' => 1557131429,
                'id' => 55,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:244;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            2 => 
            array (
                'attempts' => 0,
                'available_at' => 1557287552,
                'created_at' => 1557287552,
                'id' => 56,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:245;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            3 => 
            array (
                'attempts' => 0,
                'available_at' => 1557288075,
                'created_at' => 1557288075,
                'id' => 57,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:246;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            4 => 
            array (
                'attempts' => 0,
                'available_at' => 1557288447,
                'created_at' => 1557288447,
                'id' => 58,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:247;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            5 => 
            array (
                'attempts' => 0,
                'available_at' => 1557288781,
                'created_at' => 1557288781,
                'id' => 59,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:248;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            6 => 
            array (
                'attempts' => 0,
                'available_at' => 1557289169,
                'created_at' => 1557289169,
                'id' => 60,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:249;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            7 => 
            array (
                'attempts' => 0,
                'available_at' => 1557289579,
                'created_at' => 1557289579,
                'id' => 61,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:250;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            8 => 
            array (
                'attempts' => 0,
                'available_at' => 1557289634,
                'created_at' => 1557289634,
                'id' => 62,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:251;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            9 => 
            array (
                'attempts' => 0,
                'available_at' => 1557373833,
                'created_at' => 1557373833,
                'id' => 63,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:252;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            10 => 
            array (
                'attempts' => 0,
                'available_at' => 1557373931,
                'created_at' => 1557373931,
                'id' => 64,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:253;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            11 => 
            array (
                'attempts' => 0,
                'available_at' => 1557829805,
                'created_at' => 1557829805,
                'id' => 65,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:265;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            12 => 
            array (
                'attempts' => 0,
                'available_at' => 1557886447,
                'created_at' => 1557886447,
                'id' => 66,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:266;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            13 => 
            array (
                'attempts' => 0,
                'available_at' => 1557888666,
                'created_at' => 1557888666,
                'id' => 67,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:267;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            14 => 
            array (
                'attempts' => 0,
                'available_at' => 1557888666,
                'created_at' => 1557888666,
                'id' => 68,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:268;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            15 => 
            array (
                'attempts' => 0,
                'available_at' => 1557888667,
                'created_at' => 1557888667,
                'id' => 69,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:269;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            16 => 
            array (
                'attempts' => 0,
                'available_at' => 1557902707,
                'created_at' => 1557902707,
                'id' => 70,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:270;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            17 => 
            array (
                'attempts' => 0,
                'available_at' => 1557903609,
                'created_at' => 1557903609,
                'id' => 71,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:271;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            18 => 
            array (
                'attempts' => 0,
                'available_at' => 1557912012,
                'created_at' => 1557912012,
                'id' => 72,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:279;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            19 => 
            array (
                'attempts' => 0,
                'available_at' => 1557912909,
                'created_at' => 1557912909,
                'id' => 73,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:280;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            20 => 
            array (
                'attempts' => 0,
                'available_at' => 1557912910,
                'created_at' => 1557912910,
                'id' => 74,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:281;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            21 => 
            array (
                'attempts' => 0,
                'available_at' => 1558406835,
                'created_at' => 1558406835,
                'id' => 75,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:469;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            22 => 
            array (
                'attempts' => 0,
                'available_at' => 1558505948,
                'created_at' => 1558505948,
                'id' => 76,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:474;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            23 => 
            array (
                'attempts' => 0,
                'available_at' => 1558577096,
                'created_at' => 1558577096,
                'id' => 77,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:475;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            24 => 
            array (
                'attempts' => 0,
                'available_at' => 1558664837,
                'created_at' => 1558664837,
                'id' => 78,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:481;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            25 => 
            array (
                'attempts' => 0,
                'available_at' => 1558664872,
                'created_at' => 1558664872,
                'id' => 79,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:482;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            26 => 
            array (
                'attempts' => 0,
                'available_at' => 1558664909,
                'created_at' => 1558664909,
                'id' => 80,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:483;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            27 => 
            array (
                'attempts' => 0,
                'available_at' => 1558664977,
                'created_at' => 1558664977,
                'id' => 81,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:484;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            28 => 
            array (
                'attempts' => 0,
                'available_at' => 1558665479,
                'created_at' => 1558665479,
                'id' => 82,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:485;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            29 => 
            array (
                'attempts' => 0,
                'available_at' => 1558669224,
                'created_at' => 1558669224,
                'id' => 83,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:487;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            30 => 
            array (
                'attempts' => 0,
                'available_at' => 1558669303,
                'created_at' => 1558669303,
                'id' => 84,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:488;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            31 => 
            array (
                'attempts' => 0,
                'available_at' => 1558681677,
                'created_at' => 1558681677,
                'id' => 85,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:518;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            32 => 
            array (
                'attempts' => 0,
                'available_at' => 1558683790,
                'created_at' => 1558683790,
                'id' => 86,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:535;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            33 => 
            array (
                'attempts' => 0,
                'available_at' => 1558683927,
                'created_at' => 1558683927,
                'id' => 87,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:536;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            34 => 
            array (
                'attempts' => 0,
                'available_at' => 1558686379,
                'created_at' => 1558686379,
                'id' => 88,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:537;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            35 => 
            array (
                'attempts' => 0,
                'available_at' => 1558686727,
                'created_at' => 1558686727,
                'id' => 89,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:538;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            36 => 
            array (
                'attempts' => 0,
                'available_at' => 1558687034,
                'created_at' => 1558687034,
                'id' => 90,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:539;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            37 => 
            array (
                'attempts' => 0,
                'available_at' => 1558687292,
                'created_at' => 1558687292,
                'id' => 91,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:540;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            38 => 
            array (
                'attempts' => 0,
                'available_at' => 1558688340,
                'created_at' => 1558688340,
                'id' => 92,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:543;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            39 => 
            array (
                'attempts' => 0,
                'available_at' => 1559006676,
                'created_at' => 1559006676,
                'id' => 93,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:592;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            40 => 
            array (
                'attempts' => 0,
                'available_at' => 1559007142,
                'created_at' => 1559007142,
                'id' => 94,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:593;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            41 => 
            array (
                'attempts' => 0,
                'available_at' => 1559007739,
                'created_at' => 1559007739,
                'id' => 95,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:594;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            42 => 
            array (
                'attempts' => 0,
                'available_at' => 1559008268,
                'created_at' => 1559008268,
                'id' => 96,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:595;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            43 => 
            array (
                'attempts' => 0,
                'available_at' => 1559014750,
                'created_at' => 1559014750,
                'id' => 97,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:596;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            44 => 
            array (
                'attempts' => 0,
                'available_at' => 1559023913,
                'created_at' => 1559023913,
                'id' => 98,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:597;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            45 => 
            array (
                'attempts' => 0,
                'available_at' => 1559039612,
                'created_at' => 1559039612,
                'id' => 99,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:690;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            46 => 
            array (
                'attempts' => 0,
                'available_at' => 1559122039,
                'created_at' => 1559122039,
                'id' => 100,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:692;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            47 => 
            array (
                'attempts' => 0,
                'available_at' => 1559296776,
                'created_at' => 1559296776,
                'id' => 101,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:727;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            48 => 
            array (
                'attempts' => 0,
                'available_at' => 1559574310,
                'created_at' => 1559574310,
                'id' => 102,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:735;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            49 => 
            array (
                'attempts' => 0,
                'available_at' => 1559620510,
                'created_at' => 1559620510,
                'id' => 103,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:736;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            50 => 
            array (
                'attempts' => 0,
                'available_at' => 1559625007,
                'created_at' => 1559625007,
                'id' => 104,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:737;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            51 => 
            array (
                'attempts' => 0,
                'available_at' => 1559720708,
                'created_at' => 1559720708,
                'id' => 105,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:738;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            52 => 
            array (
                'attempts' => 0,
                'available_at' => 1559720710,
                'created_at' => 1559720710,
                'id' => 106,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:739;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            53 => 
            array (
                'attempts' => 0,
                'available_at' => 1559720712,
                'created_at' => 1559720712,
                'id' => 107,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:740;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            54 => 
            array (
                'attempts' => 0,
                'available_at' => 1559748307,
                'created_at' => 1559748307,
                'id' => 108,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:741;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            55 => 
            array (
                'attempts' => 0,
                'available_at' => 1559756708,
                'created_at' => 1559756708,
                'id' => 109,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:742;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
            56 => 
            array (
                'attempts' => 0,
                'available_at' => 1559835608,
                'created_at' => 1559835608,
                'id' => 110,
                'payload' => '{"displayName":"App\\\\Jobs\\\\PushNotificationJob","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":1,"timeout":null,"timeoutAt":null,"data":{"commandName":"App\\\\Jobs\\\\PushNotificationJob","command":"O:28:\\"App\\\\Jobs\\\\PushNotificationJob\\":11:{s:5:\\"tries\\";i:1;s:55:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000push_notification_service\\";O:56:\\"Machiyell\\\\Domain\\\\Common\\\\Services\\\\PushNotificationService\\":0:{}s:15:\\"notification_id\\";i:743;s:6:\\"\\u0000*\\u0000job\\";N;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:5:\\"delay\\";N;s:7:\\"chained\\";a:0:{}s:41:\\"\\u0000App\\\\Jobs\\\\PushNotificationJob\\u0000locked_name\\";N;}"}}',
                'queue' => 'default',
                'reserved_at' => NULL,
            ),
        ));
        
        
    }
}