<?php

use Illuminate\Database\Seeder;

class MapDataGroupsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('map_data_groups')->delete();
        
        \DB::table('map_data_groups')->insert(array (
            0 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => NULL,
                'icon_id' => 55,
                'id' => 1,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Điểm 1',
                'position' => 8,
                'updated_at' => NULL,
            ),
            1 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 17:56:38',
                'icon_id' => 55,
                'id' => 2,
                'init_display' => 0,
                'map_data_div' => 3,
                'name' => 'Polygon 1',
                'position' => 1,
                'updated_at' => '2019-02-25 17:56:38',
            ),
            2 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 17:56:53',
                'icon_id' => 51,
                'id' => 3,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Điểm 1',
                'position' => 2,
                'updated_at' => '2019-02-25 17:56:53',
            ),
            3 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 17:57:45',
                'icon_id' => 58,
                'id' => 4,
                'init_display' => 0,
                'map_data_div' => 2,
                'name' => 'Đường',
                'position' => 3,
                'updated_at' => '2019-02-26 16:00:13',
            ),
            4 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 17:58:48',
                'icon_id' => 58,
                'id' => 5,
                'init_display' => 0,
                'map_data_div' => 3,
                'name' => 'Polygon',
                'position' => 4,
                'updated_at' => '2019-02-26 16:30:08',
            ),
            5 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 17:59:18',
                'icon_id' => 59,
                'id' => 6,
                'init_display' => 0,
                'map_data_div' => 3,
                'name' => 'Polygon 2',
                'position' => 5,
                'updated_at' => '2019-02-25 17:59:18',
            ),
            6 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 18:11:28',
                'icon_id' => 60,
                'id' => 8,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Điểm 5',
                'position' => 6,
                'updated_at' => '2019-02-25 18:52:34',
            ),
            7 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 1,
                'created_at' => '2019-02-25 19:25:53',
                'icon_id' => 55,
                'id' => 9,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => '音声再生」アイコンは、現状では動作しない音声再生',
                'position' => 7,
                'updated_at' => '2019-02-26 16:35:07',
            ),
            8 => 
            array (
                'base_color_code' => '#ffaf01',
                'client_id' => 199,
                'created_at' => '2019-03-11 17:38:52',
                'icon_id' => 88,
                'id' => 10,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Diem',
                'position' => 2,
                'updated_at' => '2019-05-31 10:22:00',
            ),
            9 => 
            array (
                'base_color_code' => '#fffc03',
                'client_id' => 199,
                'created_at' => '2019-03-11 17:39:31',
                'icon_id' => 89,
                'id' => 11,
                'init_display' => 0,
                'map_data_div' => 2,
                'name' => 'Duong',
                'position' => 1,
                'updated_at' => '2019-05-31 10:22:00',
            ),
            10 => 
            array (
                'base_color_code' => '#68447f',
                'client_id' => 199,
                'created_at' => '2019-03-11 17:41:57',
                'icon_id' => 90,
                'id' => 12,
                'init_display' => 0,
                'map_data_div' => 3,
                'name' => 'Polygon',
                'position' => 3,
                'updated_at' => '2019-06-05 18:33:26',
            ),
            11 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 202,
                'created_at' => '2019-04-09 18:47:39',
                'icon_id' => 106,
                'id' => 13,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Nhom Diem 1',
                'position' => 1,
                'updated_at' => '2019-04-09 18:47:39',
            ),
            12 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 202,
                'created_at' => '2019-04-09 18:47:55',
                'icon_id' => 107,
                'id' => 14,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Nhom diem 2',
                'position' => 2,
                'updated_at' => '2019-04-09 18:47:55',
            ),
            13 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 202,
                'created_at' => '2019-04-09 19:03:42',
                'icon_id' => 111,
                'id' => 15,
                'init_display' => 0,
                'map_data_div' => 3,
                'name' => 'Nhom Polygol',
                'position' => 3,
                'updated_at' => '2019-04-09 19:03:42',
            ),
            14 => 
            array (
                'base_color_code' => '#68447f',
                'client_id' => 199,
                'created_at' => '2019-04-11 11:52:20',
                'icon_id' => 87,
                'id' => 16,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Loai Diem 2',
                'position' => 4,
                'updated_at' => '2019-04-11 12:00:43',
            ),
            15 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 199,
                'created_at' => '2019-04-11 12:01:18',
                'icon_id' => 88,
                'id' => 17,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Loai diem 3',
                'position' => 5,
                'updated_at' => '2019-04-23 15:25:08',
            ),
            16 => 
            array (
                'base_color_code' => '#e03d72',
                'client_id' => 199,
                'created_at' => '2019-04-11 12:01:45',
                'icon_id' => 89,
                'id' => 18,
                'init_display' => 1,
                'map_data_div' => 2,
                'name' => 'Loai Duong 2',
                'position' => 6,
                'updated_at' => '2019-05-15 12:57:51',
            ),
            17 => 
            array (
                'base_color_code' => '#bbea66',
                'client_id' => 199,
                'created_at' => '2019-04-11 12:02:10',
                'icon_id' => 90,
                'id' => 19,
                'init_display' => 1,
                'map_data_div' => 3,
                'name' => 'Loai Polygol 2',
                'position' => 7,
                'updated_at' => '2019-04-23 16:32:52',
            ),
            18 => 
            array (
                'base_color_code' => '#ffaf01',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:45:11',
                'icon_id' => 119,
                'id' => 20,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Benh Vien',
                'position' => 8,
                'updated_at' => '2019-04-25 13:47:02',
            ),
            19 => 
            array (
                'base_color_code' => '#27601b',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:45:59',
                'icon_id' => 131,
                'id' => 21,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Truong Hoc',
                'position' => 9,
                'updated_at' => '2019-04-25 10:31:05',
            ),
            20 => 
            array (
                'base_color_code' => '#ff6201',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:46:27',
                'icon_id' => 118,
                'id' => 22,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Tram Xang',
                'position' => 10,
                'updated_at' => '2019-04-12 15:46:27',
            ),
            21 => 
            array (
                'base_color_code' => '#a94f7a',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:49:50',
                'icon_id' => 121,
                'id' => 23,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Nguon nuoc',
                'position' => 11,
                'updated_at' => '2019-04-12 15:49:50',
            ),
            22 => 
            array (
                'base_color_code' => '#148ed0',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:50:24',
                'icon_id' => 122,
                'id' => 24,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Tu Vien',
                'position' => 12,
                'updated_at' => '2019-04-17 11:12:57',
            ),
            23 => 
            array (
                'base_color_code' => '#fff245',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:50:40',
                'icon_id' => 123,
                'id' => 25,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Noi Lanh Nan',
                'position' => 13,
                'updated_at' => '2019-04-23 15:26:33',
            ),
            24 => 
            array (
                'base_color_code' => '#fa5eaf',
                'client_id' => 199,
                'created_at' => '2019-04-12 15:54:14',
                'icon_id' => 120,
                'id' => 26,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Co so so tan',
                'position' => 14,
                'updated_at' => '2019-04-23 15:59:23',
            ),
            25 => 
            array (
                'base_color_code' => '#eb6119',
                'client_id' => 199,
                'created_at' => '2019-04-17 10:56:36',
                'icon_id' => 133,
                'id' => 27,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Nha Thuoc',
                'position' => 15,
                'updated_at' => '2019-04-17 10:56:36',
            ),
            26 => 
            array (
                'base_color_code' => '#ffaf01',
                'client_id' => 199,
                'created_at' => '2019-04-24 17:49:49',
                'icon_id' => 134,
                'id' => 28,
                'init_display' => 0,
                'map_data_div' => 1,
                'name' => 'Test map2',
                'position' => 16,
                'updated_at' => '2019-05-15 13:19:27',
            ),
            27 => 
            array (
                'base_color_code' => '#36df57',
                'client_id' => 199,
                'created_at' => '2019-05-15 12:30:35',
                'icon_id' => 90,
                'id' => 29,
                'init_display' => 1,
                'map_data_div' => 2,
                'name' => 'Duong Tinh yeu',
                'position' => 17,
                'updated_at' => '2019-05-15 12:30:35',
            ),
            28 => 
            array (
                'base_color_code' => '#fbc02d',
                'client_id' => 199,
                'created_at' => '2019-05-15 13:05:16',
                'icon_id' => 89,
                'id' => 30,
                'init_display' => 1,
                'map_data_div' => 2,
                'name' => 'Duong Di Hoc',
                'position' => 18,
                'updated_at' => '2019-05-15 13:10:30',
            ),
            29 => 
            array (
                'base_color_code' => '#59719d',
                'client_id' => 199,
                'created_at' => '2019-05-28 13:41:03',
                'icon_id' => 133,
                'id' => 31,
                'init_display' => 1,
                'map_data_div' => 1,
                'name' => 'Mau test icon',
                'position' => 19,
                'updated_at' => '2019-05-28 13:41:03',
            ),
            30 => 
            array (
                'base_color_code' => '#3097d1',
                'client_id' => 199,
                'created_at' => '2019-06-05 16:49:30',
                'icon_id' => 90,
                'id' => 33,
                'init_display' => 1,
                'map_data_div' => 3,
                'name' => 'Polygol Test End',
                'position' => 20,
                'updated_at' => '2019-06-05 18:33:43',
            ),
        ));
        
        
    }
}