<?php

use Illuminate\Database\Seeder;

class TranslationReplacementTemplatesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('translation_replacement_templates')->delete();
        
        
        
    }
}