<?php

use Illuminate\Database\Seeder;

class TriggerTagsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('trigger_tags')->delete();
        
        \DB::table('trigger_tags')->insert(array (
            0 => 
            array (
                'auto_import_trigger_id' => 116,
                'tag_id' => 1,
            ),
            1 => 
            array (
                'auto_import_trigger_id' => 116,
                'tag_id' => 2,
            ),
            2 => 
            array (
                'auto_import_trigger_id' => 116,
                'tag_id' => 5,
            ),
            3 => 
            array (
                'auto_import_trigger_id' => 116,
                'tag_id' => 6,
            ),
            4 => 
            array (
                'auto_import_trigger_id' => 116,
                'tag_id' => 7,
            ),
            5 => 
            array (
                'auto_import_trigger_id' => 117,
                'tag_id' => 5,
            ),
            6 => 
            array (
                'auto_import_trigger_id' => 117,
                'tag_id' => 6,
            ),
            7 => 
            array (
                'auto_import_trigger_id' => 117,
                'tag_id' => 7,
            ),
            8 => 
            array (
                'auto_import_trigger_id' => 121,
                'tag_id' => 3,
            ),
            9 => 
            array (
                'auto_import_trigger_id' => 121,
                'tag_id' => 4,
            ),
            10 => 
            array (
                'auto_import_trigger_id' => 122,
                'tag_id' => 3,
            ),
            11 => 
            array (
                'auto_import_trigger_id' => 123,
                'tag_id' => 5,
            ),
            12 => 
            array (
                'auto_import_trigger_id' => 124,
                'tag_id' => 2,
            ),
            13 => 
            array (
                'auto_import_trigger_id' => 124,
                'tag_id' => 1,
            ),
            14 => 
            array (
                'auto_import_trigger_id' => 125,
                'tag_id' => 2,
            ),
            15 => 
            array (
                'auto_import_trigger_id' => 125,
                'tag_id' => 1,
            ),
            16 => 
            array (
                'auto_import_trigger_id' => 127,
                'tag_id' => 34,
            ),
            17 => 
            array (
                'auto_import_trigger_id' => 127,
                'tag_id' => 33,
            ),
            18 => 
            array (
                'auto_import_trigger_id' => 128,
                'tag_id' => 32,
            ),
            19 => 
            array (
                'auto_import_trigger_id' => 128,
                'tag_id' => 31,
            ),
            20 => 
            array (
                'auto_import_trigger_id' => 129,
                'tag_id' => 34,
            ),
            21 => 
            array (
                'auto_import_trigger_id' => 131,
                'tag_id' => 34,
            ),
            22 => 
            array (
                'auto_import_trigger_id' => 131,
                'tag_id' => 33,
            ),
            23 => 
            array (
                'auto_import_trigger_id' => 131,
                'tag_id' => 32,
            ),
            24 => 
            array (
                'auto_import_trigger_id' => 131,
                'tag_id' => 31,
            ),
            25 => 
            array (
                'auto_import_trigger_id' => 132,
                'tag_id' => 33,
            ),
            26 => 
            array (
                'auto_import_trigger_id' => 132,
                'tag_id' => 32,
            ),
            27 => 
            array (
                'auto_import_trigger_id' => 132,
                'tag_id' => 31,
            ),
            28 => 
            array (
                'auto_import_trigger_id' => 133,
                'tag_id' => 33,
            ),
            29 => 
            array (
                'auto_import_trigger_id' => 133,
                'tag_id' => 32,
            ),
            30 => 
            array (
                'auto_import_trigger_id' => 214,
                'tag_id' => 94,
            ),
            31 => 
            array (
                'auto_import_trigger_id' => 214,
                'tag_id' => 93,
            ),
            32 => 
            array (
                'auto_import_trigger_id' => 214,
                'tag_id' => 75,
            ),
            33 => 
            array (
                'auto_import_trigger_id' => 214,
                'tag_id' => 76,
            ),
            34 => 
            array (
                'auto_import_trigger_id' => 214,
                'tag_id' => 78,
            ),
            35 => 
            array (
                'auto_import_trigger_id' => 215,
                'tag_id' => 94,
            ),
            36 => 
            array (
                'auto_import_trigger_id' => 215,
                'tag_id' => 93,
            ),
            37 => 
            array (
                'auto_import_trigger_id' => 215,
                'tag_id' => 75,
            ),
            38 => 
            array (
                'auto_import_trigger_id' => 215,
                'tag_id' => 76,
            ),
            39 => 
            array (
                'auto_import_trigger_id' => 215,
                'tag_id' => 78,
            ),
            40 => 
            array (
                'auto_import_trigger_id' => 216,
                'tag_id' => 94,
            ),
            41 => 
            array (
                'auto_import_trigger_id' => 216,
                'tag_id' => 93,
            ),
            42 => 
            array (
                'auto_import_trigger_id' => 216,
                'tag_id' => 75,
            ),
            43 => 
            array (
                'auto_import_trigger_id' => 217,
                'tag_id' => 94,
            ),
            44 => 
            array (
                'auto_import_trigger_id' => 217,
                'tag_id' => 93,
            ),
            45 => 
            array (
                'auto_import_trigger_id' => 217,
                'tag_id' => 75,
            ),
            46 => 
            array (
                'auto_import_trigger_id' => 217,
                'tag_id' => 76,
            ),
            47 => 
            array (
                'auto_import_trigger_id' => 217,
                'tag_id' => 78,
            ),
            48 => 
            array (
                'auto_import_trigger_id' => 218,
                'tag_id' => 94,
            ),
            49 => 
            array (
                'auto_import_trigger_id' => 218,
                'tag_id' => 93,
            ),
            50 => 
            array (
                'auto_import_trigger_id' => 218,
                'tag_id' => 75,
            ),
            51 => 
            array (
                'auto_import_trigger_id' => 218,
                'tag_id' => 76,
            ),
        ));
        
        
    }
}