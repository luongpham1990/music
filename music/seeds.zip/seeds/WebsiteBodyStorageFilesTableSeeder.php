<?php

use Illuminate\Database\Seeder;

class WebsiteBodyStorageFilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('website_body_storage_files')->delete();
        
        \DB::table('website_body_storage_files')->insert(array (
            0 => 
            array (
                'id' => 23,
                'lang' => 'es',
                'storage_file_id' => 745,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            1 => 
            array (
                'id' => 24,
                'lang' => 'es',
                'storage_file_id' => 746,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            2 => 
            array (
                'id' => 25,
                'lang' => 'es',
                'storage_file_id' => 747,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            3 => 
            array (
                'id' => 26,
                'lang' => 'ja_easy',
                'storage_file_id' => 748,
                'website_attachment_div' => 2,
                'website_id' => 8,
            ),
            4 => 
            array (
                'id' => 27,
                'lang' => 'ja_easy',
                'storage_file_id' => 749,
                'website_attachment_div' => 1,
                'website_id' => 8,
            ),
            5 => 
            array (
                'id' => 28,
                'lang' => 'ja_easy',
                'storage_file_id' => 750,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            6 => 
            array (
                'id' => 29,
                'lang' => 'ja_easy',
                'storage_file_id' => 751,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            7 => 
            array (
                'id' => 30,
                'lang' => 'ja_easy',
                'storage_file_id' => 752,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            8 => 
            array (
                'id' => 31,
                'lang' => 'ja_easy',
                'storage_file_id' => 753,
                'website_attachment_div' => 0,
                'website_id' => 8,
            ),
            9 => 
            array (
                'id' => 39,
                'lang' => 'zh',
                'storage_file_id' => 831,
                'website_attachment_div' => 2,
                'website_id' => 12,
            ),
            10 => 
            array (
                'id' => 40,
                'lang' => 'zh',
                'storage_file_id' => 832,
                'website_attachment_div' => 1,
                'website_id' => 12,
            ),
            11 => 
            array (
                'id' => 41,
                'lang' => 'zh',
                'storage_file_id' => 833,
                'website_attachment_div' => 0,
                'website_id' => 12,
            ),
            12 => 
            array (
                'id' => 42,
                'lang' => 'zh',
                'storage_file_id' => 834,
                'website_attachment_div' => 0,
                'website_id' => 12,
            ),
            13 => 
            array (
                'id' => 43,
                'lang' => 'ja_easy',
                'storage_file_id' => 835,
                'website_attachment_div' => 2,
                'website_id' => 12,
            ),
            14 => 
            array (
                'id' => 44,
                'lang' => 'ko',
                'storage_file_id' => 836,
                'website_attachment_div' => 1,
                'website_id' => 12,
            ),
            15 => 
            array (
                'id' => 48,
                'lang' => 'en',
                'storage_file_id' => 886,
                'website_attachment_div' => 2,
                'website_id' => 12,
            ),
            16 => 
            array (
                'id' => 49,
                'lang' => 'es',
                'storage_file_id' => 887,
                'website_attachment_div' => 2,
                'website_id' => 12,
            ),
            17 => 
            array (
                'id' => 56,
                'lang' => 'es',
                'storage_file_id' => 931,
                'website_attachment_div' => 2,
                'website_id' => 18,
            ),
            18 => 
            array (
                'id' => 57,
                'lang' => 'es',
                'storage_file_id' => 932,
                'website_attachment_div' => 1,
                'website_id' => 18,
            ),
            19 => 
            array (
                'id' => 59,
                'lang' => 'es',
                'storage_file_id' => 934,
                'website_attachment_div' => 0,
                'website_id' => 18,
            ),
            20 => 
            array (
                'id' => 60,
                'lang' => 'es',
                'storage_file_id' => 935,
                'website_attachment_div' => 0,
                'website_id' => 18,
            ),
            21 => 
            array (
                'id' => 61,
                'lang' => 'es',
                'storage_file_id' => 936,
                'website_attachment_div' => 0,
                'website_id' => 18,
            ),
            22 => 
            array (
                'id' => 62,
                'lang' => 'es',
                'storage_file_id' => 937,
                'website_attachment_div' => 0,
                'website_id' => 18,
            ),
            23 => 
            array (
                'id' => 63,
                'lang' => 'es',
                'storage_file_id' => 938,
                'website_attachment_div' => 0,
                'website_id' => 18,
            ),
            24 => 
            array (
                'id' => 64,
                'lang' => 'es',
                'storage_file_id' => 939,
                'website_attachment_div' => 0,
                'website_id' => 18,
            ),
            25 => 
            array (
                'id' => 65,
                'lang' => 'es',
                'storage_file_id' => 944,
                'website_attachment_div' => 1,
                'website_id' => 12,
            ),
            26 => 
            array (
                'id' => 66,
                'lang' => 'es',
                'storage_file_id' => 945,
                'website_attachment_div' => 0,
                'website_id' => 12,
            ),
            27 => 
            array (
                'id' => 67,
                'lang' => 'es',
                'storage_file_id' => 946,
                'website_attachment_div' => 0,
                'website_id' => 12,
            ),
            28 => 
            array (
                'id' => 68,
                'lang' => 'en',
                'storage_file_id' => 1078,
                'website_attachment_div' => 2,
                'website_id' => 20,
            ),
            29 => 
            array (
                'id' => 69,
                'lang' => 'en',
                'storage_file_id' => 1079,
                'website_attachment_div' => 1,
                'website_id' => 20,
            ),
            30 => 
            array (
                'id' => 70,
                'lang' => 'en',
                'storage_file_id' => 1080,
                'website_attachment_div' => 0,
                'website_id' => 20,
            ),
            31 => 
            array (
                'id' => 71,
                'lang' => 'en',
                'storage_file_id' => 1081,
                'website_attachment_div' => 0,
                'website_id' => 20,
            ),
            32 => 
            array (
                'id' => 72,
                'lang' => 'ja',
                'storage_file_id' => 1165,
                'website_attachment_div' => 2,
                'website_id' => 22,
            ),
            33 => 
            array (
                'id' => 73,
                'lang' => 'ja',
                'storage_file_id' => 1166,
                'website_attachment_div' => 1,
                'website_id' => 22,
            ),
            34 => 
            array (
                'id' => 76,
                'lang' => 'en',
                'storage_file_id' => 1169,
                'website_attachment_div' => 2,
                'website_id' => 22,
            ),
            35 => 
            array (
                'id' => 82,
                'lang' => 'en',
                'storage_file_id' => 1176,
                'website_attachment_div' => 2,
                'website_id' => 23,
            ),
            36 => 
            array (
                'id' => 83,
                'lang' => 'en',
                'storage_file_id' => 1177,
                'website_attachment_div' => 1,
                'website_id' => 23,
            ),
            37 => 
            array (
                'id' => 94,
                'lang' => 'es',
                'storage_file_id' => 1188,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            38 => 
            array (
                'id' => 95,
                'lang' => 'es',
                'storage_file_id' => 1189,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            39 => 
            array (
                'id' => 96,
                'lang' => 'es',
                'storage_file_id' => 1190,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            40 => 
            array (
                'id' => 97,
                'lang' => 'es',
                'storage_file_id' => 1191,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            41 => 
            array (
                'id' => 98,
                'lang' => 'es',
                'storage_file_id' => 1192,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            42 => 
            array (
                'id' => 99,
                'lang' => 'es',
                'storage_file_id' => 1193,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            43 => 
            array (
                'id' => 100,
                'lang' => 'en',
                'storage_file_id' => 1194,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            44 => 
            array (
                'id' => 101,
                'lang' => 'en',
                'storage_file_id' => 1195,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            45 => 
            array (
                'id' => 102,
                'lang' => 'en',
                'storage_file_id' => 1196,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            46 => 
            array (
                'id' => 103,
                'lang' => 'en',
                'storage_file_id' => 1197,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            47 => 
            array (
                'id' => 104,
                'lang' => 'en',
                'storage_file_id' => 1198,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            48 => 
            array (
                'id' => 105,
                'lang' => 'en',
                'storage_file_id' => 1199,
                'website_attachment_div' => 0,
                'website_id' => 23,
            ),
            49 => 
            array (
                'id' => 111,
                'lang' => 'ja',
                'storage_file_id' => 1210,
                'website_attachment_div' => 2,
                'website_id' => 25,
            ),
            50 => 
            array (
                'id' => 112,
                'lang' => 'ja',
                'storage_file_id' => 1211,
                'website_attachment_div' => 1,
                'website_id' => 25,
            ),
            51 => 
            array (
                'id' => 113,
                'lang' => 'ja',
                'storage_file_id' => 1212,
                'website_attachment_div' => 0,
                'website_id' => 25,
            ),
            52 => 
            array (
                'id' => 114,
                'lang' => 'ja',
                'storage_file_id' => 1213,
                'website_attachment_div' => 0,
                'website_id' => 25,
            ),
            53 => 
            array (
                'id' => 115,
                'lang' => 'en',
                'storage_file_id' => 1221,
                'website_attachment_div' => 2,
                'website_id' => 25,
            ),
            54 => 
            array (
                'id' => 116,
                'lang' => 'en',
                'storage_file_id' => 1222,
                'website_attachment_div' => 1,
                'website_id' => 25,
            ),
            55 => 
            array (
                'id' => 117,
                'lang' => 'en',
                'storage_file_id' => 1223,
                'website_attachment_div' => 0,
                'website_id' => 25,
            ),
            56 => 
            array (
                'id' => 118,
                'lang' => 'en',
                'storage_file_id' => 1224,
                'website_attachment_div' => 0,
                'website_id' => 25,
            ),
            57 => 
            array (
                'id' => 119,
                'lang' => 'en',
                'storage_file_id' => 1225,
                'website_attachment_div' => 0,
                'website_id' => 25,
            ),
            58 => 
            array (
                'id' => 120,
                'lang' => 'ko',
                'storage_file_id' => 1226,
                'website_attachment_div' => 2,
                'website_id' => 25,
            ),
            59 => 
            array (
                'id' => 121,
                'lang' => 'ko',
                'storage_file_id' => 1227,
                'website_attachment_div' => 1,
                'website_id' => 25,
            ),
            60 => 
            array (
                'id' => 122,
                'lang' => 'ko',
                'storage_file_id' => 1228,
                'website_attachment_div' => 0,
                'website_id' => 25,
            ),
            61 => 
            array (
                'id' => 123,
                'lang' => 'ja',
                'storage_file_id' => 1230,
                'website_attachment_div' => 2,
                'website_id' => 26,
            ),
            62 => 
            array (
                'id' => 124,
                'lang' => 'ja',
                'storage_file_id' => 1231,
                'website_attachment_div' => 1,
                'website_id' => 26,
            ),
            63 => 
            array (
                'id' => 125,
                'lang' => 'ja',
                'storage_file_id' => 1232,
                'website_attachment_div' => 0,
                'website_id' => 26,
            ),
            64 => 
            array (
                'id' => 126,
                'lang' => 'ja',
                'storage_file_id' => 1233,
                'website_attachment_div' => 0,
                'website_id' => 26,
            ),
            65 => 
            array (
                'id' => 131,
                'lang' => 'en',
                'storage_file_id' => 1245,
                'website_attachment_div' => 2,
                'website_id' => 26,
            ),
            66 => 
            array (
                'id' => 132,
                'lang' => 'en',
                'storage_file_id' => 1246,
                'website_attachment_div' => 1,
                'website_id' => 26,
            ),
            67 => 
            array (
                'id' => 135,
                'lang' => 'en',
                'storage_file_id' => 1273,
                'website_attachment_div' => 0,
                'website_id' => 27,
            ),
            68 => 
            array (
                'id' => 136,
                'lang' => 'en',
                'storage_file_id' => 1274,
                'website_attachment_div' => 0,
                'website_id' => 27,
            ),
            69 => 
            array (
                'id' => 137,
                'lang' => 'en',
                'storage_file_id' => 1275,
                'website_attachment_div' => 0,
                'website_id' => 27,
            ),
            70 => 
            array (
                'id' => 138,
                'lang' => 'ko',
                'storage_file_id' => 1276,
                'website_attachment_div' => 0,
                'website_id' => 27,
            ),
            71 => 
            array (
                'id' => 139,
                'lang' => 'ko',
                'storage_file_id' => 1277,
                'website_attachment_div' => 0,
                'website_id' => 27,
            ),
            72 => 
            array (
                'id' => 140,
                'lang' => 'en',
                'storage_file_id' => 1280,
                'website_attachment_div' => 0,
                'website_id' => 26,
            ),
            73 => 
            array (
                'id' => 146,
                'lang' => 'ko',
                'storage_file_id' => 1323,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            74 => 
            array (
                'id' => 147,
                'lang' => 'ko',
                'storage_file_id' => 1324,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            75 => 
            array (
                'id' => 148,
                'lang' => 'ko',
                'storage_file_id' => 1325,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            76 => 
            array (
                'id' => 154,
                'lang' => 'ja',
                'storage_file_id' => 1331,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            77 => 
            array (
                'id' => 155,
                'lang' => 'ja',
                'storage_file_id' => 1332,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            78 => 
            array (
                'id' => 156,
                'lang' => 'en',
                'storage_file_id' => 1333,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            79 => 
            array (
                'id' => 157,
                'lang' => 'en',
                'storage_file_id' => 1334,
                'website_attachment_div' => 0,
                'website_id' => 22,
            ),
            80 => 
            array (
                'id' => 158,
                'lang' => 'ko',
                'storage_file_id' => 1338,
                'website_attachment_div' => 0,
                'website_id' => 24,
            ),
            81 => 
            array (
                'id' => 159,
                'lang' => 'ko',
                'storage_file_id' => 1339,
                'website_attachment_div' => 0,
                'website_id' => 24,
            ),
            82 => 
            array (
                'id' => 160,
                'lang' => 'en',
                'storage_file_id' => 1340,
                'website_attachment_div' => 0,
                'website_id' => 24,
            ),
            83 => 
            array (
                'id' => 161,
                'lang' => 'ja',
                'storage_file_id' => 1341,
                'website_attachment_div' => 0,
                'website_id' => 24,
            ),
            84 => 
            array (
                'id' => 162,
                'lang' => 'ja',
                'storage_file_id' => 1342,
                'website_attachment_div' => 0,
                'website_id' => 24,
            ),
            85 => 
            array (
                'id' => 163,
                'lang' => 'ja',
                'storage_file_id' => 1348,
                'website_attachment_div' => 0,
                'website_id' => 31,
            ),
            86 => 
            array (
                'id' => 164,
                'lang' => 'ja',
                'storage_file_id' => 1349,
                'website_attachment_div' => 0,
                'website_id' => 31,
            ),
            87 => 
            array (
                'id' => 165,
                'lang' => 'en',
                'storage_file_id' => 1350,
                'website_attachment_div' => 0,
                'website_id' => 31,
            ),
            88 => 
            array (
                'id' => 166,
                'lang' => 'en',
                'storage_file_id' => 1351,
                'website_attachment_div' => 0,
                'website_id' => 31,
            ),
            89 => 
            array (
                'id' => 175,
                'lang' => 'ja',
                'storage_file_id' => 1495,
                'website_attachment_div' => 2,
                'website_id' => 35,
            ),
            90 => 
            array (
                'id' => 176,
                'lang' => 'ja',
                'storage_file_id' => 1496,
                'website_attachment_div' => 1,
                'website_id' => 35,
            ),
            91 => 
            array (
                'id' => 177,
                'lang' => 'ja',
                'storage_file_id' => 1497,
                'website_attachment_div' => 0,
                'website_id' => 35,
            ),
            92 => 
            array (
                'id' => 178,
                'lang' => 'ja',
                'storage_file_id' => 1498,
                'website_attachment_div' => 0,
                'website_id' => 35,
            ),
            93 => 
            array (
                'id' => 179,
                'lang' => 'ja',
                'storage_file_id' => 1499,
                'website_attachment_div' => 0,
                'website_id' => 35,
            ),
            94 => 
            array (
                'id' => 184,
                'lang' => 'ja',
                'storage_file_id' => 2288,
                'website_attachment_div' => 2,
                'website_id' => 36,
            ),
            95 => 
            array (
                'id' => 196,
                'lang' => 'ja',
                'storage_file_id' => 2472,
                'website_attachment_div' => 1,
                'website_id' => 44,
            ),
            96 => 
            array (
                'id' => 197,
                'lang' => 'ko',
                'storage_file_id' => 2473,
                'website_attachment_div' => 1,
                'website_id' => 44,
            ),
            97 => 
            array (
                'id' => 198,
                'lang' => 'en',
                'storage_file_id' => 2474,
                'website_attachment_div' => 1,
                'website_id' => 45,
            ),
            98 => 
            array (
                'id' => 199,
                'lang' => 'ko',
                'storage_file_id' => 2475,
                'website_attachment_div' => 1,
                'website_id' => 45,
            ),
            99 => 
            array (
                'id' => 204,
                'lang' => 'ja',
                'storage_file_id' => 2480,
                'website_attachment_div' => 1,
                'website_id' => 47,
            ),
            100 => 
            array (
                'id' => 205,
                'lang' => 'ko',
                'storage_file_id' => 2481,
                'website_attachment_div' => 1,
                'website_id' => 47,
            ),
            101 => 
            array (
                'id' => 211,
                'lang' => 'en',
                'storage_file_id' => 2503,
                'website_attachment_div' => 2,
                'website_id' => 49,
            ),
            102 => 
            array (
                'id' => 212,
                'lang' => 'en',
                'storage_file_id' => 2504,
                'website_attachment_div' => 1,
                'website_id' => 49,
            ),
            103 => 
            array (
                'id' => 213,
                'lang' => 'en',
                'storage_file_id' => 2533,
                'website_attachment_div' => 1,
                'website_id' => 36,
            ),
            104 => 
            array (
                'id' => 214,
                'lang' => 'ja',
                'storage_file_id' => 2743,
                'website_attachment_div' => 1,
                'website_id' => 51,
            ),
            105 => 
            array (
                'id' => 215,
                'lang' => 'en',
                'storage_file_id' => 2744,
                'website_attachment_div' => 1,
                'website_id' => 51,
            ),
            106 => 
            array (
                'id' => 216,
                'lang' => 'ja',
                'storage_file_id' => 2745,
                'website_attachment_div' => 1,
                'website_id' => 50,
            ),
            107 => 
            array (
                'id' => 217,
                'lang' => 'en',
                'storage_file_id' => 2746,
                'website_attachment_div' => 1,
                'website_id' => 50,
            ),
            108 => 
            array (
                'id' => 218,
                'lang' => 'ja',
                'storage_file_id' => 2761,
                'website_attachment_div' => 1,
                'website_id' => 45,
            ),
            109 => 
            array (
                'id' => 219,
                'lang' => 'ja',
                'storage_file_id' => 3587,
                'website_attachment_div' => 1,
                'website_id' => 36,
            ),
        ));
        
        
    }
}