<?php

use Illuminate\Database\Seeder;

class WeathersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('weathers')->delete();
        
        \DB::table('weathers')->insert(array (
            0 => 
            array (
                'body' => 'body thoi tiet hom nay ja',
                'content_id' => 3187,
                'id' => 24,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'thoi tiet hom nay ja',
                'weather_div' => 2,
            ),
            1 => 
            array (
                'body' => '11111111111111111 ja',
                'content_id' => 3188,
                'id' => 25,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '11111111111111111 ja',
                'weather_div' => 2,
            ),
            2 => 
            array (
                'body' => '222222222222222222 ja',
                'content_id' => 3189,
                'id' => 26,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '22222222222 ja',
                'weather_div' => 4,
            ),
            3 => 
            array (
                'body' => '33333333333 ja',
                'content_id' => 3190,
                'id' => 27,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '33333333333 ja',
                'weather_div' => 4,
            ),
            4 => 
            array (
                'body' => '4444444444444 ja',
                'content_id' => 3191,
                'id' => 28,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '4444444444444 ja',
                'weather_div' => 2,
            ),
            5 => 
            array (
                'body' => '555555 ja',
                'content_id' => 3192,
                'id' => 29,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '555555 ja',
                'weather_div' => 5,
            ),
            6 => 
            array (
                'body' => '7777777 ja',
                'content_id' => 3193,
                'id' => 30,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '7777777 ja',
                'weather_div' => 9,
            ),
            7 => 
            array (
                'body' => '888888888 ja',
                'content_id' => 3194,
                'id' => 31,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '888888888 ja',
                'weather_div' => 3,
            ),
            8 => 
            array (
                'body' => '999999 ja',
                'content_id' => 3195,
                'id' => 32,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '999999 ja',
                'weather_div' => 9,
            ),
            9 => 
            array (
                'body' => '1000000000000 ja',
                'content_id' => 3196,
                'id' => 33,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => '1000000000000 ja',
                'weather_div' => 2,
            ),
            10 => 
            array (
                'body' => 'Muoi Mot ja',
                'content_id' => 3197,
                'id' => 34,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Muoi Mot ja',
                'weather_div' => 4,
            ),
            11 => 
            array (
                'body' => 'Muoi Hai ja',
                'content_id' => 3198,
                'id' => 35,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Muoi Hai ja',
                'weather_div' => 4,
            ),
            12 => 
            array (
                'body' => 'Hom nay troi nang ja',
                'content_id' => 3199,
                'id' => 36,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Hom nay troi nang ja',
                'weather_div' => 4,
            ),
            13 => 
            array (
                'body' => 'Mat qua ja',
                'content_id' => 3200,
                'id' => 37,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Mat qua ja',
                'weather_div' => 3,
            ),
            14 => 
            array (
                'body' => 'Hom nay troi khong mua ja',
                'content_id' => 3201,
                'id' => 38,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Hom nay troi khong mua ja',
                'weather_div' => 4,
            ),
            15 => 
            array (
                'body' => 'Nhiet do giam manh ja',
                'content_id' => 3202,
                'id' => 39,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Nhiet do giam manh ja',
                'weather_div' => 4,
            ),
            16 => 
            array (
                'body' => 'Gio to ja',
                'content_id' => 3203,
                'id' => 40,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Gio to ja',
                'weather_div' => 7,
            ),
            17 => 
            array (
                'body' => 'Troi chuyen nang ja',
                'content_id' => 3204,
                'id' => 41,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Troi chuyen nang ja',
                'weather_div' => 5,
            ),
            18 => 
            array (
                'body' => 'Mua dong dai rac ja',
                'content_id' => 3205,
                'id' => 42,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Mua dong dai rac ja',
                'weather_div' => 3,
            ),
            19 => 
            array (
                'body' => 'nang nong keo dai ja',
                'content_id' => 3206,
                'id' => 43,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'nang nong keo dai ja',
                'weather_div' => 4,
            ),
            20 => 
            array (
                'body' => 'Them nhiet giam manh ja',
                'content_id' => 3207,
                'id' => 44,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Them nhiet giam manh ja',
                'weather_div' => 6,
            ),
            21 => 
            array (
                'body' => 'Sam set ja',
                'content_id' => 3208,
                'id' => 45,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Sam set ja',
                'weather_div' => 5,
            ),
            22 => 
            array (
                'body' => 'Dong Loc keo den ja',
                'content_id' => 3209,
                'id' => 46,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Dong Loc keo den ja',
                'weather_div' => 9,
            ),
            23 => 
            array (
                'body' => 'Nen nhiet tang dan ja',
                'content_id' => 3210,
                'id' => 47,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Nen nhiet tang dan ja',
                'weather_div' => 5,
            ),
            24 => 
            array (
                'body' => 'Sap co mua dong ja',
                'content_id' => 3211,
                'id' => 48,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Sap co mua dong ja',
                'weather_div' => 3,
            ),
            25 => 
            array (
                'body' => 'Mua phun ja',
                'content_id' => 3212,
                'id' => 49,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Mua phun ja',
                'weather_div' => 4,
            ),
            26 => 
            array (
                'body' => 'Gio dong bac ja',
                'content_id' => 3213,
                'id' => 50,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Gio dong bac ja',
                'weather_div' => 4,
            ),
            27 => 
            array (
                'body' => 'Hieu ung nha kinh ja',
                'content_id' => 3214,
                'id' => 51,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Hieu ung nha kinh ja',
                'weather_div' => 3,
            ),
            28 => 
            array (
                'body' => 'Gio lao ja',
                'content_id' => 3215,
                'id' => 52,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Gio lao ja',
                'weather_div' => 3,
            ),
            29 => 
            array (
                'body' => 'Chuyen mua dong rai rac ja',
                'content_id' => 3216,
                'id' => 53,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Chuyen mua dong rai rac ja',
                'weather_div' => 5,
            ),
            30 => 
            array (
                'body' => 'Nong keo dai ja',
                'content_id' => 3217,
                'id' => 54,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Nong keo dai ja',
                'weather_div' => 5,
            ),
            31 => 
            array (
                'body' => 'nang len roi ja',
                'content_id' => 3218,
                'id' => 55,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'nang len roi ja',
                'weather_div' => 3,
            ),
            32 => 
            array (
                'body' => 'Thoi tiet hom nay rat nang',
                'content_id' => 3288,
                'id' => 56,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Thoi tiet hom nay rat nang',
                'weather_div' => 3,
            ),
            33 => 
            array (
                'body' => 'test change type show point 2',
                'content_id' => 3380,
                'id' => 59,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'test change type show point 2',
                'weather_div' => 1,
            ),
            34 => 
            array (
                'body' => 'Hom Nay gio mat qua he he',
                'content_id' => 3381,
                'id' => 60,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Hom Nay gio mat qua',
                'weather_div' => 6,
            ),
            35 => 
            array (
                'body' => 'Troi dep qua ja',
                'content_id' => 3386,
                'id' => 61,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'Troi dep qua ja',
                'weather_div' => 4,
            ),
            36 => 
            array (
                'body' => 'khong chon tag ja',
                'content_id' => 3387,
                'id' => 62,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'khong chon tag ja',
                'weather_div' => 4,
            ),
            37 => 
            array (
                'body' => '0989209053159',
                'content_id' => 3389,
                'id' => 63,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'title' => 'test change type show point 2',
                'weather_div' => 1,
            ),
        ));
        
        
    }
}