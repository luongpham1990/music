<?php

use Illuminate\Database\Seeder;

class NotificationUsersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('notification_users')->delete();
        
        \DB::table('notification_users')->insert(array (
            0 => 
            array (
                'created_at' => '2019-03-04 16:00:11',
                'id' => 1,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'updated_at' => '2019-03-04 16:00:11',
            ),
            1 => 
            array (
                'created_at' => '2019-03-04 16:08:36',
                'id' => 2,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'updated_at' => '2019-03-04 16:08:36',
            ),
            2 => 
            array (
                'created_at' => '2019-03-04 16:01:29',
                'id' => 3,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'updated_at' => '2019-03-04 16:01:29',
            ),
            3 => 
            array (
                'created_at' => '2019-03-04 16:03:03',
                'id' => 4,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'updated_at' => '2019-03-04 16:03:03',
            ),
            4 => 
            array (
                'created_at' => '2019-03-04 16:16:08',
                'id' => 5,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'updated_at' => '2019-03-04 16:16:08',
            ),
            5 => 
            array (
                'created_at' => '2019-03-04 16:16:55',
                'id' => 6,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'updated_at' => '2019-03-04 16:16:55',
            ),
            6 => 
            array (
                'created_at' => '2019-03-04 17:02:07',
                'id' => 7,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385"]',
                'updated_at' => '2019-03-04 17:02:07',
            ),
            7 => 
            array (
                'created_at' => '2019-03-04 17:03:06',
                'id' => 8,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385"]',
                'updated_at' => '2019-03-04 17:03:06',
            ),
            8 => 
            array (
                'created_at' => '2019-03-04 17:04:07',
                'id' => 9,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385"]',
                'updated_at' => '2019-03-04 17:04:07',
            ),
            9 => 
            array (
                'created_at' => '2019-03-04 17:12:10',
                'id' => 10,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'updated_at' => '2019-03-04 17:12:10',
            ),
            10 => 
            array (
                'created_at' => '2019-03-04 17:12:37',
                'id' => 11,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'updated_at' => '2019-03-04 17:12:37',
            ),
            11 => 
            array (
                'created_at' => '2019-03-04 17:13:02',
                'id' => 12,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'updated_at' => '2019-03-04 17:13:02',
            ),
            12 => 
            array (
                'created_at' => '2019-03-04 17:13:36',
                'id' => 13,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'updated_at' => '2019-03-04 17:13:36',
            ),
            13 => 
            array (
                'created_at' => '2019-03-04 17:14:10',
                'id' => 14,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'updated_at' => '2019-03-04 17:14:10',
            ),
            14 => 
            array (
                'created_at' => '2019-03-04 17:15:29',
                'id' => 15,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'updated_at' => '2019-03-04 17:15:29',
            ),
            15 => 
            array (
                'created_at' => '2019-03-04 17:17:46',
                'id' => 16,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:17:46',
            ),
            16 => 
            array (
                'created_at' => '2019-03-04 17:18:17',
                'id' => 17,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:18:17',
            ),
            17 => 
            array (
                'created_at' => '2019-03-04 17:18:42',
                'id' => 18,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:18:42',
            ),
            18 => 
            array (
                'created_at' => '2019-03-04 17:20:34',
                'id' => 19,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:20:34',
            ),
            19 => 
            array (
                'created_at' => '2019-03-04 17:20:58',
                'id' => 20,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:20:58',
            ),
            20 => 
            array (
                'created_at' => '2019-03-04 17:21:33',
                'id' => 21,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:21:33',
            ),
            21 => 
            array (
                'created_at' => '2019-03-04 17:45:05',
                'id' => 22,
                'notification_id' => 45,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abea9025-71dd-336c-a0a8-b10a17b8051b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4bbfa62e-e16c-32c1-9678-f2b3d2353844","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/78193a12-dbc2-3b29-8e49-8c9b53331222"]',
                'updated_at' => '2019-03-04 17:45:05',
            ),
            22 => 
            array (
                'created_at' => '2019-03-04 17:45:06',
                'id' => 23,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-04 17:45:06',
            ),
            23 => 
            array (
                'created_at' => '2019-03-04 18:02:40',
                'id' => 24,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:02:40',
            ),
            24 => 
            array (
                'created_at' => '2019-03-04 18:03:13',
                'id' => 25,
                'notification_id' => 45,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abea9025-71dd-336c-a0a8-b10a17b8051b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4bbfa62e-e16c-32c1-9678-f2b3d2353844","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/78193a12-dbc2-3b29-8e49-8c9b53331222"]',
                'updated_at' => '2019-03-04 18:03:13',
            ),
            25 => 
            array (
                'created_at' => '2019-03-04 18:03:14',
                'id' => 26,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:03:14',
            ),
            26 => 
            array (
                'created_at' => '2019-03-04 18:04:16',
                'id' => 27,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:04:16',
            ),
            27 => 
            array (
                'created_at' => '2019-03-04 18:05:21',
                'id' => 28,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:05:21',
            ),
            28 => 
            array (
                'created_at' => '2019-03-04 18:06:45',
                'id' => 29,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:06:45',
            ),
            29 => 
            array (
                'created_at' => '2019-03-04 18:08:08',
                'id' => 30,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:08:08',
            ),
            30 => 
            array (
                'created_at' => '2019-03-04 18:08:46',
                'id' => 31,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:08:46',
            ),
            31 => 
            array (
                'created_at' => '2019-03-04 18:09:26',
                'id' => 32,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:09:26',
            ),
            32 => 
            array (
                'created_at' => '2019-03-04 18:13:04',
                'id' => 33,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:13:04',
            ),
            33 => 
            array (
                'created_at' => '2019-03-04 18:14:05',
                'id' => 34,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:14:05',
            ),
            34 => 
            array (
                'created_at' => '2019-03-04 18:14:38',
                'id' => 35,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:14:38',
            ),
            35 => 
            array (
                'created_at' => '2019-03-04 18:15:54',
                'id' => 36,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:15:54',
            ),
            36 => 
            array (
                'created_at' => '2019-03-04 18:54:06',
                'id' => 37,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:54:06',
            ),
            37 => 
            array (
                'created_at' => '2019-03-04 18:54:29',
                'id' => 38,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 18:54:29',
            ),
            38 => 
            array (
                'created_at' => '2019-03-04 19:02:35',
                'id' => 39,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 19:02:35',
            ),
            39 => 
            array (
                'created_at' => '2019-03-04 19:05:09',
                'id' => 40,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-04 19:05:09',
            ),
            40 => 
            array (
                'created_at' => '2019-03-04 19:05:47',
                'id' => 41,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-04 19:05:47',
            ),
            41 => 
            array (
                'created_at' => '2019-03-04 19:14:35',
                'id' => 42,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-04 19:14:35',
            ),
            42 => 
            array (
                'created_at' => '2019-03-04 19:19:42',
                'id' => 43,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-04 19:19:42',
            ),
            43 => 
            array (
                'created_at' => '2019-03-04 19:21:58',
                'id' => 44,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-04 19:21:58',
            ),
            44 => 
            array (
                'created_at' => '2019-03-04 19:25:50',
                'id' => 45,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-04 19:25:50',
            ),
            45 => 
            array (
                'created_at' => '2019-03-04 19:31:14',
                'id' => 46,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-04 19:31:14',
            ),
            46 => 
            array (
                'created_at' => '2019-03-04 19:36:21',
                'id' => 47,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-04 19:36:21',
            ),
            47 => 
            array (
                'created_at' => '2019-03-05 10:56:18',
                'id' => 48,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 10:56:18',
            ),
            48 => 
            array (
                'created_at' => '2019-03-05 10:59:49',
                'id' => 49,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 10:59:49',
            ),
            49 => 
            array (
                'created_at' => '2019-03-05 11:33:39',
                'id' => 50,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 11:33:39',
            ),
            50 => 
            array (
                'created_at' => '2019-03-05 11:48:52',
                'id' => 51,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 11:48:52',
            ),
            51 => 
            array (
                'created_at' => '2019-03-05 12:56:17',
                'id' => 52,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 12:56:17',
            ),
            52 => 
            array (
                'created_at' => '2019-03-05 12:56:23',
                'id' => 53,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 12:56:23',
            ),
            53 => 
            array (
                'created_at' => '2019-03-05 12:56:25',
                'id' => 54,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-05 12:56:25',
            ),
            54 => 
            array (
                'created_at' => '2019-03-05 13:14:14',
                'id' => 55,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 13:14:14',
            ),
            55 => 
            array (
                'created_at' => '2019-03-05 13:14:20',
                'id' => 56,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 13:14:20',
            ),
            56 => 
            array (
                'created_at' => '2019-03-05 13:14:21',
                'id' => 57,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-05 13:14:21',
            ),
            57 => 
            array (
                'created_at' => '2019-03-05 15:08:58',
                'id' => 58,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 15:08:58',
            ),
            58 => 
            array (
                'created_at' => '2019-03-05 15:09:03',
                'id' => 59,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 15:09:03',
            ),
            59 => 
            array (
                'created_at' => '2019-03-05 15:09:05',
                'id' => 60,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-05 15:09:05',
            ),
            60 => 
            array (
                'created_at' => '2019-03-05 15:16:25',
                'id' => 61,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 15:16:25',
            ),
            61 => 
            array (
                'created_at' => '2019-03-05 15:16:30',
                'id' => 62,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'updated_at' => '2019-03-05 15:16:30',
            ),
            62 => 
            array (
                'created_at' => '2019-03-05 17:34:35',
                'id' => 63,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'updated_at' => '2019-03-05 17:34:35',
            ),
            63 => 
            array (
                'created_at' => '2019-03-06 15:30:35',
                'id' => 64,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:30:35',
            ),
            64 => 
            array (
                'created_at' => '2019-03-06 15:32:15',
                'id' => 65,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:32:15',
            ),
            65 => 
            array (
                'created_at' => '2019-03-06 15:35:17',
                'id' => 66,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:35:17',
            ),
            66 => 
            array (
                'created_at' => '2019-03-06 15:37:30',
                'id' => 67,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:37:30',
            ),
            67 => 
            array (
                'created_at' => '2019-03-06 15:42:20',
                'id' => 68,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:42:20',
            ),
            68 => 
            array (
                'created_at' => '2019-03-06 15:44:05',
                'id' => 69,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:44:05',
            ),
            69 => 
            array (
                'created_at' => '2019-03-06 15:44:12',
                'id' => 70,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:44:12',
            ),
            70 => 
            array (
                'created_at' => '2019-03-06 15:44:15',
                'id' => 71,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-06 15:44:15',
            ),
            71 => 
            array (
                'created_at' => '2019-03-06 15:45:15',
                'id' => 72,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:45:15',
            ),
            72 => 
            array (
                'created_at' => '2019-03-06 15:45:22',
                'id' => 73,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:45:22',
            ),
            73 => 
            array (
                'created_at' => '2019-03-06 15:45:25',
                'id' => 74,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-06 15:45:25',
            ),
            74 => 
            array (
                'created_at' => '2019-03-06 15:46:43',
                'id' => 75,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:46:43',
            ),
            75 => 
            array (
                'created_at' => '2019-03-06 15:46:50',
                'id' => 76,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:46:50',
            ),
            76 => 
            array (
                'created_at' => '2019-03-06 15:46:53',
                'id' => 77,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-06 15:46:53',
            ),
            77 => 
            array (
                'created_at' => '2019-03-06 15:48:02',
                'id' => 78,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:48:02',
            ),
            78 => 
            array (
                'created_at' => '2019-03-06 15:48:09',
                'id' => 79,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:48:09',
            ),
            79 => 
            array (
                'created_at' => '2019-03-06 15:48:12',
                'id' => 80,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'updated_at' => '2019-03-06 15:48:12',
            ),
            80 => 
            array (
                'created_at' => '2019-03-06 15:48:57',
                'id' => 81,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:48:57',
            ),
            81 => 
            array (
                'created_at' => '2019-03-06 15:49:02',
                'id' => 82,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:49:02',
            ),
            82 => 
            array (
                'created_at' => '2019-03-06 15:49:04',
                'id' => 83,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:49:04',
            ),
            83 => 
            array (
                'created_at' => '2019-03-06 15:51:41',
                'id' => 84,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:51:41',
            ),
            84 => 
            array (
                'created_at' => '2019-03-06 15:51:46',
                'id' => 85,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:51:46',
            ),
            85 => 
            array (
                'created_at' => '2019-03-06 15:51:48',
                'id' => 86,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:51:48',
            ),
            86 => 
            array (
                'created_at' => '2019-03-06 15:52:52',
                'id' => 87,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:52:52',
            ),
            87 => 
            array (
                'created_at' => '2019-03-06 15:52:57',
                'id' => 88,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:52:57',
            ),
            88 => 
            array (
                'created_at' => '2019-03-06 15:52:59',
                'id' => 89,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:52:59',
            ),
            89 => 
            array (
                'created_at' => '2019-03-06 15:54:22',
                'id' => 90,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:54:22',
            ),
            90 => 
            array (
                'created_at' => '2019-03-06 15:54:28',
                'id' => 91,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:54:28',
            ),
            91 => 
            array (
                'created_at' => '2019-03-06 15:54:30',
                'id' => 92,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'updated_at' => '2019-03-06 15:54:30',
            ),
            92 => 
            array (
                'created_at' => '2019-03-12 12:33:56',
                'id' => 93,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16"]',
                'updated_at' => '2019-03-12 12:33:56',
            ),
            93 => 
            array (
                'created_at' => '2019-03-12 12:39:36',
                'id' => 94,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a"]',
                'updated_at' => '2019-03-12 12:39:36',
            ),
            94 => 
            array (
                'created_at' => '2019-03-12 13:13:43',
                'id' => 95,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:13:43',
            ),
            95 => 
            array (
                'created_at' => '2019-03-12 13:13:46',
                'id' => 96,
                'notification_id' => 62,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:13:46',
            ),
            96 => 
            array (
                'created_at' => '2019-03-12 13:24:07',
                'id' => 97,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:24:07',
            ),
            97 => 
            array (
                'created_at' => '2019-03-12 13:26:21',
                'id' => 98,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:26:21',
            ),
            98 => 
            array (
                'created_at' => '2019-03-12 13:28:10',
                'id' => 99,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:28:10',
            ),
            99 => 
            array (
                'created_at' => '2019-03-12 13:28:47',
                'id' => 100,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:28:47',
            ),
            100 => 
            array (
                'created_at' => '2019-03-12 13:38:14',
                'id' => 101,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'updated_at' => '2019-03-12 13:38:14',
            ),
            101 => 
            array (
                'created_at' => '2019-03-13 13:06:31',
                'id' => 102,
                'notification_id' => 63,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886"]',
                'updated_at' => '2019-03-13 13:06:31',
            ),
            102 => 
            array (
                'created_at' => '2019-03-13 13:06:34',
                'id' => 103,
                'notification_id' => 64,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886"]',
                'updated_at' => '2019-03-13 13:06:34',
            ),
            103 => 
            array (
                'created_at' => '2019-03-13 13:06:37',
                'id' => 104,
                'notification_id' => 65,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886"]',
                'updated_at' => '2019-03-13 13:06:37',
            ),
            104 => 
            array (
                'created_at' => '2019-03-13 13:06:39',
                'id' => 105,
                'notification_id' => 67,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'updated_at' => '2019-03-13 13:06:39',
            ),
            105 => 
            array (
                'created_at' => '2019-03-13 13:06:41',
                'id' => 106,
                'notification_id' => 68,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'updated_at' => '2019-03-13 13:06:41',
            ),
            106 => 
            array (
                'created_at' => '2019-03-13 13:08:31',
                'id' => 107,
                'notification_id' => 67,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'updated_at' => '2019-03-13 13:08:31',
            ),
            107 => 
            array (
                'created_at' => '2019-03-13 13:08:33',
                'id' => 108,
                'notification_id' => 68,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'updated_at' => '2019-03-13 13:08:33',
            ),
            108 => 
            array (
                'created_at' => '2019-03-13 13:42:50',
                'id' => 109,
                'notification_id' => 69,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5"]',
                'updated_at' => '2019-03-13 13:42:50',
            ),
            109 => 
            array (
                'created_at' => '2019-03-13 13:45:59',
                'id' => 110,
                'notification_id' => 69,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5"]',
                'updated_at' => '2019-03-13 13:45:59',
            ),
            110 => 
            array (
                'created_at' => '2019-03-13 13:47:19',
                'id' => 111,
                'notification_id' => 69,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5"]',
                'updated_at' => '2019-03-13 13:47:19',
            ),
            111 => 
            array (
                'created_at' => '2019-03-19 18:30:33',
                'id' => 112,
                'notification_id' => 71,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-19 18:30:33',
            ),
            112 => 
            array (
                'created_at' => '2019-03-19 18:30:41',
                'id' => 113,
                'notification_id' => 72,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/02eedfa9-0681-33aa-b00b-7377119aa387"]',
                'updated_at' => '2019-03-19 18:30:41',
            ),
            113 => 
            array (
                'created_at' => '2019-03-19 18:30:50',
                'id' => 114,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-19 18:30:50',
            ),
            114 => 
            array (
                'created_at' => '2019-03-19 18:35:01',
                'id' => 115,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-19 18:35:01',
            ),
            115 => 
            array (
                'created_at' => '2019-03-19 18:36:23',
                'id' => 116,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-19 18:36:23',
            ),
            116 => 
            array (
                'created_at' => '2019-03-19 18:40:24',
                'id' => 117,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-19 18:40:24',
            ),
            117 => 
            array (
                'created_at' => '2019-03-19 18:47:22',
                'id' => 118,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-19 18:47:22',
            ),
            118 => 
            array (
                'created_at' => '2019-03-20 10:52:27',
                'id' => 119,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ac211b1e-5b73-31a8-954c-aaa38784ad0d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-20 10:52:27',
            ),
            119 => 
            array (
                'created_at' => '2019-03-20 10:58:39',
                'id' => 120,
                'notification_id' => 72,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ac211b1e-5b73-31a8-954c-aaa38784ad0d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/02eedfa9-0681-33aa-b00b-7377119aa387"]',
                'updated_at' => '2019-03-20 10:58:39',
            ),
            120 => 
            array (
                'created_at' => '2019-03-20 10:58:48',
                'id' => 121,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ac211b1e-5b73-31a8-954c-aaa38784ad0d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'updated_at' => '2019-03-20 10:58:48',
            ),
            121 => 
            array (
                'created_at' => '2019-03-28 16:03:00',
                'id' => 122,
                'notification_id' => 86,
                'notified_users' => '[357,359,372,377,390,391,395,361,355,388,389]',
                'updated_at' => '2019-03-28 16:03:00',
            ),
            122 => 
            array (
                'created_at' => '2019-03-28 16:27:02',
                'id' => 123,
                'notification_id' => 86,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cc7375b7-db2f-3cc3-8dd5-9f9108480db8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b45f9a81-6486-3be3-a127-b89082bbc7dd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b05abef6-57e5-3ab0-9269-a9b71467b367","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/da81b261-4204-3c7b-8a60-d72bf83b1391","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f04984b3-d026-3ba0-a2d7-58a360faa65e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6e7b765c-b099-31d5-8477-20b06476a2ac","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cecaaa52-6370-31ba-baf5-4f137f4f5af6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2a369bfe-2518-37d3-afd2-ae325b316d38","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/3d215c98-74df-32d9-bf2d-fb0376fa8878","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/22a1f127-136e-325d-b1ed-721857c806bd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bcdd12ca-5e07-3d67-87e2-0645a413fe6c","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2cdeb7d3-e8ca-3e24-9835-c3634fde18c3"]',
                'updated_at' => '2019-03-28 16:27:02',
            ),
            123 => 
            array (
                'created_at' => '2019-03-29 16:45:07',
                'id' => 124,
                'notification_id' => 82,
                'notified_users' => '[357,359,361,372,377,390,391,395,397,355,388,389]',
                'updated_at' => '2019-03-29 16:45:07',
            ),
            124 => 
            array (
                'created_at' => '2019-04-02 13:28:09',
                'id' => 125,
                'notification_id' => 75,
                'notified_users' => '[361,357,416]',
                'updated_at' => '2019-04-02 13:28:09',
            ),
            125 => 
            array (
                'created_at' => '2019-04-02 13:28:11',
                'id' => 126,
                'notification_id' => 87,
                'notified_users' => '[]',
                'updated_at' => '2019-04-02 13:28:11',
            ),
            126 => 
            array (
                'created_at' => '2019-04-02 13:39:11',
                'id' => 127,
                'notification_id' => 88,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,418,361,355]',
                'updated_at' => '2019-04-02 13:39:11',
            ),
            127 => 
            array (
                'created_at' => '2019-04-02 13:44:13',
                'id' => 128,
                'notification_id' => 89,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,418,419,355,388,389]',
                'updated_at' => '2019-04-02 13:44:13',
            ),
            128 => 
            array (
                'created_at' => '2019-04-02 13:59:12',
                'id' => 129,
                'notification_id' => 90,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,418,419,361,355,388,389]',
                'updated_at' => '2019-04-02 13:59:12',
            ),
            129 => 
            array (
                'created_at' => '2019-04-02 13:59:21',
                'id' => 130,
                'notification_id' => 91,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,418,419,361,355,388,389]',
                'updated_at' => '2019-04-02 13:59:21',
            ),
            130 => 
            array (
                'created_at' => '2019-04-02 18:23:14',
                'id' => 131,
                'notification_id' => 92,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,419,423,424,361,355]',
                'updated_at' => '2019-04-02 18:23:14',
            ),
            131 => 
            array (
                'created_at' => '2019-04-03 12:49:13',
                'id' => 132,
                'notification_id' => 93,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,424,436,437,355,388,389]',
                'updated_at' => '2019-04-03 12:49:13',
            ),
            132 => 
            array (
                'created_at' => '2019-04-03 13:00:07',
                'id' => 133,
                'notification_id' => 94,
                'notified_users' => '[355,357,388,389,411,419,436,437]',
                'updated_at' => '2019-04-03 13:00:07',
            ),
            133 => 
            array (
                'created_at' => '2019-04-03 13:06:05',
                'id' => 134,
                'notification_id' => 95,
                'notified_users' => '[355,357,388,389,411,419,436,437]',
                'updated_at' => '2019-04-03 13:06:05',
            ),
            134 => 
            array (
                'created_at' => '2019-04-03 13:20:05',
                'id' => 135,
                'notification_id' => 96,
                'notified_users' => '[355,357,388,389,411,419,436,437]',
                'updated_at' => '2019-04-03 13:20:05',
            ),
            135 => 
            array (
                'created_at' => '2019-04-03 13:41:05',
                'id' => 136,
                'notification_id' => 96,
                'notified_users' => '[355,357,388,389,411,419,437,438,439]',
                'updated_at' => '2019-04-03 13:41:05',
            ),
            136 => 
            array (
                'created_at' => '2019-04-03 16:09:13',
                'id' => 137,
                'notification_id' => 102,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,424,443,444,446,447,361]',
                'updated_at' => '2019-04-03 16:09:13',
            ),
            137 => 
            array (
                'created_at' => '2019-04-03 16:12:11',
                'id' => 138,
                'notification_id' => 103,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,424,443,444,446,447,361]',
                'updated_at' => '2019-04-03 16:12:11',
            ),
            138 => 
            array (
                'created_at' => '2019-04-03 16:36:08',
                'id' => 139,
                'notification_id' => 104,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,444,446,447]',
                'updated_at' => '2019-04-03 16:36:08',
            ),
            139 => 
            array (
                'created_at' => '2019-04-03 17:01:10',
                'id' => 140,
                'notification_id' => 105,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 17:01:10',
            ),
            140 => 
            array (
                'created_at' => '2019-04-03 17:36:17',
                'id' => 141,
                'notification_id' => 106,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 17:36:17',
            ),
            141 => 
            array (
                'created_at' => '2019-04-03 17:44:07',
                'id' => 142,
                'notification_id' => 107,
                'notified_users' => '[355,357,388,389,411,419,438,444,448]',
                'updated_at' => '2019-04-03 17:44:07',
            ),
            142 => 
            array (
                'created_at' => '2019-04-03 17:47:07',
                'id' => 143,
                'notification_id' => 108,
                'notified_users' => '[355,357,388,389,411,419,438,444,448]',
                'updated_at' => '2019-04-03 17:47:07',
            ),
            143 => 
            array (
                'created_at' => '2019-04-03 18:04:12',
                'id' => 144,
                'notification_id' => 109,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,444,446,447,449,355,388,389,438,448]',
                'updated_at' => '2019-04-03 18:04:12',
            ),
            144 => 
            array (
                'created_at' => '2019-04-03 18:10:10',
                'id' => 145,
                'notification_id' => 110,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 18:10:10',
            ),
            145 => 
            array (
                'created_at' => '2019-04-03 18:12:08',
                'id' => 146,
                'notification_id' => 111,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-03 18:12:08',
            ),
            146 => 
            array (
                'created_at' => '2019-04-03 18:12:14',
                'id' => 147,
                'notification_id' => 112,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-03 18:12:14',
            ),
            147 => 
            array (
                'created_at' => '2019-04-03 18:12:18',
                'id' => 148,
                'notification_id' => 113,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,444,446,447,449,355,388,389,438,448]',
                'updated_at' => '2019-04-03 18:12:18',
            ),
            148 => 
            array (
                'created_at' => '2019-04-03 18:15:07',
                'id' => 149,
                'notification_id' => 114,
                'notified_users' => '[355,357,388,389,411,419,438,444,448,359,372,377,423,449]',
                'updated_at' => '2019-04-03 18:15:07',
            ),
            149 => 
            array (
                'created_at' => '2019-04-03 18:20:10',
                'id' => 150,
                'notification_id' => 115,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-03 18:20:10',
            ),
            150 => 
            array (
                'created_at' => '2019-04-03 18:33:09',
                'id' => 151,
                'notification_id' => 116,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 18:33:09',
            ),
            151 => 
            array (
                'created_at' => '2019-04-03 18:40:12',
                'id' => 152,
                'notification_id' => 117,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 18:40:12',
            ),
            152 => 
            array (
                'created_at' => '2019-04-03 18:50:23',
                'id' => 153,
                'notification_id' => 117,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 18:50:23',
            ),
            153 => 
            array (
                'created_at' => '2019-04-03 18:54:10',
                'id' => 154,
                'notification_id' => 117,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'updated_at' => '2019-04-03 18:54:10',
            ),
            154 => 
            array (
                'created_at' => '2019-04-03 18:56:10',
                'id' => 155,
                'notification_id' => 118,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,450,361,447]',
                'updated_at' => '2019-04-03 18:56:10',
            ),
            155 => 
            array (
                'created_at' => '2019-04-04 11:19:10',
                'id' => 156,
                'notification_id' => 105,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,361,447,454]',
                'updated_at' => '2019-04-04 11:19:10',
            ),
            156 => 
            array (
                'created_at' => '2019-04-04 11:20:15',
                'id' => 157,
                'notification_id' => 115,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,361,447,454,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:20:15',
            ),
            157 => 
            array (
                'created_at' => '2019-04-04 11:26:15',
                'id' => 158,
                'notification_id' => 119,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,455,361,447,454,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:26:15',
            ),
            158 => 
            array (
                'created_at' => '2019-04-04 11:30:14',
                'id' => 159,
                'notification_id' => 119,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,455,459,361,447,454,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:30:14',
            ),
            159 => 
            array (
                'created_at' => '2019-04-04 11:36:16',
                'id' => 160,
                'notification_id' => 71,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:36:16',
            ),
            160 => 
            array (
                'created_at' => '2019-04-04 11:37:09',
                'id' => 161,
                'notification_id' => 120,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:37:09',
            ),
            161 => 
            array (
                'created_at' => '2019-04-04 11:38:09',
                'id' => 162,
                'notification_id' => 121,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:38:09',
            ),
            162 => 
            array (
                'created_at' => '2019-04-04 11:38:15',
                'id' => 163,
                'notification_id' => 122,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:38:15',
            ),
            163 => 
            array (
                'created_at' => '2019-04-04 11:39:09',
                'id' => 164,
                'notification_id' => 123,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'updated_at' => '2019-04-04 11:39:09',
            ),
            164 => 
            array (
                'created_at' => '2019-04-04 11:49:09',
                'id' => 165,
                'notification_id' => 124,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,464,361,447]',
                'updated_at' => '2019-04-04 11:49:09',
            ),
            165 => 
            array (
                'created_at' => '2019-04-04 11:50:06',
                'id' => 166,
                'notification_id' => 125,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'updated_at' => '2019-04-04 11:50:06',
            ),
            166 => 
            array (
                'created_at' => '2019-04-04 11:50:08',
                'id' => 167,
                'notification_id' => 126,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'updated_at' => '2019-04-04 11:50:08',
            ),
            167 => 
            array (
                'created_at' => '2019-04-04 11:58:07',
                'id' => 168,
                'notification_id' => 127,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'updated_at' => '2019-04-04 11:58:07',
            ),
            168 => 
            array (
                'created_at' => '2019-04-04 12:02:07',
                'id' => 169,
                'notification_id' => 128,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'updated_at' => '2019-04-04 12:02:07',
            ),
            169 => 
            array (
                'created_at' => '2019-04-04 12:34:06',
                'id' => 170,
                'notification_id' => 129,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'updated_at' => '2019-04-04 12:34:06',
            ),
            170 => 
            array (
                'created_at' => '2019-04-04 12:36:06',
                'id' => 171,
                'notification_id' => 130,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'updated_at' => '2019-04-04 12:36:06',
            ),
            171 => 
            array (
                'created_at' => '2019-04-04 12:39:05',
                'id' => 172,
                'notification_id' => 131,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'updated_at' => '2019-04-04 12:39:05',
            ),
            172 => 
            array (
                'created_at' => '2019-04-04 13:07:06',
                'id' => 173,
                'notification_id' => 132,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'updated_at' => '2019-04-04 13:07:06',
            ),
            173 => 
            array (
                'created_at' => '2019-04-04 13:08:05',
                'id' => 174,
                'notification_id' => 133,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'updated_at' => '2019-04-04 13:08:05',
            ),
            174 => 
            array (
                'created_at' => '2019-04-04 13:10:08',
                'id' => 175,
                'notification_id' => 134,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'updated_at' => '2019-04-04 13:10:08',
            ),
            175 => 
            array (
                'created_at' => '2019-04-04 13:12:08',
                'id' => 176,
                'notification_id' => 135,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'updated_at' => '2019-04-04 13:12:08',
            ),
            176 => 
            array (
                'created_at' => '2019-04-04 13:18:08',
                'id' => 177,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'updated_at' => '2019-04-04 13:18:08',
            ),
            177 => 
            array (
                'created_at' => '2019-04-04 18:19:14',
                'id' => 178,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:19:14',
            ),
            178 => 
            array (
                'created_at' => '2019-04-04 18:19:26',
                'id' => 179,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:19:26',
            ),
            179 => 
            array (
                'created_at' => '2019-04-04 18:22:15',
                'id' => 180,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:22:15',
            ),
            180 => 
            array (
                'created_at' => '2019-04-04 18:32:06',
                'id' => 181,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,469]',
                'updated_at' => '2019-04-04 18:32:06',
            ),
            181 => 
            array (
                'created_at' => '2019-04-04 18:32:18',
                'id' => 182,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:32:18',
            ),
            182 => 
            array (
                'created_at' => '2019-04-04 18:32:29',
                'id' => 183,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:32:29',
            ),
            183 => 
            array (
                'created_at' => '2019-04-04 18:32:42',
                'id' => 184,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:32:42',
            ),
            184 => 
            array (
                'created_at' => '2019-04-04 18:34:05',
                'id' => 185,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,469]',
                'updated_at' => '2019-04-04 18:34:05',
            ),
            185 => 
            array (
                'created_at' => '2019-04-04 18:34:18',
                'id' => 186,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:34:18',
            ),
            186 => 
            array (
                'created_at' => '2019-04-04 18:34:31',
                'id' => 187,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:34:31',
            ),
            187 => 
            array (
                'created_at' => '2019-04-04 18:34:43',
                'id' => 188,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:34:43',
            ),
            188 => 
            array (
                'created_at' => '2019-04-04 18:48:06',
                'id' => 189,
                'notification_id' => 128,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,470]',
                'updated_at' => '2019-04-04 18:48:06',
            ),
            189 => 
            array (
                'created_at' => '2019-04-04 18:48:08',
                'id' => 190,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,470]',
                'updated_at' => '2019-04-04 18:48:08',
            ),
            190 => 
            array (
                'created_at' => '2019-04-04 18:50:18',
                'id' => 191,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:50:18',
            ),
            191 => 
            array (
                'created_at' => '2019-04-04 18:50:31',
                'id' => 192,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:50:31',
            ),
            192 => 
            array (
                'created_at' => '2019-04-04 18:50:44',
                'id' => 193,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:50:44',
            ),
            193 => 
            array (
                'created_at' => '2019-04-04 18:52:18',
                'id' => 194,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:52:18',
            ),
            194 => 
            array (
                'created_at' => '2019-04-04 18:52:30',
                'id' => 195,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:52:30',
            ),
            195 => 
            array (
                'created_at' => '2019-04-04 18:52:43',
                'id' => 196,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:52:43',
            ),
            196 => 
            array (
                'created_at' => '2019-04-04 18:58:18',
                'id' => 197,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:58:18',
            ),
            197 => 
            array (
                'created_at' => '2019-04-04 18:58:31',
                'id' => 198,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 18:58:31',
            ),
            198 => 
            array (
                'created_at' => '2019-04-04 19:01:18',
                'id' => 199,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:01:18',
            ),
            199 => 
            array (
                'created_at' => '2019-04-04 19:01:30',
                'id' => 200,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:01:30',
            ),
            200 => 
            array (
                'created_at' => '2019-04-04 19:02:16',
                'id' => 201,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:02:16',
            ),
            201 => 
            array (
                'created_at' => '2019-04-04 19:02:29',
                'id' => 202,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:02:29',
            ),
            202 => 
            array (
                'created_at' => '2019-04-04 19:06:15',
                'id' => 203,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:06:15',
            ),
            203 => 
            array (
                'created_at' => '2019-04-04 19:06:28',
                'id' => 204,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:06:28',
            ),
            204 => 
            array (
                'created_at' => '2019-04-04 19:06:40',
                'id' => 205,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:06:40',
            ),
            205 => 
            array (
                'created_at' => '2019-04-04 19:12:19',
                'id' => 206,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:12:19',
            ),
            206 => 
            array (
                'created_at' => '2019-04-04 19:12:31',
                'id' => 207,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:12:31',
            ),
            207 => 
            array (
                'created_at' => '2019-04-04 19:12:44',
                'id' => 208,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:12:44',
            ),
            208 => 
            array (
                'created_at' => '2019-04-04 19:12:57',
                'id' => 209,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:12:57',
            ),
            209 => 
            array (
                'created_at' => '2019-04-04 19:13:10',
                'id' => 210,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:13:10',
            ),
            210 => 
            array (
                'created_at' => '2019-04-04 19:19:16',
                'id' => 211,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:19:16',
            ),
            211 => 
            array (
                'created_at' => '2019-04-04 19:19:29',
                'id' => 212,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:19:29',
            ),
            212 => 
            array (
                'created_at' => '2019-04-04 19:19:41',
                'id' => 213,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-04 19:19:41',
            ),
            213 => 
            array (
                'created_at' => '2019-04-05 10:53:16',
                'id' => 214,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 10:53:16',
            ),
            214 => 
            array (
                'created_at' => '2019-04-05 13:03:17',
                'id' => 215,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:03:17',
            ),
            215 => 
            array (
                'created_at' => '2019-04-05 13:03:31',
                'id' => 216,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,477,478,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:03:31',
            ),
            216 => 
            array (
                'created_at' => '2019-04-05 13:03:44',
                'id' => 217,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:03:44',
            ),
            217 => 
            array (
                'created_at' => '2019-04-05 13:03:57',
                'id' => 218,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:03:57',
            ),
            218 => 
            array (
                'created_at' => '2019-04-05 13:05:17',
                'id' => 219,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:05:17',
            ),
            219 => 
            array (
                'created_at' => '2019-04-05 13:05:30',
                'id' => 220,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:05:30',
            ),
            220 => 
            array (
                'created_at' => '2019-04-05 13:05:43',
                'id' => 221,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:05:43',
            ),
            221 => 
            array (
                'created_at' => '2019-04-05 13:07:16',
                'id' => 222,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:07:16',
            ),
            222 => 
            array (
                'created_at' => '2019-04-05 13:07:29',
                'id' => 223,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:07:29',
            ),
            223 => 
            array (
                'created_at' => '2019-04-05 13:07:43',
                'id' => 224,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:07:43',
            ),
            224 => 
            array (
                'created_at' => '2019-04-05 13:09:17',
                'id' => 225,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:09:17',
            ),
            225 => 
            array (
                'created_at' => '2019-04-05 13:09:30',
                'id' => 226,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:09:30',
            ),
            226 => 
            array (
                'created_at' => '2019-04-05 13:09:43',
                'id' => 227,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:09:43',
            ),
            227 => 
            array (
                'created_at' => '2019-04-05 13:11:16',
                'id' => 228,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:11:16',
            ),
            228 => 
            array (
                'created_at' => '2019-04-05 13:11:30',
                'id' => 229,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:11:30',
            ),
            229 => 
            array (
                'created_at' => '2019-04-05 13:11:43',
                'id' => 230,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:11:43',
            ),
            230 => 
            array (
                'created_at' => '2019-04-05 13:43:19',
                'id' => 231,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:43:19',
            ),
            231 => 
            array (
                'created_at' => '2019-04-05 13:43:35',
                'id' => 232,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:43:35',
            ),
            232 => 
            array (
                'created_at' => '2019-04-05 13:43:49',
                'id' => 233,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:43:49',
            ),
            233 => 
            array (
                'created_at' => '2019-04-05 13:43:57',
                'id' => 234,
                'notification_id' => 146,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:43:57',
            ),
            234 => 
            array (
                'created_at' => '2019-04-05 13:50:19',
                'id' => 235,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:50:19',
            ),
            235 => 
            array (
                'created_at' => '2019-04-05 13:50:33',
                'id' => 236,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:50:33',
            ),
            236 => 
            array (
                'created_at' => '2019-04-05 13:50:47',
                'id' => 237,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'updated_at' => '2019-04-05 13:50:47',
            ),
            237 => 
            array (
                'created_at' => '2019-04-05 13:50:49',
                'id' => 238,
                'notification_id' => 147,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,478,480,481]',
                'updated_at' => '2019-04-05 13:50:49',
            ),
            238 => 
            array (
                'created_at' => '2019-04-05 16:24:19',
                'id' => 239,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'updated_at' => '2019-04-05 16:24:19',
            ),
            239 => 
            array (
                'created_at' => '2019-04-05 16:24:34',
                'id' => 240,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'updated_at' => '2019-04-05 16:24:34',
            ),
            240 => 
            array (
                'created_at' => '2019-04-05 16:24:48',
                'id' => 241,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'updated_at' => '2019-04-05 16:24:48',
            ),
            241 => 
            array (
                'created_at' => '2019-04-05 16:32:18',
                'id' => 242,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'updated_at' => '2019-04-05 16:32:18',
            ),
            242 => 
            array (
                'created_at' => '2019-04-05 16:32:32',
                'id' => 243,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'updated_at' => '2019-04-05 16:32:32',
            ),
            243 => 
            array (
                'created_at' => '2019-04-05 16:39:07',
                'id' => 244,
                'notification_id' => 148,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'updated_at' => '2019-04-05 16:39:07',
            ),
            244 => 
            array (
                'created_at' => '2019-04-05 16:39:11',
                'id' => 245,
                'notification_id' => 149,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'updated_at' => '2019-04-05 16:39:11',
            ),
            245 => 
            array (
                'created_at' => '2019-04-05 16:39:13',
                'id' => 246,
                'notification_id' => 150,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'updated_at' => '2019-04-05 16:39:13',
            ),
            246 => 
            array (
                'created_at' => '2019-04-05 16:41:05',
                'id' => 247,
                'notification_id' => 151,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'updated_at' => '2019-04-05 16:41:05',
            ),
            247 => 
            array (
                'created_at' => '2019-04-05 16:41:07',
                'id' => 248,
                'notification_id' => 152,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'updated_at' => '2019-04-05 16:41:07',
            ),
            248 => 
            array (
                'created_at' => '2019-04-05 20:13:21',
                'id' => 249,
                'notification_id' => 153,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484,485,493]',
                'updated_at' => '2019-04-05 20:13:21',
            ),
            249 => 
            array (
                'created_at' => '2019-04-05 20:15:14',
                'id' => 250,
                'notification_id' => 154,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484,485,493]',
                'updated_at' => '2019-04-05 20:15:14',
            ),
            250 => 
            array (
                'created_at' => '2019-04-05 20:18:07',
                'id' => 251,
                'notification_id' => 155,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484,485,493]',
                'updated_at' => '2019-04-05 20:18:07',
            ),
            251 => 
            array (
                'created_at' => '2019-04-10 13:46:07',
                'id' => 252,
                'notification_id' => 156,
                'notified_users' => '[196,209,212,213,224,227,239,524,223,241,261,264]',
                'updated_at' => '2019-04-10 13:46:07',
            ),
            252 => 
            array (
                'created_at' => '2019-04-10 15:16:10',
                'id' => 253,
                'notification_id' => 157,
                'notified_users' => '[196,209,212,213,224,227,239,529,530,223,241,261,264]',
                'updated_at' => '2019-04-10 15:16:10',
            ),
            253 => 
            array (
                'created_at' => '2019-04-10 15:24:08',
                'id' => 254,
                'notification_id' => 158,
                'notified_users' => '[196,209,212,213,224,227,239,529,530,261,264]',
                'updated_at' => '2019-04-10 15:24:08',
            ),
            254 => 
            array (
                'created_at' => '2019-04-10 15:57:11',
                'id' => 255,
                'notification_id' => 159,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'updated_at' => '2019-04-10 15:57:11',
            ),
            255 => 
            array (
                'created_at' => '2019-04-10 15:58:09',
                'id' => 256,
                'notification_id' => 157,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,223,241,261,264]',
                'updated_at' => '2019-04-10 15:58:09',
            ),
            256 => 
            array (
                'created_at' => '2019-04-10 15:58:13',
                'id' => 257,
                'notification_id' => 158,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'updated_at' => '2019-04-10 15:58:13',
            ),
            257 => 
            array (
                'created_at' => '2019-04-10 15:58:19',
                'id' => 258,
                'notification_id' => 159,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'updated_at' => '2019-04-10 15:58:19',
            ),
            258 => 
            array (
                'created_at' => '2019-04-10 15:59:10',
                'id' => 259,
                'notification_id' => 160,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,223,241,261,264]',
                'updated_at' => '2019-04-10 15:59:10',
            ),
            259 => 
            array (
                'created_at' => '2019-04-10 16:02:10',
                'id' => 260,
                'notification_id' => 161,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'updated_at' => '2019-04-10 16:02:10',
            ),
            260 => 
            array (
                'created_at' => '2019-04-16 13:26:13',
                'id' => 261,
                'notification_id' => 160,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'updated_at' => '2019-04-16 13:26:13',
            ),
            261 => 
            array (
                'created_at' => '2019-04-16 13:26:21',
                'id' => 262,
                'notification_id' => 161,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'updated_at' => '2019-04-16 13:26:21',
            ),
            262 => 
            array (
                'created_at' => '2019-04-16 15:42:13',
                'id' => 263,
                'notification_id' => 163,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 15:42:13',
            ),
            263 => 
            array (
                'created_at' => '2019-04-16 15:44:11',
                'id' => 264,
                'notification_id' => 161,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'updated_at' => '2019-04-16 15:44:11',
            ),
            264 => 
            array (
                'created_at' => '2019-04-16 15:44:20',
                'id' => 265,
                'notification_id' => 163,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 15:44:20',
            ),
            265 => 
            array (
                'created_at' => '2019-04-16 15:46:13',
                'id' => 266,
                'notification_id' => 164,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 15:46:13',
            ),
            266 => 
            array (
                'created_at' => '2019-04-16 16:03:12',
                'id' => 267,
                'notification_id' => 165,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 16:03:12',
            ),
            267 => 
            array (
                'created_at' => '2019-04-16 16:07:12',
                'id' => 268,
                'notification_id' => 166,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'updated_at' => '2019-04-16 16:07:12',
            ),
            268 => 
            array (
                'created_at' => '2019-04-16 16:24:11',
                'id' => 269,
                'notification_id' => 167,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 16:24:11',
            ),
            269 => 
            array (
                'created_at' => '2019-04-16 16:39:13',
                'id' => 270,
                'notification_id' => 168,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 16:39:13',
            ),
            270 => 
            array (
                'created_at' => '2019-04-16 16:43:11',
                'id' => 271,
                'notification_id' => 169,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 16:43:11',
            ),
            271 => 
            array (
                'created_at' => '2019-04-16 16:58:12',
                'id' => 272,
                'notification_id' => 170,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 16:58:12',
            ),
            272 => 
            array (
                'created_at' => '2019-04-16 17:22:12',
                'id' => 273,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'updated_at' => '2019-04-16 17:22:12',
            ),
            273 => 
            array (
                'created_at' => '2019-04-16 18:11:13',
                'id' => 274,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'updated_at' => '2019-04-16 18:11:13',
            ),
            274 => 
            array (
                'created_at' => '2019-04-19 19:20:15',
                'id' => 275,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e"]',
                'updated_at' => '2019-04-19 19:20:15',
            ),
            275 => 
            array (
                'created_at' => '2019-04-19 19:20:28',
                'id' => 276,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'updated_at' => '2019-04-19 19:20:28',
            ),
            276 => 
            array (
                'created_at' => '2019-04-22 17:31:16',
                'id' => 277,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208"]',
                'updated_at' => '2019-04-22 17:31:16',
            ),
            277 => 
            array (
                'created_at' => '2019-04-22 17:31:30',
                'id' => 278,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e"]',
                'updated_at' => '2019-04-22 17:31:30',
            ),
            278 => 
            array (
                'created_at' => '2019-04-22 17:32:16',
                'id' => 279,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208"]',
                'updated_at' => '2019-04-22 17:32:16',
            ),
            279 => 
            array (
                'created_at' => '2019-04-22 17:32:31',
                'id' => 280,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e"]',
                'updated_at' => '2019-04-22 17:32:31',
            ),
            280 => 
            array (
                'created_at' => '2019-04-22 17:39:17',
                'id' => 281,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208"]',
                'updated_at' => '2019-04-22 17:39:17',
            ),
            281 => 
            array (
                'created_at' => '2019-04-22 17:39:32',
                'id' => 282,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e"]',
                'updated_at' => '2019-04-22 17:39:32',
            ),
            282 => 
            array (
                'created_at' => '2019-04-26 15:34:25',
                'id' => 283,
                'notification_id' => 174,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-04-26 15:34:25',
            ),
            283 => 
            array (
                'created_at' => '2019-04-26 15:58:26',
                'id' => 284,
                'notification_id' => 177,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-04-26 15:58:26',
            ),
            284 => 
            array (
                'created_at' => '2019-04-26 16:05:27',
                'id' => 285,
                'notification_id' => 178,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-04-26 16:05:27',
            ),
            285 => 
            array (
                'created_at' => '2019-04-26 17:58:17',
                'id' => 286,
                'notification_id' => 180,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-04-26 17:58:17',
            ),
            286 => 
            array (
                'created_at' => '2019-04-26 18:05:16',
                'id' => 287,
                'notification_id' => 181,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7"]',
                'updated_at' => '2019-04-26 18:05:16',
            ),
            287 => 
            array (
                'created_at' => '2019-04-26 18:41:13',
                'id' => 288,
                'notification_id' => 184,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7"]',
                'updated_at' => '2019-04-26 18:41:13',
            ),
            288 => 
            array (
                'created_at' => '2019-04-26 19:09:24',
                'id' => 289,
                'notification_id' => 186,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-04-26 19:09:24',
            ),
            289 => 
            array (
                'created_at' => '2019-05-02 12:05:28',
                'id' => 290,
                'notification_id' => 188,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 12:05:28',
            ),
            290 => 
            array (
                'created_at' => '2019-05-02 13:20:27',
                'id' => 291,
                'notification_id' => 189,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 13:20:27',
            ),
            291 => 
            array (
                'created_at' => '2019-05-02 15:08:15',
                'id' => 292,
                'notification_id' => 192,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 15:08:15',
            ),
            292 => 
            array (
                'created_at' => '2019-05-02 15:10:07',
                'id' => 293,
                'notification_id' => 191,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-02 15:10:07',
            ),
            293 => 
            array (
                'created_at' => '2019-05-02 16:35:15',
                'id' => 294,
                'notification_id' => 193,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 16:35:15',
            ),
            294 => 
            array (
                'created_at' => '2019-05-02 18:34:17',
                'id' => 295,
                'notification_id' => 193,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 18:34:17',
            ),
            295 => 
            array (
                'created_at' => '2019-05-02 18:51:15',
                'id' => 296,
                'notification_id' => 193,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 18:51:15',
            ),
            296 => 
            array (
                'created_at' => '2019-05-02 19:10:15',
                'id' => 297,
                'notification_id' => 193,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 19:10:15',
            ),
            297 => 
            array (
                'created_at' => '2019-05-02 19:16:38',
                'id' => 298,
                'notification_id' => 193,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 19:16:38',
            ),
            298 => 
            array (
                'created_at' => '2019-05-02 19:18:59',
                'id' => 299,
                'notification_id' => 194,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-02 19:18:59',
            ),
            299 => 
            array (
                'created_at' => '2019-05-02 19:29:18',
                'id' => 300,
                'notification_id' => 196,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-02 19:29:18',
            ),
            300 => 
            array (
                'created_at' => '2019-05-02 19:30:35',
                'id' => 301,
                'notification_id' => 197,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-02 19:30:35',
            ),
            301 => 
            array (
                'created_at' => '2019-05-02 19:33:51',
                'id' => 302,
                'notification_id' => 199,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-02 19:33:51',
            ),
            302 => 
            array (
                'created_at' => '2019-05-02 19:48:15',
                'id' => 303,
                'notification_id' => 201,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-02 19:48:15',
            ),
            303 => 
            array (
                'created_at' => '2019-05-03 10:56:22',
                'id' => 304,
                'notification_id' => 202,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 10:56:22',
            ),
            304 => 
            array (
                'created_at' => '2019-05-03 11:00:06',
                'id' => 305,
                'notification_id' => 199,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 11:00:06',
            ),
            305 => 
            array (
                'created_at' => '2019-05-03 11:00:08',
                'id' => 306,
                'notification_id' => 201,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 11:00:08',
            ),
            306 => 
            array (
                'created_at' => '2019-05-03 11:02:38',
                'id' => 307,
                'notification_id' => 203,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 11:02:38',
            ),
            307 => 
            array (
                'created_at' => '2019-05-03 13:07:09',
                'id' => 308,
                'notification_id' => 204,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 13:07:09',
            ),
            308 => 
            array (
                'created_at' => '2019-05-03 13:07:56',
                'id' => 309,
                'notification_id' => 205,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 13:07:56',
            ),
            309 => 
            array (
                'created_at' => '2019-05-03 13:13:36',
                'id' => 310,
                'notification_id' => 206,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 13:13:36',
            ),
            310 => 
            array (
                'created_at' => '2019-05-03 13:38:53',
                'id' => 311,
                'notification_id' => 207,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 13:38:53',
            ),
            311 => 
            array (
                'created_at' => '2019-05-03 16:07:26',
                'id' => 312,
                'notification_id' => 209,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 16:07:26',
            ),
            312 => 
            array (
                'created_at' => '2019-05-03 16:12:06',
                'id' => 313,
                'notification_id' => 211,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 16:12:06',
            ),
            313 => 
            array (
                'created_at' => '2019-05-03 16:17:28',
                'id' => 314,
                'notification_id' => 213,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 16:17:28',
            ),
            314 => 
            array (
                'created_at' => '2019-05-03 16:40:17',
                'id' => 315,
                'notification_id' => 214,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-03 16:40:17',
            ),
            315 => 
            array (
                'created_at' => '2019-05-03 16:45:27',
                'id' => 316,
                'notification_id' => 215,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-03 16:45:27',
            ),
            316 => 
            array (
                'created_at' => '2019-05-03 16:46:35',
                'id' => 317,
                'notification_id' => 216,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-03 16:46:35',
            ),
            317 => 
            array (
                'created_at' => '2019-05-03 16:46:57',
                'id' => 318,
                'notification_id' => 217,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-03 16:46:57',
            ),
            318 => 
            array (
                'created_at' => '2019-05-03 17:06:04',
                'id' => 319,
                'notification_id' => 222,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 17:06:04',
            ),
            319 => 
            array (
                'created_at' => '2019-05-03 17:08:06',
                'id' => 320,
                'notification_id' => 223,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-03 17:08:06',
            ),
            320 => 
            array (
                'created_at' => '2019-05-03 17:10:53',
                'id' => 321,
                'notification_id' => 225,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 17:10:53',
            ),
            321 => 
            array (
                'created_at' => '2019-05-03 17:15:26',
                'id' => 322,
                'notification_id' => 224,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165"]',
                'updated_at' => '2019-05-03 17:15:26',
            ),
            322 => 
            array (
                'created_at' => '2019-05-03 17:19:07',
                'id' => 323,
                'notification_id' => 226,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 17:19:07',
            ),
            323 => 
            array (
                'created_at' => '2019-05-03 17:20:33',
                'id' => 324,
                'notification_id' => 227,
                'notified_users' => '[]',
                'updated_at' => '2019-05-03 17:20:33',
            ),
            324 => 
            array (
                'created_at' => '2019-05-03 17:22:03',
                'id' => 325,
                'notification_id' => 228,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 17:22:03',
            ),
            325 => 
            array (
                'created_at' => '2019-05-03 17:22:42',
                'id' => 326,
                'notification_id' => 229,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 17:22:42',
            ),
            326 => 
            array (
                'created_at' => '2019-05-03 17:30:19',
                'id' => 327,
                'notification_id' => 230,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'updated_at' => '2019-05-03 17:30:19',
            ),
            327 => 
            array (
                'created_at' => '2019-05-03 17:42:15',
                'id' => 328,
                'notification_id' => 233,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 17:42:15',
            ),
            328 => 
            array (
                'created_at' => '2019-05-03 17:58:12',
                'id' => 329,
                'notification_id' => 234,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 17:58:12',
            ),
            329 => 
            array (
                'created_at' => '2019-05-03 17:58:46',
                'id' => 330,
                'notification_id' => 235,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165"]',
                'updated_at' => '2019-05-03 17:58:46',
            ),
            330 => 
            array (
                'created_at' => '2019-05-03 18:01:13',
                'id' => 331,
                'notification_id' => 236,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f390832a-c927-33d8-ad20-0ab6a7a3c9bc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'updated_at' => '2019-05-03 18:01:13',
            ),
            331 => 
            array (
                'created_at' => '2019-05-03 18:14:27',
                'id' => 332,
                'notification_id' => 235,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f390832a-c927-33d8-ad20-0ab6a7a3c9bc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 18:14:27',
            ),
            332 => 
            array (
                'created_at' => '2019-05-03 18:25:06',
                'id' => 333,
                'notification_id' => 238,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f390832a-c927-33d8-ad20-0ab6a7a3c9bc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546"]',
                'updated_at' => '2019-05-03 18:25:06',
            ),
            333 => 
            array (
                'created_at' => '2019-05-06 12:35:48',
                'id' => 334,
                'notification_id' => 241,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/06e9ac5a-7b65-3e3c-9c9f-3c5e3db9c719","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a"]',
                'updated_at' => '2019-05-06 12:35:48',
            ),
            334 => 
            array (
                'created_at' => '2019-05-06 13:04:07',
                'id' => 335,
                'notification_id' => 242,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f390832a-c927-33d8-ad20-0ab6a7a3c9bc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3d1ca294-9098-3dc0-8d08-3607e07ca6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8ae0a870-a34b-39d2-9b52-fca78f6eda79","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/5be3c9b4-33e3-3e0c-b535-aa234a4bfed6","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c49a5d90-731a-3aaf-9c14-4dc65c323979"]',
                'updated_at' => '2019-05-06 13:04:07',
            ),
            335 => 
            array (
                'created_at' => '2019-05-06 13:05:06',
                'id' => 336,
                'notification_id' => 243,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f390832a-c927-33d8-ad20-0ab6a7a3c9bc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3d1ca294-9098-3dc0-8d08-3607e07ca6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8ae0a870-a34b-39d2-9b52-fca78f6eda79","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/5be3c9b4-33e3-3e0c-b535-aa234a4bfed6","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c49a5d90-731a-3aaf-9c14-4dc65c323979"]',
                'updated_at' => '2019-05-06 13:05:06',
            ),
            336 => 
            array (
                'created_at' => '2019-05-06 17:31:07',
                'id' => 337,
                'notification_id' => 244,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f390832a-c927-33d8-ad20-0ab6a7a3c9bc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3a1baa9d-960f-34af-a617-6b49e733b546","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3d1ca294-9098-3dc0-8d08-3607e07ca6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8ae0a870-a34b-39d2-9b52-fca78f6eda79","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/5be3c9b4-33e3-3e0c-b535-aa234a4bfed6","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c49a5d90-731a-3aaf-9c14-4dc65c323979","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4687e237-2de0-3b66-b428-787b6eda3611","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7c237ca1-4be0-3880-806f-0bcf15c619aa"]',
                'updated_at' => '2019-05-06 17:31:07',
            ),
            337 => 
            array (
                'created_at' => '2019-05-08 12:53:05',
                'id' => 338,
                'notification_id' => 245,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 12:53:05',
            ),
            338 => 
            array (
                'created_at' => '2019-05-08 13:02:05',
                'id' => 339,
                'notification_id' => 246,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 13:02:05',
            ),
            339 => 
            array (
                'created_at' => '2019-05-08 13:08:05',
                'id' => 340,
                'notification_id' => 247,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 13:08:05',
            ),
            340 => 
            array (
                'created_at' => '2019-05-08 13:13:05',
                'id' => 341,
                'notification_id' => 248,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 13:13:05',
            ),
            341 => 
            array (
                'created_at' => '2019-05-08 13:20:04',
                'id' => 342,
                'notification_id' => 249,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 13:20:04',
            ),
            342 => 
            array (
                'created_at' => '2019-05-08 13:27:05',
                'id' => 343,
                'notification_id' => 250,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 13:27:05',
            ),
            343 => 
            array (
                'created_at' => '2019-05-08 13:28:05',
                'id' => 344,
                'notification_id' => 251,
                'notified_users' => '[697]',
                'updated_at' => '2019-05-08 13:28:05',
            ),
            344 => 
            array (
                'created_at' => '2019-05-09 12:51:05',
                'id' => 345,
                'notification_id' => 252,
                'notified_users' => '[697,714,722]',
                'updated_at' => '2019-05-09 12:51:05',
            ),
            345 => 
            array (
                'created_at' => '2019-05-09 12:53:06',
                'id' => 346,
                'notification_id' => 253,
                'notified_users' => '[697,714,722]',
                'updated_at' => '2019-05-09 12:53:06',
            ),
            346 => 
            array (
                'created_at' => '2019-05-14 16:44:13',
                'id' => 347,
                'notification_id' => 257,
                'notified_users' => '[]',
                'updated_at' => '2019-05-14 16:44:13',
            ),
            347 => 
            array (
                'created_at' => '2019-05-14 16:59:50',
                'id' => 348,
                'notification_id' => 258,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5"]',
                'updated_at' => '2019-05-14 16:59:50',
            ),
            348 => 
            array (
                'created_at' => '2019-05-14 17:03:22',
                'id' => 349,
                'notification_id' => 259,
                'notified_users' => '[]',
                'updated_at' => '2019-05-14 17:03:22',
            ),
            349 => 
            array (
                'created_at' => '2019-05-14 17:03:41',
                'id' => 350,
                'notification_id' => 260,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5"]',
                'updated_at' => '2019-05-14 17:03:41',
            ),
            350 => 
            array (
                'created_at' => '2019-05-14 18:22:11',
                'id' => 351,
                'notification_id' => 261,
                'notified_users' => '[]',
                'updated_at' => '2019-05-14 18:22:11',
            ),
            351 => 
            array (
                'created_at' => '2019-05-14 18:22:32',
                'id' => 352,
                'notification_id' => 262,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5"]',
                'updated_at' => '2019-05-14 18:22:32',
            ),
            352 => 
            array (
                'created_at' => '2019-05-14 18:42:46',
                'id' => 353,
                'notification_id' => 263,
                'notified_users' => '[]',
                'updated_at' => '2019-05-14 18:42:46',
            ),
            353 => 
            array (
                'created_at' => '2019-05-14 18:43:04',
                'id' => 354,
                'notification_id' => 264,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5"]',
                'updated_at' => '2019-05-14 18:43:04',
            ),
            354 => 
            array (
                'created_at' => '2019-05-14 19:31:07',
                'id' => 355,
                'notification_id' => 265,
                'notified_users' => '[697,714,722,724,729]',
                'updated_at' => '2019-05-14 19:31:07',
            ),
            355 => 
            array (
                'created_at' => '2019-05-15 11:15:06',
                'id' => 356,
                'notification_id' => 266,
                'notified_users' => '[697,722,742,714]',
                'updated_at' => '2019-05-15 11:15:06',
            ),
            356 => 
            array (
                'created_at' => '2019-05-15 11:52:07',
                'id' => 357,
                'notification_id' => 267,
                'notified_users' => '[697,714,722,724,729,742]',
                'updated_at' => '2019-05-15 11:52:07',
            ),
            357 => 
            array (
                'created_at' => '2019-05-15 11:52:12',
                'id' => 358,
                'notification_id' => 268,
                'notified_users' => '[697,714,722,724,729,742]',
                'updated_at' => '2019-05-15 11:52:12',
            ),
            358 => 
            array (
                'created_at' => '2019-05-15 11:52:16',
                'id' => 359,
                'notification_id' => 269,
                'notified_users' => '[697,714,722,724,729,742]',
                'updated_at' => '2019-05-15 11:52:16',
            ),
            359 => 
            array (
                'created_at' => '2019-05-15 15:46:07',
                'id' => 360,
                'notification_id' => 270,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-15 15:46:07',
            ),
            360 => 
            array (
                'created_at' => '2019-05-15 16:01:07',
                'id' => 361,
                'notification_id' => 271,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-15 16:01:07',
            ),
            361 => 
            array (
                'created_at' => '2019-05-15 18:21:07',
                'id' => 362,
                'notification_id' => 279,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-15 18:21:07',
            ),
            362 => 
            array (
                'created_at' => '2019-05-15 18:36:06',
                'id' => 363,
                'notification_id' => 280,
                'notified_users' => '[697,722,744,714]',
                'updated_at' => '2019-05-15 18:36:06',
            ),
            363 => 
            array (
                'created_at' => '2019-05-15 18:36:10',
                'id' => 364,
                'notification_id' => 281,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-15 18:36:10',
            ),
            364 => 
            array (
                'created_at' => '2019-05-15 18:41:04',
                'id' => 365,
                'notification_id' => 282,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146"]',
                'updated_at' => '2019-05-15 18:41:04',
            ),
            365 => 
            array (
                'created_at' => '2019-05-15 18:41:20',
                'id' => 366,
                'notification_id' => 283,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146"]',
                'updated_at' => '2019-05-15 18:41:20',
            ),
            366 => 
            array (
                'created_at' => '2019-05-15 19:01:15',
                'id' => 367,
                'notification_id' => 292,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146"]',
                'updated_at' => '2019-05-15 19:01:15',
            ),
            367 => 
            array (
                'created_at' => '2019-05-15 19:01:31',
                'id' => 368,
                'notification_id' => 293,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146"]',
                'updated_at' => '2019-05-15 19:01:31',
            ),
            368 => 
            array (
                'created_at' => '2019-05-15 19:15:38',
                'id' => 369,
                'notification_id' => 302,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5"]',
                'updated_at' => '2019-05-15 19:15:38',
            ),
            369 => 
            array (
                'created_at' => '2019-05-15 19:23:00',
                'id' => 370,
                'notification_id' => 303,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2e0e6139-566a-375f-8e2c-c6ebec4c9fed","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146"]',
                'updated_at' => '2019-05-15 19:23:00',
            ),
            370 => 
            array (
                'created_at' => '2019-05-16 10:40:31',
                'id' => 371,
                'notification_id' => 304,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:40:31',
            ),
            371 => 
            array (
                'created_at' => '2019-05-16 10:40:36',
                'id' => 372,
                'notification_id' => 305,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:40:36',
            ),
            372 => 
            array (
                'created_at' => '2019-05-16 10:40:41',
                'id' => 373,
                'notification_id' => 306,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:40:41',
            ),
            373 => 
            array (
                'created_at' => '2019-05-16 10:40:46',
                'id' => 374,
                'notification_id' => 307,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:40:46',
            ),
            374 => 
            array (
                'created_at' => '2019-05-16 10:40:52',
                'id' => 375,
                'notification_id' => 308,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:40:52',
            ),
            375 => 
            array (
                'created_at' => '2019-05-16 10:40:57',
                'id' => 376,
                'notification_id' => 309,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:40:57',
            ),
            376 => 
            array (
                'created_at' => '2019-05-16 10:41:02',
                'id' => 377,
                'notification_id' => 310,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:41:02',
            ),
            377 => 
            array (
                'created_at' => '2019-05-16 10:41:07',
                'id' => 378,
                'notification_id' => 311,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:41:07',
            ),
            378 => 
            array (
                'created_at' => '2019-05-16 10:41:12',
                'id' => 379,
                'notification_id' => 312,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:41:12',
            ),
            379 => 
            array (
                'created_at' => '2019-05-16 10:41:18',
                'id' => 380,
                'notification_id' => 313,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 10:41:18',
            ),
            380 => 
            array (
                'created_at' => '2019-05-16 16:10:21',
                'id' => 381,
                'notification_id' => 314,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:21',
            ),
            381 => 
            array (
                'created_at' => '2019-05-16 16:10:27',
                'id' => 382,
                'notification_id' => 315,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:27',
            ),
            382 => 
            array (
                'created_at' => '2019-05-16 16:10:33',
                'id' => 383,
                'notification_id' => 316,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:33',
            ),
            383 => 
            array (
                'created_at' => '2019-05-16 16:10:38',
                'id' => 384,
                'notification_id' => 317,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:38',
            ),
            384 => 
            array (
                'created_at' => '2019-05-16 16:10:43',
                'id' => 385,
                'notification_id' => 318,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:43',
            ),
            385 => 
            array (
                'created_at' => '2019-05-16 16:10:50',
                'id' => 386,
                'notification_id' => 319,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:50',
            ),
            386 => 
            array (
                'created_at' => '2019-05-16 16:10:54',
                'id' => 387,
                'notification_id' => 320,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:54',
            ),
            387 => 
            array (
                'created_at' => '2019-05-16 16:10:58',
                'id' => 388,
                'notification_id' => 321,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:10:58',
            ),
            388 => 
            array (
                'created_at' => '2019-05-16 16:11:04',
                'id' => 389,
                'notification_id' => 322,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:04',
            ),
            389 => 
            array (
                'created_at' => '2019-05-16 16:11:09',
                'id' => 390,
                'notification_id' => 323,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:09',
            ),
            390 => 
            array (
                'created_at' => '2019-05-16 16:11:14',
                'id' => 391,
                'notification_id' => 324,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:14',
            ),
            391 => 
            array (
                'created_at' => '2019-05-16 16:11:20',
                'id' => 392,
                'notification_id' => 325,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:20',
            ),
            392 => 
            array (
                'created_at' => '2019-05-16 16:11:24',
                'id' => 393,
                'notification_id' => 326,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:24',
            ),
            393 => 
            array (
                'created_at' => '2019-05-16 16:11:30',
                'id' => 394,
                'notification_id' => 327,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:30',
            ),
            394 => 
            array (
                'created_at' => '2019-05-16 16:11:36',
                'id' => 395,
                'notification_id' => 328,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:36',
            ),
            395 => 
            array (
                'created_at' => '2019-05-16 16:11:41',
                'id' => 396,
                'notification_id' => 329,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:41',
            ),
            396 => 
            array (
                'created_at' => '2019-05-16 16:11:45',
                'id' => 397,
                'notification_id' => 330,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:45',
            ),
            397 => 
            array (
                'created_at' => '2019-05-16 16:11:50',
                'id' => 398,
                'notification_id' => 331,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:50',
            ),
            398 => 
            array (
                'created_at' => '2019-05-16 16:11:54',
                'id' => 399,
                'notification_id' => 332,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:11:54',
            ),
            399 => 
            array (
                'created_at' => '2019-05-16 16:12:00',
                'id' => 400,
                'notification_id' => 333,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:12:00',
            ),
            400 => 
            array (
                'created_at' => '2019-05-16 16:12:04',
                'id' => 401,
                'notification_id' => 334,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:12:04',
            ),
            401 => 
            array (
                'created_at' => '2019-05-16 16:12:08',
                'id' => 402,
                'notification_id' => 335,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:12:08',
            ),
            402 => 
            array (
                'created_at' => '2019-05-16 16:18:12',
                'id' => 403,
                'notification_id' => 336,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:18:12',
            ),
            403 => 
            array (
                'created_at' => '2019-05-16 16:20:34',
                'id' => 404,
                'notification_id' => 337,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:20:34',
            ),
            404 => 
            array (
                'created_at' => '2019-05-16 16:20:40',
                'id' => 405,
                'notification_id' => 338,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:20:40',
            ),
            405 => 
            array (
                'created_at' => '2019-05-16 16:20:45',
                'id' => 406,
                'notification_id' => 339,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:20:45',
            ),
            406 => 
            array (
                'created_at' => '2019-05-16 16:20:51',
                'id' => 407,
                'notification_id' => 340,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:20:51',
            ),
            407 => 
            array (
                'created_at' => '2019-05-16 16:20:56',
                'id' => 408,
                'notification_id' => 341,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:20:56',
            ),
            408 => 
            array (
                'created_at' => '2019-05-16 16:21:00',
                'id' => 409,
                'notification_id' => 342,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:00',
            ),
            409 => 
            array (
                'created_at' => '2019-05-16 16:21:06',
                'id' => 410,
                'notification_id' => 343,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:06',
            ),
            410 => 
            array (
                'created_at' => '2019-05-16 16:21:11',
                'id' => 411,
                'notification_id' => 344,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:11',
            ),
            411 => 
            array (
                'created_at' => '2019-05-16 16:21:17',
                'id' => 412,
                'notification_id' => 345,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:17',
            ),
            412 => 
            array (
                'created_at' => '2019-05-16 16:21:21',
                'id' => 413,
                'notification_id' => 346,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:21',
            ),
            413 => 
            array (
                'created_at' => '2019-05-16 16:21:27',
                'id' => 414,
                'notification_id' => 347,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:27',
            ),
            414 => 
            array (
                'created_at' => '2019-05-16 16:21:32',
                'id' => 415,
                'notification_id' => 348,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:32',
            ),
            415 => 
            array (
                'created_at' => '2019-05-16 16:21:37',
                'id' => 416,
                'notification_id' => 349,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:37',
            ),
            416 => 
            array (
                'created_at' => '2019-05-16 16:21:42',
                'id' => 417,
                'notification_id' => 350,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:42',
            ),
            417 => 
            array (
                'created_at' => '2019-05-16 16:21:48',
                'id' => 418,
                'notification_id' => 351,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:48',
            ),
            418 => 
            array (
                'created_at' => '2019-05-16 16:21:53',
                'id' => 419,
                'notification_id' => 352,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:53',
            ),
            419 => 
            array (
                'created_at' => '2019-05-16 16:21:58',
                'id' => 420,
                'notification_id' => 353,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:21:58',
            ),
            420 => 
            array (
                'created_at' => '2019-05-16 16:22:03',
                'id' => 421,
                'notification_id' => 354,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:22:03',
            ),
            421 => 
            array (
                'created_at' => '2019-05-16 16:22:09',
                'id' => 422,
                'notification_id' => 355,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:22:09',
            ),
            422 => 
            array (
                'created_at' => '2019-05-16 16:22:14',
                'id' => 423,
                'notification_id' => 356,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:22:14',
            ),
            423 => 
            array (
                'created_at' => '2019-05-16 16:40:34',
                'id' => 424,
                'notification_id' => 357,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:40:34',
            ),
            424 => 
            array (
                'created_at' => '2019-05-16 16:40:39',
                'id' => 425,
                'notification_id' => 358,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:40:39',
            ),
            425 => 
            array (
                'created_at' => '2019-05-16 16:40:45',
                'id' => 426,
                'notification_id' => 359,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:40:45',
            ),
            426 => 
            array (
                'created_at' => '2019-05-16 16:40:50',
                'id' => 427,
                'notification_id' => 360,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:40:50',
            ),
            427 => 
            array (
                'created_at' => '2019-05-16 16:40:55',
                'id' => 428,
                'notification_id' => 361,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:40:55',
            ),
            428 => 
            array (
                'created_at' => '2019-05-16 16:41:00',
                'id' => 429,
                'notification_id' => 362,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:00',
            ),
            429 => 
            array (
                'created_at' => '2019-05-16 16:41:05',
                'id' => 430,
                'notification_id' => 363,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:05',
            ),
            430 => 
            array (
                'created_at' => '2019-05-16 16:41:10',
                'id' => 431,
                'notification_id' => 364,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:10',
            ),
            431 => 
            array (
                'created_at' => '2019-05-16 16:41:15',
                'id' => 432,
                'notification_id' => 365,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:15',
            ),
            432 => 
            array (
                'created_at' => '2019-05-16 16:41:21',
                'id' => 433,
                'notification_id' => 366,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:21',
            ),
            433 => 
            array (
                'created_at' => '2019-05-16 16:41:25',
                'id' => 434,
                'notification_id' => 367,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:25',
            ),
            434 => 
            array (
                'created_at' => '2019-05-16 16:41:30',
                'id' => 435,
                'notification_id' => 368,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:30',
            ),
            435 => 
            array (
                'created_at' => '2019-05-16 16:41:35',
                'id' => 436,
                'notification_id' => 369,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:35',
            ),
            436 => 
            array (
                'created_at' => '2019-05-16 16:41:40',
                'id' => 437,
                'notification_id' => 370,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:40',
            ),
            437 => 
            array (
                'created_at' => '2019-05-16 16:41:45',
                'id' => 438,
                'notification_id' => 371,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:45',
            ),
            438 => 
            array (
                'created_at' => '2019-05-16 16:41:50',
                'id' => 439,
                'notification_id' => 372,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:50',
            ),
            439 => 
            array (
                'created_at' => '2019-05-16 16:41:56',
                'id' => 440,
                'notification_id' => 373,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:41:56',
            ),
            440 => 
            array (
                'created_at' => '2019-05-16 16:42:01',
                'id' => 441,
                'notification_id' => 374,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:42:01',
            ),
            441 => 
            array (
                'created_at' => '2019-05-16 16:42:06',
                'id' => 442,
                'notification_id' => 375,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:42:06',
            ),
            442 => 
            array (
                'created_at' => '2019-05-16 16:42:11',
                'id' => 443,
                'notification_id' => 376,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:42:11',
            ),
            443 => 
            array (
                'created_at' => '2019-05-16 16:42:16',
                'id' => 444,
                'notification_id' => 377,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 16:42:16',
            ),
            444 => 
            array (
                'created_at' => '2019-05-16 17:42:42',
                'id' => 446,
                'notification_id' => 379,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:42:42',
            ),
            445 => 
            array (
                'created_at' => '2019-05-16 17:42:47',
                'id' => 447,
                'notification_id' => 380,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:42:47',
            ),
            446 => 
            array (
                'created_at' => '2019-05-16 17:42:53',
                'id' => 448,
                'notification_id' => 381,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:42:53',
            ),
            447 => 
            array (
                'created_at' => '2019-05-16 17:42:59',
                'id' => 449,
                'notification_id' => 382,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:42:59',
            ),
            448 => 
            array (
                'created_at' => '2019-05-16 17:43:04',
                'id' => 450,
                'notification_id' => 383,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:43:04',
            ),
            449 => 
            array (
                'created_at' => '2019-05-16 17:43:09',
                'id' => 451,
                'notification_id' => 384,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:43:09',
            ),
            450 => 
            array (
                'created_at' => '2019-05-16 17:43:14',
                'id' => 452,
                'notification_id' => 385,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:43:14',
            ),
            451 => 
            array (
                'created_at' => '2019-05-16 17:43:19',
                'id' => 453,
                'notification_id' => 386,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:43:19',
            ),
            452 => 
            array (
                'created_at' => '2019-05-16 17:43:25',
                'id' => 454,
                'notification_id' => 387,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:43:25',
            ),
            453 => 
            array (
                'created_at' => '2019-05-16 17:43:31',
                'id' => 455,
                'notification_id' => 388,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:43:31',
            ),
            454 => 
            array (
                'created_at' => '2019-05-16 17:48:07',
                'id' => 456,
                'notification_id' => 389,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:07',
            ),
            455 => 
            array (
                'created_at' => '2019-05-16 17:48:11',
                'id' => 457,
                'notification_id' => 390,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:11',
            ),
            456 => 
            array (
                'created_at' => '2019-05-16 17:48:17',
                'id' => 458,
                'notification_id' => 391,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:17',
            ),
            457 => 
            array (
                'created_at' => '2019-05-16 17:48:22',
                'id' => 459,
                'notification_id' => 392,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:22',
            ),
            458 => 
            array (
                'created_at' => '2019-05-16 17:48:28',
                'id' => 460,
                'notification_id' => 393,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:28',
            ),
            459 => 
            array (
                'created_at' => '2019-05-16 17:48:34',
                'id' => 461,
                'notification_id' => 394,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:34',
            ),
            460 => 
            array (
                'created_at' => '2019-05-16 17:48:39',
                'id' => 462,
                'notification_id' => 395,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:39',
            ),
            461 => 
            array (
                'created_at' => '2019-05-16 17:48:45',
                'id' => 463,
                'notification_id' => 396,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:45',
            ),
            462 => 
            array (
                'created_at' => '2019-05-16 17:48:51',
                'id' => 464,
                'notification_id' => 397,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:51',
            ),
            463 => 
            array (
                'created_at' => '2019-05-16 17:48:56',
                'id' => 465,
                'notification_id' => 398,
                'notified_users' => '[697,714,722,724,729,744]',
                'updated_at' => '2019-05-16 17:48:56',
            ),
            464 => 
            array (
                'created_at' => '2019-05-16 18:23:49',
                'id' => 466,
                'notification_id' => 399,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:23:49',
            ),
            465 => 
            array (
                'created_at' => '2019-05-16 18:23:54',
                'id' => 467,
                'notification_id' => 400,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:23:54',
            ),
            466 => 
            array (
                'created_at' => '2019-05-16 18:23:59',
                'id' => 468,
                'notification_id' => 401,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:23:59',
            ),
            467 => 
            array (
                'created_at' => '2019-05-16 18:24:04',
                'id' => 469,
                'notification_id' => 402,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:04',
            ),
            468 => 
            array (
                'created_at' => '2019-05-16 18:24:07',
                'id' => 470,
                'notification_id' => 403,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:07',
            ),
            469 => 
            array (
                'created_at' => '2019-05-16 18:24:10',
                'id' => 471,
                'notification_id' => 404,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:10',
            ),
            470 => 
            array (
                'created_at' => '2019-05-16 18:24:13',
                'id' => 472,
                'notification_id' => 405,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:13',
            ),
            471 => 
            array (
                'created_at' => '2019-05-16 18:24:18',
                'id' => 473,
                'notification_id' => 406,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:18',
            ),
            472 => 
            array (
                'created_at' => '2019-05-16 18:24:23',
                'id' => 474,
                'notification_id' => 407,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:23',
            ),
            473 => 
            array (
                'created_at' => '2019-05-16 18:24:26',
                'id' => 475,
                'notification_id' => 408,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:26',
            ),
            474 => 
            array (
                'created_at' => '2019-05-16 18:24:32',
                'id' => 476,
                'notification_id' => 409,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:32',
            ),
            475 => 
            array (
                'created_at' => '2019-05-16 18:24:37',
                'id' => 477,
                'notification_id' => 410,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:37',
            ),
            476 => 
            array (
                'created_at' => '2019-05-16 18:24:42',
                'id' => 478,
                'notification_id' => 411,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:42',
            ),
            477 => 
            array (
                'created_at' => '2019-05-16 18:24:47',
                'id' => 479,
                'notification_id' => 412,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:47',
            ),
            478 => 
            array (
                'created_at' => '2019-05-16 18:24:51',
                'id' => 480,
                'notification_id' => 413,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:51',
            ),
            479 => 
            array (
                'created_at' => '2019-05-16 18:24:57',
                'id' => 481,
                'notification_id' => 414,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:24:57',
            ),
            480 => 
            array (
                'created_at' => '2019-05-16 18:25:00',
                'id' => 482,
                'notification_id' => 415,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:25:00',
            ),
            481 => 
            array (
                'created_at' => '2019-05-16 18:25:05',
                'id' => 483,
                'notification_id' => 416,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:25:05',
            ),
            482 => 
            array (
                'created_at' => '2019-05-16 18:25:11',
                'id' => 484,
                'notification_id' => 417,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:25:11',
            ),
            483 => 
            array (
                'created_at' => '2019-05-16 18:25:16',
                'id' => 485,
                'notification_id' => 418,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:25:16',
            ),
            484 => 
            array (
                'created_at' => '2019-05-16 18:53:00',
                'id' => 486,
                'notification_id' => 419,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:00',
            ),
            485 => 
            array (
                'created_at' => '2019-05-16 18:53:05',
                'id' => 487,
                'notification_id' => 420,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:05',
            ),
            486 => 
            array (
                'created_at' => '2019-05-16 18:53:10',
                'id' => 488,
                'notification_id' => 421,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:10',
            ),
            487 => 
            array (
                'created_at' => '2019-05-16 18:53:15',
                'id' => 489,
                'notification_id' => 422,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:15',
            ),
            488 => 
            array (
                'created_at' => '2019-05-16 18:53:18',
                'id' => 490,
                'notification_id' => 423,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:18',
            ),
            489 => 
            array (
                'created_at' => '2019-05-16 18:53:24',
                'id' => 491,
                'notification_id' => 424,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:24',
            ),
            490 => 
            array (
                'created_at' => '2019-05-16 18:53:29',
                'id' => 492,
                'notification_id' => 425,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:29',
            ),
            491 => 
            array (
                'created_at' => '2019-05-16 18:53:33',
                'id' => 493,
                'notification_id' => 426,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:33',
            ),
            492 => 
            array (
                'created_at' => '2019-05-16 18:53:38',
                'id' => 494,
                'notification_id' => 427,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:38',
            ),
            493 => 
            array (
                'created_at' => '2019-05-16 18:53:43',
                'id' => 495,
                'notification_id' => 428,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 18:53:43',
            ),
            494 => 
            array (
                'created_at' => '2019-05-16 19:29:19',
                'id' => 496,
                'notification_id' => 429,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:19',
            ),
            495 => 
            array (
                'created_at' => '2019-05-16 19:29:24',
                'id' => 497,
                'notification_id' => 430,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:24',
            ),
            496 => 
            array (
                'created_at' => '2019-05-16 19:29:29',
                'id' => 498,
                'notification_id' => 431,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:29',
            ),
            497 => 
            array (
                'created_at' => '2019-05-16 19:29:34',
                'id' => 499,
                'notification_id' => 432,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:34',
            ),
            498 => 
            array (
                'created_at' => '2019-05-16 19:29:37',
                'id' => 500,
                'notification_id' => 433,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:37',
            ),
            499 => 
            array (
                'created_at' => '2019-05-16 19:29:42',
                'id' => 501,
                'notification_id' => 434,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:42',
            ),
        ));
        \DB::table('notification_users')->insert(array (
            0 => 
            array (
                'created_at' => '2019-05-16 19:29:46',
                'id' => 502,
                'notification_id' => 435,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:46',
            ),
            1 => 
            array (
                'created_at' => '2019-05-16 19:29:50',
                'id' => 503,
                'notification_id' => 436,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:50',
            ),
            2 => 
            array (
                'created_at' => '2019-05-16 19:29:56',
                'id' => 504,
                'notification_id' => 437,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:29:56',
            ),
            3 => 
            array (
                'created_at' => '2019-05-16 19:30:01',
                'id' => 505,
                'notification_id' => 438,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:01',
            ),
            4 => 
            array (
                'created_at' => '2019-05-16 19:30:07',
                'id' => 506,
                'notification_id' => 439,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:07',
            ),
            5 => 
            array (
                'created_at' => '2019-05-16 19:30:12',
                'id' => 507,
                'notification_id' => 440,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:12',
            ),
            6 => 
            array (
                'created_at' => '2019-05-16 19:30:17',
                'id' => 508,
                'notification_id' => 441,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:17',
            ),
            7 => 
            array (
                'created_at' => '2019-05-16 19:30:22',
                'id' => 509,
                'notification_id' => 442,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:22',
            ),
            8 => 
            array (
                'created_at' => '2019-05-16 19:30:27',
                'id' => 510,
                'notification_id' => 443,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:27',
            ),
            9 => 
            array (
                'created_at' => '2019-05-16 19:30:32',
                'id' => 511,
                'notification_id' => 444,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:32',
            ),
            10 => 
            array (
                'created_at' => '2019-05-16 19:30:37',
                'id' => 512,
                'notification_id' => 445,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:37',
            ),
            11 => 
            array (
                'created_at' => '2019-05-16 19:30:42',
                'id' => 513,
                'notification_id' => 446,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:42',
            ),
            12 => 
            array (
                'created_at' => '2019-05-16 19:30:46',
                'id' => 514,
                'notification_id' => 447,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:46',
            ),
            13 => 
            array (
                'created_at' => '2019-05-16 19:30:51',
                'id' => 515,
                'notification_id' => 448,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-16 19:30:51',
            ),
            14 => 
            array (
                'created_at' => '2019-05-17 15:26:06',
                'id' => 516,
                'notification_id' => 449,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:06',
            ),
            15 => 
            array (
                'created_at' => '2019-05-17 15:26:10',
                'id' => 517,
                'notification_id' => 450,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:10',
            ),
            16 => 
            array (
                'created_at' => '2019-05-17 15:26:15',
                'id' => 518,
                'notification_id' => 451,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:15',
            ),
            17 => 
            array (
                'created_at' => '2019-05-17 15:26:20',
                'id' => 519,
                'notification_id' => 452,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:20',
            ),
            18 => 
            array (
                'created_at' => '2019-05-17 15:26:25',
                'id' => 520,
                'notification_id' => 453,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:25',
            ),
            19 => 
            array (
                'created_at' => '2019-05-17 15:26:30',
                'id' => 521,
                'notification_id' => 454,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:30',
            ),
            20 => 
            array (
                'created_at' => '2019-05-17 15:26:35',
                'id' => 522,
                'notification_id' => 455,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:35',
            ),
            21 => 
            array (
                'created_at' => '2019-05-17 15:26:40',
                'id' => 523,
                'notification_id' => 456,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:40',
            ),
            22 => 
            array (
                'created_at' => '2019-05-17 15:26:45',
                'id' => 524,
                'notification_id' => 457,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:45',
            ),
            23 => 
            array (
                'created_at' => '2019-05-17 15:26:50',
                'id' => 525,
                'notification_id' => 458,
                'notified_users' => '[697,722,741,744,714]',
                'updated_at' => '2019-05-17 15:26:50',
            ),
            24 => 
            array (
                'created_at' => '2019-05-20 15:29:35',
                'id' => 526,
                'notification_id' => 459,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:29:35',
            ),
            25 => 
            array (
                'created_at' => '2019-05-20 15:29:42',
                'id' => 527,
                'notification_id' => 460,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:29:42',
            ),
            26 => 
            array (
                'created_at' => '2019-05-20 15:29:48',
                'id' => 528,
                'notification_id' => 461,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:29:48',
            ),
            27 => 
            array (
                'created_at' => '2019-05-20 15:29:54',
                'id' => 529,
                'notification_id' => 462,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:29:54',
            ),
            28 => 
            array (
                'created_at' => '2019-05-20 15:30:00',
                'id' => 530,
                'notification_id' => 463,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:30:00',
            ),
            29 => 
            array (
                'created_at' => '2019-05-20 15:30:06',
                'id' => 531,
                'notification_id' => 464,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:30:06',
            ),
            30 => 
            array (
                'created_at' => '2019-05-20 15:30:12',
                'id' => 532,
                'notification_id' => 465,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:30:12',
            ),
            31 => 
            array (
                'created_at' => '2019-05-20 15:30:18',
                'id' => 533,
                'notification_id' => 466,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:30:18',
            ),
            32 => 
            array (
                'created_at' => '2019-05-20 15:30:24',
                'id' => 534,
                'notification_id' => 467,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:30:24',
            ),
            33 => 
            array (
                'created_at' => '2019-05-20 15:30:30',
                'id' => 535,
                'notification_id' => 468,
                'notified_users' => '[697,714,722,724,729,741,744]',
                'updated_at' => '2019-05-20 15:30:30',
            ),
            34 => 
            array (
                'created_at' => '2019-05-21 11:48:09',
                'id' => 536,
                'notification_id' => 469,
                'notified_users' => '[697,714,722,724,729,741,744,748,749]',
                'updated_at' => '2019-05-21 11:48:09',
            ),
            35 => 
            array (
                'created_at' => '2019-05-21 13:43:09',
                'id' => 537,
                'notification_id' => 470,
                'notified_users' => '[697,714,741,744,748,749]',
                'updated_at' => '2019-05-21 13:43:09',
            ),
            36 => 
            array (
                'created_at' => '2019-05-21 18:05:48',
                'id' => 538,
                'notification_id' => 473,
                'notified_users' => '[779]',
                'updated_at' => '2019-05-21 18:05:48',
            ),
            37 => 
            array (
                'created_at' => '2019-05-23 11:05:13',
                'id' => 539,
                'notification_id' => 475,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,751,781]',
                'updated_at' => '2019-05-23 11:05:13',
            ),
            38 => 
            array (
                'created_at' => '2019-05-23 11:29:28',
                'id' => 540,
                'notification_id' => 476,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,751,781]',
                'updated_at' => '2019-05-23 11:29:28',
            ),
            39 => 
            array (
                'created_at' => '2019-05-23 11:29:39',
                'id' => 541,
                'notification_id' => 477,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,751,781]',
                'updated_at' => '2019-05-23 11:29:39',
            ),
            40 => 
            array (
                'created_at' => '2019-05-23 11:29:50',
                'id' => 542,
                'notification_id' => 478,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,751,781]',
                'updated_at' => '2019-05-23 11:29:50',
            ),
            41 => 
            array (
                'created_at' => '2019-05-23 11:30:00',
                'id' => 543,
                'notification_id' => 479,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,751,781]',
                'updated_at' => '2019-05-23 11:30:00',
            ),
            42 => 
            array (
                'created_at' => '2019-05-24 13:01:51',
                'id' => 544,
                'notification_id' => 489,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:01:51',
            ),
            43 => 
            array (
                'created_at' => '2019-05-24 13:02:22',
                'id' => 545,
                'notification_id' => 490,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:02:22',
            ),
            44 => 
            array (
                'created_at' => '2019-05-24 13:02:35',
                'id' => 546,
                'notification_id' => 491,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:02:35',
            ),
            45 => 
            array (
                'created_at' => '2019-05-24 13:02:53',
                'id' => 547,
                'notification_id' => 492,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:02:53',
            ),
            46 => 
            array (
                'created_at' => '2019-05-24 13:03:06',
                'id' => 548,
                'notification_id' => 493,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:03:06',
            ),
            47 => 
            array (
                'created_at' => '2019-05-24 13:03:24',
                'id' => 549,
                'notification_id' => 494,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:03:24',
            ),
            48 => 
            array (
                'created_at' => '2019-05-24 13:03:36',
                'id' => 550,
                'notification_id' => 495,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:03:36',
            ),
            49 => 
            array (
                'created_at' => '2019-05-24 13:03:54',
                'id' => 551,
                'notification_id' => 496,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:03:54',
            ),
            50 => 
            array (
                'created_at' => '2019-05-24 13:04:08',
                'id' => 552,
                'notification_id' => 497,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 13:04:08',
            ),
            51 => 
            array (
                'created_at' => '2019-05-24 15:48:24',
                'id' => 553,
                'notification_id' => 498,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 15:48:24',
            ),
            52 => 
            array (
                'created_at' => '2019-05-24 15:48:39',
                'id' => 554,
                'notification_id' => 499,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 15:48:39',
            ),
            53 => 
            array (
                'created_at' => '2019-05-24 15:50:52',
                'id' => 555,
                'notification_id' => 500,
                'notified_users' => '[697,722,741,744,748,749,781,784,785,714]',
                'updated_at' => '2019-05-24 15:50:52',
            ),
            54 => 
            array (
                'created_at' => '2019-05-24 15:51:06',
                'id' => 556,
                'notification_id' => 501,
                'notified_users' => '[697,722,741,744,748,749,781,784,785,714]',
                'updated_at' => '2019-05-24 15:51:06',
            ),
            55 => 
            array (
                'created_at' => '2019-05-24 15:51:47',
                'id' => 557,
                'notification_id' => 503,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:51:47',
            ),
            56 => 
            array (
                'created_at' => '2019-05-24 15:51:52',
                'id' => 558,
                'notification_id' => 504,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:51:52',
            ),
            57 => 
            array (
                'created_at' => '2019-05-24 15:51:57',
                'id' => 559,
                'notification_id' => 505,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:51:57',
            ),
            58 => 
            array (
                'created_at' => '2019-05-24 15:52:03',
                'id' => 560,
                'notification_id' => 506,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:03',
            ),
            59 => 
            array (
                'created_at' => '2019-05-24 15:52:09',
                'id' => 561,
                'notification_id' => 507,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:09',
            ),
            60 => 
            array (
                'created_at' => '2019-05-24 15:52:13',
                'id' => 562,
                'notification_id' => 508,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:13',
            ),
            61 => 
            array (
                'created_at' => '2019-05-24 15:52:19',
                'id' => 563,
                'notification_id' => 509,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:19',
            ),
            62 => 
            array (
                'created_at' => '2019-05-24 15:52:24',
                'id' => 564,
                'notification_id' => 510,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:24',
            ),
            63 => 
            array (
                'created_at' => '2019-05-24 15:52:29',
                'id' => 565,
                'notification_id' => 511,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:29',
            ),
            64 => 
            array (
                'created_at' => '2019-05-24 15:52:34',
                'id' => 566,
                'notification_id' => 512,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:34',
            ),
            65 => 
            array (
                'created_at' => '2019-05-24 15:52:40',
                'id' => 567,
                'notification_id' => 513,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:40',
            ),
            66 => 
            array (
                'created_at' => '2019-05-24 15:52:45',
                'id' => 568,
                'notification_id' => 514,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:45',
            ),
            67 => 
            array (
                'created_at' => '2019-05-24 15:52:51',
                'id' => 569,
                'notification_id' => 515,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:51',
            ),
            68 => 
            array (
                'created_at' => '2019-05-24 15:52:56',
                'id' => 570,
                'notification_id' => 516,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:52:56',
            ),
            69 => 
            array (
                'created_at' => '2019-05-24 15:53:01',
                'id' => 571,
                'notification_id' => 517,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 15:53:01',
            ),
            70 => 
            array (
                'created_at' => '2019-05-24 16:00:04',
                'id' => 572,
                'notification_id' => 307,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,784,785]',
                'updated_at' => '2019-05-24 16:00:04',
            ),
            71 => 
            array (
                'created_at' => '2019-05-24 16:14:54',
                'id' => 573,
                'notification_id' => 519,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:14:54',
            ),
            72 => 
            array (
                'created_at' => '2019-05-24 16:15:04',
                'id' => 574,
                'notification_id' => 520,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:04',
            ),
            73 => 
            array (
                'created_at' => '2019-05-24 16:15:09',
                'id' => 575,
                'notification_id' => 521,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:09',
            ),
            74 => 
            array (
                'created_at' => '2019-05-24 16:15:15',
                'id' => 576,
                'notification_id' => 522,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:15',
            ),
            75 => 
            array (
                'created_at' => '2019-05-24 16:15:20',
                'id' => 577,
                'notification_id' => 523,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:20',
            ),
            76 => 
            array (
                'created_at' => '2019-05-24 16:15:25',
                'id' => 578,
                'notification_id' => 524,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:25',
            ),
            77 => 
            array (
                'created_at' => '2019-05-24 16:15:31',
                'id' => 579,
                'notification_id' => 525,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:31',
            ),
            78 => 
            array (
                'created_at' => '2019-05-24 16:15:36',
                'id' => 580,
                'notification_id' => 526,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:36',
            ),
            79 => 
            array (
                'created_at' => '2019-05-24 16:15:41',
                'id' => 581,
                'notification_id' => 527,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:41',
            ),
            80 => 
            array (
                'created_at' => '2019-05-24 16:15:46',
                'id' => 582,
                'notification_id' => 528,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:46',
            ),
            81 => 
            array (
                'created_at' => '2019-05-24 16:15:51',
                'id' => 583,
                'notification_id' => 529,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:51',
            ),
            82 => 
            array (
                'created_at' => '2019-05-24 16:15:56',
                'id' => 584,
                'notification_id' => 530,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:15:56',
            ),
            83 => 
            array (
                'created_at' => '2019-05-24 16:16:01',
                'id' => 585,
                'notification_id' => 531,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:16:01',
            ),
            84 => 
            array (
                'created_at' => '2019-05-24 16:16:07',
                'id' => 586,
                'notification_id' => 532,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:16:07',
            ),
            85 => 
            array (
                'created_at' => '2019-05-24 16:16:12',
                'id' => 587,
                'notification_id' => 533,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:16:12',
            ),
            86 => 
            array (
                'created_at' => '2019-05-24 16:16:17',
                'id' => 588,
                'notification_id' => 534,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-24 16:16:17',
            ),
            87 => 
            array (
                'created_at' => '2019-05-24 17:59:10',
                'id' => 589,
                'notification_id' => 543,
                'notified_users' => '[697,714,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-24 17:59:10',
            ),
            88 => 
            array (
                'created_at' => '2019-05-27 16:25:05',
                'id' => 590,
                'notification_id' => 547,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:25:05',
            ),
            89 => 
            array (
                'created_at' => '2019-05-27 16:25:17',
                'id' => 591,
                'notification_id' => 548,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:25:17',
            ),
            90 => 
            array (
                'created_at' => '2019-05-27 16:25:31',
                'id' => 592,
                'notification_id' => 549,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:25:31',
            ),
            91 => 
            array (
                'created_at' => '2019-05-27 16:25:43',
                'id' => 593,
                'notification_id' => 550,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:25:43',
            ),
            92 => 
            array (
                'created_at' => '2019-05-27 16:25:55',
                'id' => 594,
                'notification_id' => 551,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:25:55',
            ),
            93 => 
            array (
                'created_at' => '2019-05-27 16:26:03',
                'id' => 595,
                'notification_id' => 552,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:26:03',
            ),
            94 => 
            array (
                'created_at' => '2019-05-27 16:26:18',
                'id' => 596,
                'notification_id' => 553,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:26:18',
            ),
            95 => 
            array (
                'created_at' => '2019-05-27 16:26:30',
                'id' => 597,
                'notification_id' => 554,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:26:30',
            ),
            96 => 
            array (
                'created_at' => '2019-05-27 16:26:43',
                'id' => 598,
                'notification_id' => 555,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:26:43',
            ),
            97 => 
            array (
                'created_at' => '2019-05-27 16:26:58',
                'id' => 599,
                'notification_id' => 556,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:26:58',
            ),
            98 => 
            array (
                'created_at' => '2019-05-27 16:27:11',
                'id' => 600,
                'notification_id' => 557,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:27:11',
            ),
            99 => 
            array (
                'created_at' => '2019-05-27 16:27:23',
                'id' => 601,
                'notification_id' => 558,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:27:23',
            ),
            100 => 
            array (
                'created_at' => '2019-05-27 16:27:37',
                'id' => 602,
                'notification_id' => 559,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:27:37',
            ),
            101 => 
            array (
                'created_at' => '2019-05-27 16:27:49',
                'id' => 603,
                'notification_id' => 560,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:27:49',
            ),
            102 => 
            array (
                'created_at' => '2019-05-27 16:28:01',
                'id' => 604,
                'notification_id' => 561,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:28:01',
            ),
            103 => 
            array (
                'created_at' => '2019-05-27 16:28:11',
                'id' => 605,
                'notification_id' => 562,
                'notified_users' => '[697,722,741,744,748,749,781,782,784,785,714]',
                'updated_at' => '2019-05-27 16:28:11',
            ),
            104 => 
            array (
                'created_at' => '2019-05-27 16:28:21',
                'id' => 606,
                'notification_id' => 563,
                'notified_users' => '[697,722,741,744,748,749,781,782,784,785,714]',
                'updated_at' => '2019-05-27 16:28:21',
            ),
            105 => 
            array (
                'created_at' => '2019-05-27 16:28:31',
                'id' => 607,
                'notification_id' => 564,
                'notified_users' => '[697,722,741,744,748,749,781,782,784,785,714]',
                'updated_at' => '2019-05-27 16:28:31',
            ),
            106 => 
            array (
                'created_at' => '2019-05-27 16:28:38',
                'id' => 608,
                'notification_id' => 565,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:28:38',
            ),
            107 => 
            array (
                'created_at' => '2019-05-27 16:28:47',
                'id' => 609,
                'notification_id' => 566,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:28:47',
            ),
            108 => 
            array (
                'created_at' => '2019-05-27 16:28:52',
                'id' => 610,
                'notification_id' => 567,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:28:52',
            ),
            109 => 
            array (
                'created_at' => '2019-05-27 16:28:57',
                'id' => 611,
                'notification_id' => 568,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:28:57',
            ),
            110 => 
            array (
                'created_at' => '2019-05-27 16:29:03',
                'id' => 612,
                'notification_id' => 569,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:03',
            ),
            111 => 
            array (
                'created_at' => '2019-05-27 16:29:08',
                'id' => 613,
                'notification_id' => 570,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:08',
            ),
            112 => 
            array (
                'created_at' => '2019-05-27 16:29:14',
                'id' => 614,
                'notification_id' => 571,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:14',
            ),
            113 => 
            array (
                'created_at' => '2019-05-27 16:29:19',
                'id' => 615,
                'notification_id' => 572,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:19',
            ),
            114 => 
            array (
                'created_at' => '2019-05-27 16:29:24',
                'id' => 616,
                'notification_id' => 573,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:24',
            ),
            115 => 
            array (
                'created_at' => '2019-05-27 16:29:29',
                'id' => 617,
                'notification_id' => 574,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:29',
            ),
            116 => 
            array (
                'created_at' => '2019-05-27 16:29:35',
                'id' => 618,
                'notification_id' => 575,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:35',
            ),
            117 => 
            array (
                'created_at' => '2019-05-27 16:29:41',
                'id' => 619,
                'notification_id' => 576,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:41',
            ),
            118 => 
            array (
                'created_at' => '2019-05-27 16:29:46',
                'id' => 620,
                'notification_id' => 577,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:46',
            ),
            119 => 
            array (
                'created_at' => '2019-05-27 16:29:51',
                'id' => 621,
                'notification_id' => 578,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:51',
            ),
            120 => 
            array (
                'created_at' => '2019-05-27 16:29:56',
                'id' => 622,
                'notification_id' => 579,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:29:56',
            ),
            121 => 
            array (
                'created_at' => '2019-05-27 16:30:02',
                'id' => 623,
                'notification_id' => 580,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:30:02',
            ),
            122 => 
            array (
                'created_at' => '2019-05-27 16:30:07',
                'id' => 624,
                'notification_id' => 581,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:30:07',
            ),
            123 => 
            array (
                'created_at' => '2019-05-27 16:30:13',
                'id' => 625,
                'notification_id' => 582,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:30:13',
            ),
            124 => 
            array (
                'created_at' => '2019-05-27 16:30:18',
                'id' => 626,
                'notification_id' => 583,
                'notified_users' => '[784,785]',
                'updated_at' => '2019-05-27 16:30:18',
            ),
            125 => 
            array (
                'created_at' => '2019-05-27 16:30:32',
                'id' => 627,
                'notification_id' => 584,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:30:32',
            ),
            126 => 
            array (
                'created_at' => '2019-05-27 16:30:44',
                'id' => 628,
                'notification_id' => 585,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:30:44',
            ),
            127 => 
            array (
                'created_at' => '2019-05-27 16:30:56',
                'id' => 629,
                'notification_id' => 586,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:30:56',
            ),
            128 => 
            array (
                'created_at' => '2019-05-27 16:31:08',
                'id' => 630,
                'notification_id' => 587,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:31:08',
            ),
            129 => 
            array (
                'created_at' => '2019-05-27 16:31:21',
                'id' => 631,
                'notification_id' => 588,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785]',
                'updated_at' => '2019-05-27 16:31:21',
            ),
            130 => 
            array (
                'created_at' => '2019-05-28 15:12:11',
                'id' => 632,
                'notification_id' => 597,
                'notified_users' => '[812,813]',
                'updated_at' => '2019-05-28 15:12:11',
            ),
            131 => 
            array (
                'created_at' => '2019-05-28 16:05:25',
                'id' => 633,
                'notification_id' => 603,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:05:25',
            ),
            132 => 
            array (
                'created_at' => '2019-05-28 16:05:40',
                'id' => 634,
                'notification_id' => 604,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:05:40',
            ),
            133 => 
            array (
                'created_at' => '2019-05-28 16:05:55',
                'id' => 635,
                'notification_id' => 605,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:05:55',
            ),
            134 => 
            array (
                'created_at' => '2019-05-28 16:06:11',
                'id' => 636,
                'notification_id' => 606,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:06:11',
            ),
            135 => 
            array (
                'created_at' => '2019-05-28 16:06:27',
                'id' => 637,
                'notification_id' => 607,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:06:27',
            ),
            136 => 
            array (
                'created_at' => '2019-05-28 16:06:42',
                'id' => 638,
                'notification_id' => 608,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:06:42',
            ),
            137 => 
            array (
                'created_at' => '2019-05-28 16:06:58',
                'id' => 639,
                'notification_id' => 609,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:06:58',
            ),
            138 => 
            array (
                'created_at' => '2019-05-28 16:07:13',
                'id' => 640,
                'notification_id' => 610,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:07:13',
            ),
            139 => 
            array (
                'created_at' => '2019-05-28 16:07:29',
                'id' => 641,
                'notification_id' => 611,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:07:29',
            ),
            140 => 
            array (
                'created_at' => '2019-05-28 16:07:44',
                'id' => 642,
                'notification_id' => 612,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:07:44',
            ),
            141 => 
            array (
                'created_at' => '2019-05-28 16:08:00',
                'id' => 643,
                'notification_id' => 613,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:08:00',
            ),
            142 => 
            array (
                'created_at' => '2019-05-28 16:08:16',
                'id' => 644,
                'notification_id' => 614,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:08:16',
            ),
            143 => 
            array (
                'created_at' => '2019-05-28 16:08:32',
                'id' => 645,
                'notification_id' => 615,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:08:32',
            ),
            144 => 
            array (
                'created_at' => '2019-05-28 16:08:48',
                'id' => 646,
                'notification_id' => 616,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:08:48',
            ),
            145 => 
            array (
                'created_at' => '2019-05-28 16:09:04',
                'id' => 647,
                'notification_id' => 617,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:09:04',
            ),
            146 => 
            array (
                'created_at' => '2019-05-28 16:09:19',
                'id' => 648,
                'notification_id' => 618,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:09:19',
            ),
            147 => 
            array (
                'created_at' => '2019-05-28 16:09:35',
                'id' => 649,
                'notification_id' => 619,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:09:35',
            ),
            148 => 
            array (
                'created_at' => '2019-05-28 16:09:51',
                'id' => 650,
                'notification_id' => 620,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:09:51',
            ),
            149 => 
            array (
                'created_at' => '2019-05-28 16:10:07',
                'id' => 651,
                'notification_id' => 621,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:10:07',
            ),
            150 => 
            array (
                'created_at' => '2019-05-28 16:31:11',
                'id' => 652,
                'notification_id' => 636,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:31:11',
            ),
            151 => 
            array (
                'created_at' => '2019-05-28 16:31:27',
                'id' => 653,
                'notification_id' => 637,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:31:27',
            ),
            152 => 
            array (
                'created_at' => '2019-05-28 16:31:43',
                'id' => 654,
                'notification_id' => 638,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:31:43',
            ),
            153 => 
            array (
                'created_at' => '2019-05-28 16:31:59',
                'id' => 655,
                'notification_id' => 639,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:31:59',
            ),
            154 => 
            array (
                'created_at' => '2019-05-28 16:32:15',
                'id' => 656,
                'notification_id' => 640,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:32:15',
            ),
            155 => 
            array (
                'created_at' => '2019-05-28 16:32:31',
                'id' => 657,
                'notification_id' => 641,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:32:31',
            ),
            156 => 
            array (
                'created_at' => '2019-05-28 16:32:46',
                'id' => 658,
                'notification_id' => 642,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:32:46',
            ),
            157 => 
            array (
                'created_at' => '2019-05-28 16:33:02',
                'id' => 659,
                'notification_id' => 643,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:33:02',
            ),
            158 => 
            array (
                'created_at' => '2019-05-28 16:33:19',
                'id' => 660,
                'notification_id' => 644,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:33:19',
            ),
            159 => 
            array (
                'created_at' => '2019-05-28 16:33:34',
                'id' => 661,
                'notification_id' => 645,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 16:33:34',
            ),
            160 => 
            array (
                'created_at' => '2019-05-28 16:40:30',
                'id' => 662,
                'notification_id' => 664,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,811]',
                'updated_at' => '2019-05-28 16:40:30',
            ),
            161 => 
            array (
                'created_at' => '2019-05-28 17:10:54',
                'id' => 663,
                'notification_id' => 666,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:10:54',
            ),
            162 => 
            array (
                'created_at' => '2019-05-28 17:10:58',
                'id' => 664,
                'notification_id' => 667,
                'notified_users' => '[784,785,797,799,812,813,815,816,811]',
                'updated_at' => '2019-05-28 17:10:58',
            ),
            163 => 
            array (
                'created_at' => '2019-05-28 17:11:11',
                'id' => 665,
                'notification_id' => 668,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:11:11',
            ),
            164 => 
            array (
                'created_at' => '2019-05-28 17:11:27',
                'id' => 666,
                'notification_id' => 669,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:11:27',
            ),
            165 => 
            array (
                'created_at' => '2019-05-28 17:11:42',
                'id' => 667,
                'notification_id' => 670,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:11:42',
            ),
            166 => 
            array (
                'created_at' => '2019-05-28 17:11:58',
                'id' => 668,
                'notification_id' => 671,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:11:58',
            ),
            167 => 
            array (
                'created_at' => '2019-05-28 17:12:13',
                'id' => 669,
                'notification_id' => 672,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:12:13',
            ),
            168 => 
            array (
                'created_at' => '2019-05-28 17:12:29',
                'id' => 670,
                'notification_id' => 673,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:12:29',
            ),
            169 => 
            array (
                'created_at' => '2019-05-28 17:12:45',
                'id' => 671,
                'notification_id' => 674,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:12:45',
            ),
            170 => 
            array (
                'created_at' => '2019-05-28 17:13:00',
                'id' => 672,
                'notification_id' => 675,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:13:00',
            ),
            171 => 
            array (
                'created_at' => '2019-05-28 17:13:15',
                'id' => 673,
                'notification_id' => 676,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:13:15',
            ),
            172 => 
            array (
                'created_at' => '2019-05-28 17:36:38',
                'id' => 674,
                'notification_id' => 677,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:36:38',
            ),
            173 => 
            array (
                'created_at' => '2019-05-28 17:42:47',
                'id' => 675,
                'notification_id' => 678,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:42:47',
            ),
            174 => 
            array (
                'created_at' => '2019-05-28 17:48:02',
                'id' => 676,
                'notification_id' => 679,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:48:02',
            ),
            175 => 
            array (
                'created_at' => '2019-05-28 17:48:17',
                'id' => 677,
                'notification_id' => 680,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:48:17',
            ),
            176 => 
            array (
                'created_at' => '2019-05-28 17:48:31',
                'id' => 678,
                'notification_id' => 681,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:48:31',
            ),
            177 => 
            array (
                'created_at' => '2019-05-28 17:48:45',
                'id' => 679,
                'notification_id' => 682,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:48:45',
            ),
            178 => 
            array (
                'created_at' => '2019-05-28 17:49:00',
                'id' => 680,
                'notification_id' => 683,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:49:00',
            ),
            179 => 
            array (
                'created_at' => '2019-05-28 17:49:16',
                'id' => 681,
                'notification_id' => 684,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:49:16',
            ),
            180 => 
            array (
                'created_at' => '2019-05-28 17:49:31',
                'id' => 682,
                'notification_id' => 685,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:49:31',
            ),
            181 => 
            array (
                'created_at' => '2019-05-28 17:49:46',
                'id' => 683,
                'notification_id' => 686,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:49:46',
            ),
            182 => 
            array (
                'created_at' => '2019-05-28 17:50:01',
                'id' => 684,
                'notification_id' => 687,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:50:01',
            ),
            183 => 
            array (
                'created_at' => '2019-05-28 17:50:16',
                'id' => 685,
                'notification_id' => 688,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816]',
                'updated_at' => '2019-05-28 17:50:16',
            ),
            184 => 
            array (
                'created_at' => '2019-05-28 19:22:03',
                'id' => 686,
                'notification_id' => 689,
                'notified_users' => '[658]',
                'updated_at' => '2019-05-28 19:22:03',
            ),
            185 => 
            array (
                'created_at' => '2019-05-28 19:34:05',
                'id' => 687,
                'notification_id' => 690,
                'notified_users' => '[658,815]',
                'updated_at' => '2019-05-28 19:34:05',
            ),
            186 => 
            array (
                'created_at' => '2019-05-30 17:10:13',
                'id' => 688,
                'notification_id' => 694,
                'notified_users' => '[784,785,797,799,811,812,813,815,816,818,819,820]',
                'updated_at' => '2019-05-30 17:10:13',
            ),
            187 => 
            array (
                'created_at' => '2019-05-30 17:35:54',
                'id' => 689,
                'notification_id' => 695,
                'notified_users' => '[784,785,797,799,811,812,813,815,816,818,819,820]',
                'updated_at' => '2019-05-30 17:35:54',
            ),
            188 => 
            array (
                'created_at' => '2019-05-30 18:47:50',
                'id' => 690,
                'notification_id' => 696,
                'notified_users' => '[784,785,797,799,811,812,813,815,816,818,819,820]',
                'updated_at' => '2019-05-30 18:47:50',
            ),
            189 => 
            array (
                'created_at' => '2019-05-30 19:05:34',
                'id' => 691,
                'notification_id' => 697,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:05:34',
            ),
            190 => 
            array (
                'created_at' => '2019-05-30 19:05:53',
                'id' => 692,
                'notification_id' => 698,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:05:53',
            ),
            191 => 
            array (
                'created_at' => '2019-05-30 19:06:11',
                'id' => 693,
                'notification_id' => 699,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:06:11',
            ),
            192 => 
            array (
                'created_at' => '2019-05-30 19:06:31',
                'id' => 694,
                'notification_id' => 700,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:06:31',
            ),
            193 => 
            array (
                'created_at' => '2019-05-30 19:06:53',
                'id' => 695,
                'notification_id' => 701,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:06:53',
            ),
            194 => 
            array (
                'created_at' => '2019-05-30 19:07:13',
                'id' => 696,
                'notification_id' => 702,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:07:13',
            ),
            195 => 
            array (
                'created_at' => '2019-05-30 19:07:32',
                'id' => 697,
                'notification_id' => 703,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:07:32',
            ),
            196 => 
            array (
                'created_at' => '2019-05-30 19:07:53',
                'id' => 698,
                'notification_id' => 704,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:07:53',
            ),
            197 => 
            array (
                'created_at' => '2019-05-30 19:08:13',
                'id' => 699,
                'notification_id' => 705,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:08:13',
            ),
            198 => 
            array (
                'created_at' => '2019-05-30 19:08:35',
                'id' => 700,
                'notification_id' => 706,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-30 19:08:35',
            ),
            199 => 
            array (
                'created_at' => '2019-05-31 12:00:25',
                'id' => 701,
                'notification_id' => 708,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,811]',
                'updated_at' => '2019-05-31 12:00:25',
            ),
            200 => 
            array (
                'created_at' => '2019-05-31 12:32:11',
                'id' => 702,
                'notification_id' => 709,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:32:11',
            ),
            201 => 
            array (
                'created_at' => '2019-05-31 12:32:31',
                'id' => 703,
                'notification_id' => 710,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:32:31',
            ),
            202 => 
            array (
                'created_at' => '2019-05-31 12:32:49',
                'id' => 704,
                'notification_id' => 711,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:32:49',
            ),
            203 => 
            array (
                'created_at' => '2019-05-31 12:33:11',
                'id' => 705,
                'notification_id' => 712,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:33:11',
            ),
            204 => 
            array (
                'created_at' => '2019-05-31 12:33:30',
                'id' => 706,
                'notification_id' => 713,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:33:30',
            ),
            205 => 
            array (
                'created_at' => '2019-05-31 12:33:50',
                'id' => 707,
                'notification_id' => 714,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:33:50',
            ),
            206 => 
            array (
                'created_at' => '2019-05-31 12:34:10',
                'id' => 708,
                'notification_id' => 715,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:34:10',
            ),
            207 => 
            array (
                'created_at' => '2019-05-31 12:34:30',
                'id' => 709,
                'notification_id' => 716,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:34:30',
            ),
            208 => 
            array (
                'created_at' => '2019-05-31 12:34:51',
                'id' => 710,
                'notification_id' => 717,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:34:51',
            ),
            209 => 
            array (
                'created_at' => '2019-05-31 12:35:09',
                'id' => 711,
                'notification_id' => 718,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:35:09',
            ),
            210 => 
            array (
                'created_at' => '2019-05-31 12:35:28',
                'id' => 712,
                'notification_id' => 719,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:35:28',
            ),
            211 => 
            array (
                'created_at' => '2019-05-31 12:35:48',
                'id' => 713,
                'notification_id' => 720,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:35:48',
            ),
            212 => 
            array (
                'created_at' => '2019-05-31 12:36:06',
                'id' => 714,
                'notification_id' => 721,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:36:06',
            ),
            213 => 
            array (
                'created_at' => '2019-05-31 12:36:25',
                'id' => 715,
                'notification_id' => 722,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:36:25',
            ),
            214 => 
            array (
                'created_at' => '2019-05-31 12:36:45',
                'id' => 716,
                'notification_id' => 723,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:36:45',
            ),
            215 => 
            array (
                'created_at' => '2019-05-31 12:41:36',
                'id' => 717,
                'notification_id' => 724,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-05-31 12:41:36',
            ),
            216 => 
            array (
                'created_at' => '2019-06-03 10:25:30',
                'id' => 718,
                'notification_id' => 732,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-06-03 10:25:30',
            ),
            217 => 
            array (
                'created_at' => '2019-06-03 10:25:50',
                'id' => 719,
                'notification_id' => 733,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-06-03 10:25:50',
            ),
            218 => 
            array (
                'created_at' => '2019-06-03 12:05:29',
                'id' => 720,
                'notification_id' => 734,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-06-03 12:05:29',
            ),
            219 => 
            array (
                'created_at' => '2019-06-04 00:06:25',
                'id' => 721,
                'notification_id' => 735,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,811]',
                'updated_at' => '2019-06-04 00:06:25',
            ),
            220 => 
            array (
                'created_at' => '2019-06-04 12:56:21',
                'id' => 722,
                'notification_id' => 736,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,829,811]',
                'updated_at' => '2019-06-04 12:56:21',
            ),
            221 => 
            array (
                'created_at' => '2019-06-04 14:11:25',
                'id' => 723,
                'notification_id' => 737,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,818,819,820,822,826,829,811]',
                'updated_at' => '2019-06-04 14:11:25',
            ),
            222 => 
            array (
                'created_at' => '2019-06-05 16:46:46',
                'id' => 724,
                'notification_id' => 738,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8ae0a870-a34b-39d2-9b52-fca78f6eda79","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1ce93c53-a068-357f-863a-e8dfebe1e877","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/58ebefb4-62f9-3a43-82af-b8f0f0f98b89","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/947d04e8-ba1a-32b4-9946-ce82770144e4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c541a31d-b2a4-37b8-9862-0c1386e96cea","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6012672d-674e-35a0-812d-b86903bc10c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9681c71d-6f77-37ba-95d3-8312600e0427","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cfb5c611-adcf-33a7-abb1-19bf05102eb7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8a48b2ed-154e-39ce-a973-41bc3a494e3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cb9d39ac-34df-3a4a-bc89-70f3d066ddef","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bac461c0-6821-3dec-b47f-1c096f7ef7fa","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bb35bddd-1217-3bba-82de-1bf668c8741e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/dc07a38a-b0f0-389a-8936-e09398ed06d8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec2c4d77-468f-3dd1-8cea-33ac74e8df20","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9b98d1e6-66b0-3945-9bb9-4d2346a997d0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4323d45d-aa52-3c79-8cdd-34bef5fc0d03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a331e0f9-ec4f-3ca7-b088-dd0845e815eb","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1dfd8c7a-c2f1-3a37-bebf-d031e6a4e3cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/41b825b9-4531-33d2-a5eb-37f78ce982ef","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1aa69b68-4d76-3ed3-aeb4-9dc79048003e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5027470-3fd3-32e8-8734-0a21bf23c6cc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a38904c6-f27a-38eb-95fc-5779f1dd053e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/68cf22c4-18b3-3aa3-88a5-56e0b75f7af3","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e9a9c952-51c5-35d3-b8b3-514439b8121c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d77cfd49-f2d6-33af-af5f-667189b0a7c7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8f73e130-f141-3ab8-8464-8677269aa02f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/aaf87c0a-c6f7-33f3-9bdf-8d4dc96ba251","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ef72e6b1-7a7a-3cfe-9970-4511c68b7344","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5797a24e-3508-3c8b-be40-e2b8b0d84ac0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/3aaa1ad7-f401-381a-b913-ba3eb5c07108","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f8d5c0fc-2034-3931-bd0a-1da1ecc62a8b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0e2c97eb-ccf9-3f54-9423-414d95269a08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4f5d6dfb-b718-377c-9834-e477b9ed4683","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/46798615-f22c-36ef-87ad-3dee1882a906","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6cc9d82c-9e0c-39c9-84b3-d1a7230b320b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/27db3465-9d5e-33ad-9c39-78fc52ff7071"]',
                'updated_at' => '2019-06-05 16:46:46',
            ),
            223 => 
            array (
                'created_at' => '2019-06-05 16:47:26',
                'id' => 725,
                'notification_id' => 739,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8ae0a870-a34b-39d2-9b52-fca78f6eda79","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1ce93c53-a068-357f-863a-e8dfebe1e877","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/58ebefb4-62f9-3a43-82af-b8f0f0f98b89","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/947d04e8-ba1a-32b4-9946-ce82770144e4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c541a31d-b2a4-37b8-9862-0c1386e96cea","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6012672d-674e-35a0-812d-b86903bc10c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9681c71d-6f77-37ba-95d3-8312600e0427","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cfb5c611-adcf-33a7-abb1-19bf05102eb7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8a48b2ed-154e-39ce-a973-41bc3a494e3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cb9d39ac-34df-3a4a-bc89-70f3d066ddef","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bac461c0-6821-3dec-b47f-1c096f7ef7fa","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bb35bddd-1217-3bba-82de-1bf668c8741e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/dc07a38a-b0f0-389a-8936-e09398ed06d8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec2c4d77-468f-3dd1-8cea-33ac74e8df20","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9b98d1e6-66b0-3945-9bb9-4d2346a997d0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4323d45d-aa52-3c79-8cdd-34bef5fc0d03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a331e0f9-ec4f-3ca7-b088-dd0845e815eb","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1dfd8c7a-c2f1-3a37-bebf-d031e6a4e3cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/41b825b9-4531-33d2-a5eb-37f78ce982ef","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1aa69b68-4d76-3ed3-aeb4-9dc79048003e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5027470-3fd3-32e8-8734-0a21bf23c6cc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a38904c6-f27a-38eb-95fc-5779f1dd053e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/68cf22c4-18b3-3aa3-88a5-56e0b75f7af3","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e9a9c952-51c5-35d3-b8b3-514439b8121c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d77cfd49-f2d6-33af-af5f-667189b0a7c7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8f73e130-f141-3ab8-8464-8677269aa02f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/aaf87c0a-c6f7-33f3-9bdf-8d4dc96ba251","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ef72e6b1-7a7a-3cfe-9970-4511c68b7344","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5797a24e-3508-3c8b-be40-e2b8b0d84ac0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/3aaa1ad7-f401-381a-b913-ba3eb5c07108","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f8d5c0fc-2034-3931-bd0a-1da1ecc62a8b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0e2c97eb-ccf9-3f54-9423-414d95269a08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4f5d6dfb-b718-377c-9834-e477b9ed4683","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/46798615-f22c-36ef-87ad-3dee1882a906","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6cc9d82c-9e0c-39c9-84b3-d1a7230b320b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/27db3465-9d5e-33ad-9c39-78fc52ff7071"]',
                'updated_at' => '2019-06-05 16:47:26',
            ),
            224 => 
            array (
                'created_at' => '2019-06-05 16:48:06',
                'id' => 726,
                'notification_id' => 740,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8ae0a870-a34b-39d2-9b52-fca78f6eda79","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb75657-576d-37d3-8700-2f6baa873af8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b6f65705-78a6-3fe7-9635-42d0960e6880","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dfaec6d6-12c0-3580-bc56-1b0bb6078288","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/edbbbdeb-1901-319e-825f-a919b3d74b5b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c0325756-2fa1-30ec-9916-8fa4eb59de03","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1ce93c53-a068-357f-863a-e8dfebe1e877","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9a4a33ba-8f18-32aa-92e8-d8827433004c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3e9f442a-a91c-326f-87d4-66eedf5b25b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e463d31d-5016-395e-a16a-557f22fa5026","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/32d178af-ef99-35a2-86d4-f51f7270c1b5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/94a1036e-ad87-38f8-8f77-24c27dd4ce16","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6e7e7a1c-c54f-3d01-9a16-08507ff391b9","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/53601053-b8cc-3393-a38f-96bbbd41de53","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0388d846-5d3a-3162-acd8-540373327e67","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d25f39c0-5d8f-35f5-bd8d-fafcc2020688","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/0ea84210-0393-35e2-a952-d0bc0e4ca346","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/1aa71ae0-63bb-322e-909f-8e56a17c43e1","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/50dbcf31-a442-39be-a2ca-a8ab1d7fdac8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8eb25404-6d8f-375f-911b-b37f3804b4d9","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/55c64612-7db3-3312-8c2e-2312064e2b36","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abc3557f-9c48-391b-8d17-9782d53a39b6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/92c3987d-226a-3423-83e3-ed3f90d87c73","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2ad65d7d-48e0-3577-ac90-b6061e410488","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/58ebefb4-62f9-3a43-82af-b8f0f0f98b89","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/947d04e8-ba1a-32b4-9946-ce82770144e4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c541a31d-b2a4-37b8-9862-0c1386e96cea","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/6012672d-674e-35a0-812d-b86903bc10c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9681c71d-6f77-37ba-95d3-8312600e0427","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cfb5c611-adcf-33a7-abb1-19bf05102eb7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8a48b2ed-154e-39ce-a973-41bc3a494e3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cb9d39ac-34df-3a4a-bc89-70f3d066ddef","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bac461c0-6821-3dec-b47f-1c096f7ef7fa","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bb35bddd-1217-3bba-82de-1bf668c8741e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/dc07a38a-b0f0-389a-8936-e09398ed06d8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec2c4d77-468f-3dd1-8cea-33ac74e8df20","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9b98d1e6-66b0-3945-9bb9-4d2346a997d0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4323d45d-aa52-3c79-8cdd-34bef5fc0d03","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a331e0f9-ec4f-3ca7-b088-dd0845e815eb","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1dfd8c7a-c2f1-3a37-bebf-d031e6a4e3cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/41b825b9-4531-33d2-a5eb-37f78ce982ef","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1aa69b68-4d76-3ed3-aeb4-9dc79048003e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5027470-3fd3-32e8-8734-0a21bf23c6cc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a38904c6-f27a-38eb-95fc-5779f1dd053e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/68cf22c4-18b3-3aa3-88a5-56e0b75f7af3","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e9a9c952-51c5-35d3-b8b3-514439b8121c","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/d77cfd49-f2d6-33af-af5f-667189b0a7c7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8f73e130-f141-3ab8-8464-8677269aa02f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/aaf87c0a-c6f7-33f3-9bdf-8d4dc96ba251","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ef72e6b1-7a7a-3cfe-9970-4511c68b7344","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5797a24e-3508-3c8b-be40-e2b8b0d84ac0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/3aaa1ad7-f401-381a-b913-ba3eb5c07108","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f8d5c0fc-2034-3931-bd0a-1da1ecc62a8b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0e2c97eb-ccf9-3f54-9423-414d95269a08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4f5d6dfb-b718-377c-9834-e477b9ed4683","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/46798615-f22c-36ef-87ad-3dee1882a906","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3df1dbd8-30a9-3fb8-b760-4e9b05340e60","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/39bf43d2-d1e1-3989-a03e-a218ccee5ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a9f61031-936c-3f8b-bd59-be3318260146","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6cc9d82c-9e0c-39c9-84b3-d1a7230b320b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/27db3465-9d5e-33ad-9c39-78fc52ff7071"]',
                'updated_at' => '2019-06-05 16:48:06',
            ),
            225 => 
            array (
                'created_at' => '2019-06-06 00:26:28',
                'id' => 727,
                'notification_id' => 741,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,819,820,822,826,829,811]',
                'updated_at' => '2019-06-06 00:26:28',
            ),
            226 => 
            array (
                'created_at' => '2019-06-06 02:46:21',
                'id' => 728,
                'notification_id' => 742,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,819,820,822,826,829,811]',
                'updated_at' => '2019-06-06 02:46:21',
            ),
            227 => 
            array (
                'created_at' => '2019-06-07 00:41:22',
                'id' => 729,
                'notification_id' => 743,
                'notified_users' => '[697,714,716,722,724,729,741,744,748,749,750,781,782,784,785,797,799,812,813,815,816,819,820,822,826,829,811]',
                'updated_at' => '2019-06-07 00:41:22',
            ),
        ));
        
        
    }
}