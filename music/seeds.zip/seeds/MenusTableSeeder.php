<?php

use Illuminate\Database\Seeder;

class MenusTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('menus')->delete();
        
        \DB::table('menus')->insert(array (
            0 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-27 13:15:59',
                'icon_id' => 2,
                'id' => 4,
                'menu_div' => 1,
                'name' => 'ニュース',
                'position' => 15,
                'updated_at' => '2018-11-30 16:52:03',
            ),
            1 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-27 13:16:13',
                'icon_id' => 4,
                'id' => 5,
                'menu_div' => 4,
                'name' => 'コンテンツ',
                'position' => 1,
                'updated_at' => '2018-12-05 15:43:45',
            ),
            2 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-27 13:16:19',
                'icon_id' => 4,
                'id' => 6,
                'menu_div' => 2,
                'name' => 'Gioi Thieu',
                'position' => 14,
                'updated_at' => '2019-01-28 12:54:22',
            ),
            3 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-28 16:46:33',
                'icon_id' => 4,
                'id' => 17,
                'menu_div' => 1,
                'name' => 'Menu1',
                'position' => 2,
                'updated_at' => '2018-12-05 15:43:44',
            ),
            4 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-28 16:55:49',
                'icon_id' => 5,
                'id' => 18,
                'menu_div' => 1,
                'name' => '820',
                'position' => 12,
                'updated_at' => '2018-11-30 16:51:56',
            ),
            5 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-29 17:42:29',
                'icon_id' => 6,
                'id' => 31,
                'menu_div' => 2,
                'name' => 'Trang chu',
                'position' => 13,
                'updated_at' => '2019-01-28 12:54:08',
            ),
            6 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-11-29 17:42:41',
                'icon_id' => 8,
                'id' => 32,
                'menu_div' => 2,
                'name' => 'Tin tuc',
                'position' => 19,
                'updated_at' => '2019-01-28 12:54:36',
            ),
            7 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-12-04 12:22:43',
                'icon_id' => 15,
                'id' => 45,
                'menu_div' => 3,
                'name' => 'Mode Thien Tai',
                'position' => 54,
                'updated_at' => '2019-01-28 12:55:00',
            ),
            8 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-07 13:25:18',
                'icon_id' => 22,
                'id' => 49,
                'menu_div' => 0,
                'name' => 'Giới thiệu',
                'position' => 1,
                'updated_at' => '2018-12-07 13:25:18',
            ),
            9 => 
            array (
                'client_id' => 1,
                'created_at' => '2018-12-07 16:47:43',
                'icon_id' => 5,
                'id' => 52,
                'menu_div' => 2,
                'name' => 'Thi Truong',
                'position' => 57,
                'updated_at' => '2019-01-28 12:55:24',
            ),
            10 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-07 16:48:58',
                'icon_id' => 26,
                'id' => 53,
                'menu_div' => 1,
                'name' => 'Trang chủ',
                'position' => 3,
                'updated_at' => '2019-01-30 17:54:35',
            ),
            11 => 
            array (
                'client_id' => 70,
                'created_at' => '2018-12-07 16:49:03',
                'icon_id' => 32,
                'id' => 54,
                'menu_div' => 0,
                'name' => 'aaaa',
                'position' => 1,
                'updated_at' => '2018-12-07 16:49:03',
            ),
            12 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-07 18:33:20',
                'icon_id' => 21,
                'id' => 56,
                'menu_div' => 1,
                'name' => 'Tin tức',
                'position' => 5,
                'updated_at' => '2019-01-30 17:54:48',
            ),
            13 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-07 18:35:00',
                'icon_id' => 25,
                'id' => 57,
                'menu_div' => 1,
                'name' => 'Thời sự',
                'position' => 8,
                'updated_at' => '2019-01-30 17:55:02',
            ),
            14 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-07 18:36:15',
                'icon_id' => 30,
                'id' => 58,
                'menu_div' => 1,
                'name' => 'Giáo dục',
                'position' => 9,
                'updated_at' => '2019-01-30 17:55:31',
            ),
            15 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:49:21',
                'icon_id' => 23,
                'id' => 59,
                'menu_div' => 1,
                'name' => 'GioiTHieu',
                'position' => 1,
                'updated_at' => '2018-12-10 10:55:30',
            ),
            16 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:53:53',
                'icon_id' => 36,
                'id' => 60,
                'menu_div' => 1,
                'name' => 'コンテンツ',
                'position' => 2,
                'updated_at' => '2018-12-10 10:55:38',
            ),
            17 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:54:13',
                'icon_id' => 37,
                'id' => 61,
                'menu_div' => 1,
                'name' => 'ビジネ',
                'position' => 3,
                'updated_at' => '2018-12-10 10:55:48',
            ),
            18 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:54:23',
                'icon_id' => 23,
                'id' => 62,
                'menu_div' => 1,
                'name' => 'ssssssssssss',
                'position' => 4,
                'updated_at' => '2018-12-10 10:55:58',
            ),
            19 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:54:31',
                'icon_id' => 35,
                'id' => 63,
                'menu_div' => 1,
                'name' => 'gwqqqqqqqqq',
                'position' => 5,
                'updated_at' => '2018-12-10 10:56:09',
            ),
            20 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:54:38',
                'icon_id' => 36,
                'id' => 64,
                'menu_div' => 2,
                'name' => 'ThienTai',
                'position' => 6,
                'updated_at' => '2018-12-10 10:56:43',
            ),
            21 => 
            array (
                'client_id' => 71,
                'created_at' => '2018-12-10 10:54:50',
                'icon_id' => 37,
                'id' => 65,
                'menu_div' => 0,
                'name' => 'ggwwwwwwwwwww',
                'position' => 7,
                'updated_at' => '2018-12-10 10:54:50',
            ),
            22 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-10 12:31:12',
                'icon_id' => 34,
                'id' => 66,
                'menu_div' => 2,
                'name' => 'Thientai',
                'position' => 6,
                'updated_at' => '2018-12-10 15:20:14',
            ),
            23 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-10 13:06:26',
                'icon_id' => 22,
                'id' => 67,
                'menu_div' => 0,
                'name' => '妖精妖精妖精妖精妖精',
                'position' => 7,
                'updated_at' => '2018-12-10 15:20:14',
            ),
            24 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-10 15:19:48',
                'icon_id' => 20,
                'id' => 68,
                'menu_div' => 0,
                'name' => '億億',
                'position' => 10,
                'updated_at' => '2018-12-10 15:19:48',
            ),
            25 => 
            array (
                'client_id' => 72,
                'created_at' => '2018-12-10 15:20:35',
                'icon_id' => 27,
                'id' => 69,
                'menu_div' => 0,
                'name' => 'thutu',
                'position' => 11,
                'updated_at' => '2018-12-10 15:20:35',
            ),
            26 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:51:23',
                'icon_id' => 40,
                'id' => 70,
                'menu_div' => 2,
                'name' => 'Trang chủ',
                'position' => 1,
                'updated_at' => '2019-01-30 18:51:23',
            ),
            27 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:51:37',
                'icon_id' => 39,
                'id' => 71,
                'menu_div' => 3,
                'name' => 'Mode thiên tai',
                'position' => 2,
                'updated_at' => '2019-01-30 18:51:37',
            ),
            28 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:51:55',
                'icon_id' => 41,
                'id' => 72,
                'menu_div' => 4,
                'name' => 'Mode offline',
                'position' => 3,
                'updated_at' => '2019-01-30 18:51:55',
            ),
            29 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:52:13',
                'icon_id' => 40,
                'id' => 73,
                'menu_div' => 4,
                'name' => 'Mode Offline 2',
                'position' => 4,
                'updated_at' => '2019-01-30 18:52:43',
            ),
            30 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:53:47',
                'icon_id' => 39,
                'id' => 74,
                'menu_div' => 2,
                'name' => 'Giới thiệu',
                'position' => 5,
                'updated_at' => '2019-01-30 18:53:47',
            ),
            31 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:55:14',
                'icon_id' => 42,
                'id' => 75,
                'menu_div' => 2,
                'name' => 'Tin Tức',
                'position' => 6,
                'updated_at' => '2019-01-30 18:55:14',
            ),
            32 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:55:26',
                'icon_id' => 45,
                'id' => 76,
                'menu_div' => 2,
                'name' => 'Giáo dục',
                'position' => 7,
                'updated_at' => '2019-01-30 18:55:26',
            ),
            33 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:55:39',
                'icon_id' => 40,
                'id' => 77,
                'menu_div' => 2,
                'name' => 'Tư vấn',
                'position' => 8,
                'updated_at' => '2019-01-30 18:55:39',
            ),
            34 => 
            array (
                'client_id' => 77,
                'created_at' => '2019-01-30 18:58:19',
                'icon_id' => 43,
                'id' => 78,
                'menu_div' => 4,
                'name' => 'Mode offline 3',
                'position' => 9,
                'updated_at' => '2019-01-30 18:58:19',
            ),
            35 => 
            array (
                'client_id' => 1,
                'created_at' => '2019-02-14 18:08:16',
                'icon_id' => 1,
                'id' => 79,
                'menu_div' => 4,
                'name' => 'VISOR VNC',
                'position' => 58,
                'updated_at' => '2019-02-14 18:08:16',
            ),
            36 => 
            array (
                'client_id' => 1,
                'created_at' => '2019-03-01 16:36:59',
                'icon_id' => 19,
                'id' => 80,
                'menu_div' => 4,
                'name' => 'Menu Offline',
                'position' => 60,
                'updated_at' => '2019-03-04 11:37:50',
            ),
            37 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:30:57',
                'icon_id' => 64,
                'id' => 81,
                'menu_div' => 2,
                'name' => 'Menu1',
                'position' => 1,
                'updated_at' => '2019-03-01 18:30:57',
            ),
            38 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:31:06',
                'icon_id' => 66,
                'id' => 82,
                'menu_div' => 2,
                'name' => 'Menu2',
                'position' => 2,
                'updated_at' => '2019-03-01 18:31:06',
            ),
            39 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:31:15',
                'icon_id' => 67,
                'id' => 83,
                'menu_div' => 2,
                'name' => 'Menu 3',
                'position' => 3,
                'updated_at' => '2019-03-01 18:31:15',
            ),
            40 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:31:24',
                'icon_id' => 68,
                'id' => 84,
                'menu_div' => 2,
                'name' => 'Menu4',
                'position' => 4,
                'updated_at' => '2019-03-01 18:31:24',
            ),
            41 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:31:31',
                'icon_id' => 65,
                'id' => 85,
                'menu_div' => 2,
                'name' => 'Menu5',
                'position' => 5,
                'updated_at' => '2019-03-01 18:31:31',
            ),
            42 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:31:55',
                'icon_id' => 65,
                'id' => 86,
                'menu_div' => 3,
                'name' => 'Mode thiên tai',
                'position' => 6,
                'updated_at' => '2019-03-01 18:32:29',
            ),
            43 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:32:51',
                'icon_id' => 68,
                'id' => 87,
                'menu_div' => 4,
                'name' => 'Menu offline',
                'position' => 7,
                'updated_at' => '2019-03-01 18:32:51',
            ),
            44 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:33:05',
                'icon_id' => 67,
                'id' => 88,
                'menu_div' => 4,
                'name' => 'Menu offline 2',
                'position' => 8,
                'updated_at' => '2019-03-01 18:33:05',
            ),
            45 => 
            array (
                'client_id' => 1,
                'created_at' => '2019-03-04 11:37:38',
                'icon_id' => 8,
                'id' => 89,
                'menu_div' => 2,
                'name' => 'Menu_Batch_Post',
                'position' => 10,
                'updated_at' => '2019-03-04 11:50:35',
            ),
            46 => 
            array (
                'client_id' => 192,
                'created_at' => '2019-03-05 13:04:26',
                'icon_id' => 70,
                'id' => 90,
                'menu_div' => 2,
                'name' => 'Trang chu',
                'position' => 1,
                'updated_at' => '2019-03-05 13:04:26',
            ),
            47 => 
            array (
                'client_id' => 189,
                'created_at' => '2019-03-11 12:40:50',
                'icon_id' => 71,
                'id' => 91,
                'menu_div' => 4,
                'name' => 'menu test mobile',
                'position' => 1,
                'updated_at' => '2019-03-11 12:40:50',
            ),
            48 => 
            array (
                'client_id' => 190,
                'created_at' => '2019-03-11 12:58:10',
                'icon_id' => 72,
                'id' => 92,
                'menu_div' => 4,
                'name' => 'test mobile offline mode 2',
                'position' => 1,
                'updated_at' => '2019-03-11 12:58:10',
            ),
            49 => 
            array (
                'client_id' => 191,
                'created_at' => '2019-03-11 13:15:35',
                'icon_id' => 73,
                'id' => 93,
                'menu_div' => 4,
                'name' => 'test mobile offline webpage 3',
                'position' => 1,
                'updated_at' => '2019-03-11 13:15:35',
            ),
            50 => 
            array (
                'client_id' => 187,
                'created_at' => '2019-03-11 13:30:00',
                'icon_id' => 74,
                'id' => 94,
                'menu_div' => 4,
                'name' => 'test mobile offline webpage 4',
                'position' => 1,
                'updated_at' => '2019-03-11 13:30:00',
            ),
            51 => 
            array (
                'client_id' => 194,
                'created_at' => '2019-03-11 13:41:04',
                'icon_id' => 75,
                'id' => 95,
                'menu_div' => 4,
                'name' => 'test mobile offline file 1',
                'position' => 1,
                'updated_at' => '2019-03-11 13:41:14',
            ),
            52 => 
            array (
                'client_id' => 195,
                'created_at' => '2019-03-11 13:52:10',
                'icon_id' => 76,
                'id' => 96,
                'menu_div' => 4,
                'name' => 'test mobile offline file 2',
                'position' => 1,
                'updated_at' => '2019-03-11 13:52:18',
            ),
            53 => 
            array (
                'client_id' => 196,
                'created_at' => '2019-03-11 13:56:13',
                'icon_id' => 77,
                'id' => 97,
                'menu_div' => 4,
                'name' => 'test mobile offline file 3',
                'position' => 1,
                'updated_at' => '2019-03-11 13:56:13',
            ),
            54 => 
            array (
                'client_id' => 197,
                'created_at' => '2019-03-11 14:00:42',
                'icon_id' => 78,
                'id' => 98,
                'menu_div' => 4,
                'name' => 'test mobile offline file 4',
                'position' => 1,
                'updated_at' => '2019-03-11 14:00:42',
            ),
            55 => 
            array (
                'client_id' => 198,
                'created_at' => '2019-03-11 15:11:48',
                'icon_id' => 79,
                'id' => 99,
                'menu_div' => 4,
                'name' => 'test mobile offline file 5',
                'position' => 1,
                'updated_at' => '2019-03-11 15:11:48',
            ),
            56 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:56:28',
                'icon_id' => 80,
                'id' => 100,
                'menu_div' => 2,
                'name' => 'Home page',
                'position' => 1,
                'updated_at' => '2019-05-07 19:27:17',
            ),
            57 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:56:45',
                'icon_id' => 81,
                'id' => 101,
                'menu_div' => 2,
                'name' => 'Introduce',
                'position' => 2,
                'updated_at' => '2019-05-07 19:27:17',
            ),
            58 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:57:00',
                'icon_id' => 83,
                'id' => 102,
                'menu_div' => 2,
                'name' => 'News',
                'position' => 3,
                'updated_at' => '2019-05-07 19:27:24',
            ),
            59 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:57:33',
                'icon_id' => 83,
                'id' => 103,
                'menu_div' => 2,
                'name' => 'Education',
                'position' => 4,
                'updated_at' => '2019-05-07 19:27:24',
            ),
            60 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:57:58',
                'icon_id' => 84,
                'id' => 104,
                'menu_div' => 2,
                'name' => 'Science',
                'position' => 5,
                'updated_at' => '2019-03-11 16:57:58',
            ),
            61 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:59:03',
                'icon_id' => 83,
                'id' => 105,
                'menu_div' => 3,
                'name' => 'Disaster mode',
                'position' => 7,
                'updated_at' => '2019-05-07 19:53:10',
            ),
            62 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:59:19',
                'icon_id' => 85,
                'id' => 106,
                'menu_div' => 4,
                'name' => 'Offline menu',
                'position' => 6,
                'updated_at' => '2019-05-07 19:53:10',
            ),
            63 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:59:39',
                'icon_id' => 137,
                'id' => 114,
                'menu_div' => 3,
                'name' => 'disate',
                'position' => 1,
                'updated_at' => '2019-05-20 10:59:39',
            ),
            64 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 11:08:28',
                'icon_id' => 137,
                'id' => 115,
                'menu_div' => 4,
                'name' => 'offline',
                'position' => 2,
                'updated_at' => '2019-05-20 11:08:28',
            ),
        ));
        
        
    }
}