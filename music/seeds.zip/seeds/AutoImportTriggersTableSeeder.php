<?php

use Illuminate\Database\Seeder;

class AutoImportTriggersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_triggers')->delete();
        
        \DB::table('auto_import_triggers')->insert(array (
            0 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-15 10:47:52',
                'id' => 93,
                'match_div' => 2,
                'trigger_str' => 'fdfdfdfdf',
                'updated_at' => '2019-01-15 10:47:52',
            ),
            1 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-15 13:58:24',
                'id' => 101,
                'match_div' => 1,
                'trigger_str' => 'dsfsff',
                'updated_at' => '2019-01-15 13:58:24',
            ),
            2 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-15 13:59:38',
                'id' => 102,
                'match_div' => 1,
                'trigger_str' => 'hahahahhdhah  kakdkad',
                'updated_at' => '2019-01-15 13:59:38',
            ),
            3 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-21 16:44:50',
                'id' => 110,
                'match_div' => 2,
                'trigger_str' => 'fgfhfhf',
                'updated_at' => '2019-01-21 16:44:50',
            ),
            4 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-24 13:15:45',
                'id' => 111,
                'match_div' => 2,
                'trigger_str' => 'dfgdgrfgrfgr',
                'updated_at' => '2019-01-24 13:15:45',
            ),
            5 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-24 13:26:09',
                'id' => 114,
                'match_div' => 2,
                'trigger_str' => 'dfdfdfdfdf',
                'updated_at' => '2019-01-24 13:26:09',
            ),
            6 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-25 12:46:34',
                'id' => 116,
                'match_div' => 2,
                'trigger_str' => 'hhahahd

dsds

xdsds',
                'updated_at' => '2019-01-25 12:46:34',
            ),
            7 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-25 12:46:55',
                'id' => 117,
                'match_div' => 1,
                'trigger_str' => 'tesst datat

登録しました。
登録しました。',
                'updated_at' => '2019-01-25 12:46:55',
            ),
            8 => 
            array (
                'auto_import_id' => 3,
                'created_at' => '2019-01-25 12:48:28',
                'id' => 121,
                'match_div' => 2,
                'trigger_str' => 'testt datta servee',
                'updated_at' => '2019-01-25 12:48:28',
            ),
            9 => 
            array (
                'auto_import_id' => 3,
                'created_at' => '2019-01-25 12:48:35',
                'id' => 122,
                'match_div' => 0,
                'trigger_str' => 'testlddddddddddddddddddd',
                'updated_at' => '2019-01-25 12:48:35',
            ),
            10 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-01-29 19:45:12',
                'id' => 123,
                'match_div' => 2,
                'trigger_str' => 'grgr',
                'updated_at' => '2019-01-29 19:45:12',
            ),
            11 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-02-01 17:30:49',
                'id' => 124,
                'match_div' => 0,
                'trigger_str' => 'thutesst',
                'updated_at' => '2019-02-01 17:30:49',
            ),
            12 => 
            array (
                'auto_import_id' => 1,
                'created_at' => '2019-02-01 17:32:37',
                'id' => 125,
                'match_div' => 2,
                'trigger_str' => 'test on serve
test on serve

test on serve',
                'updated_at' => '2019-02-01 17:32:37',
            ),
            13 => 
            array (
                'auto_import_id' => 10,
                'created_at' => '2019-02-14 11:57:25',
                'id' => 126,
                'match_div' => 1,
                'trigger_str' => 'test abc',
                'updated_at' => '2019-02-14 11:57:25',
            ),
            14 => 
            array (
                'auto_import_id' => 24,
                'created_at' => '2019-02-14 12:44:34',
                'id' => 127,
                'match_div' => 2,
                'trigger_str' => 'năm mới',
                'updated_at' => '2019-02-14 12:44:34',
            ),
            15 => 
            array (
                'auto_import_id' => 24,
                'created_at' => '2019-02-14 12:45:11',
                'id' => 128,
                'match_div' => 1,
                'trigger_str' => 'Kỷ Hợi',
                'updated_at' => '2019-02-14 12:45:11',
            ),
            16 => 
            array (
                'auto_import_id' => 24,
                'created_at' => '2019-02-14 12:45:27',
                'id' => 129,
                'match_div' => 0,
                'trigger_str' => 'Nam con nhợn',
                'updated_at' => '2019-02-14 12:45:27',
            ),
            17 => 
            array (
                'auto_import_id' => 24,
                'created_at' => '2019-02-14 12:46:55',
                'id' => 131,
                'match_div' => 0,
                'trigger_str' => 'Phúc như đông hải',
                'updated_at' => '2019-02-14 12:46:55',
            ),
            18 => 
            array (
                'auto_import_id' => 24,
                'created_at' => '2019-02-14 12:52:07',
                'id' => 132,
                'match_div' => 1,
                'trigger_str' => 'Niềm vui ngập tràn',
                'updated_at' => '2019-02-14 12:52:07',
            ),
            19 => 
            array (
                'auto_import_id' => 24,
                'created_at' => '2019-02-14 12:55:23',
                'id' => 133,
                'match_div' => 2,
                'trigger_str' => 'IE',
                'updated_at' => '2019-02-14 12:55:23',
            ),
            20 => 
            array (
                'auto_import_id' => 112,
                'created_at' => '2019-05-31 10:57:41',
                'id' => 213,
                'match_div' => 3,
                'trigger_str' => 'GraalVM、ついに本番利用可能なバージョン',
                'updated_at' => '2019-05-31 11:40:15',
            ),
            21 => 
            array (
                'auto_import_id' => 113,
                'created_at' => '2019-05-31 11:58:44',
                'id' => 214,
                'match_div' => 0,
                'trigger_str' => 'が正式版に。',
                'updated_at' => '2019-05-31 11:58:44',
            ),
            22 => 
            array (
                'auto_import_id' => 113,
                'created_at' => '2019-05-31 11:59:12',
                'id' => 215,
                'match_div' => 1,
                'trigger_str' => 'で提供される大規模分散キーバリューストア',
                'updated_at' => '2019-05-31 11:59:12',
            ),
            23 => 
            array (
                'auto_import_id' => 114,
                'created_at' => '2019-05-31 12:26:12',
                'id' => 216,
                'match_div' => 2,
                'trigger_str' => 'が正式版に。Azure上でNetAppを用いたスケーラブルなNFS/SMBストレージが利用可能',
                'updated_at' => '2019-05-31 12:26:12',
            ),
            24 => 
            array (
                'auto_import_id' => 115,
                'created_at' => '2019-05-31 12:31:29',
                'id' => 217,
                'match_div' => 4,
                'trigger_str' => 'thu thu',
                'updated_at' => '2019-05-31 12:31:29',
            ),
            25 => 
            array (
                'auto_import_id' => 116,
                'created_at' => '2019-05-31 12:39:57',
                'id' => 218,
                'match_div' => 3,
                'trigger_str' => 'が正式版に。',
                'updated_at' => '2019-05-31 12:39:57',
            ),
            26 => 
            array (
                'auto_import_id' => 117,
                'created_at' => '2019-05-31 12:43:47',
                'id' => 219,
                'match_div' => 0,
                'trigger_str' => '「Cloudflare Workers KV」正式版がリリース。',
                'updated_at' => '2019-05-31 12:43:47',
            ),
        ));
        
        
    }
}