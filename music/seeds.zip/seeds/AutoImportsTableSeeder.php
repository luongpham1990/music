<?php

use Illuminate\Database\Seeder;

class AutoImportsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_imports')->delete();
        
        \DB::table('auto_imports')->insert(array (
            0 => 
            array (
                'client_id' => 1,
                'content_group_id' => 5,
                'created_at' => '2019-01-09 17:53:07',
                'id' => 1,
                'import_div' => 1,
                'name' => 'rffdf',
                'note' => 'dfddg',
                'setting_value' => 'gdgdgdg',
                'status' => 1,
                'updated_at' => '2019-01-09 17:53:00',
            ),
            1 => 
            array (
                'client_id' => 72,
                'content_group_id' => 45,
                'created_at' => NULL,
                'id' => 3,
                'import_div' => 1,
                'name' => '1',
                'note' => '1',
                'setting_value' => '1',
                'status' => 1,
                'updated_at' => NULL,
            ),
            2 => 
            array (
                'client_id' => 70,
                'content_group_id' => 2,
                'created_at' => NULL,
                'id' => 4,
                'import_div' => 1,
                'name' => '1',
                'note' => '1',
                'setting_value' => '1',
                'status' => 1,
                'updated_at' => NULL,
            ),
            3 => 
            array (
                'client_id' => 1,
                'content_group_id' => 16,
                'created_at' => '2019-01-11 20:00:00',
                'id' => 8,
                'import_div' => 20,
                'name' => '添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル',
                'note' => 'hello',
                'setting_value' => 'https://www.google.com/maps',
                'status' => 0,
                'updated_at' => '2019-01-11 20:50:00',
            ),
            4 => 
            array (
                'client_id' => 1,
                'content_group_id' => 19,
                'created_at' => '2019-01-14 11:46:10',
                'id' => 9,
                'import_div' => 1,
                'name' => '取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元',
                'note' => '取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元
ffds
f

取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元
fd
ff',
                'setting_value' => 'grrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrfdffdddddddddddddddđfqr234e234132412423434234322222222222222222222222222222222222222222222222214234e34e34ewwrèkjfkdè89340582984974892745893457u9345u 439ureifrjfdjfdjfdfdff',
                'status' => 1,
                'updated_at' => '2019-01-14 19:19:53',
            ),
            5 => 
            array (
                'client_id' => 1,
                'content_group_id' => 3,
                'created_at' => '2019-01-14 19:22:24',
                'id' => 10,
                'import_div' => 20,
                'name' => 'Uoc gi la gio mua he',
                'note' => '1
2
2',
                'setting_value' => 'http://www.town.anpachi.gifu.jp/feed/',
                'status' => 0,
                'updated_at' => '2019-01-14 19:22:24',
            ),
            6 => 
            array (
                'client_id' => 1,
                'content_group_id' => 24,
                'created_at' => '2019-01-15 10:58:26',
                'id' => 12,
                'import_div' => 2,
                'name' => '＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。',
                'note' => 'test auto import
v

test auto import
test auto import
test auto import',
                'setting_value' => '＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。',
                'status' => 0,
                'updated_at' => '2019-01-15 10:58:26',
            ),
            7 => 
            array (
                'client_id' => 1,
                'content_group_id' => 28,
                'created_at' => '2019-01-15 11:36:03',
                'id' => 13,
                'import_div' => 1,
                'name' => '5555',
                'note' => 'ew
ưe
e
ư
ưe
ưe
ư
ew
e
ư',
                'setting_value' => 'admin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-ap',
                'status' => 0,
                'updated_at' => '2019-01-17 10:42:14',
            ),
            8 => 
            array (
                'client_id' => 1,
                'content_group_id' => 16,
                'created_at' => '2019-01-16 20:22:43',
                'id' => 14,
                'import_div' => 1,
                'name' => 'dads',
                'note' => 'dsdfsf',
                'setting_value' => 'fdsfdsf',
                'status' => 1,
                'updated_at' => '2019-01-17 10:23:36',
            ),
            9 => 
            array (
                'client_id' => 1,
                'content_group_id' => 2,
                'created_at' => '2019-01-17 11:02:11',
                'id' => 15,
                'import_div' => 2,
                'name' => '自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み',
                'note' => NULL,
                'setting_value' => 'http://bhbhbhbhbhbh',
                'status' => 1,
                'updated_at' => '2019-02-14 12:59:35',
            ),
            10 => 
            array (
                'client_id' => 1,
                'content_group_id' => 3,
                'created_at' => '2019-01-18 13:10:52',
                'id' => 17,
                'import_div' => 1,
                'name' => 'ádasda',
                'note' => 'adasd',
                'setting_value' => 'đâsd',
                'status' => 0,
                'updated_at' => '2019-01-18 13:10:52',
            ),
            11 => 
            array (
                'client_id' => 1,
                'content_group_id' => 4,
                'created_at' => '2019-01-18 19:02:55',
                'id' => 19,
                'import_div' => 2,
                'name' => 'Htest2',
                'note' => 'あsだsd',
                'setting_value' => 'http://添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が',
                'status' => 0,
                'updated_at' => '2019-01-21 15:52:33',
            ),
            12 => 
            array (
                'client_id' => 1,
                'content_group_id' => 24,
                'created_at' => '2019-01-22 11:37:13',
                'id' => 20,
                'import_div' => 2,
                'name' => 'Menu1',
                'note' => 'hahahah',
                'setting_value' => 'http://google.com.vn',
                'status' => 1,
                'updated_at' => '2019-01-22 11:37:13',
            ),
            13 => 
            array (
                'client_id' => 1,
                'content_group_id' => 35,
                'created_at' => '2019-01-25 12:41:56',
                'id' => 23,
                'import_div' => 1,
                'name' => 'Menu1',
                'note' => 'note test data serve

note test data serve
note test data serve',
                'setting_value' => 'http://ffff',
                'status' => 1,
                'updated_at' => '2019-02-14 12:58:17',
            ),
            14 => 
            array (
                'client_id' => 1,
                'content_group_id' => 63,
                'created_at' => '2019-01-31 12:28:27',
                'id' => 24,
                'import_div' => 1,
                'name' => 'Auto import test finishAuto import test finishAuto import test finishAuto import test finishAuto import test finishAuto import test finish',
                'note' => '前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致',
                'setting_value' => 'http://fffffffffff',
                'status' => 1,
                'updated_at' => '2019-02-14 13:00:33',
            ),
            15 => 
            array (
                'client_id' => 199,
                'content_group_id' => 102,
                'created_at' => '2019-05-31 10:57:33',
                'id' => 112,
                'import_div' => 20,
                'name' => 'doc file',
                'note' => 'eqwewqe',
                'setting_value' => 'https://www.publickey1.jp/atom.xml',
                'status' => 0,
                'updated_at' => '2019-06-06 20:15:24',
            ),
            16 => 
            array (
                'client_id' => 199,
                'content_group_id' => 102,
                'created_at' => '2019-05-31 11:57:07',
                'id' => 113,
                'import_div' => 20,
                'name' => 'Test 1',
                'note' => NULL,
                'setting_value' => 'https://www.publickey1.jp/atom.xml',
                'status' => 1,
                'updated_at' => '2019-05-31 11:57:07',
            ),
            17 => 
            array (
                'client_id' => 199,
                'content_group_id' => 102,
                'created_at' => '2019-05-31 12:26:01',
                'id' => 114,
                'import_div' => 20,
                'name' => 'Test 2',
                'note' => NULL,
                'setting_value' => 'https://www.publickey1.jp/atom.xml',
                'status' => 1,
                'updated_at' => '2019-05-31 12:26:01',
            ),
            18 => 
            array (
                'client_id' => 199,
                'content_group_id' => 102,
                'created_at' => '2019-05-31 12:31:20',
                'id' => 115,
                'import_div' => 20,
                'name' => 'Test 3',
                'note' => NULL,
                'setting_value' => 'https://www.publickey1.jp/atom.xml',
                'status' => 1,
                'updated_at' => '2019-05-31 12:31:20',
            ),
            19 => 
            array (
                'client_id' => 199,
                'content_group_id' => 102,
                'created_at' => '2019-05-31 12:39:45',
                'id' => 116,
                'import_div' => 20,
                'name' => 'Mot Phan',
                'note' => NULL,
                'setting_value' => 'https://www.publickey1.jp/atom.xml',
                'status' => 1,
                'updated_at' => '2019-05-31 12:39:45',
            ),
            20 => 
            array (
                'client_id' => 199,
                'content_group_id' => 102,
                'created_at' => '2019-05-31 12:42:35',
                'id' => 117,
                'import_div' => 20,
                'name' => 'Phan Truoc',
                'note' => NULL,
                'setting_value' => 'https://www.publickey1.jp/atom.xml',
                'status' => 1,
                'updated_at' => '2019-05-31 12:42:35',
            ),
        ));
        
        
    }
}