<?php

use App\Eloquent\Client;
use App\Eloquent\Operator;
use Machiyell\Enum\ClientSettingDiv;
use Machiyell\Enum\UsageStatus;
use Illuminate\Database\Seeder;

/**
 * 開発用初期データ登録Seeder
 */
class DevelopmentInitialSeeder extends Seeder
{
    /**
     * Default operator username
     */
    private const USERNAME = 'admin';

    /**
     * Default operator password
     */
    private const PASSWORD = 'admin!99';

    /**
     * Default operator name
     */
    private const NAME = '管理者';

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(): void
    {
        try {
            DB::beginTransaction();
            $client = $this->makeClient();
            // @todo 開発用の初期データを必要に応じて追加
            $operator = $this->makeOperator($client);
            if ($operator === false) {
                throw new Exception('Failed to create operator');
            }
            DB::commit();
        } catch (\Exception $e) {
            echo $e->getMessage();
            DB::rollBack();
        }
    }

    /**
     * 顧客データを作成
     *
     * @return Client
     */
    private function makeClient(): Client
    {
        $client = Client::create([
            'client_code' => 'visor',
            'client_name' => 'VISOR',
            'service_name' => 'バイザー連絡網'
        ]);
        $client->clientSettings()->createMany(ClientSettingDiv::makeData());
        return $client;
    }

    /**
     * Create operator
     *
     * @param Client $client
     * @return false|Operator
     */
    private function makeOperator(Client $client)
    {
        return $client->operators()->save(new Operator([
            'username' => self::USERNAME,
            'password' => bcrypt(self::PASSWORD),
            'usage_status' => UsageStatus::USING,
            'name' => self::NAME
        ]));
    }

}
