<?php

use Illuminate\Database\Seeder;

class LinksTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('links')->delete();
        
        \DB::table('links')->insert(array (
            0 => 
            array (
                'content_id' => 3,
                'id' => 1,
                'lang' => 'en',
                'link_url' => 'https://machiyell.test/ctrl/visor/content_group/1/content',
                'title' => 'hello',
            ),
            1 => 
            array (
                'content_id' => 91,
                'id' => 2,
                'lang' => 'es',
                'link_url' => 'http://machiyell.test/ctrl/visor/content_group/5/content/form1',
                'title' => 'dsadsadgffgf',
            ),
            2 => 
            array (
                'content_id' => 164,
                'id' => 11,
                'lang' => 'en',
                'link_url' => 'https://xd.adobe.com/view/6515f767-9a93-4452-6dbc-d026dab206a8-1324/',
                'title' => 'test content file optional 11',
            ),
            3 => 
            array (
                'content_id' => 174,
                'id' => 14,
                'lang' => 'en',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322823/Ti%E1%BB%87c-t%E1%BA%A5t-nien-m%E1%BB%ABng-Xuan-K%E1%BB%89-H%E1%BB%A3i-2019.html',
                'title' => 'Tet Ky Hoi',
            ),
            4 => 
            array (
                'content_id' => 180,
                'id' => 15,
                'lang' => 'es',
                'link_url' => 'https://stackoverflow.com/questions/3081021/how-to-get-the-center-of-a-polygon-in-google-maps-v3',
                'title' => 'ja_title',
            ),
            5 => 
            array (
                'content_id' => 286,
                'id' => 17,
                'lang' => 'en',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322822/Du-l%E1%BB%8Bch-he-t%E1%BA%A1i-Da-N%E1%BA%B5ng-2018.html',
                'title' => 'test link1',
            ),
            6 => 
            array (
                'content_id' => 301,
                'id' => 19,
                'lang' => 'en',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322822/Du-l%E1%BB%8Bch-he-t%E1%BA%A1i-Da-N%E1%BA%B5ng-2018.html',
                'title' => 'Link es',
            ),
            7 => 
            array (
                'content_id' => 392,
                'id' => 23,
                'lang' => 'ja',
                'link_url' => 'http://vinigate.com.vn/pm/projects/visor-intl/issues',
                'title' => 'beee',
            ),
            8 => 
            array (
                'content_id' => 539,
                'id' => 26,
                'lang' => 'ja',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322824/CHUC-M%E1%BB%AANG-SINH-NH%E1%BA%ACT-VINICORP-L%E1%BA%A6N-TH%E1%BB%A8-12-04-05-2007-04-05-2019.html',
                'title' => 'Title link ja',
            ),
            9 => 
            array (
                'content_id' => 661,
                'id' => 27,
                'lang' => 'ja',
                'link_url' => 'https://3keys.jp/donation/izo/',
                'title' => 'Tran lũ chieu ngày 2/5/2019',
            ),
        ));
        
        
    }
}