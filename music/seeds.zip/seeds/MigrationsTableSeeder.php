<?php

use Illuminate\Database\Seeder;

class MigrationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('migrations')->delete();
        
        \DB::table('migrations')->insert(array (
            0 => 
            array (
                'batch' => 1,
                'id' => 1,
                'migration' => '2018_11_05_113438_create_accounts_table',
            ),
            1 => 
            array (
                'batch' => 1,
                'id' => 2,
                'migration' => '2018_11_05_113510_create_clients_table',
            ),
            2 => 
            array (
                'batch' => 1,
                'id' => 3,
                'migration' => '2018_11_15_112823_create_agreements_table',
            ),
            3 => 
            array (
                'batch' => 1,
                'id' => 4,
                'migration' => '2018_11_15_113129_create_app_settings_table',
            ),
            4 => 
            array (
                'batch' => 1,
                'id' => 5,
                'migration' => '2018_11_15_113332_create_auto_imports_table',
            ),
            5 => 
            array (
                'batch' => 1,
                'id' => 6,
                'migration' => '2018_11_15_114301_create_auto_import_triggers_table',
            ),
            6 => 
            array (
                'batch' => 1,
                'id' => 7,
                'migration' => '2018_11_15_114645_create_client_languages_table',
            ),
            7 => 
            array (
                'batch' => 1,
                'id' => 8,
                'migration' => '2018_11_15_114953_create_contents_table',
            ),
            8 => 
            array (
                'batch' => 1,
                'id' => 9,
                'migration' => '2018_11_15_115202_create_content_groups_table',
            ),
            9 => 
            array (
                'batch' => 1,
                'id' => 10,
                'migration' => '2018_11_15_115545_create_files_table',
            ),
            10 => 
            array (
                'batch' => 1,
                'id' => 11,
                'migration' => '2018_11_15_115716_create_file_body_storage_files_table',
            ),
            11 => 
            array (
                'batch' => 1,
                'id' => 12,
                'migration' => '2018_11_15_123238_create_icons_table',
            ),
            12 => 
            array (
                'batch' => 1,
                'id' => 13,
                'migration' => '2018_11_15_124150_create_links_table',
            ),
            13 => 
            array (
                'batch' => 1,
                'id' => 14,
                'migration' => '2018_11_15_124325_create_menus_table',
            ),
            14 => 
            array (
                'batch' => 1,
                'id' => 15,
                'migration' => '2018_11_15_130526_create_notifications_table',
            ),
            15 => 
            array (
                'batch' => 1,
                'id' => 16,
                'migration' => '2018_11_15_131306_create_notification_bodies_table',
            ),
            16 => 
            array (
                'batch' => 1,
                'id' => 17,
                'migration' => '2018_11_15_131836_create_notification_tag_table',
            ),
            17 => 
            array (
                'batch' => 1,
                'id' => 18,
                'migration' => '2018_11_15_131908_create_notification_user_table',
            ),
            18 => 
            array (
                'batch' => 1,
                'id' => 19,
                'migration' => '2018_11_15_131936_create_operators_table',
            ),
            19 => 
            array (
                'batch' => 1,
                'id' => 20,
                'migration' => '2018_11_15_132322_create_posts_table',
            ),
            20 => 
            array (
                'batch' => 1,
                'id' => 21,
                'migration' => '2018_11_15_132558_create_post_body_storage_files_table',
            ),
            21 => 
            array (
                'batch' => 1,
                'id' => 22,
                'migration' => '2018_11_15_132655_create_storage_files_table',
            ),
            22 => 
            array (
                'batch' => 1,
                'id' => 23,
                'migration' => '2018_11_15_133114_create_subscribes_table',
            ),
            23 => 
            array (
                'batch' => 1,
                'id' => 24,
                'migration' => '2018_11_15_133307_create_taggings_table',
            ),
            24 => 
            array (
                'batch' => 1,
                'id' => 25,
                'migration' => '2018_11_15_133508_create_tags_table',
            ),
            25 => 
            array (
                'batch' => 1,
                'id' => 26,
                'migration' => '2018_11_15_133703_create_tag_groups_table',
            ),
            26 => 
            array (
                'batch' => 1,
                'id' => 27,
                'migration' => '2018_11_15_133818_create_translations_table',
            ),
            27 => 
            array (
                'batch' => 1,
                'id' => 28,
                'migration' => '2018_11_15_133949_create_trigger_tags_table',
            ),
            28 => 
            array (
                'batch' => 1,
                'id' => 29,
                'migration' => '2018_11_15_134020_create_tutorials_table',
            ),
            29 => 
            array (
                'batch' => 1,
                'id' => 30,
                'migration' => '2018_11_15_134106_create_users_table',
            ),
            30 => 
            array (
                'batch' => 1,
                'id' => 31,
                'migration' => '2018_11_15_134411_create_websites_table',
            ),
            31 => 
            array (
                'batch' => 1,
                'id' => 32,
                'migration' => '2018_11_15_134505_create_website_body_storage_files_table',
            ),
            32 => 
            array (
                'batch' => 1,
                'id' => 33,
                'migration' => '2018_11_22_134350_create_auto_import_statuses_table',
            ),
            33 => 
            array (
                'batch' => 1,
                'id' => 34,
                'migration' => '2018_11_22_135223_create_auto_import_histories_table',
            ),
            34 => 
            array (
                'batch' => 1,
                'id' => 35,
                'migration' => '2018_11_22_135523_create_auto_import_messages_table',
            ),
            35 => 
            array (
                'batch' => 1,
                'id' => 36,
                'migration' => '2018_11_22_135627_create_auto_notifications_table',
            ),
            36 => 
            array (
                'batch' => 1,
                'id' => 37,
                'migration' => '2018_11_26_125602_alter_accounts_table',
            ),
            37 => 
            array (
                'batch' => 1,
                'id' => 38,
                'migration' => '2019_01_05_153625_create_announcements_table',
            ),
            38 => 
            array (
                'batch' => 1,
                'id' => 39,
                'migration' => '2019_01_07_111811_remove_unique_index_of_contents_table',
            ),
            39 => 
            array (
                'batch' => 1,
                'id' => 40,
                'migration' => '2019_01_22_174216_create_thumbnails_table',
            ),
            40 => 
            array (
                'batch' => 1,
                'id' => 41,
                'migration' => '2019_02_01_112109_alter_menus_table',
            ),
            41 => 
            array (
                'batch' => 1,
                'id' => 42,
                'migration' => '2019_02_12_120019_add_color_code_to_tags',
            ),
            42 => 
            array (
                'batch' => 2,
                'id' => 43,
                'migration' => '2019_02_13_155859_create_client_settings_table',
            ),
            43 => 
            array (
                'batch' => 2,
                'id' => 44,
                'migration' => '2019_02_14_111915_create_map_data_groups_table',
            ),
            44 => 
            array (
                'batch' => 2,
                'id' => 45,
                'migration' => '2019_02_14_115304_create_map_datas_table',
            ),
            45 => 
            array (
                'batch' => 2,
                'id' => 46,
                'migration' => '2019_02_14_131255_create_map_body_storage_files_table',
            ),
            46 => 
            array (
                'batch' => 3,
                'id' => 47,
                'migration' => '2019_02_26_112734_alter_users_table',
            ),
            47 => 
            array (
                'batch' => 3,
                'id' => 48,
                'migration' => '2019_02_26_191525_alter_notification_user_table',
            ),
            48 => 
            array (
                'batch' => 4,
                'id' => 49,
                'migration' => '2019_03_05_111850_remove_body_options_json_of_notification_bodies_table',
            ),
            49 => 
            array (
                'batch' => 4,
                'id' => 50,
                'migration' => '2019_03_13_113410_add_is_speech_generated_posts_table',
            ),
            50 => 
            array (
                'batch' => 4,
                'id' => 51,
                'migration' => '2019_03_13_114600_create_post_speeches_table',
            ),
            51 => 
            array (
                'batch' => 4,
                'id' => 52,
                'migration' => '2019_02_20_174254_create_weather_speeches_table',
            ),
            52 => 
            array (
                'batch' => 4,
                'id' => 53,
                'migration' => '2019_02_20_175446_create_weathers_table',
            ),
            53 => 
            array (
                'batch' => 4,
                'id' => 54,
                'migration' => '2019_02_26_124348_alter_auto_import_histories_content_id',
            ),
            54 => 
            array (
                'batch' => 4,
                'id' => 55,
                'migration' => '2019_03_22_162945_add_map_data_color_id_to_map_datas_table',
            ),
            55 => 
            array (
                'batch' => 5,
                'id' => 71,
                'migration' => '2019_03_20_103319_create_access_summaries_table',
            ),
            56 => 
            array (
                'batch' => 5,
                'id' => 72,
                'migration' => '2019_03_21_165605_remove_unused_fields_map_data_groups_table',
            ),
            57 => 
            array (
                'batch' => 5,
                'id' => 73,
                'migration' => '2019_03_21_165844_create_map_data_colors_table',
            ),
            58 => 
            array (
                'batch' => 6,
                'id' => 74,
                'migration' => '2019_04_05_134501_alter_access_summaries_table',
            ),
            59 => 
            array (
                'batch' => 7,
                'id' => 75,
                'migration' => '2019_04_05_150421_add_is_drop_latest_on_auto_imports',
            ),
            60 => 
            array (
                'batch' => 7,
                'id' => 76,
                'migration' => '2019_04_05_164923_alter_map_data_colors_table',
            ),
            61 => 
            array (
                'batch' => 7,
                'id' => 77,
                'migration' => '2019_04_05_165845_alter_map_data_groups_table',
            ),
            62 => 
            array (
                'batch' => 8,
                'id' => 78,
                'migration' => '2019_04_11_154417_add_theme_color_code_content_group_table',
            ),
            63 => 
            array (
                'batch' => 9,
                'id' => 79,
                'migration' => '2019_04_10_195007_drop_is_drop_latest',
            ),
            64 => 
            array (
                'batch' => 9,
                'id' => 80,
                'migration' => '2019_04_15_132540_create_translation_replacements_table',
            ),
            65 => 
            array (
                'batch' => 9,
                'id' => 81,
                'migration' => '2019_04_15_133458_create_translation_replacement_templates_table',
            ),
            66 => 
            array (
                'batch' => 9,
                'id' => 82,
                'migration' => '2019_04_22_113801_alter_template_sub_title_on_templates',
            ),
            67 => 
            array (
                'batch' => 10,
                'id' => 83,
                'migration' => '2019_05_02_183931_create_jobs_table',
            ),
            68 => 
            array (
                'batch' => 11,
                'id' => 84,
                'migration' => '2019_05_02_184100_create_failed_jobs_table',
            ),
            69 => 
            array (
                'batch' => 12,
                'id' => 87,
                'migration' => '2019_05_04_185107_alter_change_subscribe_table_subscribe_arn',
            ),
            70 => 
            array (
                'batch' => 13,
                'id' => 88,
                'migration' => '2019_05_16_132802_add_is_default_notify_check_and_view_check',
            ),
            71 => 
            array (
                'batch' => 14,
                'id' => 89,
                'migration' => '2019_05_20_190857_add_can_use_api_content_groups_table',
            ),
            72 => 
            array (
                'batch' => 15,
                'id' => 90,
                'migration' => '2019_05_22_104851_change_weathers_content_id',
            ),
            73 => 
            array (
                'batch' => 15,
                'id' => 91,
                'migration' => '2019_05_22_112615_change_add_tagging_index',
            ),
            74 => 
            array (
                'batch' => 15,
                'id' => 92,
                'migration' => '2019_05_22_114637_change_add_contents_index',
            ),
            75 => 
            array (
                'batch' => 16,
                'id' => 93,
                'migration' => '2019_06_03_175008_alter_unique_users_table',
            ),
        ));
        
        
    }
}