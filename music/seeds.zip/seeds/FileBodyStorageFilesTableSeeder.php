<?php

use Illuminate\Database\Seeder;

class FileBodyStorageFilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('file_body_storage_files')->delete();
        
        \DB::table('file_body_storage_files')->insert(array (
            0 => 
            array (
                'file_id' => 20,
                'id' => 19,
                'lang' => 'en',
                'storage_file_id' => 941,
            ),
            1 => 
            array (
                'file_id' => 22,
                'id' => 21,
                'lang' => 'en',
                'storage_file_id' => 1158,
            ),
            2 => 
            array (
                'file_id' => 22,
                'id' => 22,
                'lang' => 'es',
                'storage_file_id' => 1084,
            ),
            3 => 
            array (
                'file_id' => 23,
                'id' => 23,
                'lang' => 'en',
                'storage_file_id' => 1156,
            ),
            4 => 
            array (
                'file_id' => 23,
                'id' => 24,
                'lang' => 'es',
                'storage_file_id' => 1157,
            ),
            5 => 
            array (
                'file_id' => 24,
                'id' => 25,
                'lang' => 'en',
                'storage_file_id' => 1159,
            ),
            6 => 
            array (
                'file_id' => 24,
                'id' => 26,
                'lang' => 'es',
                'storage_file_id' => 1160,
            ),
            7 => 
            array (
                'file_id' => 26,
                'id' => 30,
                'lang' => 'ja',
                'storage_file_id' => 1251,
            ),
            8 => 
            array (
                'file_id' => 26,
                'id' => 31,
                'lang' => 'en',
                'storage_file_id' => 1252,
            ),
            9 => 
            array (
                'file_id' => 26,
                'id' => 32,
                'lang' => 'ko',
                'storage_file_id' => 1253,
            ),
            10 => 
            array (
                'file_id' => 27,
                'id' => 33,
                'lang' => 'ja',
                'storage_file_id' => 1255,
            ),
            11 => 
            array (
                'file_id' => 27,
                'id' => 34,
                'lang' => 'en',
                'storage_file_id' => 1256,
            ),
            12 => 
            array (
                'file_id' => 27,
                'id' => 35,
                'lang' => 'ko',
                'storage_file_id' => 1257,
            ),
            13 => 
            array (
                'file_id' => 28,
                'id' => 36,
                'lang' => 'ja',
                'storage_file_id' => 1482,
            ),
            14 => 
            array (
                'file_id' => 28,
                'id' => 37,
                'lang' => 'en',
                'storage_file_id' => 1483,
            ),
            15 => 
            array (
                'file_id' => 28,
                'id' => 38,
                'lang' => 'ko',
                'storage_file_id' => 1484,
            ),
            16 => 
            array (
                'file_id' => 29,
                'id' => 39,
                'lang' => 'ja',
                'storage_file_id' => 1269,
            ),
            17 => 
            array (
                'file_id' => 29,
                'id' => 40,
                'lang' => 'en',
                'storage_file_id' => 1270,
            ),
            18 => 
            array (
                'file_id' => 29,
                'id' => 41,
                'lang' => 'ko',
                'storage_file_id' => 1271,
            ),
            19 => 
            array (
                'file_id' => 30,
                'id' => 42,
                'lang' => 'ja',
                'storage_file_id' => 1278,
            ),
            20 => 
            array (
                'file_id' => 30,
                'id' => 43,
                'lang' => 'en',
                'storage_file_id' => 1279,
            ),
            21 => 
            array (
                'file_id' => 32,
                'id' => 45,
                'lang' => 'en',
                'storage_file_id' => 1283,
            ),
            22 => 
            array (
                'file_id' => 32,
                'id' => 46,
                'lang' => 'es',
                'storage_file_id' => 1284,
            ),
            23 => 
            array (
                'file_id' => 34,
                'id' => 49,
                'lang' => 'ja',
                'storage_file_id' => 1392,
            ),
            24 => 
            array (
                'file_id' => 34,
                'id' => 50,
                'lang' => 'en',
                'storage_file_id' => 1393,
            ),
            25 => 
            array (
                'file_id' => 34,
                'id' => 51,
                'lang' => 'ko',
                'storage_file_id' => 1394,
            ),
            26 => 
            array (
                'file_id' => 38,
                'id' => 52,
                'lang' => 'ja',
                'storage_file_id' => 2532,
            ),
            27 => 
            array (
                'file_id' => 38,
                'id' => 53,
                'lang' => 'en',
                'storage_file_id' => 1504,
            ),
            28 => 
            array (
                'file_id' => 38,
                'id' => 54,
                'lang' => 'ko',
                'storage_file_id' => 1505,
            ),
            29 => 
            array (
                'file_id' => 72,
                'id' => 86,
                'lang' => 'ja',
                'storage_file_id' => 2257,
            ),
            30 => 
            array (
                'file_id' => 73,
                'id' => 87,
                'lang' => 'ja',
                'storage_file_id' => 2258,
            ),
            31 => 
            array (
                'file_id' => 74,
                'id' => 88,
                'lang' => 'ja',
                'storage_file_id' => 2259,
            ),
            32 => 
            array (
                'file_id' => 75,
                'id' => 89,
                'lang' => 'ja',
                'storage_file_id' => 2260,
            ),
            33 => 
            array (
                'file_id' => 76,
                'id' => 90,
                'lang' => 'ja',
                'storage_file_id' => 2263,
            ),
            34 => 
            array (
                'file_id' => 77,
                'id' => 91,
                'lang' => 'ja',
                'storage_file_id' => 2264,
            ),
            35 => 
            array (
                'file_id' => 78,
                'id' => 92,
                'lang' => 'ja',
                'storage_file_id' => 2265,
            ),
            36 => 
            array (
                'file_id' => 79,
                'id' => 93,
                'lang' => 'ja',
                'storage_file_id' => 2266,
            ),
            37 => 
            array (
                'file_id' => 80,
                'id' => 94,
                'lang' => 'ja',
                'storage_file_id' => 2267,
            ),
            38 => 
            array (
                'file_id' => 81,
                'id' => 95,
                'lang' => 'ja',
                'storage_file_id' => 2268,
            ),
            39 => 
            array (
                'file_id' => 82,
                'id' => 96,
                'lang' => 'ja',
                'storage_file_id' => 2269,
            ),
            40 => 
            array (
                'file_id' => 83,
                'id' => 97,
                'lang' => 'ja',
                'storage_file_id' => 2762,
            ),
            41 => 
            array (
                'file_id' => 84,
                'id' => 99,
                'lang' => 'ja',
                'storage_file_id' => 2507,
            ),
            42 => 
            array (
                'file_id' => 85,
                'id' => 100,
                'lang' => 'ja',
                'storage_file_id' => 2571,
            ),
            43 => 
            array (
                'file_id' => 85,
                'id' => 101,
                'lang' => 'en',
                'storage_file_id' => 2572,
            ),
            44 => 
            array (
                'file_id' => 85,
                'id' => 102,
                'lang' => 'ko',
                'storage_file_id' => 2573,
            ),
            45 => 
            array (
                'file_id' => 86,
                'id' => 103,
                'lang' => 'ja',
                'storage_file_id' => 2741,
            ),
            46 => 
            array (
                'file_id' => 92,
                'id' => 105,
                'lang' => 'ja',
                'storage_file_id' => 2749,
            ),
            47 => 
            array (
                'file_id' => 94,
                'id' => 108,
                'lang' => 'ja',
                'storage_file_id' => 2752,
            ),
            48 => 
            array (
                'file_id' => 96,
                'id' => 111,
                'lang' => 'ja',
                'storage_file_id' => 2756,
            ),
            49 => 
            array (
                'file_id' => 86,
                'id' => 112,
                'lang' => 'en',
                'storage_file_id' => 2757,
            ),
            50 => 
            array (
                'file_id' => 92,
                'id' => 113,
                'lang' => 'en',
                'storage_file_id' => 2758,
            ),
            51 => 
            array (
                'file_id' => 96,
                'id' => 114,
                'lang' => 'en',
                'storage_file_id' => 2759,
            ),
            52 => 
            array (
                'file_id' => 94,
                'id' => 115,
                'lang' => 'en',
                'storage_file_id' => 2760,
            ),
            53 => 
            array (
                'file_id' => 97,
                'id' => 116,
                'lang' => 'ja',
                'storage_file_id' => 2763,
            ),
            54 => 
            array (
                'file_id' => 99,
                'id' => 117,
                'lang' => 'ja',
                'storage_file_id' => 2768,
            ),
            55 => 
            array (
                'file_id' => 137,
                'id' => 151,
                'lang' => 'ja',
                'storage_file_id' => 3759,
            ),
            56 => 
            array (
                'file_id' => 137,
                'id' => 152,
                'lang' => 'en',
                'storage_file_id' => 3761,
            ),
        ));
        
        
    }
}