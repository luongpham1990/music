<?php

use Illuminate\Database\Seeder;

class AutoImportStatusesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_statuses')->delete();
        
        \DB::table('auto_import_statuses')->insert(array (
            0 => 
            array (
                'auto_import_id' => 1,
                'continuous_failed_count' => 1,
                'created_at' => '2019-01-25 12:24:25',
                'id' => 1,
                'updated_at' => '2019-05-13 20:36:02',
            ),
            1 => 
            array (
                'auto_import_id' => 47,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 12:53:22',
                'id' => 16,
                'updated_at' => '2019-01-09 12:53:22',
            ),
            2 => 
            array (
                'auto_import_id' => 49,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 13:28:29',
                'id' => 18,
                'updated_at' => '2019-01-09 13:28:29',
            ),
            3 => 
            array (
                'auto_import_id' => 50,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 16:08:14',
                'id' => 19,
                'updated_at' => '2019-01-09 16:08:14',
            ),
            4 => 
            array (
                'auto_import_id' => 51,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 16:39:14',
                'id' => 20,
                'updated_at' => '2019-01-09 16:39:14',
            ),
            5 => 
            array (
                'auto_import_id' => 52,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 16:46:10',
                'id' => 21,
                'updated_at' => '2019-01-09 16:46:10',
            ),
            6 => 
            array (
                'auto_import_id' => 53,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 17:06:16',
                'id' => 22,
                'updated_at' => '2019-01-09 17:06:16',
            ),
            7 => 
            array (
                'auto_import_id' => 54,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-14 15:16:45',
                'id' => 23,
                'updated_at' => '2019-01-14 15:16:45',
            ),
            8 => 
            array (
                'auto_import_id' => 55,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-14 15:55:30',
                'id' => 24,
                'updated_at' => '2019-01-14 15:55:30',
            ),
            9 => 
            array (
                'auto_import_id' => 56,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-14 16:11:10',
                'id' => 25,
                'updated_at' => '2019-01-14 16:11:10',
            ),
            10 => 
            array (
                'auto_import_id' => 57,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-17 16:58:44',
                'id' => 26,
                'updated_at' => '2019-01-17 16:58:44',
            ),
            11 => 
            array (
                'auto_import_id' => 58,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-17 17:00:32',
                'id' => 27,
                'updated_at' => '2019-01-17 17:00:32',
            ),
            12 => 
            array (
                'auto_import_id' => 59,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-18 17:52:11',
                'id' => 28,
                'updated_at' => '2019-01-18 17:52:11',
            ),
            13 => 
            array (
                'auto_import_id' => 23,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-25 12:41:56',
                'id' => 30,
                'updated_at' => '2019-01-25 12:41:56',
            ),
            14 => 
            array (
                'auto_import_id' => 24,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-31 12:28:27',
                'id' => 31,
                'updated_at' => '2019-01-31 12:28:27',
            ),
            15 => 
            array (
                'auto_import_id' => 112,
                'continuous_failed_count' => 10,
                'created_at' => '2019-05-31 10:57:34',
                'id' => 119,
                'updated_at' => '2019-06-06 20:15:24',
            ),
            16 => 
            array (
                'auto_import_id' => 113,
                'continuous_failed_count' => 9,
                'created_at' => '2019-05-31 11:57:07',
                'id' => 120,
                'updated_at' => '2019-06-06 20:15:44',
            ),
            17 => 
            array (
                'auto_import_id' => 114,
                'continuous_failed_count' => 9,
                'created_at' => '2019-05-31 12:26:01',
                'id' => 121,
                'updated_at' => '2019-06-06 20:16:04',
            ),
            18 => 
            array (
                'auto_import_id' => 115,
                'continuous_failed_count' => 0,
                'created_at' => '2019-05-31 12:31:20',
                'id' => 122,
                'updated_at' => '2019-06-07 00:40:08',
            ),
            19 => 
            array (
                'auto_import_id' => 116,
                'continuous_failed_count' => 9,
                'created_at' => '2019-05-31 12:39:45',
                'id' => 123,
                'updated_at' => '2019-06-06 20:16:44',
            ),
            20 => 
            array (
                'auto_import_id' => 117,
                'continuous_failed_count' => 8,
                'created_at' => '2019-05-31 12:42:35',
                'id' => 124,
                'updated_at' => '2019-06-06 20:17:04',
            ),
        ));
        
        
    }
}