<?php

use Illuminate\Database\Seeder;

class AccountsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('accounts')->delete();
        
        \DB::table('accounts')->insert(array (
            0 => 
            array (
                'created_at' => '2018-11-27 12:34:48',
                'email' => 'sgm@ml.visor.co.jp',
                'id' => 1,
                'name' => 'Admin',
                'password' => '$2y$10$FHYUG5Eta0MnrjwuuvwhUOnwQzmyV8DwgSNWJcQeGmyCQ3jt9wIq.',
                'remember_token' => 'GZJ7HAVDhxwjWkznBWamS2U6IeUwDbNoCxcMHC09ka2qH4YHEhzqSifI3Eqo',
                'role_div' => 101,
                'updated_at' => '2018-11-27 12:34:48',
                'usage_status' => 1,
                'username' => 'visor',
            ),
            1 => 
            array (
                'created_at' => '2018-11-28 11:47:16',
                'email' => 'tran.thuy.tien@vinicorp.com.vn',
                'id' => 3,
                'name' => 'Thuy Tien Thuy Tien Thuy Tien',
                'password' => '$2y$10$HQEcjvnSykaE2zmD2BYNvO61K0zyX9llUGq67hNKKI8.ix83F6.C2',
                'remember_token' => NULL,
                'role_div' => 101,
                'updated_at' => '2018-12-06 17:35:09',
                'usage_status' => 1,
                'username' => 'tientt2',
            ),
            2 => 
            array (
                'created_at' => '2018-11-29 17:59:44',
                'email' => 'huydn@vinicorp.com.vn',
                'id' => 4,
                'name' => 'DO Huy',
                'password' => '$2y$10$eKieZf29wxUAqY6KL7UKQeT1VpwJvu4AdpP01KgxwZXD1UrMKp64a',
                'remember_token' => NULL,
                'role_div' => 101,
                'updated_at' => '2018-11-29 17:59:54',
                'usage_status' => 1,
                'username' => 'huydn',
            ),
            3 => 
            array (
                'created_at' => '2018-11-29 18:02:03',
                'email' => 'huydn1186@gmail.tk',
                'id' => 6,
                'name' => 'ten ten111',
                'password' => '$2y$10$lNRJ501.skcw8e1z551UVOEn0DFuE/.loRGYVO6i3OBz4JPqDTSTW',
                'remember_token' => NULL,
                'role_div' => 101,
                'updated_at' => '2018-11-29 18:26:16',
                'usage_status' => 1,
                'username' => 'huydn31',
            ),
            4 => 
            array (
                'created_at' => '2018-11-29 18:09:03',
                'email' => 'huadhs@gmail.com',
                'id' => 7,
                'name' => 'huydn5',
                'password' => '$2y$10$WwSHIsatqU3HSI5.EXXWKOXDLoweYMLNuW8puB7tHQ8bjK7HnT8Pm',
                'remember_token' => 'tuLmD5LVQk9OHehS7MYgK0aBo7ZfcfLMYnTWhEqs7eUHSrl053GgaCaoHJnL',
                'role_div' => 101,
                'updated_at' => '2018-11-29 18:40:33',
                'usage_status' => 1,
                'username' => 'huydn5',
            ),
            5 => 
            array (
                'created_at' => '2018-11-29 19:05:58',
                'email' => 'thai@gmail.com',
                'id' => 8,
                'name' => 'ThaiNH1991',
                'password' => '$2y$10$Ee9YhqqzdotdHFo4/zH81.rnj.5GSE1CJw/DneSDUMbCWbbczgXbS',
                'remember_token' => NULL,
                'role_div' => 101,
                'updated_at' => '2018-12-06 17:42:59',
                'usage_status' => 1,
                'username' => 'thainh',
            ),
            6 => 
            array (
                'created_at' => '2018-12-05 11:56:55',
                'email' => 'nguyenminhthu.utc@gmail.com',
                'id' => 9,
                'name' => 'thu',
                'password' => '$2y$10$CU0aAQaJtZ7xme82QDHnQeMCqisq4Hjv9tOEV.bZwu7mGaujKeCHW',
                'remember_token' => NULL,
                'role_div' => 1,
                'updated_at' => '2018-12-05 15:19:36',
                'usage_status' => 1,
                'username' => '223334',
            ),
            7 => 
            array (
                'created_at' => '2018-12-07 10:26:11',
                'email' => 'thu@gmail.com',
                'id' => 15,
                'name' => 'thuntm',
                'password' => '$2y$10$XhHHBqSzN4A9Y2idObqR.equhb739RgN1SsqOEcl68P7tZcTik5IS',
                'remember_token' => NULL,
                'role_div' => 1,
                'updated_at' => '2018-12-07 10:26:11',
                'usage_status' => 1,
                'username' => 'thuntm',
            ),
            8 => 
            array (
                'created_at' => '2019-01-30 18:38:57',
                'email' => 'nguyenminhthu.utc@gmail.com',
                'id' => 16,
                'name' => 'Minh Thu',
                'password' => '$2y$10$FQnAiHZzV6cc3jlsj97Fn.Ft4AslVuMZE4qQtu./NuC8IqRZLErGi',
                'remember_token' => NULL,
                'role_div' => 101,
                'updated_at' => '2019-01-30 18:39:29',
                'usage_status' => 1,
                'username' => 'minhthunguyenthi',
            ),
            9 => 
            array (
                'created_at' => '2019-02-11 11:24:03',
                'email' => 'huy@gmail.com',
                'id' => 17,
                'name' => 'adsdd',
                'password' => '$2y$10$AriiF2TAM5SPyCzktEEQAuohjLbh2AtjD9mPzkyReB2pr7uwVS7zm',
                'remember_token' => NULL,
                'role_div' => 1,
                'updated_at' => '2019-02-11 11:24:03',
                'usage_status' => 1,
                'username' => 'lasdasdasdasd',
            ),
            10 => 
            array (
                'created_at' => '2019-03-01 16:47:31',
                'email' => 'ngoc@gmail.com',
                'id' => 18,
                'name' => 'Ngoc',
                'password' => '$2y$10$Qf1kZTZUtgmokpWSTfyMae9kyIqIOZrZRbcatAfvq4Hwu8BJok44e',
                'remember_token' => NULL,
                'role_div' => 1,
                'updated_at' => '2019-03-01 18:38:43',
                'usage_status' => 1,
                'username' => 'khanhngoc',
            ),
        ));
        
        
    }
}