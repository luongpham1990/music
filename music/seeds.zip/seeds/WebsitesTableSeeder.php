<?php

use Illuminate\Database\Seeder;

class WebsitesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('websites')->delete();
        
        \DB::table('websites')->insert(array (
            0 => 
            array (
                'body' => 'colen khong',
                'content_id' => 125,
                'id' => 8,
                'lang' => 'es',
                'title' => 'colen khong',
            ),
            1 => 
            array (
                'body' => 'test validate webpage required 1',
                'content_id' => 156,
                'id' => 12,
                'lang' => 'zh',
                'title' => 'test validate webpage required 1',
            ),
            2 => 
            array (
                'body' => 'test',
                'content_id' => 179,
                'id' => 17,
                'lang' => 'es',
                'title' => 'test show language',
            ),
            3 => 
            array (
                'body' => 'webpage1111111111webpage1111111111',
                'content_id' => 188,
                'id' => 18,
                'lang' => 'es',
                'title' => 'webpage1111111111',
            ),
            4 => 
            array (
            'body' => '<span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>!DOCTYPE<span style="box-sizing: inherit; color: red;">&nbsp;html</span><span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">HTML Tutorial</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a heading</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a paragraph.</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span>',
                'content_id' => 271,
                'id' => 20,
                'lang' => 'en',
                'title' => 'test content offline en',
            ),
            5 => 
            array (
            'body' => 'Body (en)<div><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="box-sizing: inherit; font-size: 12pt; letter-spacing: 0px !important;"><span style="box-sizing: inherit; font-weight: 700; letter-spacing: 0px !important;"><span style="color: rgb(51, 51, 51);">■</span><span style="color: rgb(255, 0, 0);">ドイツ・イギリスの「幼少接続」事情</span></span></span><br style="box-sizing: inherit; letter-spacing: 0px !important;"><span style="color: rgb(51, 51, 255);">ドイツで進められている幼少接続プロジェクトについて、「発達に遅れのある子どもを伸ばすことは大切。しかし、優秀な子どもも伸ばす幼児教育・保育のあり方を考える必要がある」とドイツの研究者は指摘しています。</span></p><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="color: rgb(51, 51, 255);">幼児教育・保育において、単に文字を読める能力や計算能力のみはなく、自分の考えをまとめたり、表現したりできる能力も問われるようになっています。</span></p><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="color: rgb(51, 51, 255);">イギリスでは、教育・保育内容に、挑戦を伴う活動に対する評価指標が盛り込まれています。発達に遅れのある子供を伸ばすことにとどまらず、秀でた能力を持っている子供を伸ばすことにも力を入れているためです</span><span style="color: rgb(51, 51, 51);">。</span></p><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">例えば、あるイギリスの保育園では、子どもが知的にも身体的にも自分の能力を十分発揮できるような活動が組み込まれ、子どもたちが友だち同士でうまく関わりながら遊べるように、保育者が上手に間に入って支えています。</p></div>',
                'content_id' => 272,
                'id' => 21,
                'lang' => 'en',
            'title' => 'title (en)',
            ),
            6 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">49十ヘツワ同玲ノソヒ世暮ろぞぴ日織まくり役竹タテキ最神とい密計ほ製選ネレ顔科をすがめ移康りざどろ岐2際島ラオレウ静視スホ井専ぎ効要じト正撮ケヘサ況輩やかゃ輔北標経沖おぼゆう。作やきて治差ひルド加明ツヲシ聖店載8教けゆの独助するん父意りやげス加2無具リ写52堂リ進興カモ合康ぐ守京ルワユ界堀些仄伽ぎびく。</span></font>',
                'content_id' => 289,
                'id' => 22,
                'lang' => 'ja',
                'title' => 'test offline webpage moblie 1 ja',
            ),
            7 => 
            array (
            'body' => '<span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有感地震回数は、最近の１０年間では年平均１９回程度にのぼり、日本で最も有感地震回数の多い地域の一つです。特に１９２０年以降報告回数が増えたことが知られています。近年この地域に大規模な地震の発生は知られていないので、この地震活動は特定の大地震の余震ではありません。その規模は最大でもＭ５程度ですが、震源がごく浅いために、局所的に被害が生じたこともあります。この付近の東側と西側では、フィリピン海プレートの沈み込む角度が違い、この付近の地下構造は複雑になっています。また、この付近の深さ数ｋｍまでの浅いところは、堅いけれども脆い性質を持つ古い時代の岩石が分布しています。これらのことが、和歌山市付近の定常的な地震活動の原因と考えられています。また、地震が発生する深さは数ｋｍよりも浅いところに限られており、上記の岩石が分布している深さで発生していると考えられます。なお、この地震活動が発生している地域の北部には</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">があります。その活動を起こす力の向きは、和歌山市付近の地震活動（東西方向の圧縮力）と</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">の活動（北西−南東方向の圧縮力）では異なっていますが、両者の関係についてまだはっきりとは分かっていません。</span>',
                'content_id' => 290,
                'id' => 23,
                'lang' => 'en',
            'title' => 'website (en)',
            ),
            8 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font>',
                'content_id' => 291,
                'id' => 24,
                'lang' => 'ja',
                'title' => 'test offline mobile webpage 2 - ja',
            ),
            9 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font>',
                'content_id' => 292,
                'id' => 25,
                'lang' => 'ja',
                'title' => 'test offline mobile webpage 3 - ja',
            ),
            10 => 
            array (
                'body' => '<div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font></div><div><br></div>',
                'content_id' => 293,
                'id' => 26,
                'lang' => 'ja',
                'title' => 'test offline mobile webpage 4 - ja',
            ),
            11 => 
            array (
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Among the earthquakes that occurred in the surrounding area and the earthquake in 1899 (M 7.0, the estimated depth of 40 to 50 km: sometimes called the Kii Yamawa earthquake) and the Yoshino earthquake year 1952 (M 6.7, depth of about 60 km) Earthquakes that occur in a place where a deep occurrence occurs in the Philippine Sea sinking may have been damaged. In addition, like the 1960 "Chile earthquake", we had to suffer a tsunami even when an earthquake hit a foreign country.</span></font>',
                'content_id' => 302,
                'id' => 27,
                'lang' => 'en',
                'title' => 'test web en',
            ),
            12 => 
            array (
            'body' => 'body web ofline (ja)',
                'content_id' => 315,
                'id' => 31,
                'lang' => 'ja',
            'title' => 'title web ofline (ja)',
            ),
            13 => 
            array (
                'body' => '私は就職活動を通じて、留学当初とは働くことに対する考えが変わりましたね。有名な大学に入って、卒業後は有名な会社に入る。以前は、それが良い人生だと思っていました。しかし、日本で様々なことを経験する中で、スケールや影響力の大きさよりも、自分ができることを着実に遂行していくことが大事だと思うようになったんです。世の中には、自分の経験や知識を必要としている人がいて、そうした人のために行動していきたい。今はそう考えています。',
                'content_id' => 344,
                'id' => 35,
                'lang' => 'ja',
            'title' => 'Test title (ja)',
            ),
            14 => 
            array (
            'body' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">There may be many who feel in the news that the current situation surrounding children and young people is very unstable, such as child abuse, school refusal, bullying, suicide, poverty, unwanted pregnancy, etc. Child abuse reached a record high in 2017 over 130,000 (120,000 last year). In addition, 1 out of 7 children are in poverty. There are many children who suffer from abuse and poverty in families that form the foundation of children.</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">In the school where children are living next to their homes, 190,000 (130,000 in the previous year) have failed, and 410,000 in the bullying (320,000 in the previous year), both reached record highs. Homes and schools, which should be major places for children, are not places that can be relieved, but are becoming places that suffer from violence, abusive language, poverty, bullying, etc.</span></font></div>',
                'content_id' => 390,
                'id' => 36,
                'lang' => 'ja',
                'title' => 'Title webpage en',
            ),
            15 => 
            array (
                'body' => '4）講演内容が子どもの現状を伝えていることから、講演内容の録画・録音及び、当日の内容の無断の公開をお断りしています。公開を前提にしたものの場合、事前に内容等の検討が必要ですので、必ず事前にご確認をお願いします。また、講演の様子を貴団体のHP等で掲載する場合、必ずその内容の確認をとらせて頂きます。掲載内容の修正の依頼をさせて頂く場合がありますのでご了承下さい。<br>5）投影資料は当日USBにて持参いたします。データでの事前送信は原則ご遠慮いただいています。個人情報保護などの観点からもご理解いただけますと幸いです。<br>6）集合時間・解散時間は講演時間の前後45分以内でお願いしております。少人数で組織を運営しており、ご理解いただけますと幸いです。<br>7）個人情報保護などの観点からも講演内容の無断での転送・公開はご遠慮いただいています。希望される場合、事前にご相談ください',
                'content_id' => 593,
                'id' => 44,
                'lang' => 'ja',
                'title' => 'Title web ja',
            ),
            16 => 
            array (
                'body' => '1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。<br>2）講演当日の様子を、ホームページやFacebook等で当団体の活動報告として紹介をさせて頂く場合があります。紹介を望まない場合、事前にお申し付けください。なお、事前了承を得ない場合、参加者の顔や個人名は特定できない形で掲載いたします。<br>3）講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。<br>4）講演内容が子どもの現状を伝えていることから、講演内容の録画・録音及び、当日の内容の無断の公開をお断りしています。公開を前提にしたものの場合、事前に内容等の検討が必要ですので、必ず事前にご確認をお願いします。また、講演の様子を貴団体のHP等で掲載する場合、必ずその内容の確認をとらせて頂きます。掲載内容の修正の依頼をさせて頂く場合がありますのでご了承下さい',
                'content_id' => 594,
                'id' => 45,
                'lang' => 'ja',
                'title' => 'title webpage ja',
            ),
            17 => 
            array (
                'body' => '1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。<br>2）講演当日の様子を、ホームページやFacebook等で当団体の活動報告として紹介をさせて頂く場合があります。紹介を望まない場合、事前にお申し付けください。なお、事前了承を得ない場合、参加者の顔や個人名は特定できない形で掲載いたします。<br>3）講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。<br>4）講演内容が子どもの現状を伝えていることから、講演内容の録画・録音及び、当日の内容の無断の公開をお断りしています。公開を前提にしたものの場合、事前に内容等の検討が必要ですので、必ず事前にご確認をお願いします。また、講演の様子を貴団体のHP等で掲載する場合、必ずその内容の確認をとらせて頂きます。掲載内容の修正の依頼をさせて頂く場合がありますのでご了承下さい。<br>5',
                'content_id' => 596,
                'id' => 47,
                'lang' => 'ja',
                'title' => 'page 5 ja',
            ),
            18 => 
            array (
                'body' => '<span style="font-size: 13.3333px;">1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">2）講演当日の様子を、ホームページやFacebook等で当団体の活動報告として紹介をさせて頂く場合があります。紹介を望まない場合、事前にお申し付けください。なお、事前了承を得ない場合、参加者の顔や個人名は特定できない形で掲載いたします。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">3）講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。</span>',
                'content_id' => 598,
                'id' => 49,
                'lang' => 'ja',
                'title' => 'webpage 4',
            ),
            19 => 
            array (
                'body' => '<div style=""><span style="font-size: 13.3333px;">3）領収証の宛名は、当団体へのご登録名・ご登録住所とさせていただきます。転居などされた場合は、ご登録情報変更についてご連絡くださいますようお願いいたします。</span></div>
ベトナム生地
<br>
<img src="vai-09_52_42_002_815e1fe1-8877-41fb-912b-88bd924f2cfa_20190508175139.jpg" width="300" height="300">
</br>
さくら
<br>
<img src="japan-sakura_750_536_8fb78241-ad67-426a-a609-5828b6945244_20190508175830.jpg" width="300" height="300">
</br>',
                'content_id' => 724,
                'id' => 50,
                'lang' => 'ja',
                'title' => 'Subpage1',
            ),
            20 => 
            array (
                'body' => '（２）保安確保の指導
危険物施設の位置・構造・設備の状況及び危険物の貯蔵・取扱いの方法が、危険物
関係法令に適合しているか否かについて立入検査を実施し、必要がある場合は、事業
所の管理者等に対し、災害防止上必要な助言又は指導を行う。 <br>
<img src="Anh1_da64e148-31f2-40ae-85e4-0ac971d7a0e1_20190508163129.png" width="300" height="300">
<br>
Japanese food
<br>
<img src="Nho_8c60c75a-e7e0-4e81-be9f-468f825ed121_20190508175043.jpg" width="300" height="300">
<br>',
                'content_id' => 725,
                'id' => 51,
                'lang' => 'ja',
                'title' => 'offline 2',
            ),
            21 => 
            array (
            'body' => '<div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">危険物等（危険物、高圧ガス、火薬類、毒劇物をいう。以下同じ）による災害を防止す
るため、取扱施設の現況を把握し、消防法令等関係法令に基づく安全確保対策を推進する
ため、今後とも法令遵守の徹底を図る。
各危険物等取扱事業所等への災害に対するマニュアル（災害時に対する応急措置・連絡
系統の確保など）作成指導の徹底のほか、消防本部等関係機関の施設立入検査の徹底を図
り、法令遵守に基づく危険物等施設の安全確保を推進する。
また、施設全体の安全性向上の確立を図る。</span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"=""><br></span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">
<a href="177.html">WebPage 1</a>
<br><br>
<a href="178.html">WebPage 2</a><br></span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">

<br>File 1
<br><img src="hinh-anh-ngua-lua-1_20190312114747.png"  ="" width="350" height="350"><br>
<br>File 2
<br><img src="anh-dep-ve-chau-au-thap-eiffel-cua-phap-5_a6522597-9d38-4566-b30e-62b83a7bf9fc_20190422172726.jpg" width="350" height="350"><br></span></div><a data-name="abc" href="https://stackoverflow.com/questions/32106849/getcurrentposition-and-watchposition-are-deprecated-on-insecure-origins" class="btn btn-menu btn-menu-blue content-item"><div class="border-dash flex-container" style="display: flex; padding: 5px 10px;">
<div class="" style="flex-grow: 1; text-align: right">
<i class="fas fa-angle-right"></i>
</div>
</div>
</a>

<ul><li><a href="matchi-yell_5ebddc2f-e661-4ee9-9f33-843e950e79cd_20190509122000.pdf">File PDF</a></li></ul>
<ul><li><a href="M03.2%20顧客作成_f4526ca0-511a-44a5-87da-1d30a6a68331_20190509122403.pdf">File PDF2</a></li></ul>',
                'content_id' => 745,
                'id' => 52,
                'lang' => 'ja',
                'title' => 'web offline ja',
            ),
        ));
        
        
    }
}