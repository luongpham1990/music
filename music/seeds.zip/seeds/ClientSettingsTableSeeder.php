<?php

use Illuminate\Database\Seeder;

class ClientSettingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('client_settings')->delete();
        
        \DB::table('client_settings')->insert(array (
            0 => 
            array (
                'client_id' => 1,
                'created_at' => NULL,
                'id' => 1,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyDXWUSlt71lXYTR4jAQeQNIx5G2jIMWjd4',
                'updated_at' => NULL,
            ),
            1 => 
            array (
                'client_id' => 182,
                'created_at' => '2019-03-01 16:58:37',
                'id' => 2,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            2 => 
            array (
                'client_id' => 182,
                'created_at' => '2019-03-01 16:58:37',
                'id' => 3,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            3 => 
            array (
                'client_id' => 182,
                'created_at' => '2019-03-01 16:58:37',
                'id' => 4,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            4 => 
            array (
                'client_id' => 183,
                'created_at' => '2019-03-01 17:09:17',
                'id' => 5,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            5 => 
            array (
                'client_id' => 183,
                'created_at' => '2019-03-01 17:09:17',
                'id' => 6,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            6 => 
            array (
                'client_id' => 183,
                'created_at' => '2019-03-01 17:09:17',
                'id' => 7,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            7 => 
            array (
                'client_id' => 184,
                'created_at' => '2019-03-01 17:16:50',
                'id' => 8,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            8 => 
            array (
                'client_id' => 184,
                'created_at' => '2019-03-01 17:16:50',
                'id' => 9,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            9 => 
            array (
                'client_id' => 184,
                'created_at' => '2019-03-01 17:16:50',
                'id' => 10,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            10 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:00:59',
                'id' => 11,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            11 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:00:59',
                'id' => 12,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            12 => 
            array (
                'client_id' => 185,
                'created_at' => '2019-03-01 18:00:59',
                'id' => 13,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            13 => 
            array (
                'client_id' => 186,
                'created_at' => '2019-03-01 18:04:35',
                'id' => 14,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            14 => 
            array (
                'client_id' => 186,
                'created_at' => '2019-03-01 18:04:35',
                'id' => 15,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            15 => 
            array (
                'client_id' => 186,
                'created_at' => '2019-03-01 18:04:35',
                'id' => 16,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            16 => 
            array (
                'client_id' => 187,
                'created_at' => '2019-03-01 18:24:12',
                'id' => 17,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            17 => 
            array (
                'client_id' => 187,
                'created_at' => '2019-03-01 18:24:12',
                'id' => 18,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            18 => 
            array (
                'client_id' => 187,
                'created_at' => '2019-03-01 18:24:12',
                'id' => 19,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            19 => 
            array (
                'client_id' => 188,
                'created_at' => '2019-03-01 18:29:49',
                'id' => 20,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:29:49',
            ),
            20 => 
            array (
                'client_id' => 188,
                'created_at' => '2019-03-01 18:29:49',
                'id' => 21,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:29:49',
            ),
            21 => 
            array (
                'client_id' => 188,
                'created_at' => '2019-03-01 18:29:49',
                'id' => 22,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:29:49',
            ),
            22 => 
            array (
                'client_id' => 189,
                'created_at' => '2019-03-01 18:33:11',
                'id' => 23,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:33:11',
            ),
            23 => 
            array (
                'client_id' => 189,
                'created_at' => '2019-03-01 18:33:11',
                'id' => 24,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:33:11',
            ),
            24 => 
            array (
                'client_id' => 189,
                'created_at' => '2019-03-01 18:33:11',
                'id' => 25,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:33:11',
            ),
            25 => 
            array (
                'client_id' => 190,
                'created_at' => '2019-03-01 18:59:44',
                'id' => 26,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:59:44',
            ),
            26 => 
            array (
                'client_id' => 190,
                'created_at' => '2019-03-01 18:59:44',
                'id' => 27,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:59:44',
            ),
            27 => 
            array (
                'client_id' => 190,
                'created_at' => '2019-03-01 18:59:44',
                'id' => 28,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 18:59:44',
            ),
            28 => 
            array (
                'client_id' => 191,
                'created_at' => '2019-03-01 19:33:25',
                'id' => 29,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            29 => 
            array (
                'client_id' => 191,
                'created_at' => '2019-03-01 19:33:25',
                'id' => 30,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            30 => 
            array (
                'client_id' => 191,
                'created_at' => '2019-03-01 19:33:25',
                'id' => 31,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            31 => 
            array (
                'client_id' => 192,
                'created_at' => '2019-03-05 13:03:04',
                'id' => 32,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            32 => 
            array (
                'client_id' => 192,
                'created_at' => '2019-03-05 13:03:04',
                'id' => 33,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            33 => 
            array (
                'client_id' => 192,
                'created_at' => '2019-03-05 13:03:04',
                'id' => 34,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            34 => 
            array (
                'client_id' => 1,
                'created_at' => '2019-03-05 13:03:04',
                'id' => 35,
                'setting_div' => 102,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/APNS_SANDBOX/Machiyell-iOS',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            35 => 
            array (
                'client_id' => 193,
                'created_at' => '2019-03-06 16:56:30',
                'id' => 36,
                'setting_div' => 101,
                'setting_value' => 'Zd9itsbJhI20vYvShuiZek8ntBKSBROqVNze6ANe',
                'updated_at' => '2019-03-06 17:02:35',
            ),
            36 => 
            array (
                'client_id' => 193,
                'created_at' => '2019-03-06 16:56:30',
                'id' => 37,
                'setting_div' => 102,
                'setting_value' => 'BjC55n6hr5dS5N6MTOPH0bv3Cs8fPDPhMhcIv9QM',
                'updated_at' => '2019-03-06 17:19:58',
            ),
            37 => 
            array (
                'client_id' => 193,
                'created_at' => '2019-03-06 16:56:30',
                'id' => 38,
                'setting_div' => 103,
                'setting_value' => 'g5ZAMS9XQZkVsIaq4lz8L8Ph8dhlawbhs0H5JHSp',
                'updated_at' => '2019-03-06 17:20:12',
            ),
            38 => 
            array (
                'client_id' => 1,
                'created_at' => NULL,
                'id' => 39,
                'setting_div' => 101,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/GCM/Machiyell-Android',
                'updated_at' => NULL,
            ),
            39 => 
            array (
                'client_id' => 194,
                'created_at' => '2019-03-11 13:40:07',
                'id' => 40,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:40:07',
            ),
            40 => 
            array (
                'client_id' => 194,
                'created_at' => '2019-03-11 13:40:07',
                'id' => 41,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:40:07',
            ),
            41 => 
            array (
                'client_id' => 194,
                'created_at' => '2019-03-11 13:40:07',
                'id' => 42,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:40:07',
            ),
            42 => 
            array (
                'client_id' => 195,
                'created_at' => '2019-03-11 13:51:29',
                'id' => 43,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            43 => 
            array (
                'client_id' => 195,
                'created_at' => '2019-03-11 13:51:29',
                'id' => 44,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            44 => 
            array (
                'client_id' => 195,
                'created_at' => '2019-03-11 13:51:29',
                'id' => 45,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            45 => 
            array (
                'client_id' => 196,
                'created_at' => '2019-03-11 13:55:19',
                'id' => 46,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            46 => 
            array (
                'client_id' => 196,
                'created_at' => '2019-03-11 13:55:19',
                'id' => 47,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            47 => 
            array (
                'client_id' => 196,
                'created_at' => '2019-03-11 13:55:19',
                'id' => 48,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyDXWUSlt71lXYTR4jAQeQNIx5G2jIMWjd4',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            48 => 
            array (
                'client_id' => 197,
                'created_at' => '2019-03-11 13:59:54',
                'id' => 49,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:59:54',
            ),
            49 => 
            array (
                'client_id' => 197,
                'created_at' => '2019-03-11 13:59:54',
                'id' => 50,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-11 13:59:54',
            ),
            50 => 
            array (
                'client_id' => 197,
                'created_at' => '2019-03-11 13:59:54',
                'id' => 51,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyBJjMqBHpHbBqS-FjW9aCCK6jTZSd4sNVw',
                'updated_at' => '2019-03-11 13:59:54',
            ),
            51 => 
            array (
                'client_id' => 198,
                'created_at' => '2019-03-11 15:10:22',
                'id' => 52,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-11 15:10:22',
            ),
            52 => 
            array (
                'client_id' => 198,
                'created_at' => '2019-03-11 15:10:22',
                'id' => 53,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-11 15:10:22',
            ),
            53 => 
            array (
                'client_id' => 198,
                'created_at' => '2019-03-11 15:10:22',
                'id' => 54,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyBNkH_Qvk6uSyG8g_slFLxAxJqjNqShHEo',
                'updated_at' => '2019-03-11 15:10:22',
            ),
            54 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:52:23',
                'id' => 55,
                'setting_div' => 101,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/GCM/Machiyell-Android-VNC',
                'updated_at' => '2019-03-11 16:52:23',
            ),
            55 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-03-11 16:52:23',
                'id' => 56,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyDXWUSlt71lXYTR4jAQeQNIx5G2jIMWjd4',
                'updated_at' => '2019-03-11 16:52:23',
            ),
            56 => 
            array (
                'client_id' => 199,
                'created_at' => NULL,
                'id' => 57,
                'setting_div' => 102,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/APNS_SANDBOX/Machiyell-iOS',
                'updated_at' => NULL,
            ),
            57 => 
            array (
                'client_id' => 199,
                'created_at' => NULL,
                'id' => 58,
                'setting_div' => 104,
                'setting_value' => '2.6',
                'updated_at' => '2019-04-22 18:30:22',
            ),
            58 => 
            array (
                'client_id' => 199,
                'created_at' => NULL,
                'id' => 59,
                'setting_div' => 105,
                'setting_value' => '1.0',
                'updated_at' => '2019-04-22 16:35:11',
            ),
            59 => 
            array (
                'client_id' => 200,
                'created_at' => '2019-03-25 17:50:56',
                'id' => 60,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            60 => 
            array (
                'client_id' => 200,
                'created_at' => '2019-03-25 17:50:56',
                'id' => 61,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            61 => 
            array (
                'client_id' => 200,
                'created_at' => '2019-03-25 17:50:56',
                'id' => 62,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyCkUOdZ5y7hMm0yrcCQoCvLwzdM6M8s5qk',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            62 => 
            array (
                'client_id' => 200,
                'created_at' => '2019-03-25 17:50:56',
                'id' => 63,
                'setting_div' => 104,
                'setting_value' => '1.3',
                'updated_at' => '2019-03-25 17:51:22',
            ),
            63 => 
            array (
                'client_id' => 200,
                'created_at' => '2019-03-25 17:50:56',
                'id' => 64,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            64 => 
            array (
                'client_id' => 201,
                'created_at' => '2019-03-26 19:15:26',
                'id' => 65,
                'setting_div' => 101,
                'setting_value' => 'setting value',
                'updated_at' => '2019-03-27 13:36:57',
            ),
            65 => 
            array (
                'client_id' => 201,
                'created_at' => '2019-03-26 19:15:26',
                'id' => 66,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-03-26 19:15:26',
            ),
            66 => 
            array (
                'client_id' => 201,
                'created_at' => '2019-03-26 19:15:26',
                'id' => 67,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-03-26 19:15:26',
            ),
            67 => 
            array (
                'client_id' => 201,
                'created_at' => '2019-03-26 19:15:26',
                'id' => 68,
                'setting_div' => 104,
                'setting_value' => '100.00',
                'updated_at' => '2019-03-27 15:13:05',
            ),
            68 => 
            array (
                'client_id' => 201,
                'created_at' => '2019-03-26 19:15:26',
                'id' => 69,
                'setting_div' => 105,
                'setting_value' => '1.1',
                'updated_at' => '2019-03-27 13:48:30',
            ),
            69 => 
            array (
                'client_id' => 202,
                'created_at' => '2019-04-09 15:45:48',
                'id' => 70,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            70 => 
            array (
                'client_id' => 202,
                'created_at' => '2019-04-09 15:45:48',
                'id' => 71,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            71 => 
            array (
                'client_id' => 202,
                'created_at' => '2019-04-09 15:45:48',
                'id' => 72,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            72 => 
            array (
                'client_id' => 202,
                'created_at' => '2019-04-09 15:45:48',
                'id' => 73,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            73 => 
            array (
                'client_id' => 202,
                'created_at' => '2019-04-09 15:45:48',
                'id' => 74,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            74 => 
            array (
                'client_id' => 205,
                'created_at' => '2019-04-10 12:29:07',
                'id' => 75,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            75 => 
            array (
                'client_id' => 205,
                'created_at' => '2019-04-10 12:29:07',
                'id' => 76,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            76 => 
            array (
                'client_id' => 205,
                'created_at' => '2019-04-10 12:29:07',
                'id' => 77,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            77 => 
            array (
                'client_id' => 205,
                'created_at' => '2019-04-10 12:29:07',
                'id' => 78,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            78 => 
            array (
                'client_id' => 205,
                'created_at' => '2019-04-10 12:29:07',
                'id' => 79,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            79 => 
            array (
                'client_id' => 206,
                'created_at' => '2019-04-10 12:31:12',
                'id' => 80,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            80 => 
            array (
                'client_id' => 206,
                'created_at' => '2019-04-10 12:31:12',
                'id' => 81,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            81 => 
            array (
                'client_id' => 206,
                'created_at' => '2019-04-10 12:31:12',
                'id' => 82,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            82 => 
            array (
                'client_id' => 206,
                'created_at' => '2019-04-10 12:31:12',
                'id' => 83,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            83 => 
            array (
                'client_id' => 206,
                'created_at' => '2019-04-10 12:31:12',
                'id' => 84,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            84 => 
            array (
                'client_id' => 207,
                'created_at' => '2019-04-10 13:02:30',
                'id' => 85,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            85 => 
            array (
                'client_id' => 207,
                'created_at' => '2019-04-10 13:02:30',
                'id' => 86,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            86 => 
            array (
                'client_id' => 207,
                'created_at' => '2019-04-10 13:02:30',
                'id' => 87,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            87 => 
            array (
                'client_id' => 207,
                'created_at' => '2019-04-10 13:02:30',
                'id' => 88,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            88 => 
            array (
                'client_id' => 207,
                'created_at' => '2019-04-10 13:02:30',
                'id' => 89,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            89 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 90,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-05-17 17:01:24',
            ),
            90 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 91,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-05-17 17:01:24',
            ),
            91 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 92,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-05-17 17:01:24',
            ),
            92 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 93,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-05-17 17:01:24',
            ),
            93 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 94,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-05-17 17:01:24',
            ),
            94 => 
            array (
                'client_id' => 209,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 95,
                'setting_div' => 106,
                'setting_value' => '"http://mimata-saigai.jp"',
                'updated_at' => '2019-05-17 17:03:05',
            ),
            95 => 
            array (
                'client_id' => 199,
                'created_at' => NULL,
                'id' => 96,
                'setting_div' => 106,
                'setting_value' => 'https://www.google.com/search?ei=UnHeXIfXMYG7mAW16JWAAg&q=check+user+agent+is+android+laravel&oq=check+user+agent+is+android+lar&gs_l=psy-ab.1.0.33i22i29i30.1889.3169..4768...1.0..0.114.542.0j5......0....1..gws-wiz.......0i71j0i22i30.SVlP8A1ZlaI',
                'updated_at' => NULL,
            ),
            96 => 
            array (
                'client_id' => 210,
                'created_at' => '2019-05-17 19:34:20',
                'id' => 97,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-05-17 19:34:20',
            ),
            97 => 
            array (
                'client_id' => 210,
                'created_at' => '2019-05-17 19:34:20',
                'id' => 98,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-05-17 19:34:20',
            ),
            98 => 
            array (
                'client_id' => 210,
                'created_at' => '2019-05-17 19:34:20',
                'id' => 99,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-05-17 19:34:20',
            ),
            99 => 
            array (
                'client_id' => 210,
                'created_at' => '2019-05-17 19:34:20',
                'id' => 100,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-05-17 19:34:20',
            ),
            100 => 
            array (
                'client_id' => 210,
                'created_at' => '2019-05-17 19:34:20',
                'id' => 101,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-05-17 19:34:20',
            ),
            101 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:45:36',
                'id' => 102,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-05-20 10:45:36',
            ),
            102 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:45:37',
                'id' => 103,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-05-20 10:45:37',
            ),
            103 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:45:37',
                'id' => 104,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-05-20 10:45:37',
            ),
            104 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:45:37',
                'id' => 105,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-05-20 10:45:37',
            ),
            105 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:45:37',
                'id' => 106,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-05-20 10:45:37',
            ),
            106 => 
            array (
                'client_id' => 211,
                'created_at' => '2019-05-20 10:45:37',
                'id' => 107,
                'setting_div' => 106,
                'setting_value' => 'http://mimata-saigai.jp/',
                'updated_at' => '2019-05-20 11:33:19',
            ),
            107 => 
            array (
                'client_id' => 212,
                'created_at' => '2019-05-22 16:40:58',
                'id' => 108,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-05-22 16:40:58',
            ),
            108 => 
            array (
                'client_id' => 212,
                'created_at' => '2019-05-22 16:40:59',
                'id' => 109,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-05-22 16:40:59',
            ),
            109 => 
            array (
                'client_id' => 212,
                'created_at' => '2019-05-22 16:40:59',
                'id' => 110,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-05-22 16:40:59',
            ),
            110 => 
            array (
                'client_id' => 212,
                'created_at' => '2019-05-22 16:40:59',
                'id' => 111,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-05-22 16:40:59',
            ),
            111 => 
            array (
                'client_id' => 212,
                'created_at' => '2019-05-22 16:40:59',
                'id' => 112,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-05-22 16:40:59',
            ),
            112 => 
            array (
                'client_id' => 199,
                'created_at' => '2019-05-30 16:40:59',
                'id' => 113,
                'setting_div' => 107,
                'setting_value' => 'emergency1',
                'updated_at' => '2019-06-03 12:23:31',
            ),
            113 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 114,
                'setting_div' => 101,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
            114 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 115,
                'setting_div' => 102,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
            115 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 116,
                'setting_div' => 103,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
            116 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 117,
                'setting_div' => 104,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
            117 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 118,
                'setting_div' => 105,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
            118 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 119,
                'setting_div' => 106,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
            119 => 
            array (
                'client_id' => 213,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 120,
                'setting_div' => 107,
                'setting_value' => '',
                'updated_at' => '2019-06-03 13:38:01',
            ),
        ));
        
        
    }
}