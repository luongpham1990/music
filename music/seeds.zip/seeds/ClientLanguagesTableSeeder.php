<?php

use Illuminate\Database\Seeder;

class ClientLanguagesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('client_languages')->delete();
        
        \DB::table('client_languages')->insert(array (
            0 => 
            array (
                'client_id' => 2,
                'id' => 750,
                'lang' => 'ko',
                'position' => 13,
            ),
            1 => 
            array (
                'client_id' => 71,
                'id' => 763,
                'lang' => 'ja',
                'position' => 1,
            ),
            2 => 
            array (
                'client_id' => 71,
                'id' => 764,
                'lang' => 'en',
                'position' => 2,
            ),
            3 => 
            array (
                'client_id' => 71,
                'id' => 765,
                'lang' => 'ko',
                'position' => 3,
            ),
            4 => 
            array (
                'client_id' => 71,
                'id' => 766,
                'lang' => 'zh',
                'position' => 4,
            ),
            5 => 
            array (
                'client_id' => 71,
                'id' => 767,
                'lang' => 'pt',
                'position' => 5,
            ),
            6 => 
            array (
                'client_id' => 71,
                'id' => 768,
                'lang' => 'es',
                'position' => 6,
            ),
            7 => 
            array (
                'client_id' => 72,
                'id' => 770,
                'lang' => 'ja',
                'position' => 9,
            ),
            8 => 
            array (
                'client_id' => 72,
                'id' => 771,
                'lang' => 'en',
                'position' => 13,
            ),
            9 => 
            array (
                'client_id' => 77,
                'id' => 772,
                'lang' => 'ja',
                'position' => 1,
            ),
            10 => 
            array (
                'client_id' => 77,
                'id' => 773,
                'lang' => 'en',
                'position' => 3,
            ),
            11 => 
            array (
                'client_id' => 78,
                'id' => 778,
                'lang' => 'en',
                'position' => 4,
            ),
            12 => 
            array (
                'client_id' => 78,
                'id' => 780,
                'lang' => 'es',
                'position' => 2,
            ),
            13 => 
            array (
                'client_id' => 78,
                'id' => 781,
                'lang' => 'tl',
                'position' => 3,
            ),
            14 => 
            array (
                'client_id' => 78,
                'id' => 782,
                'lang' => 'zh',
                'position' => 6,
            ),
            15 => 
            array (
                'client_id' => 78,
                'id' => 783,
                'lang' => 'pt',
                'position' => 5,
            ),
            16 => 
            array (
                'client_id' => 1,
                'id' => 789,
                'lang' => 'es',
                'position' => 6,
            ),
            17 => 
            array (
                'client_id' => 79,
                'id' => 791,
                'lang' => 'en',
                'position' => 2,
            ),
            18 => 
            array (
                'client_id' => 79,
                'id' => 792,
                'lang' => 'ko',
                'position' => 3,
            ),
            19 => 
            array (
                'client_id' => 79,
                'id' => 793,
                'lang' => 'zh',
                'position' => 4,
            ),
            20 => 
            array (
                'client_id' => 2,
                'id' => 795,
                'lang' => 'zh',
                'position' => 15,
            ),
            21 => 
            array (
                'client_id' => 2,
                'id' => 796,
                'lang' => 'tl',
                'position' => 16,
            ),
            22 => 
            array (
                'client_id' => 70,
                'id' => 798,
                'lang' => 'ja',
                'position' => 1,
            ),
            23 => 
            array (
                'client_id' => 70,
                'id' => 799,
                'lang' => 'ko',
                'position' => 2,
            ),
            24 => 
            array (
                'client_id' => 70,
                'id' => 800,
                'lang' => 'zh',
                'position' => 3,
            ),
            25 => 
            array (
                'client_id' => 70,
                'id' => 801,
                'lang' => 'es',
                'position' => 4,
            ),
            26 => 
            array (
                'client_id' => 1,
                'id' => 802,
                'lang' => 'en',
                'position' => 7,
            ),
            27 => 
            array (
                'client_id' => 1,
                'id' => 803,
                'lang' => 'ko',
                'position' => 9,
            ),
            28 => 
            array (
                'client_id' => 182,
                'id' => 804,
                'lang' => 'ja',
                'position' => 1,
            ),
            29 => 
            array (
                'client_id' => 182,
                'id' => 805,
                'lang' => 'en',
                'position' => 2,
            ),
            30 => 
            array (
                'client_id' => 183,
                'id' => 806,
                'lang' => 'ja',
                'position' => 1,
            ),
            31 => 
            array (
                'client_id' => 184,
                'id' => 807,
                'lang' => 'ja',
                'position' => 1,
            ),
            32 => 
            array (
                'client_id' => 185,
                'id' => 808,
                'lang' => 'ja',
                'position' => 2,
            ),
            33 => 
            array (
                'client_id' => 186,
                'id' => 809,
                'lang' => 'ja',
                'position' => 1,
            ),
            34 => 
            array (
                'client_id' => 185,
                'id' => 812,
                'lang' => 'tl',
                'position' => 4,
            ),
            35 => 
            array (
                'client_id' => 187,
                'id' => 813,
                'lang' => 'ja',
                'position' => 1,
            ),
            36 => 
            array (
                'client_id' => 188,
                'id' => 814,
                'lang' => 'ja',
                'position' => 1,
            ),
            37 => 
            array (
                'client_id' => 189,
                'id' => 815,
                'lang' => 'ja',
                'position' => 1,
            ),
            38 => 
            array (
                'client_id' => 190,
                'id' => 816,
                'lang' => 'ja',
                'position' => 1,
            ),
            39 => 
            array (
                'client_id' => 191,
                'id' => 817,
                'lang' => 'ja',
                'position' => 1,
            ),
            40 => 
            array (
                'client_id' => 192,
                'id' => 818,
                'lang' => 'ja',
                'position' => 1,
            ),
            41 => 
            array (
                'client_id' => 193,
                'id' => 819,
                'lang' => 'ja',
                'position' => 1,
            ),
            42 => 
            array (
                'client_id' => 189,
                'id' => 820,
                'lang' => 'en',
                'position' => 2,
            ),
            43 => 
            array (
                'client_id' => 189,
                'id' => 821,
                'lang' => 'ko',
                'position' => 3,
            ),
            44 => 
            array (
                'client_id' => 190,
                'id' => 822,
                'lang' => 'en',
                'position' => 2,
            ),
            45 => 
            array (
                'client_id' => 190,
                'id' => 823,
                'lang' => 'ko',
                'position' => 3,
            ),
            46 => 
            array (
                'client_id' => 191,
                'id' => 824,
                'lang' => 'en',
                'position' => 2,
            ),
            47 => 
            array (
                'client_id' => 191,
                'id' => 825,
                'lang' => 'ko',
                'position' => 3,
            ),
            48 => 
            array (
                'client_id' => 187,
                'id' => 826,
                'lang' => 'en',
                'position' => 2,
            ),
            49 => 
            array (
                'client_id' => 187,
                'id' => 827,
                'lang' => 'ko',
                'position' => 3,
            ),
            50 => 
            array (
                'client_id' => 194,
                'id' => 828,
                'lang' => 'ja',
                'position' => 1,
            ),
            51 => 
            array (
                'client_id' => 194,
                'id' => 829,
                'lang' => 'en',
                'position' => 2,
            ),
            52 => 
            array (
                'client_id' => 194,
                'id' => 830,
                'lang' => 'ko',
                'position' => 3,
            ),
            53 => 
            array (
                'client_id' => 195,
                'id' => 831,
                'lang' => 'ja',
                'position' => 1,
            ),
            54 => 
            array (
                'client_id' => 195,
                'id' => 832,
                'lang' => 'en',
                'position' => 2,
            ),
            55 => 
            array (
                'client_id' => 195,
                'id' => 833,
                'lang' => 'ko',
                'position' => 3,
            ),
            56 => 
            array (
                'client_id' => 196,
                'id' => 834,
                'lang' => 'ja',
                'position' => 1,
            ),
            57 => 
            array (
                'client_id' => 196,
                'id' => 835,
                'lang' => 'en',
                'position' => 2,
            ),
            58 => 
            array (
                'client_id' => 196,
                'id' => 836,
                'lang' => 'ko',
                'position' => 3,
            ),
            59 => 
            array (
                'client_id' => 197,
                'id' => 837,
                'lang' => 'ja',
                'position' => 1,
            ),
            60 => 
            array (
                'client_id' => 197,
                'id' => 838,
                'lang' => 'en',
                'position' => 2,
            ),
            61 => 
            array (
                'client_id' => 197,
                'id' => 839,
                'lang' => 'ko',
                'position' => 3,
            ),
            62 => 
            array (
                'client_id' => 198,
                'id' => 840,
                'lang' => 'ja',
                'position' => 1,
            ),
            63 => 
            array (
                'client_id' => 198,
                'id' => 841,
                'lang' => 'en',
                'position' => 2,
            ),
            64 => 
            array (
                'client_id' => 198,
                'id' => 842,
                'lang' => 'ko',
                'position' => 3,
            ),
            65 => 
            array (
                'client_id' => 199,
                'id' => 843,
                'lang' => 'ja',
                'position' => 1,
            ),
            66 => 
            array (
                'client_id' => 199,
                'id' => 844,
                'lang' => 'en',
                'position' => 2,
            ),
            67 => 
            array (
                'client_id' => 205,
                'id' => 856,
                'lang' => 'ja',
                'position' => 1,
            ),
            68 => 
            array (
                'client_id' => 206,
                'id' => 857,
                'lang' => 'ja',
                'position' => 1,
            ),
            69 => 
            array (
                'client_id' => 207,
                'id' => 858,
                'lang' => 'ja',
                'position' => 1,
            ),
            70 => 
            array (
                'client_id' => 209,
                'id' => 861,
                'lang' => 'ja',
                'position' => 1,
            ),
            71 => 
            array (
                'client_id' => 210,
                'id' => 862,
                'lang' => 'ja',
                'position' => 1,
            ),
            72 => 
            array (
                'client_id' => 211,
                'id' => 863,
                'lang' => 'ja',
                'position' => 1,
            ),
            73 => 
            array (
                'client_id' => 199,
                'id' => 867,
                'lang' => 'zh',
                'position' => 4,
            ),
            74 => 
            array (
                'client_id' => 199,
                'id' => 869,
                'lang' => 'ko',
                'position' => 5,
            ),
            75 => 
            array (
                'client_id' => 212,
                'id' => 870,
                'lang' => 'ja',
                'position' => 1,
            ),
            76 => 
            array (
                'client_id' => 212,
                'id' => 871,
                'lang' => 'en',
                'position' => 2,
            ),
            77 => 
            array (
                'client_id' => 199,
                'id' => 872,
                'lang' => 'pt',
                'position' => 6,
            ),
            78 => 
            array (
                'client_id' => 213,
                'id' => 873,
                'lang' => 'ja',
                'position' => 1,
            ),
        ));
        
        
    }
}