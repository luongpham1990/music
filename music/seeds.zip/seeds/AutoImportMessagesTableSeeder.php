<?php

use Illuminate\Database\Seeder;

class AutoImportMessagesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_messages')->delete();
        
        \DB::table('auto_import_messages')->insert(array (
            0 => 
            array (
                'auto_import_id' => 1,
                'body' => '[@pubDate]
[@ categories]',
                'id' => 1,
                'lang' => 'es',
                'title' => 'spa_tittle',
            ),
            1 => 
            array (
                'auto_import_id' => 1,
                'body' => '[@title]
[@body]',
                'id' => 2,
                'lang' => 'ja_easy',
                'title' => 'ja_easy',
            ),
            2 => 
            array (
                'auto_import_id' => 9,
                'body' => '[@link]
[@body]',
                'id' => 5,
                'lang' => 'ja',
                'title' => 'eded',
            ),
            3 => 
            array (
                'auto_import_id' => 9,
                'body' => 'hd
fdfd
f
f
ds
f',
                'id' => 6,
                'lang' => 'ko',
                'title' => 'ggggggghhhh',
            ),
            4 => 
            array (
                'auto_import_id' => 10,
                'body' => '23',
                'id' => 7,
                'lang' => 'ko',
                'title' => '2323',
            ),
            5 => 
            array (
                'auto_import_id' => 10,
                'body' => '2',
                'id' => 8,
                'lang' => 'ja',
                'title' => '32',
            ),
            6 => 
            array (
                'auto_import_id' => 1,
                'body' => 'contentf

fsdf
sfa
[@pubDate]
[@link]
[@body]',
                'id' => 9,
                'lang' => 'ja',
                'title' => 'dsfsf',
            ),
            7 => 
            array (
                'auto_import_id' => 1,
                'body' => '[@Link]
[@title]

[@Link]
[@body]
[@categories]
[@categories]
[@link]
[@categories]',
                'id' => 10,
                'lang' => 'ko',
                'title' => ';l;lk;',
            ),
            8 => 
            array (
                'auto_import_id' => 12,
                'body' => 'e
e

[@title]
[@Link]
[@Link]
[@Link]
[@Link]
[@title]
[@title]
[@title]',
                'id' => 11,
                'lang' => 'ko',
                'title' => 'Content 1',
            ),
            9 => 
            array (
                'auto_import_id' => 12,
                'body' => '1
2
3
[@title]
[@Link]',
                'id' => 12,
                'lang' => 'ja',
                'title' => 'Content 2',
            ),
            10 => 
            array (
                'auto_import_id' => 13,
                'body' => '[@title]
[@Link]
[@Link]
[@title]
[@pubDate]
[@pubDate]
[@categories]
[@categories]
[@body]',
                'id' => 13,
                'lang' => 'ko',
                'title' => '件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名',
            ),
            11 => 
            array (
                'auto_import_id' => 13,
                'body' => '名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名
名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名',
                'id' => 14,
                'lang' => 'ja',
                'title' => '名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名',
            ),
            12 => 
            array (
                'auto_import_id' => 14,
                'body' => 'dfdsfsd',
                'id' => 15,
                'lang' => 'ja',
                'title' => 'dfdsf',
            ),
            13 => 
            array (
                'auto_import_id' => 14,
                'body' => 'dsfdsf',
                'id' => 16,
                'lang' => 'tl',
                'title' => 'sfdsf',
            ),
            14 => 
            array (
                'auto_import_id' => 15,
                'body' => NULL,
                'id' => 17,
                'lang' => 'ja',
                'title' => 'demooooooooooooooooooooooooooooooooooooooooooooooo',
            ),
            15 => 
            array (
                'auto_import_id' => 15,
                'body' => NULL,
                'id' => 18,
                'lang' => 'tl',
                'title' => 'testtttttttttttttttttttttttttttttttttttt',
            ),
            16 => 
            array (
                'auto_import_id' => 17,
                'body' => 'dasdasd',
                'id' => 21,
                'lang' => 'ja',
                'title' => 'ádas',
            ),
            17 => 
            array (
                'auto_import_id' => 17,
                'body' => 'dasdsdad',
                'id' => 22,
                'lang' => 'en',
                'title' => 'asdasdad',
            ),
            18 => 
            array (
                'auto_import_id' => 19,
                'body' => 'd
[@link]
[@link]',
                'id' => 25,
                'lang' => 'ja',
                'title' => 'sdasd',
            ),
            19 => 
            array (
                'auto_import_id' => 19,
                'body' => 'dasd',
                'id' => 26,
                'lang' => 'en',
                'title' => 'ddddd',
            ),
            20 => 
            array (
                'auto_import_id' => 20,
                'body' => '[@title]
[@body]
[@link]',
                'id' => 27,
                'lang' => 'ja',
                'title' => 'ja_title',
            ),
            21 => 
            array (
                'auto_import_id' => 20,
                'body' => '[@categories]
[@pubDate]',
                'id' => 28,
                'lang' => 'en',
                'title' => 'en_title',
            ),
            22 => 
            array (
                'auto_import_id' => 21,
                'body' => 'dfdfdfd
[@title]',
                'id' => 29,
                'lang' => 'ja',
                'title' => 'ja_title',
            ),
            23 => 
            array (
                'auto_import_id' => 21,
                'body' => '[@title]',
                'id' => 30,
                'lang' => 'en',
                'title' => 'en_title',
            ),
            24 => 
            array (
                'auto_import_id' => 23,
                'body' => '[@pubDate]',
                'id' => 37,
                'lang' => 'es',
                'title' => 'spa_tittle',
            ),
            25 => 
            array (
                'auto_import_id' => 23,
                'body' => '[@body]
[@title]',
                'id' => 38,
                'lang' => 'ja_easy',
                'title' => 'ja_easy',
            ),
            26 => 
            array (
                'auto_import_id' => 24,
                'body' => '[@title]
[@pubDate]',
                'id' => 39,
                'lang' => 'es',
                'title' => 'ngôn ngữ',
            ),
            27 => 
            array (
                'auto_import_id' => 24,
                'body' => 'fdf

[@title]',
                'id' => 40,
                'lang' => 'ja_easy',
                'title' => 'fd',
            ),
            28 => 
            array (
                'auto_import_id' => 112,
                'body' => '[@category]',
                'id' => 340,
                'lang' => 'ja',
                'title' => 'eqweq',
            ),
            29 => 
            array (
                'auto_import_id' => 112,
                'body' => NULL,
                'id' => 341,
                'lang' => 'en',
                'title' => NULL,
            ),
            30 => 
            array (
                'auto_import_id' => 112,
                'body' => NULL,
                'id' => 342,
                'lang' => 'zh',
                'title' => NULL,
            ),
            31 => 
            array (
                'auto_import_id' => 112,
                'body' => NULL,
                'id' => 343,
                'lang' => 'ko',
                'title' => NULL,
            ),
            32 => 
            array (
                'auto_import_id' => 112,
                'body' => NULL,
                'id' => 344,
                'lang' => 'pt',
                'title' => NULL,
            ),
            33 => 
            array (
                'auto_import_id' => 113,
                'body' => '[@category]
[@content]',
                'id' => 345,
                'lang' => 'ja',
                'title' => '[@title][@published]',
            ),
            34 => 
            array (
                'auto_import_id' => 113,
                'body' => NULL,
                'id' => 346,
                'lang' => 'en',
                'title' => NULL,
            ),
            35 => 
            array (
                'auto_import_id' => 113,
                'body' => NULL,
                'id' => 347,
                'lang' => 'zh',
                'title' => NULL,
            ),
            36 => 
            array (
                'auto_import_id' => 113,
                'body' => NULL,
                'id' => 348,
                'lang' => 'ko',
                'title' => NULL,
            ),
            37 => 
            array (
                'auto_import_id' => 113,
                'body' => NULL,
                'id' => 349,
                'lang' => 'pt',
                'title' => NULL,
            ),
            38 => 
            array (
                'auto_import_id' => 114,
                'body' => '[@category]',
                'id' => 350,
                'lang' => 'ja',
                'title' => '[@title][@published]',
            ),
            39 => 
            array (
                'auto_import_id' => 114,
                'body' => NULL,
                'id' => 351,
                'lang' => 'en',
                'title' => NULL,
            ),
            40 => 
            array (
                'auto_import_id' => 114,
                'body' => NULL,
                'id' => 352,
                'lang' => 'zh',
                'title' => NULL,
            ),
            41 => 
            array (
                'auto_import_id' => 114,
                'body' => NULL,
                'id' => 353,
                'lang' => 'ko',
                'title' => NULL,
            ),
            42 => 
            array (
                'auto_import_id' => 114,
                'body' => NULL,
                'id' => 354,
                'lang' => 'pt',
                'title' => NULL,
            ),
            43 => 
            array (
                'auto_import_id' => 115,
                'body' => '[@category]',
                'id' => 355,
                'lang' => 'ja',
                'title' => '[@title][@published]',
            ),
            44 => 
            array (
                'auto_import_id' => 115,
                'body' => NULL,
                'id' => 356,
                'lang' => 'en',
                'title' => NULL,
            ),
            45 => 
            array (
                'auto_import_id' => 115,
                'body' => NULL,
                'id' => 357,
                'lang' => 'zh',
                'title' => NULL,
            ),
            46 => 
            array (
                'auto_import_id' => 115,
                'body' => NULL,
                'id' => 358,
                'lang' => 'ko',
                'title' => NULL,
            ),
            47 => 
            array (
                'auto_import_id' => 115,
                'body' => NULL,
                'id' => 359,
                'lang' => 'pt',
                'title' => NULL,
            ),
            48 => 
            array (
                'auto_import_id' => 116,
                'body' => '[@category]
[@content]',
                'id' => 360,
                'lang' => 'ja',
                'title' => '[@title][@published]',
            ),
            49 => 
            array (
                'auto_import_id' => 116,
                'body' => NULL,
                'id' => 361,
                'lang' => 'en',
                'title' => NULL,
            ),
            50 => 
            array (
                'auto_import_id' => 116,
                'body' => NULL,
                'id' => 362,
                'lang' => 'zh',
                'title' => NULL,
            ),
            51 => 
            array (
                'auto_import_id' => 116,
                'body' => NULL,
                'id' => 363,
                'lang' => 'ko',
                'title' => NULL,
            ),
            52 => 
            array (
                'auto_import_id' => 116,
                'body' => NULL,
                'id' => 364,
                'lang' => 'pt',
                'title' => NULL,
            ),
            53 => 
            array (
                'auto_import_id' => 117,
                'body' => '[@category]
[@content]',
                'id' => 365,
                'lang' => 'ja',
                'title' => '[@title][@published]',
            ),
            54 => 
            array (
                'auto_import_id' => 117,
                'body' => NULL,
                'id' => 366,
                'lang' => 'en',
                'title' => NULL,
            ),
            55 => 
            array (
                'auto_import_id' => 117,
                'body' => NULL,
                'id' => 367,
                'lang' => 'zh',
                'title' => NULL,
            ),
            56 => 
            array (
                'auto_import_id' => 117,
                'body' => NULL,
                'id' => 368,
                'lang' => 'ko',
                'title' => NULL,
            ),
            57 => 
            array (
                'auto_import_id' => 117,
                'body' => NULL,
                'id' => 369,
                'lang' => 'pt',
                'title' => NULL,
            ),
        ));
        
        
    }
}