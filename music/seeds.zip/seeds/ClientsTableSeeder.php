<?php

use Illuminate\Database\Seeder;

class ClientsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('clients')->delete();
        
        \DB::table('clients')->insert(array (
            0 => 
            array (
                'client_code' => 'visor',
                'client_name' => 'VISOR',
                'client_status' => 1,
                'created_at' => '2018-11-27 12:35:02',
                'id' => 1,
                'service_name' => 'バイザー連絡網',
                'updated_at' => '2018-11-27 12:35:02',
            ),
            1 => 
            array (
                'client_code' => 'vnc1',
                'client_name' => 'vinicorp',
                'client_status' => 1,
                'created_at' => '2018-11-28 13:08:30',
                'id' => 37,
                'service_name' => 'service1',
                'updated_at' => '2018-11-28 13:08:30',
            ),
            2 => 
            array (
                'client_code' => 'vnc2',
                'client_name' => 'vnc2',
                'client_status' => 3,
                'created_at' => '2018-11-29 17:24:41',
                'id' => 38,
                'service_name' => 'dasd',
                'updated_at' => '2018-11-29 17:24:41',
            ),
            3 => 
            array (
                'client_code' => 'vnc4',
                'client_name' => 'vnc4',
                'client_status' => 1,
                'created_at' => '2018-11-30 13:06:24',
                'id' => 39,
                'service_name' => 'svvnc4',
                'updated_at' => '2018-11-30 13:06:24',
            ),
            4 => 
            array (
                'client_code' => 'vnc5',
                'client_name' => 'vnc5',
                'client_status' => 1,
                'created_at' => '2018-11-30 13:21:07',
                'id' => 40,
                'service_name' => 'vnc5',
                'updated_at' => '2018-11-30 13:21:07',
            ),
            5 => 
            array (
                'client_code' => 'hfhggdf',
                'client_name' => 'gfdfg',
                'client_status' => 9,
                'created_at' => '2018-11-30 13:43:27',
                'id' => 41,
                'service_name' => 'gdgdfg',
                'updated_at' => '2018-11-30 13:43:27',
            ),
            6 => 
            array (
                'client_code' => 'jrrrrrrrrrrrrrrr',
                'client_name' => '多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧',
                'client_status' => 1,
                'created_at' => '2018-11-30 15:29:48',
                'id' => 42,
                'service_name' => '多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言',
                'updated_at' => '2018-12-05 16:02:38',
            ),
            7 => 
            array (
                'client_code' => 'vncvncvncvncvncvncvncvncvncvncvncvncvncv',
                'client_name' => 'ログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくだ',
                'client_status' => 3,
                'created_at' => '2018-12-05 16:00:46',
                'id' => 43,
                'service_name' => 'ログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくだ',
                'updated_at' => '2018-12-05 16:02:02',
            ),
            8 => 
            array (
                'client_code' => '111111111',
                'client_name' => '2客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのは',
                'client_status' => 1,
                'created_at' => '2018-12-05 16:03:32',
                'id' => 44,
                'service_name' => '3客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのは',
                'updated_at' => '2018-12-05 16:03:32',
            ),
            9 => 
            array (
                'client_code' => 'tung',
                'client_name' => 'tung',
                'client_status' => 2,
                'created_at' => '2018-12-05 18:45:40',
                'id' => 45,
                'service_name' => 'hotel',
                'updated_at' => '2018-12-05 18:45:40',
            ),
            10 => 
            array (
                'client_code' => '000000000000002',
                'client_name' => 'Tiênnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn',
                'client_status' => 1,
                'created_at' => '2018-12-06 18:58:22',
                'id' => 47,
                'service_name' => 'cdddddddddddddđaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
                'updated_at' => '2018-12-06 18:58:22',
            ),
            11 => 
            array (
                'client_code' => 'vvvvveqqqqqq',
                'client_name' => 'qqqqqqqqqqqqqqqqq',
                'client_status' => 1,
                'created_at' => '2018-12-06 18:58:57',
                'id' => 48,
                'service_name' => 'ffffffffffffffffff',
                'updated_at' => '2018-12-06 18:58:57',
            ),
            12 => 
            array (
                'client_code' => 'linh',
                'client_name' => 'linh',
                'client_status' => 1,
                'created_at' => '2018-12-06 18:59:16',
                'id' => 49,
                'service_name' => 'http://it-machiyell.test/mgr/auth/login',
                'updated_at' => '2018-12-06 18:59:16',
            ),
            13 => 
            array (
                'client_code' => 'thao',
                'client_name' => 'thao',
                'client_status' => 1,
                'created_at' => '2018-12-06 18:59:29',
                'id' => 50,
                'service_name' => 'thao',
                'updated_at' => '2018-12-06 18:59:29',
            ),
            14 => 
            array (
                'client_code' => 'thong',
                'client_name' => 'thong',
                'client_status' => 1,
                'created_at' => '2018-12-06 18:59:48',
                'id' => 51,
                'service_name' => 'thong',
                'updated_at' => '2018-12-06 18:59:48',
            ),
            15 => 
            array (
                'client_code' => 'csssssssssssssss',
                'client_name' => 'sssssssssssss',
                'client_status' => 1,
                'created_at' => '2018-12-06 19:00:40',
                'id' => 52,
                'service_name' => 'ssssssssssssssss',
                'updated_at' => '2018-12-06 19:00:40',
            ),
            16 => 
            array (
                'client_code' => 'vietnam',
                'client_name' => 'vietnam',
                'client_status' => 1,
                'created_at' => '2018-12-06 19:00:52',
                'id' => 53,
                'service_name' => 'vietnam',
                'updated_at' => '2018-12-06 19:00:52',
            ),
            17 => 
            array (
                'client_code' => 'tygq',
                'client_name' => 'hhhhhhhhhh',
                'client_status' => 1,
                'created_at' => '2018-12-06 19:05:16',
                'id' => 56,
                'service_name' => 'hhhhhhhhhhhhhh',
                'updated_at' => '2018-12-06 19:05:16',
            ),
            18 => 
            array (
                'client_code' => 'demo',
                'client_name' => 'demo',
                'client_status' => 3,
                'created_at' => '2018-12-06 19:14:25',
                'id' => 70,
                'service_name' => 'demo',
                'updated_at' => '2018-12-06 19:14:25',
            ),
            19 => 
            array (
                'client_code' => 'Dangchuanbi',
                'client_name' => 'Đang chuẩn bị222',
                'client_status' => 2,
                'created_at' => '2018-12-06 19:15:41',
                'id' => 71,
                'service_name' => 'Đang chuẩn bị',
                'updated_at' => '2018-12-06 19:22:48',
            ),
            20 => 
            array (
                'client_code' => 'thuntm',
                'client_name' => 'thuntm',
                'client_status' => 1,
                'created_at' => '2018-12-07 10:21:12',
                'id' => 72,
                'service_name' => 'Dịch vụ',
                'updated_at' => '2018-12-07 10:35:18',
            ),
            21 => 
            array (
                'client_code' => 'test',
                'client_name' => 'test',
                'client_status' => 1,
                'created_at' => '2018-12-10 11:56:05',
                'id' => 73,
                'service_name' => 'test',
                'updated_at' => '2018-12-10 11:56:05',
            ),
            22 => 
            array (
                'client_code' => '0002',
                'client_name' => 'コレクション',
                'client_status' => 1,
                'created_at' => '2018-12-10 12:47:04',
                'id' => 74,
                'service_name' => 'コレクションコレクション',
                'updated_at' => '2018-12-10 12:47:04',
            ),
            23 => 
            array (
                'client_code' => 'ID001',
                'client_name' => '妖精',
                'client_status' => 1,
                'created_at' => '2018-12-10 12:51:38',
                'id' => 75,
                'service_name' => '妖精',
                'updated_at' => '2018-12-10 12:51:38',
            ),
            24 => 
            array (
                'client_code' => 'TC001',
                'client_name' => 'Thubeo',
                'client_status' => 1,
                'created_at' => '2018-12-10 13:49:46',
                'id' => 76,
                'service_name' => 'Thubeo',
                'updated_at' => '2018-12-10 13:49:46',
            ),
            25 => 
            array (
                'client_code' => 'TC002',
                'client_name' => 'Tungvd',
                'client_status' => 1,
                'created_at' => '2018-12-10 13:57:28',
                'id' => 77,
                'service_name' => 'Tungvd',
                'updated_at' => '2018-12-10 13:57:28',
            ),
            26 => 
            array (
                'client_code' => 'TesterTesterTesterTesterTesterTesterTest',
                'client_name' => 'TesterTesterTesterTesterTesterTesterTestTesterTesterTesterTesterTesterTesterTestTesterTesterTesterTe',
                'client_status' => 9,
                'created_at' => '2018-12-10 15:45:30',
                'id' => 78,
                'service_name' => 'Review code for branch feature-route-languageReview code for branch feature-route-languageReview cod',
                'updated_at' => '2018-12-11 13:01:07',
            ),
            27 => 
            array (
                'client_code' => 'hieudu',
                'client_name' => 'ducathegioi',
                'client_status' => 2,
                'created_at' => '2018-12-10 18:26:25',
                'id' => 79,
                'service_name' => 'ducathegioinayhaha',
                'updated_at' => '2018-12-10 18:26:25',
            ),
            28 => 
            array (
                'client_code' => 'nosplash',
                'client_name' => 'ducathegioi',
                'client_status' => 2,
                'created_at' => '2018-12-10 18:26:25',
                'id' => 80,
                'service_name' => 'ducathegioinayhaha',
                'updated_at' => '2018-12-10 18:26:25',
            ),
            29 => 
            array (
                'client_code' => 'no_app_setting',
                'client_name' => 'ducathegioi',
                'client_status' => 2,
                'created_at' => '2018-12-10 18:26:25',
                'id' => 181,
                'service_name' => 'ducathegioinayhaha',
                'updated_at' => '2018-12-10 18:26:25',
            ),
            30 => 
            array (
                'client_code' => 'khachhang',
                'client_name' => 'Thang',
                'client_status' => 2,
                'created_at' => '2019-03-01 16:58:37',
                'id' => 182,
                'service_name' => 'Spa',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            31 => 
            array (
                'client_code' => 'LanAnh',
                'client_name' => 'Lan',
                'client_status' => 1,
                'created_at' => '2019-03-01 17:09:17',
                'id' => 183,
                'service_name' => 'KhachSan',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            32 => 
            array (
                'client_code' => 'thang3',
                'client_name' => 'thang3',
                'client_status' => 1,
                'created_at' => '2019-03-01 17:16:50',
                'id' => 184,
                'service_name' => 'thang3',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            33 => 
            array (
                'client_code' => 'Quang',
                'client_name' => 'Quang',
                'client_status' => 1,
                'created_at' => '2019-03-01 18:00:59',
                'id' => 185,
                'service_name' => 'Hotel',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            34 => 
            array (
                'client_code' => 'eqwewq',
                'client_name' => 'eqweqw',
                'client_status' => 3,
                'created_at' => '2019-03-01 18:04:35',
                'id' => 186,
                'service_name' => 'zxczcxzc',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            35 => 
            array (
                'client_code' => 'luongtest',
                'client_name' => 'luongtest',
                'client_status' => 2,
                'created_at' => '2019-03-01 18:24:12',
                'id' => 187,
                'service_name' => 'etetet',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            36 => 
            array (
                'client_code' => 'tetetasdsadasdasdww',
                'client_name' => 'etete11111',
                'client_status' => 2,
                'created_at' => '2019-03-01 18:29:49',
                'id' => 188,
                'service_name' => 'etetet',
                'updated_at' => '2019-03-01 18:39:31',
            ),
            37 => 
            array (
                'client_code' => 'luongtest1',
                'client_name' => 'luongtest1',
                'client_status' => 1,
                'created_at' => '2019-03-01 18:33:11',
                'id' => 189,
                'service_name' => 'luongtest1',
                'updated_at' => '2019-03-12 10:48:53',
            ),
            38 => 
            array (
                'client_code' => 'luongtest2',
                'client_name' => 'luongtest2',
                'client_status' => 1,
                'created_at' => '2019-03-01 18:59:44',
                'id' => 190,
                'service_name' => 'luongtest2',
                'updated_at' => '2019-03-11 12:50:55',
            ),
            39 => 
            array (
                'client_code' => 'luongtest3',
                'client_name' => 'luongtest3',
                'client_status' => 1,
                'created_at' => '2019-03-01 19:33:25',
                'id' => 191,
                'service_name' => 'etetet',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            40 => 
            array (
                'client_code' => 'son',
                'client_name' => 'son',
                'client_status' => 1,
                'created_at' => '2019-03-05 13:03:04',
                'id' => 192,
                'service_name' => 'Dịch vụ',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            41 => 
            array (
                'client_code' => 'tetetclient_setting',
                'client_name' => 'tetet client_setting',
                'client_status' => 1,
                'created_at' => '2019-03-06 16:56:30',
                'id' => 193,
                'service_name' => 'tetet client_setting',
                'updated_at' => '2019-03-06 16:56:30',
            ),
            42 => 
            array (
                'client_code' => 'luongtest4',
                'client_name' => 'luongtest4',
                'client_status' => 2,
                'created_at' => '2019-03-11 13:40:07',
                'id' => 194,
                'service_name' => 'luongtest4',
                'updated_at' => '2019-03-11 15:30:34',
            ),
            43 => 
            array (
                'client_code' => 'luongtest5',
                'client_name' => 'luongtest5',
                'client_status' => 1,
                'created_at' => '2019-03-11 13:51:29',
                'id' => 195,
                'service_name' => 'luongtest5',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            44 => 
            array (
                'client_code' => 'luongtest6',
                'client_name' => 'luongtest6',
                'client_status' => 1,
                'created_at' => '2019-03-11 13:55:19',
                'id' => 196,
                'service_name' => 'luongtest6',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            45 => 
            array (
                'client_code' => 'luongtest7',
                'client_name' => 'luongtest7',
                'client_status' => 1,
                'created_at' => '2019-03-11 13:59:53',
                'id' => 197,
                'service_name' => 'luongtest7',
                'updated_at' => '2019-03-11 13:59:53',
            ),
            46 => 
            array (
                'client_code' => 'luongtest8',
                'client_name' => 'luongtest8',
                'client_status' => 1,
                'created_at' => '2019-03-11 15:10:21',
                'id' => 198,
                'service_name' => 'luongtest8',
                'updated_at' => '2019-03-11 15:10:21',
            ),
            47 => 
            array (
                'client_code' => 'vinicorp',
                'client_name' => 'vinicorp',
                'client_status' => 1,
                'created_at' => '2019-03-11 16:52:23',
                'id' => 199,
                'service_name' => 'Computer',
                'updated_at' => '2019-03-11 16:52:23',
            ),
            48 => 
            array (
                'client_code' => 'Thuntmm',
                'client_name' => 'ThuLibero',
                'client_status' => 1,
                'created_at' => '2019-04-10 12:29:07',
                'id' => 205,
                'service_name' => 'Dịch vụ',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            49 => 
            array (
                'client_code' => 'demo1',
                'client_name' => 'demo',
                'client_status' => 1,
                'created_at' => '2019-04-10 12:31:12',
                'id' => 206,
                'service_name' => 'demo',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            50 => 
            array (
                'client_code' => 'hieu_hieu',
                'client_name' => 'hieuhieu',
                'client_status' => 1,
                'created_at' => '2019-04-10 13:02:30',
                'id' => 207,
                'service_name' => 'hieuhieu',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            51 => 
            array (
                'client_code' => 'luong_test_api',
                'client_name' => 'luongtestapi',
                'client_status' => 2,
                'created_at' => '2019-05-17 17:01:24',
                'id' => 209,
                'service_name' => 'API_ACCESS_CONTROL_ALLOW_ORIGIN',
                'updated_at' => '2019-05-17 17:01:24',
            ),
            52 => 
            array (
                'client_code' => 'ngoc',
                'client_name' => 'Ngoc',
                'client_status' => 2,
                'created_at' => '2019-05-17 19:34:20',
                'id' => 210,
                'service_name' => 'Dịch vụ',
                'updated_at' => '2019-05-17 19:34:20',
            ),
            53 => 
            array (
                'client_code' => 'khanhchi',
                'client_name' => 'khanh chi',
                'client_status' => 1,
                'created_at' => '2019-05-20 10:45:33',
                'id' => 211,
                'service_name' => 'KhachSan',
                'updated_at' => '2019-05-20 10:45:33',
            ),
            54 => 
            array (
                'client_code' => 'test23',
                'client_name' => 'test 123',
                'client_status' => 1,
                'created_at' => '2019-05-22 16:40:58',
                'id' => 212,
                'service_name' => 'zxczcxzc',
                'updated_at' => '2019-05-22 16:40:58',
            ),
            55 => 
            array (
                'client_code' => 'test123',
                'client_name' => 'tetst',
                'client_status' => 3,
                'created_at' => '2019-06-03 13:38:01',
                'id' => 213,
                'service_name' => 'eqe',
                'updated_at' => '2019-06-03 13:38:01',
            ),
        ));
        
        
    }
}