<?php

use Illuminate\Database\Seeder;

class MapBodyStorageFilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('map_body_storage_files')->delete();
        
        \DB::table('map_body_storage_files')->insert(array (
            0 => 
            array (
                'id' => 1,
                'lang' => NULL,
                'map_data_id' => 4,
                'storage_file_id' => 1426,
            ),
            1 => 
            array (
                'id' => 11,
                'lang' => NULL,
                'map_data_id' => 28,
                'storage_file_id' => 2025,
            ),
            2 => 
            array (
                'id' => 12,
                'lang' => NULL,
                'map_data_id' => 31,
                'storage_file_id' => 2084,
            ),
            3 => 
            array (
                'id' => 13,
                'lang' => NULL,
                'map_data_id' => 34,
                'storage_file_id' => 2298,
            ),
            4 => 
            array (
                'id' => 14,
                'lang' => NULL,
                'map_data_id' => 40,
                'storage_file_id' => 2316,
            ),
            5 => 
            array (
                'id' => 18,
                'lang' => NULL,
                'map_data_id' => 46,
                'storage_file_id' => 2321,
            ),
            6 => 
            array (
                'id' => 20,
                'lang' => NULL,
                'map_data_id' => 49,
                'storage_file_id' => 2325,
            ),
            7 => 
            array (
                'id' => 21,
                'lang' => NULL,
                'map_data_id' => 50,
                'storage_file_id' => 2326,
            ),
            8 => 
            array (
                'id' => 22,
                'lang' => NULL,
                'map_data_id' => 37,
                'storage_file_id' => 2327,
            ),
            9 => 
            array (
                'id' => 25,
                'lang' => NULL,
                'map_data_id' => 47,
                'storage_file_id' => 2338,
            ),
            10 => 
            array (
                'id' => 26,
                'lang' => NULL,
                'map_data_id' => 54,
                'storage_file_id' => 2340,
            ),
            11 => 
            array (
                'id' => 27,
                'lang' => NULL,
                'map_data_id' => 54,
                'storage_file_id' => 2341,
            ),
            12 => 
            array (
                'id' => 28,
                'lang' => NULL,
                'map_data_id' => 53,
                'storage_file_id' => 2345,
            ),
            13 => 
            array (
                'id' => 29,
                'lang' => NULL,
                'map_data_id' => 53,
                'storage_file_id' => 2346,
            ),
            14 => 
            array (
                'id' => 30,
                'lang' => NULL,
                'map_data_id' => 53,
                'storage_file_id' => 2347,
            ),
            15 => 
            array (
                'id' => 31,
                'lang' => NULL,
                'map_data_id' => 57,
                'storage_file_id' => 2351,
            ),
            16 => 
            array (
                'id' => 32,
                'lang' => NULL,
                'map_data_id' => 57,
                'storage_file_id' => 2352,
            ),
            17 => 
            array (
                'id' => 33,
                'lang' => NULL,
                'map_data_id' => 58,
                'storage_file_id' => 2357,
            ),
            18 => 
            array (
                'id' => 34,
                'lang' => NULL,
                'map_data_id' => 58,
                'storage_file_id' => 2358,
            ),
            19 => 
            array (
                'id' => 35,
                'lang' => NULL,
                'map_data_id' => 58,
                'storage_file_id' => 2359,
            ),
            20 => 
            array (
                'id' => 39,
                'lang' => NULL,
                'map_data_id' => 51,
                'storage_file_id' => 2366,
            ),
            21 => 
            array (
                'id' => 40,
                'lang' => NULL,
                'map_data_id' => 30,
                'storage_file_id' => 2367,
            ),
            22 => 
            array (
                'id' => 43,
                'lang' => NULL,
                'map_data_id' => 59,
                'storage_file_id' => 2375,
            ),
            23 => 
            array (
                'id' => 44,
                'lang' => NULL,
                'map_data_id' => 59,
                'storage_file_id' => 2376,
            ),
            24 => 
            array (
                'id' => 45,
                'lang' => NULL,
                'map_data_id' => 61,
                'storage_file_id' => 2383,
            ),
            25 => 
            array (
                'id' => 46,
                'lang' => NULL,
                'map_data_id' => 61,
                'storage_file_id' => 2384,
            ),
            26 => 
            array (
                'id' => 49,
                'lang' => NULL,
                'map_data_id' => 52,
                'storage_file_id' => 2396,
            ),
            27 => 
            array (
                'id' => 50,
                'lang' => NULL,
                'map_data_id' => 62,
                'storage_file_id' => 2399,
            ),
            28 => 
            array (
                'id' => 51,
                'lang' => NULL,
                'map_data_id' => 62,
                'storage_file_id' => 2400,
            ),
            29 => 
            array (
                'id' => 52,
                'lang' => NULL,
                'map_data_id' => 62,
                'storage_file_id' => 2401,
            ),
            30 => 
            array (
                'id' => 53,
                'lang' => NULL,
                'map_data_id' => 64,
                'storage_file_id' => 2403,
            ),
            31 => 
            array (
                'id' => 54,
                'lang' => NULL,
                'map_data_id' => 65,
                'storage_file_id' => 2416,
            ),
            32 => 
            array (
                'id' => 55,
                'lang' => NULL,
                'map_data_id' => 65,
                'storage_file_id' => 2417,
            ),
            33 => 
            array (
                'id' => 56,
                'lang' => NULL,
                'map_data_id' => 65,
                'storage_file_id' => 2418,
            ),
            34 => 
            array (
                'id' => 57,
                'lang' => NULL,
                'map_data_id' => 66,
                'storage_file_id' => 2431,
            ),
            35 => 
            array (
                'id' => 58,
                'lang' => NULL,
                'map_data_id' => 66,
                'storage_file_id' => 2432,
            ),
            36 => 
            array (
                'id' => 59,
                'lang' => NULL,
                'map_data_id' => 66,
                'storage_file_id' => 2433,
            ),
            37 => 
            array (
                'id' => 60,
                'lang' => NULL,
                'map_data_id' => 67,
                'storage_file_id' => 2434,
            ),
            38 => 
            array (
                'id' => 61,
                'lang' => NULL,
                'map_data_id' => 67,
                'storage_file_id' => 2435,
            ),
            39 => 
            array (
                'id' => 62,
                'lang' => NULL,
                'map_data_id' => 67,
                'storage_file_id' => 2436,
            ),
            40 => 
            array (
                'id' => 63,
                'lang' => NULL,
                'map_data_id' => 67,
                'storage_file_id' => 2437,
            ),
            41 => 
            array (
                'id' => 64,
                'lang' => NULL,
                'map_data_id' => 44,
                'storage_file_id' => 2439,
            ),
            42 => 
            array (
                'id' => 65,
                'lang' => NULL,
                'map_data_id' => 44,
                'storage_file_id' => 2440,
            ),
            43 => 
            array (
                'id' => 66,
                'lang' => NULL,
                'map_data_id' => 44,
                'storage_file_id' => 2441,
            ),
            44 => 
            array (
                'id' => 67,
                'lang' => NULL,
                'map_data_id' => 44,
                'storage_file_id' => 2442,
            ),
            45 => 
            array (
                'id' => 68,
                'lang' => NULL,
                'map_data_id' => 45,
                'storage_file_id' => 2443,
            ),
            46 => 
            array (
                'id' => 69,
                'lang' => NULL,
                'map_data_id' => 45,
                'storage_file_id' => 2444,
            ),
            47 => 
            array (
                'id' => 70,
                'lang' => NULL,
                'map_data_id' => 45,
                'storage_file_id' => 2445,
            ),
            48 => 
            array (
                'id' => 71,
                'lang' => NULL,
                'map_data_id' => 45,
                'storage_file_id' => 2446,
            ),
            49 => 
            array (
                'id' => 72,
                'lang' => NULL,
                'map_data_id' => 41,
                'storage_file_id' => 2447,
            ),
            50 => 
            array (
                'id' => 73,
                'lang' => NULL,
                'map_data_id' => 41,
                'storage_file_id' => 2448,
            ),
            51 => 
            array (
                'id' => 74,
                'lang' => NULL,
                'map_data_id' => 41,
                'storage_file_id' => 2449,
            ),
            52 => 
            array (
                'id' => 75,
                'lang' => NULL,
                'map_data_id' => 70,
                'storage_file_id' => 2450,
            ),
            53 => 
            array (
                'id' => 76,
                'lang' => NULL,
                'map_data_id' => 70,
                'storage_file_id' => 2451,
            ),
            54 => 
            array (
                'id' => 77,
                'lang' => NULL,
                'map_data_id' => 70,
                'storage_file_id' => 2452,
            ),
            55 => 
            array (
                'id' => 78,
                'lang' => NULL,
                'map_data_id' => 70,
                'storage_file_id' => 2453,
            ),
            56 => 
            array (
                'id' => 79,
                'lang' => NULL,
                'map_data_id' => 71,
                'storage_file_id' => 2454,
            ),
            57 => 
            array (
                'id' => 80,
                'lang' => NULL,
                'map_data_id' => 73,
                'storage_file_id' => 2455,
            ),
            58 => 
            array (
                'id' => 81,
                'lang' => NULL,
                'map_data_id' => 73,
                'storage_file_id' => 2456,
            ),
            59 => 
            array (
                'id' => 82,
                'lang' => NULL,
                'map_data_id' => 73,
                'storage_file_id' => 2457,
            ),
            60 => 
            array (
                'id' => 83,
                'lang' => NULL,
                'map_data_id' => 74,
                'storage_file_id' => 2468,
            ),
            61 => 
            array (
                'id' => 84,
                'lang' => NULL,
                'map_data_id' => 74,
                'storage_file_id' => 2469,
            ),
            62 => 
            array (
                'id' => 85,
                'lang' => NULL,
                'map_data_id' => 74,
                'storage_file_id' => 2470,
            ),
            63 => 
            array (
                'id' => 86,
                'lang' => NULL,
                'map_data_id' => 76,
                'storage_file_id' => 2471,
            ),
            64 => 
            array (
                'id' => 87,
                'lang' => NULL,
                'map_data_id' => 68,
                'storage_file_id' => 2485,
            ),
            65 => 
            array (
                'id' => 88,
                'lang' => NULL,
                'map_data_id' => 68,
                'storage_file_id' => 2486,
            ),
            66 => 
            array (
                'id' => 89,
                'lang' => NULL,
                'map_data_id' => 68,
                'storage_file_id' => 2487,
            ),
            67 => 
            array (
                'id' => 90,
                'lang' => NULL,
                'map_data_id' => 68,
                'storage_file_id' => 2488,
            ),
            68 => 
            array (
                'id' => 91,
                'lang' => NULL,
                'map_data_id' => 75,
                'storage_file_id' => 2489,
            ),
            69 => 
            array (
                'id' => 92,
                'lang' => NULL,
                'map_data_id' => 38,
                'storage_file_id' => 2490,
            ),
            70 => 
            array (
                'id' => 93,
                'lang' => NULL,
                'map_data_id' => 38,
                'storage_file_id' => 2491,
            ),
            71 => 
            array (
                'id' => 94,
                'lang' => NULL,
                'map_data_id' => 38,
                'storage_file_id' => 2492,
            ),
            72 => 
            array (
                'id' => 95,
                'lang' => NULL,
                'map_data_id' => 38,
                'storage_file_id' => 2493,
            ),
            73 => 
            array (
                'id' => 96,
                'lang' => NULL,
                'map_data_id' => 39,
                'storage_file_id' => 2494,
            ),
            74 => 
            array (
                'id' => 97,
                'lang' => NULL,
                'map_data_id' => 78,
                'storage_file_id' => 2520,
            ),
            75 => 
            array (
                'id' => 98,
                'lang' => NULL,
                'map_data_id' => 79,
                'storage_file_id' => 2521,
            ),
            76 => 
            array (
                'id' => 99,
                'lang' => NULL,
                'map_data_id' => 79,
                'storage_file_id' => 2522,
            ),
            77 => 
            array (
                'id' => 100,
                'lang' => NULL,
                'map_data_id' => 79,
                'storage_file_id' => 2523,
            ),
            78 => 
            array (
                'id' => 101,
                'lang' => NULL,
                'map_data_id' => 79,
                'storage_file_id' => 2524,
            ),
            79 => 
            array (
                'id' => 102,
                'lang' => NULL,
                'map_data_id' => 79,
                'storage_file_id' => 2525,
            ),
            80 => 
            array (
                'id' => 103,
                'lang' => NULL,
                'map_data_id' => 80,
                'storage_file_id' => 2526,
            ),
            81 => 
            array (
                'id' => 104,
                'lang' => NULL,
                'map_data_id' => 80,
                'storage_file_id' => 2527,
            ),
            82 => 
            array (
                'id' => 105,
                'lang' => NULL,
                'map_data_id' => 80,
                'storage_file_id' => 2528,
            ),
            83 => 
            array (
                'id' => 106,
                'lang' => NULL,
                'map_data_id' => 80,
                'storage_file_id' => 2529,
            ),
            84 => 
            array (
                'id' => 107,
                'lang' => NULL,
                'map_data_id' => 80,
                'storage_file_id' => 2530,
            ),
            85 => 
            array (
                'id' => 108,
                'lang' => NULL,
                'map_data_id' => 80,
                'storage_file_id' => 2531,
            ),
            86 => 
            array (
                'id' => 109,
                'lang' => NULL,
                'map_data_id' => 81,
                'storage_file_id' => 2534,
            ),
            87 => 
            array (
                'id' => 110,
                'lang' => NULL,
                'map_data_id' => 81,
                'storage_file_id' => 2535,
            ),
            88 => 
            array (
                'id' => 111,
                'lang' => NULL,
                'map_data_id' => 81,
                'storage_file_id' => 2536,
            ),
            89 => 
            array (
                'id' => 112,
                'lang' => NULL,
                'map_data_id' => 81,
                'storage_file_id' => 2537,
            ),
            90 => 
            array (
                'id' => 113,
                'lang' => NULL,
                'map_data_id' => 82,
                'storage_file_id' => 2554,
            ),
            91 => 
            array (
                'id' => 114,
                'lang' => NULL,
                'map_data_id' => 82,
                'storage_file_id' => 2555,
            ),
            92 => 
            array (
                'id' => 115,
                'lang' => NULL,
                'map_data_id' => 82,
                'storage_file_id' => 2556,
            ),
            93 => 
            array (
                'id' => 116,
                'lang' => NULL,
                'map_data_id' => 83,
                'storage_file_id' => 2557,
            ),
            94 => 
            array (
                'id' => 117,
                'lang' => NULL,
                'map_data_id' => 83,
                'storage_file_id' => 2558,
            ),
            95 => 
            array (
                'id' => 118,
                'lang' => NULL,
                'map_data_id' => 83,
                'storage_file_id' => 2559,
            ),
            96 => 
            array (
                'id' => 119,
                'lang' => NULL,
                'map_data_id' => 83,
                'storage_file_id' => 2560,
            ),
            97 => 
            array (
                'id' => 120,
                'lang' => NULL,
                'map_data_id' => 84,
                'storage_file_id' => 2561,
            ),
            98 => 
            array (
                'id' => 121,
                'lang' => NULL,
                'map_data_id' => 84,
                'storage_file_id' => 2562,
            ),
            99 => 
            array (
                'id' => 122,
                'lang' => NULL,
                'map_data_id' => 84,
                'storage_file_id' => 2563,
            ),
            100 => 
            array (
                'id' => 123,
                'lang' => NULL,
                'map_data_id' => 87,
                'storage_file_id' => 2565,
            ),
            101 => 
            array (
                'id' => 124,
                'lang' => NULL,
                'map_data_id' => 87,
                'storage_file_id' => 2566,
            ),
            102 => 
            array (
                'id' => 125,
                'lang' => NULL,
                'map_data_id' => 88,
                'storage_file_id' => 2568,
            ),
            103 => 
            array (
                'id' => 126,
                'lang' => NULL,
                'map_data_id' => 88,
                'storage_file_id' => 2569,
            ),
            104 => 
            array (
                'id' => 127,
                'lang' => NULL,
                'map_data_id' => 88,
                'storage_file_id' => 2570,
            ),
            105 => 
            array (
                'id' => 128,
                'lang' => NULL,
                'map_data_id' => 2198,
                'storage_file_id' => 2769,
            ),
            106 => 
            array (
                'id' => 129,
                'lang' => NULL,
                'map_data_id' => 2198,
                'storage_file_id' => 2770,
            ),
            107 => 
            array (
                'id' => 130,
                'lang' => NULL,
                'map_data_id' => 2198,
                'storage_file_id' => 2771,
            ),
            108 => 
            array (
                'id' => 131,
                'lang' => NULL,
                'map_data_id' => 2202,
                'storage_file_id' => 2788,
            ),
            109 => 
            array (
                'id' => 132,
                'lang' => NULL,
                'map_data_id' => 2202,
                'storage_file_id' => 2789,
            ),
            110 => 
            array (
                'id' => 133,
                'lang' => NULL,
                'map_data_id' => 2202,
                'storage_file_id' => 2790,
            ),
            111 => 
            array (
                'id' => 134,
                'lang' => NULL,
                'map_data_id' => 2206,
                'storage_file_id' => 2791,
            ),
            112 => 
            array (
                'id' => 135,
                'lang' => NULL,
                'map_data_id' => 2206,
                'storage_file_id' => 2792,
            ),
            113 => 
            array (
                'id' => 136,
                'lang' => NULL,
                'map_data_id' => 2206,
                'storage_file_id' => 2793,
            ),
            114 => 
            array (
                'id' => 137,
                'lang' => NULL,
                'map_data_id' => 2207,
                'storage_file_id' => 2794,
            ),
            115 => 
            array (
                'id' => 138,
                'lang' => NULL,
                'map_data_id' => 2207,
                'storage_file_id' => 2795,
            ),
            116 => 
            array (
                'id' => 139,
                'lang' => NULL,
                'map_data_id' => 2209,
                'storage_file_id' => 2796,
            ),
            117 => 
            array (
                'id' => 140,
                'lang' => NULL,
                'map_data_id' => 2210,
                'storage_file_id' => 2797,
            ),
            118 => 
            array (
                'id' => 141,
                'lang' => NULL,
                'map_data_id' => 2210,
                'storage_file_id' => 2798,
            ),
        ));
        
        
    }
}