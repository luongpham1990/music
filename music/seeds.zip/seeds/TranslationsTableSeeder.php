<?php

use Illuminate\Database\Seeder;

class TranslationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('translations')->delete();
        
        \DB::table('translations')->insert(array (
            0 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 1,
                'foreign_table' => 'posts',
                'id' => 1,
                'lang' => 'ja_easy',
                'translated_text' => 'sdfasd',
            ),
            1 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 1,
                'foreign_table' => 'posts',
                'id' => 2,
                'lang' => 'ja_easy',
                'translated_text' => 'fasdf',
            ),
            2 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 4,
                'foreign_table' => 'posts',
                'id' => 7,
                'lang' => 'ja_easy',
                'translated_text' => 'bdb',
            ),
            3 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 4,
                'foreign_table' => 'posts',
                'id' => 8,
                'lang' => 'ja_easy',
                'translated_text' => 'dbdbgbbbdfdbfdbdfbgdfbdfgbdfbgdfbgdfgbdg',
            ),
            4 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 5,
                'foreign_table' => 'posts',
                'id' => 11,
                'lang' => 'ja_easy',
                'translated_text' => 'à',
            ),
            5 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 5,
                'foreign_table' => 'posts',
                'id' => 12,
                'lang' => 'ja_easy',
                'translated_text' => 'sdfasd',
            ),
            6 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 6,
                'foreign_table' => 'posts',
                'id' => 13,
                'lang' => 'ja_easy',
                'translated_text' => 'sdf',
            ),
            7 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 6,
                'foreign_table' => 'posts',
                'id' => 14,
                'lang' => 'ja_easy',
                'translated_text' => 'fgsdf',
            ),
            8 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 7,
                'foreign_table' => 'posts',
                'id' => 15,
                'lang' => 'ja_easy',
                'translated_text' => 'sdf',
            ),
            9 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 7,
                'foreign_table' => 'posts',
                'id' => 16,
                'lang' => 'ja_easy',
                'translated_text' => 'sdfsdf',
            ),
            10 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 23,
                'foreign_table' => 'posts',
                'id' => 17,
                'lang' => 'ja_easy',
                'translated_text' => 'sdc',
            ),
            11 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 23,
                'foreign_table' => 'posts',
                'id' => 18,
                'lang' => 'ja_easy',
                'translated_text' => 'sdcsdc',
            ),
            12 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 28,
                'foreign_table' => 'posts',
                'id' => 21,
                'lang' => 'ja_easy',
                'translated_text' => 'sad',
            ),
            13 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 28,
                'foreign_table' => 'posts',
                'id' => 22,
                'lang' => 'ja_easy',
                'translated_text' => 'sadasd',
            ),
            14 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 29,
                'foreign_table' => 'posts',
                'id' => 27,
                'lang' => 'ja_easy',
                'translated_text' => 'asc',
            ),
            15 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 29,
                'foreign_table' => 'posts',
                'id' => 28,
                'lang' => 'ja_easy',
                'translated_text' => 'ascas',
            ),
            16 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 2,
                'foreign_table' => 'links',
                'id' => 29,
                'lang' => 'ja_easy',
                'translated_text' => 'das',
            ),
            17 => 
            array (
                'foreign_field' => 'link_url',
                'foreign_id' => 2,
                'foreign_table' => 'links',
                'id' => 30,
                'lang' => 'ja_easy',
                'translated_text' => 'http://machiyell.test/ctrl/visor/content_group/5/content/form2',
            ),
            18 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 30,
                'foreign_table' => 'posts',
                'id' => 31,
                'lang' => 'ja_easy',
                'translated_text' => 'đá',
            ),
            19 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 30,
                'foreign_table' => 'posts',
                'id' => 32,
                'lang' => 'ja_easy',
                'translated_text' => 'd',
            ),
            20 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 13,
                'foreign_table' => 'tags',
                'id' => 33,
                'lang' => 'ja_easy',
                'translated_text' => '今日のサッカー',
            ),
            21 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 14,
                'foreign_table' => 'tags',
                'id' => 34,
                'lang' => 'ja_easy',
                'translated_text' => 'フライトチケット',
            ),
            22 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 15,
                'foreign_table' => 'tags',
                'id' => 35,
                'lang' => 'ja_easy',
                'translated_text' => 'テトホリデー',
            ),
            23 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 16,
                'foreign_table' => 'tags',
                'id' => 36,
                'lang' => 'ja_easy',
                'translated_text' => 'ファッション',
            ),
            24 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 17,
                'foreign_table' => 'tags',
                'id' => 37,
                'lang' => 'ja_easy',
                'translated_text' => '旅行する',
            ),
            25 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 18,
                'foreign_table' => 'tags',
                'id' => 38,
                'lang' => 'ja_easy',
                'translated_text' => '学校',
            ),
            26 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 19,
                'foreign_table' => 'tags',
                'id' => 39,
                'lang' => 'ja_easy',
                'translated_text' => '学校教育',
            ),
            27 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 20,
                'foreign_table' => 'tags',
                'id' => 40,
                'lang' => 'ja_easy',
                'translated_text' => '健康',
            ),
            28 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 31,
                'foreign_table' => 'posts',
                'id' => 41,
                'lang' => 'ja_easy',
                'translated_text' => 'eeeeeeeeeeeeee',
            ),
            29 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 31,
                'foreign_table' => 'posts',
                'id' => 42,
                'lang' => 'ja_easy',
                'translated_text' => 'eeeeeeeeeeeeeeeeeeeee',
            ),
            30 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 21,
                'foreign_table' => 'tags',
                'id' => 43,
                'lang' => 'ja_easy',
                'translated_text' => 'Ca phe sang',
            ),
            31 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 32,
                'foreign_table' => 'posts',
                'id' => 44,
                'lang' => 'ja_easy',
                'translated_text' => 'j7777',
            ),
            32 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 32,
                'foreign_table' => 'posts',
                'id' => 45,
                'lang' => 'ja_easy',
                'translated_text' => '777777777777777',
            ),
            33 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 34,
                'foreign_table' => 'posts',
                'id' => 49,
                'lang' => 'ja_easy',
                'translated_text' => 'rrrr2222222222',
            ),
            34 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 34,
                'foreign_table' => 'posts',
                'id' => 50,
                'lang' => 'ja_easy',
                'translated_text' => '22222222222',
            ),
            35 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 38,
                'foreign_table' => 'posts',
                'id' => 51,
                'lang' => 'ja_easy',
                'translated_text' => 'oooooo',
            ),
            36 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 38,
                'foreign_table' => 'posts',
                'id' => 52,
                'lang' => 'ja_easy',
                'translated_text' => 'ooooooooooooooooooooooooooo<br>',
            ),
            37 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 22,
                'foreign_table' => 'tags',
                'id' => 56,
                'lang' => 'ja_easy',
                'translated_text' => 'test 2',
            ),
            38 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 41,
                'foreign_table' => 'posts',
                'id' => 57,
                'lang' => 'ja_easy',
                'translated_text' => 'thubeo222222222222',
            ),
            39 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 41,
                'foreign_table' => 'posts',
                'id' => 58,
                'lang' => 'ja_easy',
            'translated_text' => '<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#cc33cc"><strong>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></strong></font></span>',
            ),
            40 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 43,
                'foreign_table' => 'posts',
                'id' => 64,
                'lang' => 'ja_easy',
                'translated_text' => 'thudieuthudieuthudieu2222',
            ),
            41 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 43,
                'foreign_table' => 'posts',
                'id' => 65,
                'lang' => 'ja_easy',
                'translated_text' => 'thudieuthudieuthudieuthudieuthudieuthudieuthudieu',
            ),
            42 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 44,
                'foreign_table' => 'posts',
                'id' => 66,
                'lang' => 'ja_easy',
                'translated_text' => 'thuamthuam',
            ),
            43 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 44,
                'foreign_table' => 'posts',
                'id' => 67,
                'lang' => 'ja_easy',
                'translated_text' => 'thuamthuamthuamthuam',
            ),
            44 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 46,
                'foreign_table' => 'posts',
                'id' => 68,
                'lang' => 'ja_easy',
                'translated_text' => 'test duoi 6MB',
            ),
            45 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 46,
                'foreign_table' => 'posts',
                'id' => 69,
                'lang' => 'ja_easy',
                'translated_text' => 'test duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MB',
            ),
            46 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 47,
                'foreign_table' => 'posts',
                'id' => 72,
                'lang' => 'ja_easy',
                'translated_text' => 'test 7Mb',
            ),
            47 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 47,
                'foreign_table' => 'posts',
                'id' => 73,
                'lang' => 'ja_easy',
                'translated_text' => 'test 7Mb<br>',
            ),
            48 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 8,
                'foreign_table' => 'websites',
                'id' => 77,
                'lang' => 'ja_easy',
                'translated_text' => 'colen khong',
            ),
            49 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 8,
                'foreign_table' => 'websites',
                'id' => 78,
                'lang' => 'ja_easy',
                'translated_text' => 'colen khongcolen khongcolen khongcolen khongcolen khongcolen khong',
            ),
            50 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 48,
                'foreign_table' => 'posts',
                'id' => 79,
                'lang' => 'ja_easy',
                'translated_text' => 'test trên 7MB',
            ),
            51 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 48,
                'foreign_table' => 'posts',
                'id' => 80,
                'lang' => 'ja_easy',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test trên 7MBtest trên 7MBtest trên 7MBtest trên 7MB</span></font>',
            ),
            52 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 49,
                'foreign_table' => 'posts',
                'id' => 83,
                'lang' => 'es',
                'translated_text' => '戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ',
            ),
            53 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 49,
                'foreign_table' => 'posts',
                'id' => 84,
                'lang' => 'es',
                'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">開断ーび前禁ナチ数歳げーて認3長ヱルネ翌氏さみせ率際ンをろ開向更イル場善せだフ毎37樹上像とお。碁クコキユ指香ルぴすぽ不後ハレムセ動懲ねうど川血テヌア都訃ナ歳7像リあへょ合練時透辞サラ替也っ神炎評ワム団一合アニマ究3区リセ戦代技福電がむみつ。去サ無選政へゃ川記ぽ団職ぱ善通まげぶの鈴日ムナ医應ミ観高クリロ最今クモ省努とらつ同連む表震めーもク表会ーもリ月不辞吏じてフは。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">数マツケメ様業ょば人指属ヱセヌマ円自匂ク際明きぎンょ問囲土ソ償一じ将刻モチソ提新はぽじく愛動けイ運純ミ営発ト念均づめろい声聞ヤミタ暮的がす同解曽膨じリ。写従ヌ韓航ゅもリ白気をゅレト意83通十ロエアオ信磯ょ列36将色ラスナサ申献にぴへ予集ニクイ設86克即両69克即両19敢渓窮胡あの。劾メ件会ヲニ税史ばぐトす能入イぎ提価じ水設こごぽラ田掲年勲う回芸テセコア催速んふき米次布益陣むてふ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">声ヨフ情林元ク迂輸ムヒ斜配ストヱ性休38妊舌頃魔8異ずちしぶ第愛ほ川治ラロ度67今更フユ治薬るいばぼ室任提思吏んろ。会みどろ続違ぐ者福ニメヲ理企中一づ幕音リウ新午おがとの経第ずーのば広2記定フキシリ引海ぽ恥離夢みらん。焦ねる建料ゅやせち措訃ルユキ化場トくリ空頑聞が反例ノ見低導ワ編51郎えぽ金兵けス区元ヌ河集ラ応洗ス並大けば方性ぴべづ記大べをず意憂喰杜椿ルッ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">暮もルめ娘良キタル委呈オケ荒別マヘユホ歌精さたしば様6手地リぱかろ毎作はろ断国がに尽環ク画稿やつが変態票特ぱ。禁いぱだろ切事スいみ一投監お外尚岡ヘソト城木おてたク作63府属ば自大レチヒイ回1表不ずきト富投ケヒモニ郎区ウ松完スヘ昨賞花飛んぜだぎ。全ヨ最毎クワシ明立止クサユ救消ミニコヒ重軽ト正費せ普転外がし届集期タ披61感毎ト児紀えば位情ばがれド断45欠ウワニ聞局予現情の。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">入チマムホ村社みるン安滴クたま石記カ成訃ムネナモ民各ンっぴべ江73知きド全足ヱ差薫メカフア市全者サチト航問キハケ意備ニチメル模年でほ内参他ほれわっ。石リょ法営ルづけ飛変ねが豊注スヤナ雲市ハ髄1訪稿づぐぎぼ後声ヤロハタ入住び補2転ほづっ刊運永マヨ介候タカマ一正古26俑ばリび小記購仁借つまう。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">31速どきぱ択到おリ載試報ルリ水浅か澄芸ちわて講1気りだ味影げた勢属ぞりせ志展メ人者ヤホ動賀ナ禁周暮ホムオテ店雇余献だらげべ。会シム東一女ノオネ賞聞びめが鍵特スユ月米モ付増飛コリ導提んあて頻受略ロ一更なうー掲属井ヌマヘ差界師ヤヱシ天事ごよぴづ録息曲燃階みけ。図にをてイ角健だ公植ム冬当ーひぱス載特日ぴ況5断ンぎっ長会ムクレヌ保半図ふいでね心飯オト位楽義ょぴちご。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">断あ他賞車ちげでま積政ッさ材下イ翔山ワウ割和ほクぐ札促チメク作23応べる年月ぐ月麓トノフヲ活北ムヘキ学球購締ぴじ。追レだふス校詰然アネタ中入悲椅ロリカモ媛年むレびク被信トミ力議ハカミ慣係ヌメヤ用14士3幕ド本9重こにっリ。戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">日ぶ山評ス欧供そひ業児ヒキ望暮シノ銀月んす分子めどっ師術告き芸進っ理定ヱヤ帯測キシケク示新アミウ松聖スせりっ治合ネノ像93本フエ記公地映イえン。玉業ラぶめ荻広ごたく循新げ余試ルラカ業企ヲヨニネ暮4引リメイ要8習ツオヌ暮分よりきわ北朝籍華踏麻わめ。援資見へぐな棋活ワオト領方カナケミ間連治長ん確水よおみぎ遺掲もいほぽ厳77万所特5型チレ止急コ申難ねざルわ芸害もラご頭広郎互札く。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">都け保6留メイツヌ会育月ヒ系案ー返74便ょ質使ふ春質むぼ数期き要板植抜いおえ。坂ハ意規マケレナ象護見トサ申果ナシフミ君質ラワテヒ極佐にど三能ろル組労日かびそ酒25好著わ遺載オ専説喫羅踊こほ。写ゃぽ築相ぐぜよ事持ヘアヲヤ料頃でたんと館担ぎく交手わぼド携速ヒ応現ケラロ話堀近チ伴絵ち史45家ろ毎王購歩ょすに。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">案4事岐情ヌソナ未住づびべ選号キ重納なラふ済年セウ足中ほ禁写マセワナ無62壺柱っは潟太がびら定止ッ際庭やざへイ。断主なうぜフ部点チヌ知78洋電ねル誤金しら棋然レフるぽ事占けそぞれ農義ヨモ切人判りこかぱ時特ヲユ以野れ問編い音青ラヱメマ持目ソ嶋接年よはゅ。全地気ナマラ日主オコ海長イケヨア世田へスぱや伸備クロマネ外2消ねえまお暢山オニル週57純ツニウテ示象晶いむ。</span></font></div>',
            ),
            54 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 49,
                'foreign_table' => 'posts',
                'id' => 85,
                'lang' => 'ja_easy',
                'translated_text' => '戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ',
            ),
            55 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 49,
                'foreign_table' => 'posts',
                'id' => 86,
                'lang' => 'ja_easy',
                'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">開断ーび前禁ナチ数歳げーて認3長ヱルネ翌氏さみせ率際ンをろ開向更イル場善せだフ毎37樹上像とお。碁クコキユ指香ルぴすぽ不後ハレムセ動懲ねうど川血テヌア都訃ナ歳7像リあへょ合練時透辞サラ替也っ神炎評ワム団一合アニマ究3区リセ戦代技福電がむみつ。去サ無選政へゃ川記ぽ団職ぱ善通まげぶの鈴日ムナ医應ミ観高クリロ最今クモ省努とらつ同連む表震めーもク表会ーもリ月不辞吏じてフは。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">数マツケメ様業ょば人指属ヱセヌマ円自匂ク際明きぎンょ問囲土ソ償一じ将刻モチソ提新はぽじく愛動けイ運純ミ営発ト念均づめろい声聞ヤミタ暮的がす同解曽膨じリ。写従ヌ韓航ゅもリ白気をゅレト意83通十ロエアオ信磯ょ列36将色ラスナサ申献にぴへ予集ニクイ設86克即両69克即両19敢渓窮胡あの。劾メ件会ヲニ税史ばぐトす能入イぎ提価じ水設こごぽラ田掲年勲う回芸テセコア催速んふき米次布益陣むてふ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">声ヨフ情林元ク迂輸ムヒ斜配ストヱ性休38妊舌頃魔8異ずちしぶ第愛ほ川治ラロ度67今更フユ治薬るいばぼ室任提思吏んろ。会みどろ続違ぐ者福ニメヲ理企中一づ幕音リウ新午おがとの経第ずーのば広2記定フキシリ引海ぽ恥離夢みらん。焦ねる建料ゅやせち措訃ルユキ化場トくリ空頑聞が反例ノ見低導ワ編51郎えぽ金兵けス区元ヌ河集ラ応洗ス並大けば方性ぴべづ記大べをず意憂喰杜椿ルッ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">暮もルめ娘良キタル委呈オケ荒別マヘユホ歌精さたしば様6手地リぱかろ毎作はろ断国がに尽環ク画稿やつが変態票特ぱ。禁いぱだろ切事スいみ一投監お外尚岡ヘソト城木おてたク作63府属ば自大レチヒイ回1表不ずきト富投ケヒモニ郎区ウ松完スヘ昨賞花飛んぜだぎ。全ヨ最毎クワシ明立止クサユ救消ミニコヒ重軽ト正費せ普転外がし届集期タ披61感毎ト児紀えば位情ばがれド断45欠ウワニ聞局予現情の。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">入チマムホ村社みるン安滴クたま石記カ成訃ムネナモ民各ンっぴべ江73知きド全足ヱ差薫メカフア市全者サチト航問キハケ意備ニチメル模年でほ内参他ほれわっ。石リょ法営ルづけ飛変ねが豊注スヤナ雲市ハ髄1訪稿づぐぎぼ後声ヤロハタ入住び補2転ほづっ刊運永マヨ介候タカマ一正古26俑ばリび小記購仁借つまう。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">31速どきぱ択到おリ載試報ルリ水浅か澄芸ちわて講1気りだ味影げた勢属ぞりせ志展メ人者ヤホ動賀ナ禁周暮ホムオテ店雇余献だらげべ。会シム東一女ノオネ賞聞びめが鍵特スユ月米モ付増飛コリ導提んあて頻受略ロ一更なうー掲属井ヌマヘ差界師ヤヱシ天事ごよぴづ録息曲燃階みけ。図にをてイ角健だ公植ム冬当ーひぱス載特日ぴ況5断ンぎっ長会ムクレヌ保半図ふいでね心飯オト位楽義ょぴちご。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">断あ他賞車ちげでま積政ッさ材下イ翔山ワウ割和ほクぐ札促チメク作23応べる年月ぐ月麓トノフヲ活北ムヘキ学球購締ぴじ。追レだふス校詰然アネタ中入悲椅ロリカモ媛年むレびク被信トミ力議ハカミ慣係ヌメヤ用14士3幕ド本9重こにっリ。戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">日ぶ山評ス欧供そひ業児ヒキ望暮シノ銀月んす分子めどっ師術告き芸進っ理定ヱヤ帯測キシケク示新アミウ松聖スせりっ治合ネノ像93本フエ記公地映イえン。玉業ラぶめ荻広ごたく循新げ余試ルラカ業企ヲヨニネ暮4引リメイ要8習ツオヌ暮分よりきわ北朝籍華踏麻わめ。援資見へぐな棋活ワオト領方カナケミ間連治長ん確水よおみぎ遺掲もいほぽ厳77万所特5型チレ止急コ申難ねざルわ芸害もラご頭広郎互札く。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">都け保6留メイツヌ会育月ヒ系案ー返74便ょ質使ふ春質むぼ数期き要板植抜いおえ。坂ハ意規マケレナ象護見トサ申果ナシフミ君質ラワテヒ極佐にど三能ろル組労日かびそ酒25好著わ遺載オ専説喫羅踊こほ。写ゃぽ築相ぐぜよ事持ヘアヲヤ料頃でたんと館担ぎく交手わぼド携速ヒ応現ケラロ話堀近チ伴絵ち史45家ろ毎王購歩ょすに。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">案4事岐情ヌソナ未住づびべ選号キ重納なラふ済年セウ足中ほ禁写マセワナ無62壺柱っは潟太がびら定止ッ際庭やざへイ。断主なうぜフ部点チヌ知78洋電ねル誤金しら棋然レフるぽ事占けそぞれ農義ヨモ切人判りこかぱ時特ヲユ以野れ問編い音青ラヱメマ持目ソ嶋接年よはゅ。全地気ナマラ日主オコ海長イケヨア世田へスぱや伸備クロマネ外2消ねえまお暢山オニル週57純ツニウテ示象晶いむ。</span></font></div>',
            ),
            56 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 50,
                'foreign_table' => 'posts',
                'id' => 87,
                'lang' => 'es',
                'translated_text' => 'dede',
            ),
            57 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 50,
                'foreign_table' => 'posts',
                'id' => 88,
                'lang' => 'es',
                'translated_text' => 'sacasc',
            ),
            58 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 50,
                'foreign_table' => 'posts',
                'id' => 89,
                'lang' => 'ja_easy',
                'translated_text' => 'asd',
            ),
            59 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 50,
                'foreign_table' => 'posts',
                'id' => 90,
                'lang' => 'ja_easy',
                'translated_text' => 'ascasc',
            ),
            60 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 58,
                'foreign_table' => 'posts',
                'id' => 92,
                'lang' => 'es',
                'translated_text' => 'ascsacasc',
            ),
            61 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 58,
                'foreign_table' => 'posts',
                'id' => 93,
                'lang' => 'ko',
                'translated_text' => 'scascascasc',
            ),
            62 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 59,
                'foreign_table' => 'posts',
                'id' => 94,
                'lang' => 'es',
                'translated_text' => 'fdfasdfasdf',
            ),
            63 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 59,
                'foreign_table' => 'posts',
                'id' => 95,
                'lang' => 'ko',
                'translated_text' => 'dasfsdf',
            ),
            64 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 60,
                'foreign_table' => 'posts',
                'id' => 96,
                'lang' => 'es',
                'translated_text' => 'asdsad',
            ),
            65 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 60,
                'foreign_table' => 'posts',
                'id' => 97,
                'lang' => 'ko',
                'translated_text' => '67897asdas',
            ),
            66 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 60,
                'foreign_table' => 'posts',
                'id' => 107,
                'lang' => 'ko',
                'translated_text' => 'test update content post optional',
            ),
            67 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 60,
                'foreign_table' => 'posts',
                'id' => 108,
                'lang' => 'es',
                'translated_text' => 'sdasdas',
            ),
            68 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 60,
                'foreign_table' => 'posts',
                'id' => 109,
                'lang' => 'en',
                'translated_text' => 'adasd',
            ),
            69 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 58,
                'foreign_table' => 'posts',
                'id' => 110,
                'lang' => 'ko',
                'translated_text' => 'kr_title 1',
            ),
            70 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 23,
                'foreign_table' => 'tags',
                'id' => 114,
                'lang' => 'en',
                'translated_text' => 'zxczxczxc',
            ),
            71 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 23,
                'foreign_table' => 'tags',
                'id' => 115,
                'lang' => 'es',
                'translated_text' => 'eqweqweewqe',
            ),
            72 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 23,
                'foreign_table' => 'tags',
                'id' => 116,
                'lang' => 'ja_easy',
                'translated_text' => 'czxczxc',
            ),
            73 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 23,
                'foreign_table' => 'tags',
                'id' => 117,
                'lang' => 'ko',
                'translated_text' => 'cxzczc',
            ),
            74 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 24,
                'foreign_table' => 'tags',
                'id' => 129,
                'lang' => 'en',
                'translated_text' => 'tgtgtgtgtgtgtgtgtgtg',
            ),
            75 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 24,
                'foreign_table' => 'tags',
                'id' => 130,
                'lang' => 'es',
                'translated_text' => 'tttttttttttt',
            ),
            76 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 24,
                'foreign_table' => 'tags',
                'id' => 131,
                'lang' => 'ja_easy',
                'translated_text' => 'tttttttttttttt',
            ),
            77 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 24,
                'foreign_table' => 'tags',
                'id' => 132,
                'lang' => 'ko',
                'translated_text' => 'ttttttttt',
            ),
            78 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 25,
                'foreign_table' => 'tags',
                'id' => 133,
                'lang' => 'en',
                'translated_text' => 'Thu tests',
            ),
            79 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 25,
                'foreign_table' => 'tags',
                'id' => 134,
                'lang' => 'es',
                'translated_text' => 'Thu testdsdsdsdsdsdsdsdsds',
            ),
            80 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 25,
                'foreign_table' => 'tags',
                'id' => 135,
                'lang' => 'ja_easy',
                'translated_text' => 'Thu test333',
            ),
            81 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 25,
                'foreign_table' => 'tags',
                'id' => 136,
                'lang' => 'ko',
                'translated_text' => 'Thu test44',
            ),
            82 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 12,
                'foreign_table' => 'websites',
                'id' => 137,
                'lang' => 'en',
                'translated_text' => 'test webpage 2 optional',
            ),
            83 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 12,
                'foreign_table' => 'websites',
                'id' => 138,
                'lang' => 'es',
                'translated_text' => 'test webpage 3 optional',
            ),
            84 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 26,
                'foreign_table' => 'tags',
                'id' => 139,
                'lang' => 'es',
                'translated_text' => 'dfew',
            ),
            85 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 26,
                'foreign_table' => 'tags',
                'id' => 140,
                'lang' => 'ko',
                'translated_text' => 'fwe3',
            ),
            86 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 27,
                'foreign_table' => 'tags',
                'id' => 141,
                'lang' => 'es',
                'translated_text' => 'brweq',
            ),
            87 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 27,
                'foreign_table' => 'tags',
                'id' => 142,
                'lang' => 'ko',
                'translated_text' => 'wwwwww54',
            ),
            88 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 28,
                'foreign_table' => 'tags',
                'id' => 143,
                'lang' => 'es',
                'translated_text' => 'rr',
            ),
            89 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 28,
                'foreign_table' => 'tags',
                'id' => 144,
                'lang' => 'ko',
                'translated_text' => 'rrrrrrrrrrrrrrrr',
            ),
            90 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 12,
                'foreign_table' => 'websites',
                'id' => 145,
                'lang' => 'ja_easy',
                'translated_text' => 'test update webpage optional',
            ),
            91 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 12,
                'foreign_table' => 'websites',
                'id' => 146,
                'lang' => 'ko',
                'translated_text' => 'test update webpage optional',
            ),
            92 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 29,
                'foreign_table' => 'tags',
                'id' => 150,
                'lang' => 'es',
                'translated_text' => 'gt',
            ),
            93 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 29,
                'foreign_table' => 'tags',
                'id' => 151,
                'lang' => 'ko',
                'translated_text' => 'tssss',
            ),
            94 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 30,
                'foreign_table' => 'tags',
                'id' => 152,
                'lang' => 'es',
                'translated_text' => 'ss',
            ),
            95 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 30,
                'foreign_table' => 'tags',
                'id' => 153,
                'lang' => 'ko',
                'translated_text' => 'đ',
            ),
            96 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 11,
                'foreign_table' => 'links',
                'id' => 154,
                'lang' => 'es',
                'translated_text' => '腕座おイし札照ヲ紙遣オセウヱ遅新ぜき様題要テキ券運ラほょ盤大くれむ日3山ざべむそ写改志叙孟やリがあ。球づずうド月掲病シ共感トクコ職天レオエヤ第俳ルン図備いぼえ記山ゃドべ面93教レ込康ヒキ死象だぼ細余クッルち評6償ケノ近右ヲモイセ口資イよ聞6拡盛秀す。自点くた国周にひ過示日オトモコ題準提ば年議売ホキセウ激勤ヱ支別環モメ読棄銃取略ひく。',
            ),
            97 => 
            array (
                'foreign_field' => 'link_url',
                'foreign_id' => 11,
                'foreign_table' => 'links',
                'id' => 155,
                'lang' => 'ko',
                'translated_text' => 'https://xd.adobe.com/view/6515f767-9a93-4452-6dbc-d026dab206a8-1324/',
            ),
            98 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 11,
                'foreign_table' => 'links',
                'id' => 156,
                'lang' => 'en',
                'translated_text' => 'test content file optional 11',
            ),
            99 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 11,
                'foreign_table' => 'links',
                'id' => 157,
                'lang' => 'ko',
                'translated_text' => 'kr_title 1',
            ),
            100 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 61,
                'foreign_table' => 'posts',
                'id' => 167,
                'lang' => 'es',
                'translated_text' => 'thu222222',
            ),
            101 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 31,
                'foreign_table' => 'tags',
                'id' => 168,
                'lang' => 'es',
                'translated_text' => 'Tags Tin tức1',
            ),
            102 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 31,
                'foreign_table' => 'tags',
                'id' => 169,
                'lang' => 'ko',
                'translated_text' => 'Tags Tin tức2',
            ),
            103 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 32,
                'foreign_table' => 'tags',
                'id' => 170,
                'lang' => 'es',
                'translated_text' => 'Tags tai chinh2',
            ),
            104 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 32,
                'foreign_table' => 'tags',
                'id' => 171,
                'lang' => 'ko',
                'translated_text' => 'Tags tai chinh3',
            ),
            105 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 33,
                'foreign_table' => 'tags',
                'id' => 172,
                'lang' => 'es',
                'translated_text' => 'Tags Khoa Hoc2',
            ),
            106 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 33,
                'foreign_table' => 'tags',
                'id' => 173,
                'lang' => 'ko',
                'translated_text' => 'Tags Khoa Hoc3',
            ),
            107 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 34,
                'foreign_table' => 'tags',
                'id' => 174,
                'lang' => 'es',
                'translated_text' => 'Tags Hoa Hau2',
            ),
            108 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 34,
                'foreign_table' => 'tags',
                'id' => 175,
                'lang' => 'ko',
                'translated_text' => 'Tags Hoa Hau3',
            ),
            109 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 62,
                'foreign_table' => 'posts',
                'id' => 176,
                'lang' => 'es',
                'translated_text' => 'finish Test ngon ngu2',
            ),
            110 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 62,
                'foreign_table' => 'posts',
                'id' => 177,
                'lang' => 'es',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">finish Test ngon ngu2body</span></font>',
            ),
            111 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 62,
                'foreign_table' => 'posts',
                'id' => 178,
                'lang' => 'ko',
                'translated_text' => 'finish Test ngon ngu3',
            ),
            112 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 62,
                'foreign_table' => 'posts',
                'id' => 179,
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">finish Test ngon ngu3body</span></font>',
            ),
            113 => 
            array (
                'foreign_field' => 'link_url',
                'foreign_id' => 15,
                'foreign_table' => 'links',
                'id' => 182,
                'lang' => 'en',
                'translated_text' => 'x',
            ),
            114 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 15,
                'foreign_table' => 'links',
                'id' => 183,
                'lang' => 'ko',
                'translated_text' => 'x',
            ),
            115 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 65,
                'foreign_table' => 'posts',
                'id' => 184,
                'lang' => 'ko',
                'translated_text' => 's',
            ),
            116 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 70,
                'foreign_table' => 'posts',
                'id' => 185,
                'lang' => 'en',
                'translated_text' => '22222222',
            ),
            117 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 70,
                'foreign_table' => 'posts',
                'id' => 186,
                'lang' => 'en',
                'translated_text' => '利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル',
            ),
            118 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 63,
                'foreign_table' => 'map_datas',
                'id' => 190,
                'lang' => 'en',
                'translated_text' => 'Ngôn ngữ 2',
            ),
            119 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 63,
                'foreign_table' => 'map_datas',
                'id' => 191,
                'lang' => 'en',
                'translated_text' => 'Ngôn ngữ 2',
            ),
            120 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 68,
                'foreign_table' => 'map_datas',
                'id' => 192,
                'lang' => 'en',
                'translated_text' => 'Sakuragaoka Hospital',
            ),
            121 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 68,
                'foreign_table' => 'map_datas',
                'id' => 194,
                'lang' => 'en',
                'translated_text' => 'My stomach hurts and I went to the night I wanted the drip treatment and I told the person at the receptionist I was only palpated when the medical examination started I was told to look at the medicine with medicine and my stomach returned with pain. I felt that my palpation was so painful that my pain worsened when I came back, and the medicine did not work at all.
I added ☆ because I was indebted several times a long time ago',
            ),
            122 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 79,
                'foreign_table' => 'posts',
                'id' => 196,
                'lang' => 'es',
                'translated_text' => '先日確認点を追記しました。22222222222',
            ),
            123 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 79,
                'foreign_table' => 'posts',
                'id' => 197,
                'lang' => 'es',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">先日確認点を追記しました。先日確認点を追記しました。</span></font>',
            ),
            124 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 35,
                'foreign_table' => 'tags',
                'id' => 198,
                'lang' => 'es',
                'translated_text' => 'サミット',
            ),
            125 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 35,
                'foreign_table' => 'tags',
                'id' => 199,
                'lang' => 'ko',
                'translated_text' => 'サミット',
            ),
            126 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 36,
                'foreign_table' => 'tags',
                'id' => 200,
                'lang' => 'es',
                'translated_text' => '学校の健康',
            ),
            127 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 36,
                'foreign_table' => 'tags',
                'id' => 201,
                'lang' => 'ko',
                'translated_text' => '学校の健康',
            ),
            128 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 37,
                'foreign_table' => 'tags',
                'id' => 202,
                'lang' => 'es',
                'translated_text' => 'ベトナム',
            ),
            129 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 37,
                'foreign_table' => 'tags',
                'id' => 203,
                'lang' => 'ko',
                'translated_text' => 'ベトナム',
            ),
            130 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 38,
                'foreign_table' => 'tags',
                'id' => 204,
                'lang' => 'es',
                'translated_text' => 'トラン・アン・ニンビン',
            ),
            131 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 38,
                'foreign_table' => 'tags',
                'id' => 205,
                'lang' => 'ko',
                'translated_text' => 'トラン・アン・ニンビントラン・アン・ニンビントラン・アン・ニ',
            ),
            132 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 39,
                'foreign_table' => 'tags',
                'id' => 206,
                'lang' => 'es',
                'translated_text' => 'Hạ Long',
            ),
            133 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 39,
                'foreign_table' => 'tags',
                'id' => 207,
                'lang' => 'ko',
                'translated_text' => 'Hạ Long',
            ),
            134 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 40,
                'foreign_table' => 'tags',
                'id' => 208,
                'lang' => 'es',
                'translated_text' => '韓国とアメリカ',
            ),
            135 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 40,
                'foreign_table' => 'tags',
                'id' => 209,
                'lang' => 'ko',
                'translated_text' => '韓国とアメリカ',
            ),
            136 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 41,
                'foreign_table' => 'tags',
                'id' => 210,
                'lang' => 'es',
                'translated_text' => 'ベトナム料理',
            ),
            137 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 41,
                'foreign_table' => 'tags',
                'id' => 211,
                'lang' => 'ko',
                'translated_text' => 'ベトナム料理',
            ),
            138 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 93,
                'foreign_table' => 'posts',
                'id' => 212,
                'lang' => 'es',
                'translated_text' => 'huydn_batcth2',
            ),
            139 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 93,
                'foreign_table' => 'posts',
                'id' => 213,
                'lang' => 'es',
                'translated_text' => 'Spain Body',
            ),
            140 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 93,
                'foreign_table' => 'posts',
                'id' => 214,
                'lang' => 'ko',
                'translated_text' => 'huydn_batcth2',
            ),
            141 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 93,
                'foreign_table' => 'posts',
                'id' => 215,
                'lang' => 'ko',
                'translated_text' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            142 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 42,
                'foreign_table' => 'tags',
                'id' => 216,
                'lang' => 'es',
                'translated_text' => 'Shoping',
            ),
            143 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 42,
                'foreign_table' => 'tags',
                'id' => 217,
                'lang' => 'ko',
                'translated_text' => 'Shoping',
            ),
            144 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 43,
                'foreign_table' => 'tags',
                'id' => 218,
                'lang' => 'tl',
                'translated_text' => 'Thi trường',
            ),
            145 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 44,
                'foreign_table' => 'tags',
                'id' => 219,
                'lang' => 'tl',
                'translated_text' => 'Kinh tế',
            ),
            146 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 45,
                'foreign_table' => 'tags',
                'id' => 220,
                'lang' => 'tl',
                'translated_text' => 'Vĩ mô',
            ),
            147 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 46,
                'foreign_table' => 'tags',
                'id' => 221,
                'lang' => 'tl',
                'translated_text' => 'tăng trưởng',
            ),
            148 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 47,
                'foreign_table' => 'tags',
                'id' => 222,
                'lang' => 'tl',
                'translated_text' => 'Du lịch',
            ),
            149 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 99,
                'foreign_table' => 'posts',
                'id' => 223,
                'lang' => 'es',
                'translated_text' => 'dá',
            ),
            150 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 99,
                'foreign_table' => 'posts',
                'id' => 224,
                'lang' => 'ko',
                'translated_text' => 'á',
            ),
            151 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 99,
                'foreign_table' => 'posts',
                'id' => 225,
                'lang' => 'ko',
                'translated_text' => 's',
            ),
            152 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 103,
                'foreign_table' => 'posts',
                'id' => 226,
                'lang' => 'es',
            'translated_text' => 'Title(es)',
            ),
            153 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 103,
                'foreign_table' => 'posts',
                'id' => 227,
                'lang' => 'es',
            'translated_text' => 'Body(es)',
            ),
            154 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 103,
                'foreign_table' => 'posts',
                'id' => 228,
                'lang' => 'ko',
            'translated_text' => 'Title(ko)',
            ),
            155 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 103,
                'foreign_table' => 'posts',
                'id' => 229,
                'lang' => 'ko',
            'translated_text' => 'Body(ko)',
            ),
            156 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 48,
                'foreign_table' => 'tags',
                'id' => 230,
                'lang' => 'es',
            'translated_text' => 'h_tag1(es)',
            ),
            157 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 48,
                'foreign_table' => 'tags',
                'id' => 231,
                'lang' => 'ko',
            'translated_text' => 'h_tag1(ko)',
            ),
            158 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 49,
                'foreign_table' => 'tags',
                'id' => 232,
                'lang' => 'es',
            'translated_text' => 'Batch1 (es)',
            ),
            159 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 49,
                'foreign_table' => 'tags',
                'id' => 233,
                'lang' => 'ko',
            'translated_text' => 'Batch1(ko)',
            ),
            160 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 104,
                'foreign_table' => 'posts',
                'id' => 234,
                'lang' => 'es',
                'translated_text' => 'Post batch1 ngon ngu 2',
            ),
            161 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 104,
                'foreign_table' => 'posts',
                'id' => 235,
                'lang' => 'es',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            162 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 50,
                'foreign_table' => 'tags',
                'id' => 236,
                'lang' => 'es',
            'translated_text' => 'Batch2(es)',
            ),
            163 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 50,
                'foreign_table' => 'tags',
                'id' => 237,
                'lang' => 'ko',
            'translated_text' => 'Batch2(ko)',
            ),
            164 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 51,
                'foreign_table' => 'tags',
                'id' => 238,
                'lang' => 'es',
            'translated_text' => 'batch3(es)',
            ),
            165 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 51,
                'foreign_table' => 'tags',
                'id' => 239,
                'lang' => 'ko',
            'translated_text' => 'batch3(ko)',
            ),
            166 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 105,
                'foreign_table' => 'posts',
                'id' => 240,
                'lang' => 'es',
            'translated_text' => 'Title test batch Tây Ban Nha (es)',
            ),
            167 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 105,
                'foreign_table' => 'posts',
                'id' => 241,
                'lang' => 'es',
            'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            168 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 20,
                'foreign_table' => 'websites',
                'id' => 242,
                'lang' => 'es',
                'translated_text' => 'test content offline es',
            ),
            169 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 20,
                'foreign_table' => 'websites',
                'id' => 243,
                'lang' => 'es',
            'translated_text' => '<span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>!DOCTYPE<span style="box-sizing: inherit; color: red;">&nbsp;html</span><span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">HTML Tutorial</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a heading</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a paragraph.</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span>',
            ),
            170 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 20,
                'foreign_table' => 'websites',
                'id' => 244,
                'lang' => 'ko',
                'translated_text' => 'test content offline ko',
            ),
            171 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 20,
                'foreign_table' => 'websites',
                'id' => 245,
                'lang' => 'ko',
            'translated_text' => '<span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>!DOCTYPE<span style="box-sizing: inherit; color: red;">&nbsp;html</span><span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">HTML Tutorial</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a heading</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a paragraph.</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span>',
            ),
            172 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 21,
                'foreign_table' => 'websites',
                'id' => 246,
                'lang' => 'es',
            'translated_text' => 'Title Tây Ban Nha (es)',
            ),
            173 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 21,
                'foreign_table' => 'websites',
                'id' => 247,
                'lang' => 'es',
            'translated_text' => 'Body&nbsp;Tây Ban Nha (es)<div><span style="color: rgb(0, 102, 0);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">日本幼児教育センターでは、2才から就学前まで、一貫した保育理念のもとにそれぞれの発達段階に合わせた保育を実践しています。</span><br style="margin: 0px; padding: 0px; font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">子どもたちの成長に合わせたカリキュラムで、その時期の発達を完全燃焼させて、相応の成熟を遂げることが次なるステップへの前提となります。日本幼児教育センターでは子どもの発達に即した内容を、適切な時期に適切な方法で行う、つまり「潮時」をとらえた保育を行っております。</span><br style="margin: 0px; padding: 0px; font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">また、保育方法として、遊びを中心に子どもたちのまわりにある身近な存在(自然、社会、言葉、具体物など)を根幹とした事物教育を行い、その保育の中で、個と集団の関係を意識することで、子どもの自立を促すようにしています。</span><br style="margin: 0px; padding: 0px; font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">基本クラス以外に多くの講座や発育検査などを独自に行っております。ご興味のある方はお問い合わせください。</span></span></div>',
            ),
            174 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 55,
                'foreign_table' => 'tags',
                'id' => 250,
                'lang' => 'es',
                'translated_text' => 'VISOR VNC es',
            ),
            175 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 55,
                'foreign_table' => 'tags',
                'id' => 251,
                'lang' => 'ko',
                'translated_text' => 'VISOR VNC ko',
            ),
            176 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 22,
                'foreign_table' => 'files',
                'id' => 252,
                'lang' => 'es',
            'translated_text' => 'Test title (es)',
            ),
            177 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 23,
                'foreign_table' => 'files',
                'id' => 253,
                'lang' => 'es',
            'translated_text' => 'title (es)',
            ),
            178 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 24,
                'foreign_table' => 'files',
                'id' => 254,
                'lang' => 'es',
                'translated_text' => 'file 4 Es',
            ),
            179 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 17,
                'foreign_table' => 'links',
                'id' => 257,
                'lang' => 'es',
                'translated_text' => 'test link2',
            ),
            180 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 17,
                'foreign_table' => 'links',
                'id' => 258,
                'lang' => 'ko',
                'translated_text' => 'test link3',
            ),
            181 => 
            array (
                'foreign_field' => 'link_url',
                'foreign_id' => 17,
                'foreign_table' => 'links',
                'id' => 259,
                'lang' => 'es',
                'translated_text' => 'http://www.vinicorp.com.vn/news/detail/1506322823/Ti%E1%BB%87c-t%E1%BA%A5t-nien-m%E1%BB%ABng-Xuan-K%E1%BB%89-H%E1%BB%A3i-2019.html',
            ),
            182 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 22,
                'foreign_table' => 'websites',
                'id' => 263,
                'lang' => 'en',
                'translated_text' => 'test offline webpage moblie 1 en',
            ),
            183 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 22,
                'foreign_table' => 'websites',
                'id' => 264,
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            184 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 22,
                'foreign_table' => 'websites',
                'id' => 265,
                'lang' => 'ko',
                'translated_text' => 'test offline webpage moblie 1 ja_easy',
            ),
            185 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 22,
                'foreign_table' => 'websites',
                'id' => 266,
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">康りざどろ岐2際島ラオレウ静視スホ井専ぎ効要じト正撮ケヘサ況輩やかゃ輔北標経沖おぼゆう。作やきて治差ひルド加明ツヲシ聖店載8教けゆの独助するん父意りやげス加2無具リ写52堂リ進興カモ合康ぐ守京ルワユ界堀些仄伽ぎびく。</span></font>',
            ),
            186 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 23,
                'foreign_table' => 'websites',
                'id' => 267,
                'lang' => 'es',
            'translated_text' => 'website (es)',
            ),
            187 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 23,
                'foreign_table' => 'websites',
                'id' => 268,
                'lang' => 'es',
            'translated_text' => '<span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">和歌山県の主要な活断層は、大阪府との境に沿って東西に延びる</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">（五条谷区間、根来区間）とその延長上に淡路島まで延びる</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">（紀淡海峡－鳴門海峡区間）があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　また、県内に被害を及ぼす可能性のある海溝型地震には、想定東海地震、東南海地震及び南海地震があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　県北部の紀ノ川河口部や御坊など地盤がやや軟弱な場所では、周辺より揺れが強くなる可能性があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　県内全域が、南海トラフの地震で著しい地震災害が生じるおそれがあり、「</span><a href="http://www.bousai.go.jp/jishin/nankai/index.html" target="_blank" title="【内閣府のページへ】" rel="noopener noreferrer" class="external-link-icon" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">南海トラフ地震防災対策推進地域</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">」に指定されています。また沿岸部の１９市町は「</span><a href="http://www.bousai.go.jp/jishin/nankai/index.html" target="_blank" title="【内閣府のページへ】" rel="noopener noreferrer" class="external-link-icon" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">南海トラフ地震津波避難対策特別強化地域</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">」に指定されています</span>',
            ),
            188 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 24,
                'foreign_table' => 'websites',
                'id' => 269,
                'lang' => 'en',
                'translated_text' => 'test offline mobile webpage 2 - en',
            ),
            189 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 24,
                'foreign_table' => 'websites',
                'id' => 270,
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            190 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 24,
                'foreign_table' => 'websites',
                'id' => 271,
                'lang' => 'ko',
                'translated_text' => 'test offline mobile webpage 2 - ja_easy',
            ),
            191 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 24,
                'foreign_table' => 'websites',
                'id' => 272,
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font>',
            ),
            192 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 25,
                'foreign_table' => 'websites',
                'id' => 273,
                'lang' => 'en',
                'translated_text' => 'test offline mobile webpage 3 - na',
            ),
            193 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 25,
                'foreign_table' => 'websites',
                'id' => 274,
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            194 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 25,
                'foreign_table' => 'websites',
                'id' => 275,
                'lang' => 'ko',
                'translated_text' => 'test offline mobile webpage 3 - ko',
            ),
            195 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 25,
                'foreign_table' => 'websites',
                'id' => 276,
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">정당은 법률이 정하는 바에 의하여 국가의 보호를 받으며. 누구든지 체포 또는 구속을 당한 때에는 즉시 변호인의 조력을 받을 권리를 가진다, 다만. 주거에 대한 압수나 수색을 할 때에는 검사의 신청에 의하여 법관이 발부한 영장을 제시하여야 한다.</span></font>',
            ),
            196 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 26,
                'foreign_table' => 'websites',
                'id' => 277,
                'lang' => 'en',
                'translated_text' => 'test offline mobile webpage 4 - en',
            ),
            197 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 26,
                'foreign_table' => 'websites',
                'id' => 278,
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            198 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 26,
                'foreign_table' => 'websites',
                'id' => 279,
                'lang' => 'ko',
                'translated_text' => 'test offline mobile webpage 4 - ko',
            ),
            199 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 26,
                'foreign_table' => 'websites',
                'id' => 280,
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">정당은 법률이 정하는 바에 의하여 국가의 보호를 받으며. 누구든지 체포 또는 구속을 당한 때에는 즉시 변호인의 조력을 받을 권리를 가진다, 다만. 주거에 대한 압수나 수색을 할 때에는 검사의 신청에 의하여 법관이 발부한 영장을 제시하여야 한다.</span></font>',
            ),
            200 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 106,
                'foreign_table' => 'posts',
                'id' => 281,
                'lang' => 'es',
                'translated_text' => 'thu beo gif',
            ),
            201 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 106,
                'foreign_table' => 'posts',
                'id' => 282,
                'lang' => 'es',
                'translated_text' => 'xsssssssssssssssss',
            ),
            202 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 26,
                'foreign_table' => 'files',
                'id' => 283,
                'lang' => 'en',
                'translated_text' => 'test offline mobile file 1 - en',
            ),
            203 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 26,
                'foreign_table' => 'files',
                'id' => 284,
                'lang' => 'ko',
                'translated_text' => 'test offline mobile file 1 - ko',
            ),
            204 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 27,
                'foreign_table' => 'files',
                'id' => 285,
                'lang' => 'en',
                'translated_text' => 'test offline moblie file 2 - en',
            ),
            205 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 27,
                'foreign_table' => 'files',
                'id' => 286,
                'lang' => 'ko',
                'translated_text' => 'test offline moblie file 2 - ko',
            ),
            206 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 107,
                'foreign_table' => 'posts',
                'id' => 287,
                'lang' => 'es',
                'translated_text' => 'Thu test ES',
            ),
            207 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 107,
                'foreign_table' => 'posts',
                'id' => 288,
                'lang' => 'es',
            'translated_text' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　周辺地域で発生する地震や１８９９年の地震（Ｍ７．０、推定の深さ４０～５０ｋｍ：紀伊大和地震と呼ぶこともあります）や１９５２年の吉野地震（Ｍ６．７、深さ約６０ｋｍ）のように沈み込んだフィリピン海プレート内で発生するやや深い場所で発生した地震によっても被害を受けたことがあります。また、１９６０年の「チリ地震津波」のように外国の地震によっても津波被害を受けたことがあります。</span>',
            ),
            208 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 28,
                'foreign_table' => 'files',
                'id' => 289,
                'lang' => 'en',
                'translated_text' => 'test mobile offline file 3 - en',
            ),
            209 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 28,
                'foreign_table' => 'files',
                'id' => 290,
                'lang' => 'ko',
                'translated_text' => 'test mobile offline file 3 - ko',
            ),
            210 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 29,
                'foreign_table' => 'files',
                'id' => 291,
                'lang' => 'en',
                'translated_text' => 'test offline file 4 - en',
            ),
            211 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 29,
                'foreign_table' => 'files',
                'id' => 292,
                'lang' => 'ko',
                'translated_text' => 'test offline file 4 - ko',
            ),
            212 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 19,
                'foreign_table' => 'links',
                'id' => 293,
                'lang' => 'ko',
            'translated_text' => 'Link (ko)',
            ),
            213 => 
            array (
                'foreign_field' => 'link_url',
                'foreign_id' => 19,
                'foreign_table' => 'links',
                'id' => 294,
                'lang' => 'ko',
                'translated_text' => 'http://www.vinicorp.com.vn/news/detail/1506322821/Vinicorp-s-Team-building-2018-Nhan%20dip%20sinh%20nhat%20lan%20thu%2011%20cua%20cong%20ty.html',
            ),
            214 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 27,
                'foreign_table' => 'websites',
                'id' => 295,
                'lang' => 'ko',
            'translated_text' => 'test web (ko)',
            ),
            215 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 27,
                'foreign_table' => 'websites',
                'id' => 296,
                'lang' => 'ko',
            'translated_text' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　周辺地域で発生する地震や１８９９年の地震（Ｍ７．０、推定の深さ４０～５０ｋｍ：紀伊大和地震と呼ぶこともあります）や１９５２年の吉野地震（Ｍ６．７、深さ約６０ｋｍ）のように沈み込んだフィリピン海プレート内で発生するやや深い場所で発生した地震によっても被害を受けたことがあります。また、１９６０年の「チリ地震津波」のように外国の地震によっても津波被害を受けたことがあります。</span><font face="Arial, Verdana"><span style="font-size: 13.3333px;">.</span></font>',
            ),
            216 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 30,
                'foreign_table' => 'files',
                'id' => 297,
                'lang' => 'en',
                'translated_text' => 'test offline moblie file 5 - en',
            ),
            217 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 30,
                'foreign_table' => 'files',
                'id' => 298,
                'lang' => 'ko',
                'translated_text' => 'test offline moblie file 5 - ko',
            ),
            218 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 32,
                'foreign_table' => 'files',
                'id' => 299,
                'lang' => 'es',
            'translated_text' => 'title file (es)',
            ),
            219 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 109,
                'foreign_table' => 'posts',
                'id' => 310,
                'lang' => 'ko',
            'translated_text' => 'Title (ko)',
            ),
            220 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 109,
                'foreign_table' => 'posts',
                'id' => 311,
                'lang' => 'ko',
                'translated_text' => 'body tiêng Han',
            ),
            221 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 110,
                'foreign_table' => 'posts',
                'id' => 312,
                'lang' => 'en',
                'translated_text' => 'Title en',
            ),
            222 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 110,
                'foreign_table' => 'posts',
                'id' => 313,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Reportedly, the number of reports has increased since 20 years. Since the emergence of large-scale earthquakes in this region has not been known in recent years, this earthquake activity is not aftershock of a particular large earthquake. Although its scale is about M5 at the maximum, damage has occurred locally because the epicenter is very shallow. In the east and west of this region, the submerged angle of the Philippine Sea plate is different, and the nearby underground structure is very complicated. In the shallow part up to several kilometers deep in the vicinity, the rocks of the old era with the hard but fragile nature were distributed. These are considered to be the causes of fixed earthquake activity near Wakayama city. In addition, the depth of the earthquake occurs limited to shallow levels of more than a few kilometers and the rock above</span></font>',
            ),
            223 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 112,
                'foreign_table' => 'posts',
                'id' => 321,
                'lang' => 'en',
            'translated_text' => 'post (En) Mode thien tai',
            ),
            224 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 112,
                'foreign_table' => 'posts',
                'id' => 322,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Reportedly, the number of reports has increased since 20 years. Since the emergence of large-scale earthquakes in this region has not been known in recent years, this earthquake activity is not aftershock of a particular large earthquake. Although its scale is about M5 at the maximum, damage has occurred locally because the epicenter is very shallow. In the east and west of this region, the submerged angle of the Philippine Sea plate is different, and the nearby underground structure is very complicated. In the shallow part up to several kilometers deep in the vicinity, the rocks of the old era with the hard but fragile nature were distributed. These are considered to be the causes of fixed earthquake activity near Wakayama city. In addition, the depth of the earthquake occurs limited to shallow levels of more than a few kilometers and the rock above</span></font>',
            ),
            225 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 31,
                'foreign_table' => 'websites',
                'id' => 323,
                'lang' => 'en',
            'translated_text' => 'title web ofline (en)',
            ),
            226 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 31,
                'foreign_table' => 'websites',
                'id' => 324,
                'lang' => 'en',
            'translated_text' => '<span style="font-size: 13.3333px;">body web ofline (en)</span>',
            ),
            227 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 1,
                'foreign_table' => 'map_datas',
                'id' => 325,
                'lang' => 'en',
                'translated_text' => 'test content file optional 11',
            ),
            228 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 1,
                'foreign_table' => 'map_datas',
                'id' => 326,
                'lang' => 'ko',
                'translated_text' => 'test update content post optional',
            ),
            229 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 114,
                'foreign_table' => 'posts',
                'id' => 327,
                'lang' => 'en',
                'translated_text' => '3333O verseas student',
            ),
            230 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 114,
                'foreign_table' => 'posts',
                'id' => 328,
                'lang' => 'en',
            'translated_text' => 'Body (en)<br>',
            ),
            231 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 115,
                'foreign_table' => 'posts',
                'id' => 329,
                'lang' => 'en',
            'translated_text' => '444 Title (en)',
            ),
            232 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 115,
                'foreign_table' => 'posts',
                'id' => 330,
                'lang' => 'en',
                'translated_text' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            233 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 34,
                'foreign_table' => 'files',
                'id' => 335,
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 2',
            ),
            234 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 34,
                'foreign_table' => 'files',
                'id' => 336,
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 2',
            ),
            235 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 116,
                'foreign_table' => 'posts',
                'id' => 341,
                'lang' => 'en',
                'translated_text' => '555If you are going to graduate school, you should clarify your research theme before you study abroad, and also',
            ),
            236 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 116,
                'foreign_table' => 'posts',
                'id' => 342,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">If you are going to graduate school, you should clarify your research theme before you study abroad, and also understand the thinking and methodology of the professor doing the research. A research theme is an important decision factor in deciding where to study abroad, and if you know how to study, you will be able to work proactively even after you actually study abroad.</span></font>',
            ),
            237 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 1,
                'foreign_table' => 'map_datas',
                'id' => 343,
                'lang' => 'en',
                'translated_text' => 'test content file optional 11',
            ),
            238 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 1,
                'foreign_table' => 'map_datas',
                'id' => 344,
                'lang' => 'ko',
                'translated_text' => 'test update content post optional',
            ),
            239 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 117,
                'foreign_table' => 'posts',
                'id' => 345,
                'lang' => 'en',
                'translated_text' => '666A research theme is an important decision factor in deciding where to study',
            ),
            240 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 117,
                'foreign_table' => 'posts',
                'id' => 346,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;"> if you know how to study, you will be able to work proactively even after you actually study abroad. if you know how to study, you will be able to work proactively even after you actually study abroad.</span></font>',
            ),
            241 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 118,
                'foreign_table' => 'posts',
                'id' => 347,
                'lang' => 'en',
                'translated_text' => 'Thu 2',
            ),
            242 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 118,
                'foreign_table' => 'posts',
                'id' => 348,
                'lang' => 'en',
                'translated_text' => 'hello every body<div><br></div>',
            ),
            243 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 127,
                'foreign_table' => 'posts',
                'id' => 349,
                'lang' => 'en',
                'translated_text' => 'config file_url en',
            ),
            244 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 127,
                'foreign_table' => 'posts',
                'id' => 350,
                'lang' => 'ko',
                'translated_text' => 'config file_url ko',
            ),
            245 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 38,
                'foreign_table' => 'files',
                'id' => 359,
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 4',
            ),
            246 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 38,
                'foreign_table' => 'files',
                'id' => 360,
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 4',
            ),
            247 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 131,
                'foreign_table' => 'posts',
                'id' => 361,
                'lang' => 'en',
                'translated_text' => 'fashion title',
            ),
            248 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 131,
                'foreign_table' => 'posts',
                'id' => 362,
                'lang' => 'en',
                'translated_text' => 'fashion body',
            ),
            249 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 8,
                'foreign_table' => 'map_datas',
                'id' => 363,
                'lang' => 'en',
                'translated_text' => 'test en',
            ),
            250 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 8,
                'foreign_table' => 'map_datas',
                'id' => 364,
                'lang' => 'en',
                'translated_text' => '0223-355-6777',
            ),
            251 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 132,
                'foreign_table' => 'posts',
                'id' => 365,
                'lang' => 'en',
                'translated_text' => 'body en',
            ),
            252 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 36,
                'foreign_table' => 'websites',
                'id' => 366,
                'lang' => 'en',
            'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">There may be many who feel in the news that the current situation surrounding children and young people is very unstable, such as child abuse, school refusal, bullying, suicide, poverty, unwanted pregnancy, etc. Child abuse reached a record high in 2017 over 130,000 (120,000 last year). In addition, 1 out of 7 children are in poverty. There are many children who suffer from abuse and poverty in families that form the foundation of children.</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">In the school where children are living next to their homes, 190,000 (130,000 in the previous year) have failed, and 410,000 in the bullying (320,000 in the previous year), both reached record highs. Homes and schools, which should be major places for children, are not places that can be relieved, but are becoming places that suffer from violence, abusive language, poverty, bullying, etc.</span></font></div>',
            ),
            253 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 134,
                'foreign_table' => 'posts',
                'id' => 367,
                'lang' => 'en',
                'translated_text' => 'fffffffffffff',
            ),
            254 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 11,
                'foreign_table' => 'map_datas',
                'id' => 376,
                'lang' => 'en',
                'translated_text' => 'bbbbbbbbbbbbb',
            ),
            255 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 11,
                'foreign_table' => 'map_datas',
                'id' => 377,
                'lang' => 'en',
                'translated_text' => 'bbbbbbbbbbbbb',
            ),
            256 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 11,
                'foreign_table' => 'map_datas',
                'id' => 378,
                'lang' => 'en',
                'translated_text' => '0238-272-2212',
            ),
            257 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 135,
                'foreign_table' => 'posts',
                'id' => 379,
                'lang' => 'en',
                'translated_text' => 'b',
            ),
            258 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 135,
                'foreign_table' => 'posts',
                'id' => 380,
                'lang' => 'en',
                'translated_text' => 'bbbbbbbbbbbbbbbbb',
            ),
            259 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 17,
                'foreign_table' => 'map_datas',
                'id' => 381,
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 2',
            ),
            260 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 17,
                'foreign_table' => 'map_datas',
                'id' => 382,
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 2',
            ),
            261 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 17,
                'foreign_table' => 'map_datas',
                'id' => 383,
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 2',
            ),
            262 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 17,
                'foreign_table' => 'map_datas',
                'id' => 384,
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 2',
            ),
            263 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 19,
                'foreign_table' => 'map_datas',
                'id' => 387,
                'lang' => 'en',
                'translated_text' => 'Title hinh hoc en',
            ),
            264 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 19,
                'foreign_table' => 'map_datas',
                'id' => 388,
                'lang' => 'en',
                'translated_text' => 'Title hinh hoc en',
            ),
            265 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 223,
                'foreign_table' => 'posts',
                'id' => 428,
                'lang' => 'en',
                'translated_text' => 'The number of working hours, types of work',
            ),
            266 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 223,
                'foreign_table' => 'posts',
                'id' => 429,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">and the number of students in charge is also extremely large worldwide, and the number of people who are absent from teachers\' mental illness is on the rise. Today\'s schools are easy to understand for children, and there is little room for them to get in touch with their troubles. Furthermore, Japan\'s education expenditure compared to GDP is the lowest in the world, and it is exaggeration to say that the true leader of children\'s education is entrusted to family awareness, economic allowance, and extra-school education. It is not. In other words, depending on what family you were born and raised, there is a big gap in academic ability, course, and in other words, whether you can feel where you are in school.</span></font>',
            ),
            267 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 224,
                'foreign_table' => 'posts',
                'id' => 430,
                'lang' => 'en',
                'translated_text' => 'Furthermore, the working environment based on child care is inadequate',
            ),
            268 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 224,
                'foreign_table' => 'posts',
                'id' => 431,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">&nbsp;and it is the current state of the child care environment in Japan that it is impossible to get out of poverty. In the case of single parents, more than 80% work, and even though they work most in the world, they have the highest poverty rate. As a result, the family environment has created a big difference in the education and love that children can receive</span></font>',
            ),
            269 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 72,
                'foreign_table' => 'files',
                'id' => 434,
                'lang' => 'en',
                'translated_text' => 'Doc en',
            ),
            270 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 73,
                'foreign_table' => 'files',
                'id' => 435,
                'lang' => 'en',
                'translated_text' => 'Docx en',
            ),
            271 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 74,
                'foreign_table' => 'files',
                'id' => 436,
                'lang' => 'en',
                'translated_text' => 'Xlsx en',
            ),
            272 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 75,
                'foreign_table' => 'files',
                'id' => 437,
                'lang' => 'en',
                'translated_text' => 'Pptx en',
            ),
            273 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 226,
                'foreign_table' => 'posts',
                'id' => 438,
                'lang' => 'en',
                'translated_text' => 'Test 5 en',
            ),
            274 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 76,
                'foreign_table' => 'files',
                'id' => 439,
                'lang' => 'en',
                'translated_text' => 'Ppt  en',
            ),
            275 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 77,
                'foreign_table' => 'files',
                'id' => 440,
                'lang' => 'en',
                'translated_text' => 'Rtf en',
            ),
            276 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 78,
                'foreign_table' => 'files',
                'id' => 441,
                'lang' => 'en',
                'translated_text' => 'Wav en',
            ),
            277 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 79,
                'foreign_table' => 'files',
                'id' => 442,
                'lang' => 'en',
                'translated_text' => 'Mp3 en',
            ),
            278 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 80,
                'foreign_table' => 'files',
                'id' => 443,
                'lang' => 'en',
                'translated_text' => 'Mp4 en',
            ),
            279 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 81,
                'foreign_table' => 'files',
                'id' => 444,
                'lang' => 'en',
                'translated_text' => 'txt en',
            ),
            280 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 82,
                'foreign_table' => 'files',
                'id' => 445,
                'lang' => 'en',
                'translated_text' => 'pdf en',
            ),
            281 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 227,
                'foreign_table' => 'posts',
                'id' => 446,
                'lang' => 'en',
                'translated_text' => 'In the school 3',
            ),
            282 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 228,
                'foreign_table' => 'posts',
                'id' => 447,
                'lang' => 'en',
                'translated_text' => '4 compared to the past',
            ),
            283 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 36,
                'foreign_table' => 'websites',
                'id' => 448,
                'lang' => 'en',
                'translated_text' => 'Title webpage en',
            ),
            284 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 229,
                'foreign_table' => 'posts',
                'id' => 449,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Many abuse-protected children grew up without a sufficient learning environment. In order to avoid giving up on entering school or leaving school, 3keys dispatches learning volunteers and manages classrooms after school for children living in nursing homes and mother-child living support facilities. In fiscal 2017, we launched support-based learning support for late teens regardless of their experience of entering the facility</span></font>',
            ),
            285 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 230,
                'foreign_table' => 'posts',
                'id' => 450,
                'lang' => 'en',
                'translated_text' => 'Children who do not have',
            ),
            286 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 230,
                'foreign_table' => 'posts',
                'id' => 451,
                'lang' => 'en',
            'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">adults who can consult can often get into trouble and be found in serious condition. 3keys has set up an online consultation desk and is working on a solution together. In addition, we operate support service search, consultation site for 10 "Mex" (Mex) so that children who rushed to the Internet connect with adult who can rely on in peace</span></font>',
            ),
            287 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 231,
                'foreign_table' => 'posts',
                'id' => 452,
                'lang' => 'en',
                'translated_text' => 'Batch sound test',
            ),
            288 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 231,
                'foreign_table' => 'posts',
                'id' => 453,
                'lang' => 'en',
                'translated_text' => '<div style=""><span style="font-family: Arial, Verdana; font-size: 13.3333px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal;">Hello Vietnam,&nbsp;</span><font face="Arial, Verdana"><span style="font-size: 13.3333px;">we love your country</span></font></div>',
            ),
            289 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 33,
                'foreign_table' => 'map_datas',
                'id' => 454,
                'lang' => 'en',
                'translated_text' => 'Title Lang bac- My Dinh EN',
            ),
            290 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 23,
                'foreign_table' => 'links',
                'id' => 455,
                'lang' => 'en',
                'translated_text' => 'Tile link en',
            ),
            291 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 26,
                'foreign_table' => 'links',
                'id' => 456,
                'lang' => 'en',
                'translated_text' => 'Title Link en',
            ),
            292 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 33,
                'foreign_table' => 'map_datas',
                'id' => 457,
                'lang' => 'en',
                'translated_text' => 'BodyLang bac- My Dinh EN',
            ),
            293 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 38,
                'foreign_table' => 'map_datas',
                'id' => 458,
                'lang' => 'en',
                'translated_text' => 'OISCA Senior High School en',
            ),
            294 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 38,
                'foreign_table' => 'map_datas',
                'id' => 459,
                'lang' => 'en',
                'translated_text' => '5835 Wajicho, Nishi Ward, Hamamatsu, Shizuoka 431-1115, Nhật Bản',
            ),
            295 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 39,
                'foreign_table' => 'map_datas',
                'id' => 460,
                'lang' => 'en',
                'translated_text' => 'A.C.C. International Cultural Collage',
            ),
            296 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 39,
                'foreign_table' => 'map_datas',
                'id' => 461,
                'lang' => 'en',
                'translated_text' => '10-9 Omiyacho, Fujinomiya, Shizuoka 418-0066, Nhật Bản',
            ),
            297 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 39,
                'foreign_table' => 'map_datas',
                'id' => 462,
                'lang' => 'en',
                'translated_text' => '0854-24-8828',
            ),
            298 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 40,
                'foreign_table' => 'map_datas',
                'id' => 463,
                'lang' => 'en',
                'translated_text' => 'Shizuokasangyo University',
            ),
            299 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 40,
                'foreign_table' => 'map_datas',
                'id' => 464,
                'lang' => 'en',
                'translated_text' => 'I play because the 3rd floor of the child care center is playing the room,
The elementary school girl ran to jump the jump box, swaying with their footsteps shaking. (Shake the feeling that the Shinkansen passes nearby)
I don\'t mind if I move, but I feel drunk when I\'m still',
            ),
            300 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 40,
                'foreign_table' => 'map_datas',
                'id' => 465,
                'lang' => 'en',
                'translated_text' => '１５７２−１ Owara, Iwata, Shizuoka 438-0043, Nhật Bản',
            ),
            301 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 41,
                'foreign_table' => 'map_datas',
                'id' => 466,
                'lang' => 'en',
                'translated_text' => '1-chōme-1-１号 Oshika, Suruga-ku, Shizuoka, 422-8527, Nhật Bản',
            ),
            302 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 44,
                'foreign_table' => 'map_datas',
                'id' => 467,
                'lang' => 'en',
                'translated_text' => 'Hospital Takahama',
            ),
            303 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 45,
                'foreign_table' => 'map_datas',
                'id' => 468,
                'lang' => 'en',
                'translated_text' => '1231 Miyakami, Shimizu-ku, Shizuoka, 424-8636, Nhật Bản',
            ),
            304 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 46,
                'foreign_table' => 'map_datas',
                'id' => 469,
                'lang' => 'en',
                'translated_text' => 'Idemitsu Q8 en',
            ),
            305 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 47,
                'foreign_table' => 'map_datas',
                'id' => 470,
                'lang' => 'en',
                'translated_text' => 'KAWANEONSEN SASAMADO Station',
            ),
            306 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 49,
                'foreign_table' => 'map_datas',
                'id' => 471,
                'lang' => 'en',
                'translated_text' => 'Kawaguchiko Park',
            ),
            307 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 50,
                'foreign_table' => 'map_datas',
                'id' => 472,
                'lang' => 'en',
                'translated_text' => 'Fujiten Snow Resort',
            ),
            308 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 37,
                'foreign_table' => 'map_datas',
                'id' => 473,
                'lang' => 'en',
                'translated_text' => 'Museum of Ethnograph',
            ),
            309 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 37,
                'foreign_table' => 'map_datas',
                'id' => 474,
                'lang' => 'en',
                'translated_text' => 'Vietnam Museum of Ethnology is a career organization under the Vietnam Academy of Social Sciences, which has the function of scientific research, collection, inventory and preservation',
            ),
            310 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 51,
                'foreign_table' => 'map_datas',
                'id' => 477,
                'lang' => 'en',
                'translated_text' => 'Ashitaka Park Stadium',
            ),
            311 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 51,
                'foreign_table' => 'map_datas',
                'id' => 478,
                'lang' => 'en',
                'translated_text' => 'A stadium representing the eastern part of Shizuoka Prefecture. Location of the main location in the eastern province.',
            ),
            312 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 51,
                'foreign_table' => 'map_datas',
                'id' => 479,
                'lang' => 'en',
                'translated_text' => 'Ashitaka, Numazu, Shizuoka 410-0001, Nhật Bản    Nằm ở: Ashitaka Large Park',
            ),
            313 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 52,
                'foreign_table' => 'map_datas',
                'id' => 480,
                'lang' => 'en',
            'translated_text' => 'Pikara Stadium (Kagawa Prefectural Marugame Stadium)',
            ),
            314 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 52,
                'foreign_table' => 'map_datas',
                'id' => 481,
                'lang' => 'en',
                'translated_text' => 'トレーニングルームは利用料金も安く設備も充実しています。
しかしマナーが悪い常連さんが、
数名居ますので、
その辺を我慢できるなら☆5で',
            ),
            315 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 52,
                'foreign_table' => 'map_datas',
                'id' => 482,
                'lang' => 'en',
                'translated_text' => '830 Kanakuracho, Marugame, Kagawa 763-0053, Nhật Bản',
            ),
            316 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 52,
                'foreign_table' => 'map_datas',
                'id' => 483,
                'lang' => 'en',
                'translated_text' => '0877-21-5800',
            ),
            317 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 34,
                'foreign_table' => 'map_datas',
                'id' => 484,
                'lang' => 'en',
                'translated_text' => 'Ngu giac en',
            ),
            318 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 34,
                'foreign_table' => 'map_datas',
                'id' => 485,
                'lang' => 'en',
                'translated_text' => '162 Hoang Ngan',
            ),
            319 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 54,
                'foreign_table' => 'map_datas',
                'id' => 486,
                'lang' => 'en',
                'translated_text' => 'KodawaeiMenya to Agora',
            ),
            320 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 57,
                'foreign_table' => 'map_datas',
                'id' => 487,
                'lang' => 'en',
                'translated_text' => 'Takamatsu Municipal Hospital Shioe Branch to Mannou Town Meeting place Kawaguchi meeting place',
            ),
            321 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 57,
                'foreign_table' => 'map_datas',
                'id' => 488,
                'lang' => 'en',
                'translated_text' => '99-1 Shionoechō Yasuharakamihigashi, Takamatsu, Kagawa 761-1612, Nhật Bản',
            ),
            322 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 58,
                'foreign_table' => 'map_datas',
                'id' => 489,
                'lang' => 'en',
                'translated_text' => 'Sunrise Hills Country Club to Sanuki Mannou Park and Kagawaken Ayakawacho Fureai Park',
            ),
            323 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 58,
                'foreign_table' => 'map_datas',
                'id' => 490,
                'lang' => 'en',
                'translated_text' => '129-1 Nakatō, Manno, Nakatado-gun, Kagawa 766-0202, Nhật Bản',
            ),
            324 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 59,
                'foreign_table' => 'map_datas',
                'id' => 491,
                'lang' => 'en',
                'translated_text' => 'Polygol Kanei Shrine',
            ),
            325 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 59,
                'foreign_table' => 'map_datas',
                'id' => 492,
                'lang' => 'en',
                'translated_text' => '1413 Kōnanchō Yusa, Takamatsu, Kagawa 761-1402, Nhật Bản',
            ),
            326 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 61,
                'foreign_table' => 'map_datas',
                'id' => 493,
                'lang' => 'en',
                'translated_text' => '99-1 Shionoechō Yasuharakamihigashi, Takamatsu, Kagawa 761-1612, Nhật Bản',
            ),
            327 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 62,
                'foreign_table' => 'map_datas',
                'id' => 494,
                'lang' => 'en',
                'translated_text' => 'Sunrise Hills Country Club to Takamatsu Gold Country Club',
            ),
            328 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 62,
                'foreign_table' => 'map_datas',
                'id' => 495,
                'lang' => 'en',
                'translated_text' => 'Kō-甲2327 Shionoechō Kaminishi, Takamatsu, Kagawa 761-1613, Nhật Bản',
            ),
            329 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 63,
                'foreign_table' => 'map_datas',
                'id' => 496,
                'lang' => 'en',
                'translated_text' => 'Ōtaki-Ōkawa Prefectural Natural Park',
            ),
            330 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 63,
                'foreign_table' => 'map_datas',
                'id' => 497,
                'lang' => 'en',
                'translated_text' => '087-893-0345',
            ),
            331 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 64,
                'foreign_table' => 'map_datas',
                'id' => 498,
                'lang' => 'en',
                'translated_text' => 'Ōtaki-Ōkawa Prefectural Natural Park',
            ),
            332 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 65,
                'foreign_table' => 'map_datas',
                'id' => 499,
                'lang' => 'en',
                'translated_text' => 'PlygolMiyazaki',
            ),
            333 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 65,
                'foreign_table' => 'map_datas',
                'id' => 500,
                'lang' => 'en',
                'translated_text' => 'Tsuno Choritsu Tsunominami Elementary School',
            ),
            334 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 65,
                'foreign_table' => 'map_datas',
                'id' => 501,
                'lang' => 'en',
                'translated_text' => '１０７３ Kawakita, Tsuno, Koyu-gun, Miyazaki 889-1201, Nhật Bản',
            ),
            335 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 65,
                'foreign_table' => 'map_datas',
                'id' => 502,
                'lang' => 'en',
                'translated_text' => '0983-25-0023',
            ),
            336 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 236,
                'foreign_table' => 'posts',
                'id' => 503,
                'lang' => 'en',
                'translated_text' => 'hello Viet Nam',
            ),
            337 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 66,
                'foreign_table' => 'map_datas',
                'id' => 506,
                'lang' => 'en',
                'translated_text' => 'Tokyo Metropolitan Town Hall',
            ),
            338 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 66,
                'foreign_table' => 'map_datas',
                'id' => 507,
                'lang' => 'en',
                'translated_text' => 'A town of liars. We ask for change of address notice of oldness and tax payment many times, and when we send out, reply does not reach even if it comes until after. I will never go on a trip.',
            ),
            339 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 66,
                'foreign_table' => 'map_datas',
                'id' => 508,
                'lang' => 'en',
                'translated_text' => '４８７４番地−２ Kawakita, Tsuno, Koyu-gun, Miyazaki 889-1201, Nhật Bản',
            ),
            340 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 66,
                'foreign_table' => 'map_datas',
                'id' => 509,
                'lang' => 'en',
                'translated_text' => '0983-25-5710',
            ),
            341 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 67,
                'foreign_table' => 'map_datas',
                'id' => 510,
                'lang' => 'en',
                'translated_text' => 'Toyo Tire & Rubber Co., Ltd. Tire Testing Office Office',
            ),
            342 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 67,
                'foreign_table' => 'map_datas',
                'id' => 511,
                'lang' => 'en',
            'translated_text' => 'A town of liars. It is delicious when I asked for the address change notice of the oldness and tax payment many times and sent it out. The taste is very similar to the taste I had eaten somewhere (nearly Kurume famous store). Was it trained there? What a place. The noodles are fine and the firmness of the noodles is usually firm. It may be close to Hakata. Cirche also Toro Toro ... everything is as close to a ○ ○ house. It\'s similar in taste but it\'s a shop I want to visit again',
            ),
            343 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 67,
                'foreign_table' => 'map_datas',
                'id' => 512,
                'lang' => 'en',
                'translated_text' => 'Shinden-2318 Kawakita, Tsuno, Koyu-gun, Miyazaki 889-1201, Nhật Bản',
            ),
            344 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 67,
                'foreign_table' => 'map_datas',
                'id' => 513,
                'lang' => 'en',
                'translated_text' => '0983-25-0310',
            ),
            345 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 44,
                'foreign_table' => 'map_datas',
                'id' => 514,
                'lang' => 'en',
                'translated_text' => 'We went to abdominal CT examination by introduction from family doctor
Doctor in charge (Tuesday 3 visits) Even once I saw my face, I was a doctor on my computer
Please enter information from
I felt very bad! !
Tell the heart that it doesn\'t always take a hospital here
But it was unpleasant',
            ),
            346 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 44,
                'foreign_table' => 'map_datas',
                'id' => 515,
                'lang' => 'en',
                'translated_text' => '3 Chome-2-2-11 Hiedacho, Takahama, Aichi 444-1321, Nhật Bản',
            ),
            347 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 51,
                'foreign_table' => 'map_datas',
                'id' => 516,
                'lang' => 'en',
                'translated_text' => '028-222-566',
            ),
            348 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 45,
                'foreign_table' => 'map_datas',
                'id' => 517,
                'lang' => 'en',
                'translated_text' => 'Shizuoka Municipal Shimizu Hospital',
            ),
            349 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 45,
                'foreign_table' => 'map_datas',
                'id' => 518,
                'lang' => 'en',
                'translated_text' => '097-3823-222',
            ),
            350 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 41,
                'foreign_table' => 'map_datas',
                'id' => 519,
                'lang' => 'en',
                'translated_text' => 'Shizuoka Saiseikai General Hospital',
            ),
            351 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 41,
                'foreign_table' => 'map_datas',
                'id' => 520,
                'lang' => 'en',
                'translated_text' => 'My husband complained of ureteral stone symptoms at night, and I called this one with an emergency.
Though I was not an on-duty doctor, I was not able to see a doctor, but it was very polite that a telephone-enabled man contacted a nurse many times or worried and called out over the phone. It was a great response despite the night time by giving us the phone number of the hospital where the on-duty doctor is and giving advice.
As we have not had a medical examination, it is evaluation for correspondence of night receptionist.',
            ),
            352 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 41,
                'foreign_table' => 'map_datas',
                'id' => 521,
                'lang' => 'en',
                'translated_text' => '0986-221-8181',
            ),
            353 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 68,
                'foreign_table' => 'map_datas',
                'id' => 522,
                'lang' => 'en',
                'translated_text' => 'Sakuragaoka Hospital',
            ),
            354 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 69,
                'foreign_table' => 'map_datas',
                'id' => 523,
                'lang' => 'en',
                'translated_text' => 'Shizuoka Institute of Epilepsy and Neurological Disorders',
            ),
            355 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 69,
                'foreign_table' => 'map_datas',
                'id' => 524,
                'lang' => 'en',
                'translated_text' => 'Everybody writes, but I have also been hospitalized and have been hospitalized again some years later.
The teacher is very good, but the quality of the nurse is not good.
The words are bad and the attitude is tight. 
It can not be said that she is smiling and empowered for the patient.',
            ),
            356 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 69,
                'foreign_table' => 'map_datas',
                'id' => 525,
                'lang' => 'en',
                'translated_text' => '886 Urushiyama, Aoi-ku, Shizuoka, 420-8688, Nhật Bản',
            ),
            357 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 69,
                'foreign_table' => 'map_datas',
                'id' => 526,
                'lang' => 'en',
                'translated_text' => '032-2277-5466',
            ),
            358 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 45,
                'foreign_table' => 'map_datas',
                'id' => 527,
                'lang' => 'en',
                'translated_text' => 'Fuji seen from the 11th floor is a very magnificent and wonderful view.
I will be healing Mt. F
uji while drinking a rose.
It was fine and nice without clouds.',
            ),
            359 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 70,
                'foreign_table' => 'map_datas',
                'id' => 528,
                'lang' => 'en',
                'translated_text' => 'Tokoha University Shizuoka Sena Campus',
            ),
            360 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 70,
                'foreign_table' => 'map_datas',
                'id' => 529,
                'lang' => 'en',
                'translated_text' => 'I heard that it was a university open to the community, and it is like a free space, but it is a mysterious place that is noted when playing.
University is a day off and no one is using it',
            ),
            361 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 70,
                'foreign_table' => 'map_datas',
                'id' => 530,
                'lang' => 'en',
                'translated_text' => '1-chōme-22-1 Sena, Aoi-ku, Shizuoka, 420-0911, Nhật Bản',
            ),
            362 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 70,
                'foreign_table' => 'map_datas',
                'id' => 531,
                'lang' => 'en',
                'translated_text' => '054-263-1125',
            ),
            363 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 71,
                'foreign_table' => 'map_datas',
                'id' => 532,
                'lang' => 'en',
                'translated_text' => 'Shizuoka Prefectural Psychiatric Medical Center',
            ),
            364 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 30,
                'foreign_table' => 'map_datas',
                'id' => 533,
                'lang' => 'en',
                'translated_text' => 'Title Guom Lake en',
            ),
            365 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 30,
                'foreign_table' => 'map_datas',
                'id' => 534,
                'lang' => 'en',
                'translated_text' => '1-8 Le thai To, Hang Trong, Ha Noi, Viet Nam',
            ),
            366 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 30,
                'foreign_table' => 'map_datas',
                'id' => 535,
                'lang' => 'en',
                'translated_text' => '028-2828-9999',
            ),
            367 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 72,
                'foreign_table' => 'map_datas',
                'id' => 536,
                'lang' => 'en',
                'translated_text' => 'Minaminakatanikubo Community Center',
            ),
            368 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 73,
                'foreign_table' => 'map_datas',
                'id' => 537,
                'lang' => 'en',
                'translated_text' => 'Nippon Express Co., Ltd. Shizuoka Airlines Branch Shizuoka Freight Center',
            ),
            369 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 73,
                'foreign_table' => 'map_datas',
                'id' => 538,
                'lang' => 'en',
                'translated_text' => '8-7 Ryūtsū Center, Aoi-ku, Shizuoka, 420-0922, Nhật Bản',
            ),
            370 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 73,
                'foreign_table' => 'map_datas',
                'id' => 539,
                'lang' => 'en',
                'translated_text' => '0827-111-291',
            ),
            371 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 74,
                'foreign_table' => 'map_datas',
                'id' => 544,
                'lang' => 'en',
                'translated_text' => 'Shizuoka City Mizumi Elementary School',
            ),
            372 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 74,
                'foreign_table' => 'map_datas',
                'id' => 545,
                'lang' => 'en',
                'translated_text' => 'Specified Non-Profit Activities Promotion Act In accordance with Article 2.
we have refused to give lectures on the purpose of supporting and developing specific religious and political principles',
            ),
            373 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 74,
                'foreign_table' => 'map_datas',
                'id' => 546,
                'lang' => 'en',
                'translated_text' => '１０４０−３ Mizumiiro, Aoi-ku, Shizuoka, 421-1313, Nhật Bản',
            ),
            374 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 74,
                'foreign_table' => 'map_datas',
                'id' => 547,
                'lang' => 'en',
                'translated_text' => '092-282-8913',
            ),
            375 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 75,
                'foreign_table' => 'map_datas',
                'id' => 548,
                'lang' => 'en',
                'translated_text' => 'Shizuoka Aoi Hospital',
            ),
            376 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 75,
                'foreign_table' => 'map_datas',
                'id' => 549,
                'lang' => 'en',
                'translated_text' => '0787-287-999',
            ),
            377 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 76,
                'foreign_table' => 'map_datas',
                'id' => 550,
                'lang' => 'en',
                'translated_text' => 'Shizuoka Municipal Shimizu Hospital',
            ),
            378 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 76,
                'foreign_table' => 'map_datas',
                'id' => 551,
                'lang' => 'en',
                'translated_text' => 'Mother is introduced to suspicion of dementia, and visited our forgotten department.
Dementia test, MRI and other necessary examinations, and it is reported that Mr. Hata, who is the leading person here, whether it is FTD or not, let\'s go for a slow examination.',
            ),
            379 => 
            array (
                'foreign_field' => 'address',
                'foreign_id' => 76,
                'foreign_table' => 'map_datas',
                'id' => 552,
                'lang' => 'en',
                'translated_text' => '1231 Miyakami, Shimizu-ku, Shizuoka, 424-8636, Nhật Bản',
            ),
            380 => 
            array (
                'foreign_field' => 'tel',
                'foreign_id' => 76,
                'foreign_table' => 'map_datas',
                'id' => 553,
                'lang' => 'en',
                'translated_text' => '054-336-1111',
            ),
            381 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 44,
                'foreign_table' => 'websites',
                'id' => 554,
                'lang' => 'en',
            'translated_text' => '1) Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally.<br>2) The situation on the day of the lecture may be introduced as an activity report of our group on the website or Facebook etc. If you do not want to introduce, please tell us in advance. In addition, we will publish the participant\'s face and personal name in an unidentifiable form unless prior approval is given.<br>3) The lecture fee will be paid to the corporation. Please do not deduct, etc. for withholding tax. In addition, it will be bank transfer in principle. Please consult us in case of cash payment. In principle, no invoices for lecture fees are issued. If necessary, please request one month prior to the issue date. In addition, the invoice will be issued in principle pdf.<br>',
        ),
        382 => 
        array (
            'foreign_field' => 'title',
            'foreign_id' => 45,
            'foreign_table' => 'websites',
            'id' => 555,
            'lang' => 'en',
            'translated_text' => 'Title webpage en',
        ),
        383 => 
        array (
            'foreign_field' => 'body',
            'foreign_id' => 45,
            'foreign_table' => 'websites',
            'id' => 556,
            'lang' => 'en',
        'translated_text' => '4) Since the content of the lecture conveys the current situation of the child, we have refused to record the content of the lecture and to disclose the content of the day without permission. In the case of what is assumed to be public, it is necessary to consider the contents etc. in advance, so please be sure to confirm in advance. In addition, when posting the state of the lecture on the HP etc. of your organization, I will make sure to confirm the contents. Please note that we may ask you to correct the contents of the publication.<br>5) The projection data will be brought by USB on the day. In principle, we do not pre-send data. I hope that you understand from the perspective of personal information protection etc.<br>6) Meeting time and break up time should be within 45 minutes before and after the lecture time. We run the organization with a small number of people, and I hope you understand.<br>7) Please refrain from forwarding and disclosing the contents of the lecture without permission from the viewpoint of personal information protection. If you wish, please consult in advance',
    ),
    384 => 
    array (
        'foreign_field' => 'body',
        'foreign_id' => 45,
        'foreign_table' => 'websites',
        'id' => 557,
        'lang' => 'ko',
        'translated_text' => '어머니가 치매의 혐의로 소개되고 여기 건망증과 수진.<br>치매 테스트, MRI 등 필요한 검사를 FTD이든 여기의 제일 인자 인 밭 씨로부터 전해져 천천히 진단 갑시다라는 것에.',
    ),
    385 => 
    array (
        'foreign_field' => 'body',
        'foreign_id' => 47,
        'foreign_table' => 'websites',
        'id' => 561,
        'lang' => 'en',
    'translated_text' => '1) Specified Non-Profit Activities Promotion Act In accordance with 
Article 2, we have refused to give lectures on the purpose of supporting
and developing specific religious and political principles. Please note
that even if the purpose is not clearly stated, the decision may be 
refused internally.<br>2) The situation on the day of the lecture may be
introduced as an activity report of our group on the website or 
Facebook etc. If you do not want to introduce, please tell us in 
advance. In addition, we will publish the participant\'s face and 
personal name in an unidentifiable form unless prior approval is given.<br>3)
The lecture fee will be paid to the corporation. Please do not deduct, 
etc. for withholding tax. In addition, it will be bank transfer in 
principle. Please consult us in case of cash payment. In principle, no 
invoices for lecture fees are issued. If necessary, please request one 
month prior to the issue date. In addition, the invoice will be issued 
in principle pdf.',
),
386 => 
array (
'foreign_field' => 'body',
'foreign_id' => 75,
'foreign_table' => 'map_datas',
'id' => 563,
'lang' => 'en',
'translated_text' => 'Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally',
),
387 => 
array (
'foreign_field' => 'title',
'foreign_id' => 49,
'foreign_table' => 'websites',
'id' => 564,
'lang' => 'en',
'translated_text' => 'Webpage4 en',
),
388 => 
array (
'foreign_field' => 'body',
'foreign_id' => 49,
'foreign_table' => 'websites',
'id' => 565,
'lang' => 'en',
'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">1) Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally.</span></font>',
),
389 => 
array (
'foreign_field' => 'body',
'foreign_id' => 77,
'foreign_table' => 'map_datas',
'id' => 566,
'lang' => 'en',
'translated_text' => 'The situation on the day of the lecture may be introduced as an activity report of our group on the website or Facebook etc. If you do not want to introduce, please tell us in advance. In addition, we will publish the participant\'s face and personal name in an unidentifiable form unless prior approval is given',
),
390 => 
array (
'foreign_field' => 'address',
'foreign_id' => 77,
'foreign_table' => 'map_datas',
'id' => 567,
'lang' => 'en',
'translated_text' => '1039 Kuzukawa, Kakegawa, Shizuoka 436-0074, Nhật Bản',
),
391 => 
array (
'foreign_field' => 'title',
'foreign_id' => 78,
'foreign_table' => 'map_datas',
'id' => 568,
'lang' => 'en',
'translated_text' => 'Kakegawa City Hall Health and Welfare Department Health Prevention Division, Health Planning, Maternal and Child Health, Adult Health Care Section',
),
392 => 
array (
'foreign_field' => 'body',
'foreign_id' => 78,
'foreign_table' => 'map_datas',
'id' => 569,
'lang' => 'en',
'translated_text' => 'Some were friendly and others were phone-friendly.
That person was said clerical.
I was worried at the time of the first person and I called once, but I think that one can understand humanity with one phone call',
),
393 => 
array (
'foreign_field' => 'address',
'foreign_id' => 78,
'foreign_table' => 'map_datas',
'id' => 570,
'lang' => 'en',
'translated_text' => '9-28 Goshobara, Kakegawa, Shizuoka 436-0068, Nhật Bản',
),
394 => 
array (
'foreign_field' => 'title',
'foreign_id' => 77,
'foreign_table' => 'map_datas',
'id' => 571,
'lang' => 'en',
'translated_text' => 'Kakegawa City East Junior High School',
),
395 => 
array (
'foreign_field' => 'title',
'foreign_id' => 79,
'foreign_table' => 'map_datas',
'id' => 572,
'lang' => 'en',
'translated_text' => 'Kakegawa City Hall Health and Welfare Department Health Prevention Division, Health Planning, Maternal and Child Health, Adult Health Care Section to Kakegawa City East Junior High School',
),
396 => 
array (
'foreign_field' => 'address',
'foreign_id' => 79,
'foreign_table' => 'map_datas',
'id' => 573,
'lang' => 'en',
'translated_text' => '1039 Kuzukawa, Kakegawa, Shizuoka 436-0074, Nhật Bản',
),
397 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 79,
'foreign_table' => 'map_datas',
'id' => 574,
'lang' => 'en',
'translated_text' => '0537-22-5158',
),
398 => 
array (
'foreign_field' => 'title',
'foreign_id' => 80,
'foreign_table' => 'map_datas',
'id' => 575,
'lang' => 'en',
'translated_text' => 'Kakegawa City East Junior High School to Shizuoka Aoi Hospital',
),
399 => 
array (
'foreign_field' => 'body',
'foreign_id' => 80,
'foreign_table' => 'map_datas',
'id' => 576,
'lang' => 'en',
'translated_text' => 'Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally',
),
400 => 
array (
'foreign_field' => 'address',
'foreign_id' => 80,
'foreign_table' => 'map_datas',
'id' => 577,
'lang' => 'en',
'translated_text' => '9-28 Goshobara, Kakegawa, Shizuoka 436-0068, Nhật Bản',
),
401 => 
array (
'foreign_field' => 'title',
'foreign_id' => 81,
'foreign_table' => 'map_datas',
'id' => 578,
'lang' => 'en',
'translated_text' => 'Miki-no-Sato Country Club to Kakegawa Green Hill Country Club to Ikoi no Hiroba Station to Shibata City General Hospital',
),
402 => 
array (
'foreign_field' => 'body',
'foreign_id' => 81,
'foreign_table' => 'map_datas',
'id' => 579,
'lang' => 'en',
'translated_text' => 'It is quite interesting to read the golf course ゴ ル フ green which can be enjoyed with the back of the horse
There is a place where there is a poultry house in the IN course near the IN course, but I endure patience (lol)
In the evening, the sun was so tight that the tee shot lost sight of the destination and did not know the pin.
I would like to come again',
),
403 => 
array (
'foreign_field' => 'address',
'foreign_id' => 81,
'foreign_table' => 'map_datas',
'id' => 580,
'lang' => 'en',
'translated_text' => '1000 Terashima, Kakegawa, Shizuoka 436-0106, Nhật Bản',
),
404 => 
array (
'foreign_field' => 'title',
'foreign_id' => 82,
'foreign_table' => 'map_datas',
'id' => 584,
'lang' => 'en',
'translated_text' => 'Numazu City Harato Elementary School to Numazu City Ehime Junior High School to Numazu City Sawada Elementary School',
),
405 => 
array (
'foreign_field' => 'body',
'foreign_id' => 82,
'foreign_table' => 'map_datas',
'id' => 585,
'lang' => 'en',
'translated_text' => 'In the evening, the sun was so tight that the tee shot lost sight of the destination and did not know the pin.
I would like to come again',
),
406 => 
array (
'foreign_field' => 'address',
'foreign_id' => 82,
'foreign_table' => 'map_datas',
'id' => 586,
'lang' => 'en',
'translated_text' => '715 Nakasawada, Numazu, Shizuoka 410-0006, Nhật Bản',
),
407 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 82,
'foreign_table' => 'map_datas',
'id' => 587,
'lang' => 'en',
'translated_text' => '097-3823-222',
),
408 => 
array (
'foreign_field' => 'title',
'foreign_id' => 83,
'foreign_table' => 'map_datas',
'id' => 588,
'lang' => 'en',
'translated_text' => 'Numazu City Katahama Junior High School to Numazu City Fifth Junior High School to National Hospital Organization Shizuoka Medical Center to Shizuoka Prefectural Numazu Industrial High School',
),
409 => 
array (
'foreign_field' => 'body',
'foreign_id' => 83,
'foreign_table' => 'map_datas',
'id' => 589,
'lang' => 'en',
'translated_text' => 'I have a job in my hand. In the current era, it is important to have no problem with cultural sciences. Qualifications in technology are important in order to be comfortable.',
),
410 => 
array (
'foreign_field' => 'address',
'foreign_id' => 83,
'foreign_table' => 'map_datas',
'id' => 590,
'lang' => 'en',
'translated_text' => 'Nhật Bản, 〒410-0822 Shizuoka, Numazu, 下香貫八重１２９−１',
),
411 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 83,
'foreign_table' => 'map_datas',
'id' => 591,
'lang' => 'en',
'translated_text' => '054-336-1111',
),
412 => 
array (
'foreign_field' => 'title',
'foreign_id' => 84,
'foreign_table' => 'map_datas',
'id' => 592,
'lang' => 'en',
'translated_text' => 'Numazu City Katahama Junior High School to Numazu City Fifth Elementary School',
),
413 => 
array (
'foreign_field' => 'address',
'foreign_id' => 84,
'foreign_table' => 'map_datas',
'id' => 593,
'lang' => 'en',
'translated_text' => '9-1 Yoneyamacho, Numazu, Shizuoka 410-0046, Nhật Bản',
),
414 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 84,
'foreign_table' => 'map_datas',
'id' => 594,
'lang' => 'en',
'translated_text' => '055-921-0355',
),
415 => 
array (
'foreign_field' => 'title',
'foreign_id' => 85,
'foreign_table' => 'map_datas',
'id' => 595,
'lang' => 'en',
'translated_text' => 'Eastern Driving School to Numazu City Baseball Stadium',
),
416 => 
array (
'foreign_field' => 'address',
'foreign_id' => 85,
'foreign_table' => 'map_datas',
'id' => 596,
'lang' => 'en',
'translated_text' => '17-1 Kotobukicho, Numazu, Shizuoka 410-0053, Nhật Bản',
),
417 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 85,
'foreign_table' => 'map_datas',
'id' => 597,
'lang' => 'en',
'translated_text' => '055-922-7200',
),
418 => 
array (
'foreign_field' => 'title',
'foreign_id' => 86,
'foreign_table' => 'map_datas',
'id' => 598,
'lang' => 'en',
'translated_text' => 'Harada Dental Clinic',
),
419 => 
array (
'foreign_field' => 'address',
'foreign_id' => 68,
'foreign_table' => 'map_datas',
'id' => 599,
'lang' => 'en',
'translated_text' => '7-2 Kyoeicho, Numazu, Shizuoka 410-0064, Nhật Bản',
),
420 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 68,
'foreign_table' => 'map_datas',
'id' => 600,
'lang' => 'en',
'translated_text' => '055-924-0500',
),
421 => 
array (
'foreign_field' => 'body',
'foreign_id' => 86,
'foreign_table' => 'map_datas',
'id' => 601,
'lang' => 'en',
'translated_text' => 'Harada Dental Clinic3333',
),
422 => 
array (
'foreign_field' => 'address',
'foreign_id' => 86,
'foreign_table' => 'map_datas',
'id' => 602,
'lang' => 'en',
'translated_text' => '7-2 Kyōeichō, Numazu, Shizuoka 410-0064, Nhật Bản, Hello',
),
423 => 
array (
'foreign_field' => 'tel',
'foreign_id' => 86,
'foreign_table' => 'map_datas',
'id' => 603,
'lang' => 'en',
'translated_text' => '0271-7171-889',
),
424 => 
array (
'foreign_field' => 'title',
'foreign_id' => 85,
'foreign_table' => 'files',
'id' => 604,
'lang' => 'en',
'translated_text' => 'File en',
),
425 => 
array (
'foreign_field' => 'title',
'foreign_id' => 85,
'foreign_table' => 'files',
'id' => 605,
'lang' => 'ko',
'translated_text' => 'file ko',
),
426 => 
array (
'foreign_field' => 'title',
'foreign_id' => 48,
'foreign_table' => 'map_datas',
'id' => 606,
'lang' => 'en',
'translated_text' => 'Fujikawaguchiko',
),
427 => 
array (
'foreign_field' => 'body',
'foreign_id' => 48,
'foreign_table' => 'map_datas',
'id' => 607,
'lang' => 'en',
'translated_text' => 'Fujikawaguchiko',
),
428 => 
array (
'foreign_field' => 'address',
'foreign_id' => 48,
'foreign_table' => 'map_datas',
'id' => 608,
'lang' => 'en',
'translated_text' => 'Minamitsuru District, Yamanashi Nhat Ban',
),
429 => 
array (
'foreign_field' => 'title',
'foreign_id' => 266,
'foreign_table' => 'posts',
'id' => 611,
'lang' => 'en',
'translated_text' => 'Information on the data immediately 2/5/2019',
),
430 => 
array (
'foreign_field' => 'body',
'foreign_id' => 266,
'foreign_table' => 'posts',
'id' => 612,
'lang' => 'en',
'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">The situation on the day of the lecture may be introduced as an activity report of our group on the website or Facebook etc. If you do not want to introduce, please tell us in advance. In addition, we will publish the participant\'s face and personal name in an unidentifiable form if prior consent is not obtained</span></font>',
),
431 => 
array (
'foreign_field' => 'title',
'foreign_id' => 267,
'foreign_table' => 'posts',
'id' => 613,
'lang' => 'en',
'translated_text' => 'Information on the data immediately 3/5/2019',
),
432 => 
array (
'foreign_field' => 'body',
'foreign_id' => 267,
'foreign_table' => 'posts',
'id' => 614,
'lang' => 'en',
'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">The lecture fee will be paid to the corporation. Please do not deduct, etc. for withholding tax. In addition, it will be bank transfer in principle. Please consult us in case of cash payment. In principle, no invoices for lecture fees are issued. If necessary, please request one month prior to the issue date. In addition, the invoice will be issued in principle pdf.</span></font>',
),
433 => 
array (
'foreign_field' => 'title',
'foreign_id' => 268,
'foreign_table' => 'posts',
'id' => 615,
'lang' => 'en',
'translated_text' => 'latest information on tsunamis on 2/5/2019',
),
434 => 
array (
'foreign_field' => 'title',
'foreign_id' => 315,
'foreign_table' => 'posts',
'id' => 616,
'lang' => 'en',
'translated_text' => 'dong dat 2 en',
),
435 => 
array (
'foreign_field' => 'body',
'foreign_id' => 315,
'foreign_table' => 'posts',
'id' => 617,
'lang' => 'en',
'translated_text' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">遺贈先として「特定非営利活動法人3keys」を指定された旨をお知らせください。定期的に活動報告をお送りいたします。</span>',
),
436 => 
array (
'foreign_field' => 'name',
'foreign_id' => 75,
'foreign_table' => 'tags',
'id' => 622,
'lang' => 'en',
'translated_text' => 'Fresh food',
),
437 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 75,
'foreign_table' => 'tags',
'id' => 623,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_90c4d092-d003-4d28-8035-86d7d9313ebf',
),
438 => 
array (
'foreign_field' => 'name',
'foreign_id' => 76,
'foreign_table' => 'tags',
'id' => 624,
'lang' => 'en',
'translated_text' => 'Fastfood',
),
439 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 76,
'foreign_table' => 'tags',
'id' => 625,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_7b63e39e-1a93-4bbb-b7e9-c35da7be9b0b',
),
440 => 
array (
'foreign_field' => 'name',
'foreign_id' => 77,
'foreign_table' => 'tags',
'id' => 626,
'lang' => 'en',
'translated_text' => 'Science',
),
441 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 77,
'foreign_table' => 'tags',
'id' => 627,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_82068e75-60d4-46bf-aa97-fe2b8d650bfc',
),
442 => 
array (
'foreign_field' => 'name',
'foreign_id' => 78,
'foreign_table' => 'tags',
'id' => 628,
'lang' => 'en',
'translated_text' => 'Fashion',
),
443 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 78,
'foreign_table' => 'tags',
'id' => 629,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_2ddd230b-6d73-49cb-a081-d54c76a76c40',
),
444 => 
array (
'foreign_field' => 'name',
'foreign_id' => 79,
'foreign_table' => 'tags',
'id' => 630,
'lang' => 'en',
'translated_text' => 'weather today',
),
445 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 79,
'foreign_table' => 'tags',
'id' => 631,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_42cdca86-f38b-4e8c-a30b-dbca60127a11',
),
446 => 
array (
'foreign_field' => 'name',
'foreign_id' => 80,
'foreign_table' => 'tags',
'id' => 632,
'lang' => 'en',
'translated_text' => 'Weather Tomorrow',
),
447 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 80,
'foreign_table' => 'tags',
'id' => 633,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_136c8d3c-83dc-4582-88e6-85c4bc1f3e60',
),
448 => 
array (
'foreign_field' => 'name',
'foreign_id' => 81,
'foreign_table' => 'tags',
'id' => 634,
'lang' => 'en',
'translated_text' => 'Tsunami',
),
449 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 81,
'foreign_table' => 'tags',
'id' => 635,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_a1d64723-bccc-47b5-b282-60a1667cf1dc',
),
450 => 
array (
'foreign_field' => 'name',
'foreign_id' => 82,
'foreign_table' => 'tags',
'id' => 636,
'lang' => 'en',
'translated_text' => 'Earthquake',
),
451 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 82,
'foreign_table' => 'tags',
'id' => 637,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_3183ee93-d4dc-4b50-9218-1ae84ba6a25d',
),
452 => 
array (
'foreign_field' => 'name',
'foreign_id' => 83,
'foreign_table' => 'tags',
'id' => 638,
'lang' => 'en',
'translated_text' => 'Emergency',
),
453 => 
array (
'foreign_field' => 'topic_arn',
'foreign_id' => 83,
'foreign_table' => 'tags',
'id' => 639,
'lang' => 'en',
'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_4ea46148-f560-466b-a050-92798d670ac6',
),
454 => 
array (
'foreign_field' => 'title',
'foreign_id' => 331,
'foreign_table' => 'posts',
'id' => 640,
'lang' => 'en',
'translated_text' => 'Song than en',
),
455 => 
array (
'foreign_field' => 'body',
'foreign_id' => 331,
'foreign_table' => 'posts',
'id' => 641,
'lang' => 'en',
'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Song than en</span></font>',
),
456 => 
array (
'foreign_field' => 'title',
'foreign_id' => 333,
'foreign_table' => 'posts',
'id' => 642,
'lang' => 'en',
'translated_text' => 'Earthquake warning',
),
457 => 
array (
'foreign_field' => 'body',
'foreign_id' => 333,
'foreign_table' => 'posts',
'id' => 643,
'lang' => 'en',
'translated_text' => '<span class="tlid-translation translation" lang="en"><span title="" class="">5 richte town residences</span></span>',
),
458 => 
array (
'foreign_field' => 'title',
'foreign_id' => 334,
'foreign_table' => 'posts',
'id' => 644,
'lang' => 'en',
'translated_text' => 'Emergency notice',
),
459 => 
array (
'foreign_field' => 'body',
'foreign_id' => 334,
'foreign_table' => 'posts',
'id' => 645,
'lang' => 'en',
'translated_text' => '<span class="tlid-translation translation" lang="en"><span title="" class="">The spirit is about to land in our waters</span><br><br></span>',
),
460 => 
array (
'foreign_field' => 'link_url',
'foreign_id' => 23,
'foreign_table' => 'links',
'id' => 646,
'lang' => 'en',
'translated_text' => 'https://www.google.com.vn/',
),
461 => 
array (
'foreign_field' => 'title',
'foreign_id' => 51,
'foreign_table' => 'websites',
'id' => 649,
'lang' => 'en',
'translated_text' => 'offline 2en',
),
462 => 
array (
'foreign_field' => 'body',
'foreign_id' => 51,
'foreign_table' => 'websites',
'id' => 650,
'lang' => 'en',
'translated_text' => '<span class="tlid-translation translation" lang="en"><span title="" class="">2) In the case of donations from individuals, once a year (early February), we will send a receipt stating the total amount of donations from the previous year.</span> <span title="" class="">In case of corporate donations, receipts will be issued each time.</span> <span title="">As we can not do reissue by loss, please keep carefully.</span></span>
<br>
Japanese food 
<br>
<img src="ban-da-thuong-thuc-mon-nhat-dung-cach-chua_e0afaf67-7c64-4970-8866-ab3c80095188_20190508180347.jpg" width="300" height="300">
</br>
Japanese food
<br>
<img src="vuon-nho-ninh-thuan_dc28d8b6-4175-4ea5-9b07-c43002ee9b73_20190508180429.png" width="300" height="300">
</br>',
),
463 => 
array (
'foreign_field' => 'title',
'foreign_id' => 50,
'foreign_table' => 'websites',
'id' => 651,
'lang' => 'en',
'translated_text' => 'Subpage1 en',
),
464 => 
array (
'foreign_field' => 'body',
'foreign_id' => 50,
'foreign_table' => 'websites',
'id' => 652,
'lang' => 'en',
'translated_text' => '<span class="tlid-translation translation" lang="en"><span title="" class="">3) The address of the receipt will be the registered name and registered address for this group.</span> <span title="" class="">If you move, etc., please contact us about your registration information change.</span></span>
Vietnamese fabric
<br>
<img src="v-i-fixed_438b9214-15cb-4404-889e-a9aac39cf20d_20190508181337.jpg" width="300" height="300">
</br>
Vietnamese fabric
<br>
<img src="mon-an-nguoi-nhat_b5b40261-d599-4363-bc96-3b7be7800de7_20190508181313.jpg" width="300" height="300">
</br>',
),
465 => 
array (
'foreign_field' => 'title',
'foreign_id' => 86,
'foreign_table' => 'files',
'id' => 655,
'lang' => 'en',
'translated_text' => 'Mon Nhat',
),
466 => 
array (
'foreign_field' => 'title',
'foreign_id' => 92,
'foreign_table' => 'files',
'id' => 656,
'lang' => 'en',
'translated_text' => 'Nho nha',
),
467 => 
array (
'foreign_field' => 'title',
'foreign_id' => 96,
'foreign_table' => 'files',
'id' => 657,
'lang' => 'en',
'translated_text' => 'mon an',
),
468 => 
array (
'foreign_field' => 'title',
'foreign_id' => 94,
'foreign_table' => 'files',
'id' => 658,
'lang' => 'en',
'translated_text' => 'Vai thieu',
),
469 => 
array (
'foreign_field' => 'title',
'foreign_id' => 52,
'foreign_table' => 'websites',
'id' => 659,
'lang' => 'en',
'translated_text' => 'title en',
),
470 => 
array (
'foreign_field' => 'body',
'foreign_id' => 52,
'foreign_table' => 'websites',
'id' => 660,
'lang' => 'en',
'translated_text' => '<div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima v</span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"=""><br></span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">
<a href="177.html">WebPage 1</a>
<br><br>
<a href="178.html">WebPage 2</a>

<br>File 1
<br><img src="2_20190313150842.jpg"  ="" width="350" height="350"><br>
<br>File 2
<br><img src="hinh-anh-dep-ve-tinh-yeu-34_052632738_20190312114756.jpg" width="350" height="350"><br></span></div><a data-name="abc" href="https://stackoverflow.com/questions/32106849/getcurrentposition-and-watchposition-are-deprecated-on-insecure-origins" class="btn btn-menu btn-menu-blue content-item"><div class="border-dash flex-container" style="display: flex; padding: 5px 10px;">
<div class="" style="flex-grow: 1; text-align: right">
<i class="fas fa-angle-right"></i>
</div>
</div>
</a>

<ul><li><a href="matchi-yell_5ebddc2f-e661-4ee9-9f33-843e950e79cd_20190509122000.pdf">File PDF</a></li></ul>
<ul><li><a href="M03.2%20顧客作成_f4526ca0-511a-44a5-87da-1d30a6a68331_20190509122403.pdf">File PDF2</a></li></ul>',
),
471 => 
array (
'foreign_field' => 'title',
'foreign_id' => 540,
'foreign_table' => 'posts',
'id' => 773,
'lang' => 'en',
'translated_text' => 'english title',
),
472 => 
array (
'foreign_field' => 'body',
'foreign_id' => 540,
'foreign_table' => 'posts',
'id' => 774,
'lang' => 'en',
'translated_text' => '
<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
),
473 => 
array (
'foreign_field' => 'title',
'foreign_id' => 540,
'foreign_table' => 'posts',
'id' => 775,
'lang' => 'ko',
'translated_text' => 'korean title',
),
474 => 
array (
'foreign_field' => 'body',
'foreign_id' => 540,
'foreign_table' => 'posts',
'id' => 776,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

zxc',
),
475 => 
array (
'foreign_field' => 'title',
'foreign_id' => 541,
'foreign_table' => 'posts',
'id' => 777,
'lang' => 'en',
'translated_text' => 'english title',
),
476 => 
array (
'foreign_field' => 'body',
'foreign_id' => 541,
'foreign_table' => 'posts',
'id' => 778,
'lang' => 'en',
'translated_text' => '
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
),
477 => 
array (
'foreign_field' => 'title',
'foreign_id' => 541,
'foreign_table' => 'posts',
'id' => 779,
'lang' => 'ko',
'translated_text' => 'korean title',
),
478 => 
array (
'foreign_field' => 'body',
'foreign_id' => 541,
'foreign_table' => 'posts',
'id' => 780,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

zxc',
),
479 => 
array (
'foreign_field' => 'title',
'foreign_id' => 542,
'foreign_table' => 'posts',
'id' => 781,
'lang' => 'en',
'translated_text' => 'english title',
),
480 => 
array (
'foreign_field' => 'body',
'foreign_id' => 542,
'foreign_table' => 'posts',
'id' => 782,
'lang' => 'en',
'translated_text' => '
<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
),
481 => 
array (
'foreign_field' => 'title',
'foreign_id' => 542,
'foreign_table' => 'posts',
'id' => 783,
'lang' => 'ko',
'translated_text' => 'korean title',
),
482 => 
array (
'foreign_field' => 'body',
'foreign_id' => 542,
'foreign_table' => 'posts',
'id' => 784,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

zxc',
),
483 => 
array (
'foreign_field' => 'title',
'foreign_id' => 543,
'foreign_table' => 'posts',
'id' => 785,
'lang' => 'en',
'translated_text' => 'english title',
),
484 => 
array (
'foreign_field' => 'body',
'foreign_id' => 543,
'foreign_table' => 'posts',
'id' => 786,
'lang' => 'en',
'translated_text' => '
<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
),
485 => 
array (
'foreign_field' => 'title',
'foreign_id' => 543,
'foreign_table' => 'posts',
'id' => 787,
'lang' => 'ko',
'translated_text' => 'korean title',
),
486 => 
array (
'foreign_field' => 'body',
'foreign_id' => 543,
'foreign_table' => 'posts',
'id' => 788,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

zxc',
),
487 => 
array (
'foreign_field' => 'title',
'foreign_id' => 544,
'foreign_table' => 'posts',
'id' => 789,
'lang' => 'en',
'translated_text' => 'english title',
),
488 => 
array (
'foreign_field' => 'body',
'foreign_id' => 544,
'foreign_table' => 'posts',
'id' => 790,
'lang' => 'en',
'translated_text' => '
<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
),
489 => 
array (
'foreign_field' => 'title',
'foreign_id' => 544,
'foreign_table' => 'posts',
'id' => 791,
'lang' => 'ko',
'translated_text' => 'korean title',
),
490 => 
array (
'foreign_field' => 'body',
'foreign_id' => 544,
'foreign_table' => 'posts',
'id' => 792,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

zxc',
),
491 => 
array (
'foreign_field' => 'title',
'foreign_id' => 545,
'foreign_table' => 'posts',
'id' => 793,
'lang' => 'en',
'translated_text' => 'english title',
),
492 => 
array (
'foreign_field' => 'body',
'foreign_id' => 545,
'foreign_table' => 'posts',
'id' => 794,
'lang' => 'en',
'translated_text' => '
<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
),
493 => 
array (
'foreign_field' => 'title',
'foreign_id' => 545,
'foreign_table' => 'posts',
'id' => 795,
'lang' => 'ko',
'translated_text' => 'korean title',
),
494 => 
array (
'foreign_field' => 'body',
'foreign_id' => 545,
'foreign_table' => 'posts',
'id' => 796,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

zxc',
),
495 => 
array (
'foreign_field' => 'title',
'foreign_id' => 546,
'foreign_table' => 'posts',
'id' => 797,
'lang' => 'en',
'translated_text' => 'english title',
),
496 => 
array (
'foreign_field' => 'body',
'foreign_id' => 546,
'foreign_table' => 'posts',
'id' => 798,
'lang' => 'en',
'translated_text' => '
<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
),
497 => 
array (
'foreign_field' => 'title',
'foreign_id' => 546,
'foreign_table' => 'posts',
'id' => 799,
'lang' => 'ko',
'translated_text' => 'korean title',
),
498 => 
array (
'foreign_field' => 'body',
'foreign_id' => 546,
'foreign_table' => 'posts',
'id' => 800,
'lang' => 'ko',
'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

zxc',
),
499 => 
array (
'foreign_field' => 'title',
'foreign_id' => 547,
'foreign_table' => 'posts',
'id' => 801,
'lang' => 'en',
'translated_text' => 'english title',
),
));
        \DB::table('translations')->insert(array (
            0 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 547,
                'foreign_table' => 'posts',
                'id' => 802,
                'lang' => 'en',
                'translated_text' => '
<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            1 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 547,
                'foreign_table' => 'posts',
                'id' => 803,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            2 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 547,
                'foreign_table' => 'posts',
                'id' => 804,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

zxc',
            ),
            3 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 548,
                'foreign_table' => 'posts',
                'id' => 805,
                'lang' => 'en',
                'translated_text' => 'english title',
            ),
            4 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 548,
                'foreign_table' => 'posts',
                'id' => 806,
                'lang' => 'en',
                'translated_text' => '
<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            5 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 548,
                'foreign_table' => 'posts',
                'id' => 807,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            6 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 548,
                'foreign_table' => 'posts',
                'id' => 808,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

zxc',
            ),
            7 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 549,
                'foreign_table' => 'posts',
                'id' => 809,
                'lang' => 'en',
                'translated_text' => 'english title',
            ),
            8 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 549,
                'foreign_table' => 'posts',
                'id' => 810,
                'lang' => 'en',
                'translated_text' => '
<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            9 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 549,
                'foreign_table' => 'posts',
                'id' => 811,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            10 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 549,
                'foreign_table' => 'posts',
                'id' => 812,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

zxc',
            ),
            11 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 550,
                'foreign_table' => 'posts',
                'id' => 813,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            12 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 550,
                'foreign_table' => 'posts',
                'id' => 814,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            13 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 550,
                'foreign_table' => 'posts',
                'id' => 815,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            14 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 550,
                'foreign_table' => 'posts',
                'id' => 816,
                'lang' => 'ko',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            15 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 551,
                'foreign_table' => 'posts',
                'id' => 817,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            16 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 551,
                'foreign_table' => 'posts',
                'id' => 818,
                'lang' => 'en',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            17 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 551,
                'foreign_table' => 'posts',
                'id' => 819,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            18 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 551,
                'foreign_table' => 'posts',
                'id' => 820,
                'lang' => 'ko',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            19 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 552,
                'foreign_table' => 'posts',
                'id' => 821,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            20 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 552,
                'foreign_table' => 'posts',
                'id' => 822,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            21 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 552,
                'foreign_table' => 'posts',
                'id' => 823,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            22 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 552,
                'foreign_table' => 'posts',
                'id' => 824,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            23 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 553,
                'foreign_table' => 'posts',
                'id' => 825,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            24 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 553,
                'foreign_table' => 'posts',
                'id' => 826,
                'lang' => 'en',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            25 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 553,
                'foreign_table' => 'posts',
                'id' => 827,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            26 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 553,
                'foreign_table' => 'posts',
                'id' => 828,
                'lang' => 'ko',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            27 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 554,
                'foreign_table' => 'posts',
                'id' => 829,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            28 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 554,
                'foreign_table' => 'posts',
                'id' => 830,
                'lang' => 'en',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            29 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 554,
                'foreign_table' => 'posts',
                'id' => 831,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            30 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 554,
                'foreign_table' => 'posts',
                'id' => 832,
                'lang' => 'ko',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            31 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 555,
                'foreign_table' => 'posts',
                'id' => 833,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            32 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 555,
                'foreign_table' => 'posts',
                'id' => 834,
                'lang' => 'en',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            33 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 555,
                'foreign_table' => 'posts',
                'id' => 835,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            34 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 555,
                'foreign_table' => 'posts',
                'id' => 836,
                'lang' => 'ko',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            35 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 556,
                'foreign_table' => 'posts',
                'id' => 837,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            36 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 556,
                'foreign_table' => 'posts',
                'id' => 838,
                'lang' => 'en',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            37 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 556,
                'foreign_table' => 'posts',
                'id' => 839,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            38 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 556,
                'foreign_table' => 'posts',
                'id' => 840,
                'lang' => 'ko',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            39 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 557,
                'foreign_table' => 'posts',
                'id' => 841,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            40 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 557,
                'foreign_table' => 'posts',
                'id' => 842,
                'lang' => 'en',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            41 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 557,
                'foreign_table' => 'posts',
                'id' => 843,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            42 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 557,
                'foreign_table' => 'posts',
                'id' => 844,
                'lang' => 'ko',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            43 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 558,
                'foreign_table' => 'posts',
                'id' => 845,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            44 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 558,
                'foreign_table' => 'posts',
                'id' => 846,
                'lang' => 'en',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            45 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 558,
                'foreign_table' => 'posts',
                'id' => 847,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            46 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 558,
                'foreign_table' => 'posts',
                'id' => 848,
                'lang' => 'ko',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            47 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 559,
                'foreign_table' => 'posts',
                'id' => 849,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            48 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 559,
                'foreign_table' => 'posts',
                'id' => 850,
                'lang' => 'en',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            49 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 559,
                'foreign_table' => 'posts',
                'id' => 851,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            50 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 559,
                'foreign_table' => 'posts',
                'id' => 852,
                'lang' => 'ko',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            51 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 560,
                'foreign_table' => 'posts',
                'id' => 853,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            52 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 560,
                'foreign_table' => 'posts',
                'id' => 854,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            53 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 560,
                'foreign_table' => 'posts',
                'id' => 855,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            54 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 560,
                'foreign_table' => 'posts',
                'id' => 856,
                'lang' => 'ko',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            55 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 561,
                'foreign_table' => 'posts',
                'id' => 857,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            56 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 561,
                'foreign_table' => 'posts',
                'id' => 858,
                'lang' => 'en',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            57 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 561,
                'foreign_table' => 'posts',
                'id' => 859,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            58 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 561,
                'foreign_table' => 'posts',
                'id' => 860,
                'lang' => 'ko',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            59 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 562,
                'foreign_table' => 'posts',
                'id' => 861,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            60 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 562,
                'foreign_table' => 'posts',
                'id' => 862,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            61 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 562,
                'foreign_table' => 'posts',
                'id' => 863,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            62 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 562,
                'foreign_table' => 'posts',
                'id' => 864,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            63 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 563,
                'foreign_table' => 'posts',
                'id' => 865,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            64 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 563,
                'foreign_table' => 'posts',
                'id' => 866,
                'lang' => 'en',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            65 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 563,
                'foreign_table' => 'posts',
                'id' => 867,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            66 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 563,
                'foreign_table' => 'posts',
                'id' => 868,
                'lang' => 'ko',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            67 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 564,
                'foreign_table' => 'posts',
                'id' => 869,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            68 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 564,
                'foreign_table' => 'posts',
                'id' => 870,
                'lang' => 'en',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            69 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 564,
                'foreign_table' => 'posts',
                'id' => 871,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            70 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 564,
                'foreign_table' => 'posts',
                'id' => 872,
                'lang' => 'ko',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            71 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 565,
                'foreign_table' => 'posts',
                'id' => 873,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            72 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 565,
                'foreign_table' => 'posts',
                'id' => 874,
                'lang' => 'en',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            73 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 565,
                'foreign_table' => 'posts',
                'id' => 875,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            74 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 565,
                'foreign_table' => 'posts',
                'id' => 876,
                'lang' => 'ko',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            75 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 566,
                'foreign_table' => 'posts',
                'id' => 877,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            76 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 566,
                'foreign_table' => 'posts',
                'id' => 878,
                'lang' => 'en',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            77 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 566,
                'foreign_table' => 'posts',
                'id' => 879,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            78 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 566,
                'foreign_table' => 'posts',
                'id' => 880,
                'lang' => 'ko',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            79 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 567,
                'foreign_table' => 'posts',
                'id' => 881,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            80 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 567,
                'foreign_table' => 'posts',
                'id' => 882,
                'lang' => 'en',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            81 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 567,
                'foreign_table' => 'posts',
                'id' => 883,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            82 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 567,
                'foreign_table' => 'posts',
                'id' => 884,
                'lang' => 'ko',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            83 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 568,
                'foreign_table' => 'posts',
                'id' => 885,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            84 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 568,
                'foreign_table' => 'posts',
                'id' => 886,
                'lang' => 'en',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            85 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 568,
                'foreign_table' => 'posts',
                'id' => 887,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            86 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 568,
                'foreign_table' => 'posts',
                'id' => 888,
                'lang' => 'ko',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            87 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 569,
                'foreign_table' => 'posts',
                'id' => 889,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            88 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 569,
                'foreign_table' => 'posts',
                'id' => 890,
                'lang' => 'en',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            89 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 569,
                'foreign_table' => 'posts',
                'id' => 891,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            90 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 569,
                'foreign_table' => 'posts',
                'id' => 892,
                'lang' => 'ko',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            91 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 570,
                'foreign_table' => 'posts',
                'id' => 893,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            92 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 570,
                'foreign_table' => 'posts',
                'id' => 894,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            93 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 570,
                'foreign_table' => 'posts',
                'id' => 895,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            94 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 570,
                'foreign_table' => 'posts',
                'id' => 896,
                'lang' => 'ko',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            95 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 571,
                'foreign_table' => 'posts',
                'id' => 897,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            96 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 571,
                'foreign_table' => 'posts',
                'id' => 898,
                'lang' => 'en',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            97 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 571,
                'foreign_table' => 'posts',
                'id' => 899,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            98 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 571,
                'foreign_table' => 'posts',
                'id' => 900,
                'lang' => 'ko',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            99 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 572,
                'foreign_table' => 'posts',
                'id' => 901,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            100 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 572,
                'foreign_table' => 'posts',
                'id' => 902,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            101 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 572,
                'foreign_table' => 'posts',
                'id' => 903,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            102 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 572,
                'foreign_table' => 'posts',
                'id' => 904,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            103 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 573,
                'foreign_table' => 'posts',
                'id' => 905,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            104 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 573,
                'foreign_table' => 'posts',
                'id' => 906,
                'lang' => 'en',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            105 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 573,
                'foreign_table' => 'posts',
                'id' => 907,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            106 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 573,
                'foreign_table' => 'posts',
                'id' => 908,
                'lang' => 'ko',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            107 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 574,
                'foreign_table' => 'posts',
                'id' => 909,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            108 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 574,
                'foreign_table' => 'posts',
                'id' => 910,
                'lang' => 'en',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            109 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 574,
                'foreign_table' => 'posts',
                'id' => 911,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            110 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 574,
                'foreign_table' => 'posts',
                'id' => 912,
                'lang' => 'ko',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            111 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 575,
                'foreign_table' => 'posts',
                'id' => 913,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            112 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 575,
                'foreign_table' => 'posts',
                'id' => 914,
                'lang' => 'en',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            113 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 575,
                'foreign_table' => 'posts',
                'id' => 915,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            114 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 575,
                'foreign_table' => 'posts',
                'id' => 916,
                'lang' => 'ko',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            115 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 576,
                'foreign_table' => 'posts',
                'id' => 917,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            116 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 576,
                'foreign_table' => 'posts',
                'id' => 918,
                'lang' => 'en',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            117 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 576,
                'foreign_table' => 'posts',
                'id' => 919,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            118 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 576,
                'foreign_table' => 'posts',
                'id' => 920,
                'lang' => 'ko',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            119 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 577,
                'foreign_table' => 'posts',
                'id' => 921,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            120 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 577,
                'foreign_table' => 'posts',
                'id' => 922,
                'lang' => 'en',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            121 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 577,
                'foreign_table' => 'posts',
                'id' => 923,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            122 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 577,
                'foreign_table' => 'posts',
                'id' => 924,
                'lang' => 'ko',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            123 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 578,
                'foreign_table' => 'posts',
                'id' => 925,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            124 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 578,
                'foreign_table' => 'posts',
                'id' => 926,
                'lang' => 'en',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            125 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 578,
                'foreign_table' => 'posts',
                'id' => 927,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            126 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 578,
                'foreign_table' => 'posts',
                'id' => 928,
                'lang' => 'ko',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            127 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 579,
                'foreign_table' => 'posts',
                'id' => 929,
                'lang' => 'en',
                'translated_text' => 'Test automation en',
            ),
            128 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 579,
                'foreign_table' => 'posts',
                'id' => 930,
                'lang' => 'en',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            129 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 579,
                'foreign_table' => 'posts',
                'id' => 931,
                'lang' => 'ko',
                'translated_text' => 'Test automation ko',
            ),
            130 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 579,
                'foreign_table' => 'posts',
                'id' => 932,
                'lang' => 'ko',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            131 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 580,
                'foreign_table' => 'posts',
                'id' => 933,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            132 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 580,
                'foreign_table' => 'posts',
                'id' => 934,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            133 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 580,
                'foreign_table' => 'posts',
                'id' => 935,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            134 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 580,
                'foreign_table' => 'posts',
                'id' => 936,
                'lang' => 'ko',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
            ),
            135 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 581,
                'foreign_table' => 'posts',
                'id' => 937,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            136 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 581,
                'foreign_table' => 'posts',
                'id' => 938,
                'lang' => 'en',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            137 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 581,
                'foreign_table' => 'posts',
                'id' => 939,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            138 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 581,
                'foreign_table' => 'posts',
                'id' => 940,
                'lang' => 'ko',
                'translated_text' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
            ),
            139 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 582,
                'foreign_table' => 'posts',
                'id' => 941,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            140 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 582,
                'foreign_table' => 'posts',
                'id' => 942,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            141 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 582,
                'foreign_table' => 'posts',
                'id' => 943,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            142 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 582,
                'foreign_table' => 'posts',
                'id' => 944,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            143 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 583,
                'foreign_table' => 'posts',
                'id' => 945,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            144 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 583,
                'foreign_table' => 'posts',
                'id' => 946,
                'lang' => 'en',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            145 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 583,
                'foreign_table' => 'posts',
                'id' => 947,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            146 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 583,
                'foreign_table' => 'posts',
                'id' => 948,
                'lang' => 'ko',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
            ),
            147 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 584,
                'foreign_table' => 'posts',
                'id' => 949,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            148 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 584,
                'foreign_table' => 'posts',
                'id' => 950,
                'lang' => 'en',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            149 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 584,
                'foreign_table' => 'posts',
                'id' => 951,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            150 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 584,
                'foreign_table' => 'posts',
                'id' => 952,
                'lang' => 'ko',
                'translated_text' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
            ),
            151 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 585,
                'foreign_table' => 'posts',
                'id' => 953,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            152 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 585,
                'foreign_table' => 'posts',
                'id' => 954,
                'lang' => 'en',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            153 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 585,
                'foreign_table' => 'posts',
                'id' => 955,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            154 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 585,
                'foreign_table' => 'posts',
                'id' => 956,
                'lang' => 'ko',
                'translated_text' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
            ),
            155 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 586,
                'foreign_table' => 'posts',
                'id' => 957,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            156 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 586,
                'foreign_table' => 'posts',
                'id' => 958,
                'lang' => 'en',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            157 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 586,
                'foreign_table' => 'posts',
                'id' => 959,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            158 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 586,
                'foreign_table' => 'posts',
                'id' => 960,
                'lang' => 'ko',
                'translated_text' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
            ),
            159 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 587,
                'foreign_table' => 'posts',
                'id' => 961,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            160 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 587,
                'foreign_table' => 'posts',
                'id' => 962,
                'lang' => 'en',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            161 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 587,
                'foreign_table' => 'posts',
                'id' => 963,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            162 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 587,
                'foreign_table' => 'posts',
                'id' => 964,
                'lang' => 'ko',
                'translated_text' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            163 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 588,
                'foreign_table' => 'posts',
                'id' => 965,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            164 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 588,
                'foreign_table' => 'posts',
                'id' => 966,
                'lang' => 'en',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            165 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 588,
                'foreign_table' => 'posts',
                'id' => 967,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            166 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 588,
                'foreign_table' => 'posts',
                'id' => 968,
                'lang' => 'ko',
                'translated_text' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
            ),
            167 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 589,
                'foreign_table' => 'posts',
                'id' => 969,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            168 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 589,
                'foreign_table' => 'posts',
                'id' => 970,
                'lang' => 'en',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            169 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 589,
                'foreign_table' => 'posts',
                'id' => 971,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            170 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 589,
                'foreign_table' => 'posts',
                'id' => 972,
                'lang' => 'ko',
                'translated_text' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
            ),
            171 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 600,
                'foreign_table' => 'posts',
                'id' => 973,
                'lang' => 'en',
                'translated_text' => 'eqeqwe',
            ),
            172 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 600,
                'foreign_table' => 'posts',
                'id' => 974,
                'lang' => 'en',
                'translated_text' => 'ádasdadasda',
            ),
            173 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 88,
                'foreign_table' => 'tags',
                'id' => 991,
                'lang' => 'en',
                'translated_text' => 'test english',
            ),
            174 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 88,
                'foreign_table' => 'tags',
                'id' => 992,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_a182c443-b7ab-4de3-b1ec-4707b6259c6c',
            ),
            175 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 88,
                'foreign_table' => 'tags',
                'id' => 993,
                'lang' => 'ko',
                'translated_text' => 'test',
            ),
            176 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 88,
                'foreign_table' => 'tags',
                'id' => 994,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_38bad0c5-e152-457c-a299-bf3eb83c2cdb',
            ),
            177 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 89,
                'foreign_table' => 'tags',
                'id' => 995,
                'lang' => 'en',
                'translated_text' => 'eqwe',
            ),
            178 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 89,
                'foreign_table' => 'tags',
                'id' => 996,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_e864f419-6abe-48a2-aa11-1d8c978d4127',
            ),
            179 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 89,
                'foreign_table' => 'tags',
                'id' => 997,
                'lang' => 'ko',
                'translated_text' => 'qeqwe',
            ),
            180 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 89,
                'foreign_table' => 'tags',
                'id' => 998,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_c10a4e2f-2bdd-4157-a126-031ab680c74a',
            ),
            181 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 90,
                'foreign_table' => 'tags',
                'id' => 999,
                'lang' => 'en',
                'translated_text' => 'eqweq',
            ),
            182 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 90,
                'foreign_table' => 'tags',
                'id' => 1000,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_55f87bb8-91fc-4282-835f-48956a64e92e',
            ),
            183 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 90,
                'foreign_table' => 'tags',
                'id' => 1001,
                'lang' => 'ko',
                'translated_text' => 'ewqeqwewqe',
            ),
            184 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 90,
                'foreign_table' => 'tags',
                'id' => 1002,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_ba768d13-dc71-43ff-9f70-216b19610a6e',
            ),
            185 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 92,
                'foreign_table' => 'tags',
                'id' => 1007,
                'lang' => 'en',
                'translated_text' => 'eqweq',
            ),
            186 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 92,
                'foreign_table' => 'tags',
                'id' => 1008,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_b6cb8b87-4a13-40bc-ac3b-232d9e876fc1',
            ),
            187 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 92,
                'foreign_table' => 'tags',
                'id' => 1009,
                'lang' => 'ko',
                'translated_text' => 'eqweqwe',
            ),
            188 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 92,
                'foreign_table' => 'tags',
                'id' => 1010,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_4118a8a0-497a-4692-accd-2b773b5635bc',
            ),
            189 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 620,
                'foreign_table' => 'posts',
                'id' => 1011,
                'lang' => 'en',
                'translated_text' => 'test en',
            ),
            190 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 620,
                'foreign_table' => 'posts',
                'id' => 1012,
                'lang' => 'en',
                'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">As for the expedition facilities, regulatory standards are indicated in detail by the Fire Service Law and related laws and regulations, and the town</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">Based on these laws and regulations, we will strengthen regulations and strengthen guidance for business establishments.</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">In addition, we will promote manual preparation guidance assuming damage to dangerous goods facilities and functional</span></font></div>',
            ),
            191 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 93,
                'foreign_table' => 'tags',
                'id' => 1013,
                'lang' => 'en',
                'translated_text' => 'Thu test2',
            ),
            192 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 93,
                'foreign_table' => 'tags',
                'id' => 1014,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_6fefb85c-6c0a-40e1-b7ae-1b57e97d8e61',
            ),
            193 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 93,
                'foreign_table' => 'tags',
                'id' => 1015,
                'lang' => 'ko',
                'translated_text' => 'Thu test3',
            ),
            194 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 93,
                'foreign_table' => 'tags',
                'id' => 1016,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_33d247b2-59a1-4a53-aa31-921e49be39d2',
            ),
            195 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1017,
                'lang' => 'en',
                'translated_text' => 'Thu Notifi2',
            ),
            196 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1018,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_242b27ec-4b76-4265-9f98-74bdc4910cac',
            ),
            197 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1019,
                'lang' => 'ko',
                'translated_text' => 'Thu Notifi3',
            ),
            198 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1020,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_a9347f85-c4b3-4b0f-bafb-d9bcd933c047',
            ),
            199 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 622,
                'foreign_table' => 'posts',
                'id' => 1021,
                'lang' => 'en',
                'translated_text' => 'Minh Thu en',
            ),
            200 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 622,
                'foreign_table' => 'posts',
                'id' => 1022,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Minh Thu en</span></font>',
            ),
            201 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 622,
                'foreign_table' => 'posts',
                'id' => 1023,
                'lang' => 'ko',
                'translated_text' => 'Minh Thu ko',
            ),
            202 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 622,
                'foreign_table' => 'posts',
                'id' => 1024,
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Minh Thu ko</span></font>',
            ),
            203 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 623,
                'foreign_table' => 'posts',
                'id' => 1025,
                'lang' => 'en',
                'translated_text' => 'Test P9 en',
            ),
            204 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 623,
                'foreign_table' => 'posts',
                'id' => 1026,
                'lang' => 'en',
                'translated_text' => 'Hello Thu',
            ),
            205 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 623,
                'foreign_table' => 'posts',
                'id' => 1027,
                'lang' => 'zh',
                'translated_text' => 'Test P9 zh',
            ),
            206 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 623,
                'foreign_table' => 'posts',
                'id' => 1028,
                'lang' => 'zh',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Tieng Trung</span></font>',
            ),
            207 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 624,
                'foreign_table' => 'posts',
                'id' => 1029,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            208 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 624,
                'foreign_table' => 'posts',
                'id' => 1030,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            209 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 624,
                'foreign_table' => 'posts',
                'id' => 1031,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            210 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 624,
                'foreign_table' => 'posts',
                'id' => 1032,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            211 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 625,
                'foreign_table' => 'posts',
                'id' => 1033,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            212 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 625,
                'foreign_table' => 'posts',
                'id' => 1034,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            213 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 625,
                'foreign_table' => 'posts',
                'id' => 1035,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            214 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 625,
                'foreign_table' => 'posts',
                'id' => 1036,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            215 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 626,
                'foreign_table' => 'posts',
                'id' => 1037,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            216 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 626,
                'foreign_table' => 'posts',
                'id' => 1038,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            217 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 626,
                'foreign_table' => 'posts',
                'id' => 1039,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            218 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 626,
                'foreign_table' => 'posts',
                'id' => 1040,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            219 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 628,
                'foreign_table' => 'posts',
                'id' => 1041,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果',
            ),
            220 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 628,
                'foreign_table' => 'posts',
                'id' => 1042,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果

[@body]

xzt',
            ),
            221 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 623,
                'foreign_table' => 'posts',
                'id' => 1043,
                'lang' => 'ko',
                'translated_text' => 'Test P9 ko',
            ),
            222 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 623,
                'foreign_table' => 'posts',
                'id' => 1044,
                'lang' => 'ko',
                'translated_text' => '<span style="font-size: 13.3333px;">필요가있는 경우에는 사업장의 관리자 등에 대하여 재해 방지에 필요한 조언이나지도를 실시한다.</span>',
            ),
            223 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 24,
                'foreign_table' => 'weathers',
                'id' => 1045,
                'lang' => 'en',
                'translated_text' => 'thoi tiet hom nay en',
            ),
            224 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 24,
                'foreign_table' => 'weathers',
                'id' => 1046,
                'lang' => 'en',
                'translated_text' => 'body thoi tiet hom nay en',
            ),
            225 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 24,
                'foreign_table' => 'weathers',
                'id' => 1047,
                'lang' => 'zh',
                'translated_text' => 'body thoi tiet hom nay zh',
            ),
            226 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 24,
                'foreign_table' => 'weathers',
                'id' => 1048,
                'lang' => 'zh',
                'translated_text' => 'body thoi tiet hom nay zh',
            ),
            227 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 25,
                'foreign_table' => 'weathers',
                'id' => 1049,
                'lang' => 'en',
                'translated_text' => '11111111111111111 en',
            ),
            228 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 25,
                'foreign_table' => 'weathers',
                'id' => 1050,
                'lang' => 'en',
                'translated_text' => '11111111111111111 en',
            ),
            229 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 26,
                'foreign_table' => 'weathers',
                'id' => 1051,
                'lang' => 'zh',
                'translated_text' => '22222222222 zh',
            ),
            230 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 26,
                'foreign_table' => 'weathers',
                'id' => 1052,
                'lang' => 'zh',
                'translated_text' => '22222222222 zh',
            ),
            231 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 27,
                'foreign_table' => 'weathers',
                'id' => 1053,
                'lang' => 'ko',
                'translated_text' => '33333333333 ko',
            ),
            232 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 27,
                'foreign_table' => 'weathers',
                'id' => 1054,
                'lang' => 'ko',
                'translated_text' => '33333333333 ko',
            ),
            233 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 28,
                'foreign_table' => 'weathers',
                'id' => 1055,
                'lang' => 'zh',
                'translated_text' => '4444444444444 zh',
            ),
            234 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 28,
                'foreign_table' => 'weathers',
                'id' => 1056,
                'lang' => 'zh',
                'translated_text' => '4444444444444 zh',
            ),
            235 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 29,
                'foreign_table' => 'weathers',
                'id' => 1057,
                'lang' => 'en',
                'translated_text' => '555555 en',
            ),
            236 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 29,
                'foreign_table' => 'weathers',
                'id' => 1058,
                'lang' => 'en',
                'translated_text' => '555555 en',
            ),
            237 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 29,
                'foreign_table' => 'weathers',
                'id' => 1059,
                'lang' => 'zh',
                'translated_text' => '555555 zh',
            ),
            238 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 29,
                'foreign_table' => 'weathers',
                'id' => 1060,
                'lang' => 'zh',
                'translated_text' => '555555 zh',
            ),
            239 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 30,
                'foreign_table' => 'weathers',
                'id' => 1061,
                'lang' => 'en',
                'translated_text' => '7777777 en',
            ),
            240 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 30,
                'foreign_table' => 'weathers',
                'id' => 1062,
                'lang' => 'en',
                'translated_text' => '7777777 en',
            ),
            241 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 31,
                'foreign_table' => 'weathers',
                'id' => 1063,
                'lang' => 'ko',
                'translated_text' => '888888888 ko',
            ),
            242 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 31,
                'foreign_table' => 'weathers',
                'id' => 1064,
                'lang' => 'ko',
                'translated_text' => '888888888 ko',
            ),
            243 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 32,
                'foreign_table' => 'weathers',
                'id' => 1065,
                'lang' => 'zh',
                'translated_text' => '999999 zh',
            ),
            244 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 32,
                'foreign_table' => 'weathers',
                'id' => 1066,
                'lang' => 'zh',
                'translated_text' => '999999 zh',
            ),
            245 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 33,
                'foreign_table' => 'weathers',
                'id' => 1067,
                'lang' => 'en',
                'translated_text' => '1000000000000 en',
            ),
            246 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 33,
                'foreign_table' => 'weathers',
                'id' => 1068,
                'lang' => 'en',
                'translated_text' => '1000000000000 en',
            ),
            247 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 33,
                'foreign_table' => 'weathers',
                'id' => 1069,
                'lang' => 'ko',
                'translated_text' => '1000000000000 ko',
            ),
            248 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 33,
                'foreign_table' => 'weathers',
                'id' => 1070,
                'lang' => 'ko',
                'translated_text' => '1000000000000 ko',
            ),
            249 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 34,
                'foreign_table' => 'weathers',
                'id' => 1071,
                'lang' => 'zh',
                'translated_text' => 'Muoi Mot zh',
            ),
            250 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 34,
                'foreign_table' => 'weathers',
                'id' => 1072,
                'lang' => 'zh',
                'translated_text' => 'Muoi Mot zh',
            ),
            251 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 35,
                'foreign_table' => 'weathers',
                'id' => 1073,
                'lang' => 'en',
                'translated_text' => 'Muoi Hai en',
            ),
            252 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 35,
                'foreign_table' => 'weathers',
                'id' => 1074,
                'lang' => 'en',
                'translated_text' => 'Muoi Hai en',
            ),
            253 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 36,
                'foreign_table' => 'weathers',
                'id' => 1075,
                'lang' => 'en',
                'translated_text' => 'Hom nay troi nang en',
            ),
            254 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 36,
                'foreign_table' => 'weathers',
                'id' => 1076,
                'lang' => 'en',
                'translated_text' => 'Hom nay troi nang en',
            ),
            255 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 37,
                'foreign_table' => 'weathers',
                'id' => 1077,
                'lang' => 'en',
                'translated_text' => 'Mat qua en',
            ),
            256 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 37,
                'foreign_table' => 'weathers',
                'id' => 1078,
                'lang' => 'en',
                'translated_text' => 'Mat qua en',
            ),
            257 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 37,
                'foreign_table' => 'weathers',
                'id' => 1079,
                'lang' => 'zh',
                'translated_text' => 'Mat qua zh',
            ),
            258 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 37,
                'foreign_table' => 'weathers',
                'id' => 1080,
                'lang' => 'zh',
                'translated_text' => 'Mat qua zh',
            ),
            259 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 38,
                'foreign_table' => 'weathers',
                'id' => 1081,
                'lang' => 'ko',
                'translated_text' => 'Hom nay troi khong mua ko',
            ),
            260 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 38,
                'foreign_table' => 'weathers',
                'id' => 1082,
                'lang' => 'ko',
                'translated_text' => 'Hom nay troi khong mua ko',
            ),
            261 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 39,
                'foreign_table' => 'weathers',
                'id' => 1083,
                'lang' => 'en',
                'translated_text' => 'Nhiet do giam manh en',
            ),
            262 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 39,
                'foreign_table' => 'weathers',
                'id' => 1084,
                'lang' => 'en',
                'translated_text' => 'Nhiet do giam manh en',
            ),
            263 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 40,
                'foreign_table' => 'weathers',
                'id' => 1085,
                'lang' => 'en',
                'translated_text' => 'Gio to en',
            ),
            264 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 40,
                'foreign_table' => 'weathers',
                'id' => 1086,
                'lang' => 'en',
                'translated_text' => 'Gio to en',
            ),
            265 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 41,
                'foreign_table' => 'weathers',
                'id' => 1087,
                'lang' => 'en',
                'translated_text' => 'Troi chuyen nang en',
            ),
            266 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 41,
                'foreign_table' => 'weathers',
                'id' => 1088,
                'lang' => 'en',
                'translated_text' => 'Troi chuyen nang en',
            ),
            267 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 42,
                'foreign_table' => 'weathers',
                'id' => 1089,
                'lang' => 'en',
                'translated_text' => 'Mua dong dai rac en',
            ),
            268 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 42,
                'foreign_table' => 'weathers',
                'id' => 1090,
                'lang' => 'en',
                'translated_text' => 'Mua dong dai rac en',
            ),
            269 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 43,
                'foreign_table' => 'weathers',
                'id' => 1091,
                'lang' => 'en',
                'translated_text' => 'nang nong keo dai en',
            ),
            270 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 43,
                'foreign_table' => 'weathers',
                'id' => 1092,
                'lang' => 'en',
                'translated_text' => 'nang nong keo dai en',
            ),
            271 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 44,
                'foreign_table' => 'weathers',
                'id' => 1093,
                'lang' => 'en',
                'translated_text' => 'Them nhiet giam manh en',
            ),
            272 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 44,
                'foreign_table' => 'weathers',
                'id' => 1094,
                'lang' => 'en',
                'translated_text' => 'Them nhiet giam manh en',
            ),
            273 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 45,
                'foreign_table' => 'weathers',
                'id' => 1095,
                'lang' => 'en',
                'translated_text' => 'Sam set en',
            ),
            274 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 45,
                'foreign_table' => 'weathers',
                'id' => 1096,
                'lang' => 'en',
                'translated_text' => 'Sam set en',
            ),
            275 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 46,
                'foreign_table' => 'weathers',
                'id' => 1097,
                'lang' => 'en',
                'translated_text' => 'Dong Loc keo den en',
            ),
            276 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 46,
                'foreign_table' => 'weathers',
                'id' => 1098,
                'lang' => 'en',
                'translated_text' => 'Dong Loc keo den en',
            ),
            277 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 47,
                'foreign_table' => 'weathers',
                'id' => 1099,
                'lang' => 'en',
                'translated_text' => 'Nen nhiet tang dan en',
            ),
            278 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 47,
                'foreign_table' => 'weathers',
                'id' => 1100,
                'lang' => 'en',
                'translated_text' => 'Nen nhiet tang dan en',
            ),
            279 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 48,
                'foreign_table' => 'weathers',
                'id' => 1101,
                'lang' => 'en',
                'translated_text' => 'Sap co mua dong en',
            ),
            280 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 48,
                'foreign_table' => 'weathers',
                'id' => 1102,
                'lang' => 'en',
                'translated_text' => 'Sap co mua dong en',
            ),
            281 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 49,
                'foreign_table' => 'weathers',
                'id' => 1103,
                'lang' => 'en',
                'translated_text' => 'Mua phun en',
            ),
            282 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 49,
                'foreign_table' => 'weathers',
                'id' => 1104,
                'lang' => 'en',
                'translated_text' => 'Mua phun en',
            ),
            283 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 50,
                'foreign_table' => 'weathers',
                'id' => 1105,
                'lang' => 'en',
                'translated_text' => 'Gio dong bac en',
            ),
            284 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 50,
                'foreign_table' => 'weathers',
                'id' => 1106,
                'lang' => 'en',
                'translated_text' => 'Gio dong bac en',
            ),
            285 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 51,
                'foreign_table' => 'weathers',
                'id' => 1107,
                'lang' => 'en',
                'translated_text' => 'Hieu ung nha kinh en',
            ),
            286 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 51,
                'foreign_table' => 'weathers',
                'id' => 1108,
                'lang' => 'en',
                'translated_text' => 'Hieu ung nha kinh en',
            ),
            287 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 52,
                'foreign_table' => 'weathers',
                'id' => 1109,
                'lang' => 'en',
                'translated_text' => 'Gio lao en',
            ),
            288 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 52,
                'foreign_table' => 'weathers',
                'id' => 1110,
                'lang' => 'en',
                'translated_text' => 'Gio lao en',
            ),
            289 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 53,
                'foreign_table' => 'weathers',
                'id' => 1111,
                'lang' => 'en',
                'translated_text' => 'Chuyen mua dong rai rac en',
            ),
            290 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 53,
                'foreign_table' => 'weathers',
                'id' => 1112,
                'lang' => 'en',
                'translated_text' => 'Chuyen mua dong rai rac en',
            ),
            291 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 54,
                'foreign_table' => 'weathers',
                'id' => 1113,
                'lang' => 'en',
                'translated_text' => 'Nong keo dai en',
            ),
            292 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 54,
                'foreign_table' => 'weathers',
                'id' => 1114,
                'lang' => 'en',
                'translated_text' => 'Nong keo dai en',
            ),
            293 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 55,
                'foreign_table' => 'weathers',
                'id' => 1115,
                'lang' => 'en',
                'translated_text' => 'nang len roi en',
            ),
            294 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 55,
                'foreign_table' => 'weathers',
                'id' => 1116,
                'lang' => 'en',
                'translated_text' => 'nang len roi en',
            ),
            295 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 638,
                'foreign_table' => 'posts',
                'id' => 1117,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            296 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 638,
                'foreign_table' => 'posts',
                'id' => 1118,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            297 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 638,
                'foreign_table' => 'posts',
                'id' => 1119,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            298 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 638,
                'foreign_table' => 'posts',
                'id' => 1120,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            299 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 639,
                'foreign_table' => 'posts',
                'id' => 1121,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            300 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 639,
                'foreign_table' => 'posts',
                'id' => 1122,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            301 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 639,
                'foreign_table' => 'posts',
                'id' => 1123,
                'lang' => 'ko',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            302 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 639,
                'foreign_table' => 'posts',
                'id' => 1124,
                'lang' => 'ko',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            303 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 640,
                'foreign_table' => 'posts',
                'id' => 1125,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            304 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 640,
                'foreign_table' => 'posts',
                'id' => 1126,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            305 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 640,
                'foreign_table' => 'posts',
                'id' => 1127,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            306 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 640,
                'foreign_table' => 'posts',
                'id' => 1128,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            307 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 641,
                'foreign_table' => 'posts',
                'id' => 1129,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            308 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 641,
                'foreign_table' => 'posts',
                'id' => 1130,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            309 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 641,
                'foreign_table' => 'posts',
                'id' => 1131,
                'lang' => 'ko',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            310 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 641,
                'foreign_table' => 'posts',
                'id' => 1132,
                'lang' => 'ko',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            311 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 642,
                'foreign_table' => 'posts',
                'id' => 1133,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            312 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 642,
                'foreign_table' => 'posts',
                'id' => 1134,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            313 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 642,
                'foreign_table' => 'posts',
                'id' => 1135,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            314 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 642,
                'foreign_table' => 'posts',
                'id' => 1136,
                'lang' => 'ko',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            315 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 643,
                'foreign_table' => 'posts',
                'id' => 1137,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            316 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 643,
                'foreign_table' => 'posts',
                'id' => 1138,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            317 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 643,
                'foreign_table' => 'posts',
                'id' => 1139,
                'lang' => 'ko',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            318 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 643,
                'foreign_table' => 'posts',
                'id' => 1140,
                'lang' => 'ko',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
            ),
            319 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 647,
                'foreign_table' => 'posts',
                'id' => 1141,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            320 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 647,
                'foreign_table' => 'posts',
                'id' => 1142,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

zxc',
            ),
            321 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 651,
                'foreign_table' => 'posts',
                'id' => 1143,
                'lang' => 'en',
                'translated_text' => '【告知】えこ之助と一緒に！「ほっかいどう・省エネ３Ｓキャンペーン」夏の陣',
            ),
            322 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 651,
                'foreign_table' => 'posts',
                'id' => 1144,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            323 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 652,
                'foreign_table' => 'posts',
                'id' => 1145,
                'lang' => 'en',
            'translated_text' => '【催し】令和元年度(2019年度)景観の日パネル展',
            ),
            324 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 652,
                'foreign_table' => 'posts',
                'id' => 1146,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            325 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 653,
                'foreign_table' => 'posts',
                'id' => 1147,
                'lang' => 'en',
                'translated_text' => '【その他】公有水面埋立免許（変更）許可申請書等の告示・縦覧のお知らせ',
            ),
            326 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 653,
                'foreign_table' => 'posts',
                'id' => 1148,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            327 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 654,
                'foreign_table' => 'posts',
                'id' => 1149,
                'lang' => 'en',
                'translated_text' => '【催し】ほっかいどうナイスハートフェアのお知らせ（障がい者保健福祉課）',
            ),
            328 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 654,
                'foreign_table' => 'posts',
                'id' => 1150,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            329 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 655,
                'foreign_table' => 'posts',
                'id' => 1151,
                'lang' => 'en',
                'translated_text' => '【告知】北海道ミライノート',
            ),
            330 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 655,
                'foreign_table' => 'posts',
                'id' => 1152,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            331 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 656,
                'foreign_table' => 'posts',
                'id' => 1153,
                'lang' => 'en',
                'translated_text' => '【募集】北海道インフラツアー',
            ),
            332 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 656,
                'foreign_table' => 'posts',
                'id' => 1154,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            333 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 657,
                'foreign_table' => 'posts',
                'id' => 1155,
                'lang' => 'en',
                'translated_text' => '【その他】道路維持管理　北海道告示（道路関係）',
            ),
            334 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 657,
                'foreign_table' => 'posts',
                'id' => 1156,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            335 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 658,
                'foreign_table' => 'posts',
                'id' => 1157,
                'lang' => 'en',
                'translated_text' => '【募集】北海道とつながるカフェ参加者募集中',
            ),
            336 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 658,
                'foreign_table' => 'posts',
                'id' => 1158,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            337 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 659,
                'foreign_table' => 'posts',
                'id' => 1159,
                'lang' => 'en',
                'translated_text' => '【その他】知事定例記者会見（令和元年5月22日）',
            ),
            338 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 659,
                'foreign_table' => 'posts',
                'id' => 1160,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            339 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 660,
                'foreign_table' => 'posts',
                'id' => 1161,
                'lang' => 'en',
                'translated_text' => '【入札】公募型プロポーザルの実施について（江差高看）',
            ),
            340 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 660,
                'foreign_table' => 'posts',
                'id' => 1162,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            341 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 661,
                'foreign_table' => 'posts',
                'id' => 1163,
                'lang' => 'en',
                'translated_text' => '【入札】一般競争入札の実施について（道庁行政情報ネットワーク機器の賃貸借その１）',
            ),
            342 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 661,
                'foreign_table' => 'posts',
                'id' => 1164,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            343 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 662,
                'foreign_table' => 'posts',
                'id' => 1165,
                'lang' => 'en',
                'translated_text' => '【告知】告示（測量法に関する「諸手続」に係る通知）',
            ),
            344 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 662,
                'foreign_table' => 'posts',
                'id' => 1166,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            345 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 663,
                'foreign_table' => 'posts',
                'id' => 1167,
                'lang' => 'en',
                'translated_text' => '【告知】北海道クールあいらんどキャンペーン',
            ),
            346 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 663,
                'foreign_table' => 'posts',
                'id' => 1168,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            347 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 664,
                'foreign_table' => 'posts',
                'id' => 1169,
                'lang' => 'en',
                'translated_text' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）',
            ),
            348 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 664,
                'foreign_table' => 'posts',
                'id' => 1170,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            349 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 665,
                'foreign_table' => 'posts',
                'id' => 1171,
                'lang' => 'en',
                'translated_text' => '【募集】審議会委員の募集',
            ),
            350 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 665,
                'foreign_table' => 'posts',
                'id' => 1172,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            351 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 667,
                'foreign_table' => 'posts',
                'id' => 1173,
                'lang' => 'en',
                'translated_text' => '【入札】大学法人室トップページ（公立大学法人に関する情報）',
            ),
            352 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 667,
                'foreign_table' => 'posts',
                'id' => 1174,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            353 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 668,
                'foreign_table' => 'posts',
                'id' => 1175,
                'lang' => 'en',
            'translated_text' => '【催し】令和元年度(2019年度)景観の日パネル展',
            ),
            354 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 668,
                'foreign_table' => 'posts',
                'id' => 1176,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            355 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 669,
                'foreign_table' => 'posts',
                'id' => 1177,
                'lang' => 'en',
                'translated_text' => '【その他】公有水面埋立免許（変更）許可申請書等の告示・縦覧のお知らせ',
            ),
            356 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 669,
                'foreign_table' => 'posts',
                'id' => 1178,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            357 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 670,
                'foreign_table' => 'posts',
                'id' => 1179,
                'lang' => 'en',
                'translated_text' => '【催し】ほっかいどうナイスハートフェアのお知らせ（障がい者保健福祉課）',
            ),
            358 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 670,
                'foreign_table' => 'posts',
                'id' => 1180,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            359 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 671,
                'foreign_table' => 'posts',
                'id' => 1181,
                'lang' => 'en',
                'translated_text' => '【告知】北海道ミライノート',
            ),
            360 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 671,
                'foreign_table' => 'posts',
                'id' => 1182,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            361 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 672,
                'foreign_table' => 'posts',
                'id' => 1183,
                'lang' => 'en',
                'translated_text' => '【募集】北海道インフラツアー',
            ),
            362 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 672,
                'foreign_table' => 'posts',
                'id' => 1184,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            363 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 673,
                'foreign_table' => 'posts',
                'id' => 1185,
                'lang' => 'en',
                'translated_text' => '【その他】道路維持管理　北海道告示（道路関係）',
            ),
            364 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 673,
                'foreign_table' => 'posts',
                'id' => 1186,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            365 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 674,
                'foreign_table' => 'posts',
                'id' => 1187,
                'lang' => 'en',
                'translated_text' => '【募集】北海道とつながるカフェ参加者募集中',
            ),
            366 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 674,
                'foreign_table' => 'posts',
                'id' => 1188,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            367 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 675,
                'foreign_table' => 'posts',
                'id' => 1189,
                'lang' => 'en',
                'translated_text' => '【その他】知事定例記者会見（令和元年5月22日）',
            ),
            368 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 675,
                'foreign_table' => 'posts',
                'id' => 1190,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            369 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 676,
                'foreign_table' => 'posts',
                'id' => 1191,
                'lang' => 'en',
                'translated_text' => '【入札】公募型プロポーザルの実施について（江差高看）',
            ),
            370 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 676,
                'foreign_table' => 'posts',
                'id' => 1192,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            371 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 677,
                'foreign_table' => 'posts',
                'id' => 1193,
                'lang' => 'en',
                'translated_text' => '【入札】一般競争入札の実施について（道庁行政情報ネットワーク機器の賃貸借その１）',
            ),
            372 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 677,
                'foreign_table' => 'posts',
                'id' => 1194,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            373 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 678,
                'foreign_table' => 'posts',
                'id' => 1195,
                'lang' => 'en',
                'translated_text' => '【告知】告示（測量法に関する「諸手続」に係る通知）',
            ),
            374 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 678,
                'foreign_table' => 'posts',
                'id' => 1196,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            375 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 679,
                'foreign_table' => 'posts',
                'id' => 1197,
                'lang' => 'en',
                'translated_text' => '【告知】北海道クールあいらんどキャンペーン',
            ),
            376 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 679,
                'foreign_table' => 'posts',
                'id' => 1198,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            377 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 680,
                'foreign_table' => 'posts',
                'id' => 1199,
                'lang' => 'en',
                'translated_text' => '【入札】大学法人室トップページ（公立大学法人に関する情報）',
            ),
            378 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 680,
                'foreign_table' => 'posts',
                'id' => 1200,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            379 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 681,
                'foreign_table' => 'posts',
                'id' => 1201,
                'lang' => 'en',
                'translated_text' => '【募集】審議会委員の募集',
            ),
            380 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 681,
                'foreign_table' => 'posts',
                'id' => 1202,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            381 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 682,
                'foreign_table' => 'posts',
                'id' => 1203,
                'lang' => 'en',
                'translated_text' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）',
            ),
            382 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 682,
                'foreign_table' => 'posts',
                'id' => 1204,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            383 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 695,
                'foreign_table' => 'posts',
                'id' => 1205,
                'lang' => 'en',
                'translated_text' => 'english title',
            ),
            384 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 695,
                'foreign_table' => 'posts',
                'id' => 1206,
                'lang' => 'en',
                'translated_text' => '
<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            385 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 695,
                'foreign_table' => 'posts',
                'id' => 1207,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            386 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 695,
                'foreign_table' => 'posts',
                'id' => 1208,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

zxc',
            ),
            387 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 696,
                'foreign_table' => 'posts',
                'id' => 1209,
                'lang' => 'en',
                'translated_text' => 'english title',
            ),
            388 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 696,
                'foreign_table' => 'posts',
                'id' => 1210,
                'lang' => 'en',
                'translated_text' => '
<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            389 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 696,
                'foreign_table' => 'posts',
                'id' => 1211,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            390 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 696,
                'foreign_table' => 'posts',
                'id' => 1212,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

zxc',
            ),
            391 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 697,
                'foreign_table' => 'posts',
                'id' => 1213,
                'lang' => 'en',
                'translated_text' => 'english title',
            ),
            392 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 697,
                'foreign_table' => 'posts',
                'id' => 1214,
                'lang' => 'en',
                'translated_text' => '
<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            393 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 697,
                'foreign_table' => 'posts',
                'id' => 1215,
                'lang' => 'ko',
                'translated_text' => 'korean title',
            ),
            394 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 697,
                'foreign_table' => 'posts',
                'id' => 1216,
                'lang' => 'ko',
                'translated_text' => 'http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

zxc',
            ),
            395 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 698,
                'foreign_table' => 'posts',
                'id' => 1217,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            396 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 698,
                'foreign_table' => 'posts',
                'id' => 1218,
                'lang' => 'en',
                'translated_text' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            397 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 698,
                'foreign_table' => 'posts',
                'id' => 1219,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            398 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 698,
                'foreign_table' => 'posts',
                'id' => 1220,
                'lang' => 'ko',
                'translated_text' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            399 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 699,
                'foreign_table' => 'posts',
                'id' => 1221,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            400 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 699,
                'foreign_table' => 'posts',
                'id' => 1222,
                'lang' => 'en',
                'translated_text' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            401 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 699,
                'foreign_table' => 'posts',
                'id' => 1223,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            402 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 699,
                'foreign_table' => 'posts',
                'id' => 1224,
                'lang' => 'ko',
                'translated_text' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            403 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 700,
                'foreign_table' => 'posts',
                'id' => 1225,
                'lang' => 'en',
                'translated_text' => 'title en',
            ),
            404 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 700,
                'foreign_table' => 'posts',
                'id' => 1226,
                'lang' => 'en',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            405 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 700,
                'foreign_table' => 'posts',
                'id' => 1227,
                'lang' => 'ko',
                'translated_text' => 'Title ko',
            ),
            406 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 700,
                'foreign_table' => 'posts',
                'id' => 1228,
                'lang' => 'ko',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            407 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 701,
                'foreign_table' => 'posts',
                'id' => 1229,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            408 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 701,
                'foreign_table' => 'posts',
                'id' => 1230,
                'lang' => 'en',
                'translated_text' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            409 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 701,
                'foreign_table' => 'posts',
                'id' => 1231,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            410 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 701,
                'foreign_table' => 'posts',
                'id' => 1232,
                'lang' => 'ko',
                'translated_text' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            411 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 702,
                'foreign_table' => 'posts',
                'id' => 1233,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            412 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 702,
                'foreign_table' => 'posts',
                'id' => 1234,
                'lang' => 'en',
                'translated_text' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            413 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 702,
                'foreign_table' => 'posts',
                'id' => 1235,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            414 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 702,
                'foreign_table' => 'posts',
                'id' => 1236,
                'lang' => 'ko',
                'translated_text' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            415 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 703,
                'foreign_table' => 'posts',
                'id' => 1237,
                'lang' => 'en',
                'translated_text' => 'Chao thu en',
            ),
            416 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 703,
                'foreign_table' => 'posts',
                'id' => 1238,
                'lang' => 'en',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            417 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 703,
                'foreign_table' => 'posts',
                'id' => 1239,
                'lang' => 'ko',
                'translated_text' => 'Chao thu ko',
            ),
            418 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 703,
                'foreign_table' => 'posts',
                'id' => 1240,
                'lang' => 'ko',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            419 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 704,
                'foreign_table' => 'posts',
                'id' => 1241,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            420 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 704,
                'foreign_table' => 'posts',
                'id' => 1242,
                'lang' => 'en',
                'translated_text' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            421 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 704,
                'foreign_table' => 'posts',
                'id' => 1243,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            422 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 704,
                'foreign_table' => 'posts',
                'id' => 1244,
                'lang' => 'ko',
                'translated_text' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
            ),
            423 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 705,
                'foreign_table' => 'posts',
                'id' => 1245,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            424 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 705,
                'foreign_table' => 'posts',
                'id' => 1246,
                'lang' => 'en',
                'translated_text' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            425 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 705,
                'foreign_table' => 'posts',
                'id' => 1247,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            426 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 705,
                'foreign_table' => 'posts',
                'id' => 1248,
                'lang' => 'ko',
                'translated_text' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
            ),
            427 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 706,
                'foreign_table' => 'posts',
                'id' => 1249,
                'lang' => 'en',
                'translated_text' => 'Lan Cuoi en',
            ),
            428 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 706,
                'foreign_table' => 'posts',
                'id' => 1250,
                'lang' => 'en',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            429 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 706,
                'foreign_table' => 'posts',
                'id' => 1251,
                'lang' => 'ko',
                'translated_text' => 'Lan Cuoi ko',
            ),
            430 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 706,
                'foreign_table' => 'posts',
                'id' => 1252,
                'lang' => 'ko',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
            ),
            431 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 713,
                'foreign_table' => 'posts',
                'id' => 1253,
                'lang' => 'en',
                'translated_text' => 'tieng anh ne',
            ),
            432 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 713,
                'foreign_table' => 'posts',
                'id' => 1254,
                'lang' => 'en',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ

[@body]

xzt',
            ),
            433 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 714,
                'foreign_table' => 'posts',
                'id' => 1255,
                'lang' => 'en',
                'translated_text' => '【その他】指定、届出等の告示一覧',
            ),
            434 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 714,
                'foreign_table' => 'posts',
                'id' => 1256,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            435 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 715,
                'foreign_table' => 'posts',
                'id' => 1257,
                'lang' => 'en',
                'translated_text' => '【その他】人づくりを通した国際貢献',
            ),
            436 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 715,
                'foreign_table' => 'posts',
                'id' => 1258,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            437 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 716,
                'foreign_table' => 'posts',
                'id' => 1259,
                'lang' => 'en',
                'translated_text' => '【入札】研究法人室',
            ),
            438 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 716,
                'foreign_table' => 'posts',
                'id' => 1260,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            439 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 717,
                'foreign_table' => 'posts',
                'id' => 1261,
                'lang' => 'en',
                'translated_text' => '【募集】食関連産業室トップページ',
            ),
            440 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 717,
                'foreign_table' => 'posts',
                'id' => 1262,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            441 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 718,
                'foreign_table' => 'posts',
                'id' => 1263,
                'lang' => 'en',
                'translated_text' => '【告知】土木のお仕事のページ',
            ),
            442 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 718,
                'foreign_table' => 'posts',
                'id' => 1264,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            443 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 719,
                'foreign_table' => 'posts',
                'id' => 1265,
                'lang' => 'en',
                'translated_text' => '【告知】自動車税の納期限は５月３１日（金）です',
            ),
            444 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 719,
                'foreign_table' => 'posts',
                'id' => 1266,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            445 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 720,
                'foreign_table' => 'posts',
                'id' => 1267,
                'lang' => 'en',
                'translated_text' => '【その他】食中毒警報発令情報',
            ),
            446 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 720,
                'foreign_table' => 'posts',
                'id' => 1268,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            447 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 721,
                'foreign_table' => 'posts',
                'id' => 1269,
                'lang' => 'en',
                'translated_text' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集',
            ),
            448 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 721,
                'foreign_table' => 'posts',
                'id' => 1270,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            449 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 722,
                'foreign_table' => 'posts',
                'id' => 1271,
                'lang' => 'en',
                'translated_text' => '【入札】H31ベッドサイドモニタ賃貸借契約',
            ),
            450 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 722,
                'foreign_table' => 'posts',
                'id' => 1272,
                'lang' => 'en',
                'translated_text' => 'xcv

ads',
            ),
            451 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 723,
                'foreign_table' => 'posts',
                'id' => 1273,
                'lang' => 'en',
                'translated_text' => '【その他】指定、届出等の告示一覧',
            ),
            452 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 723,
                'foreign_table' => 'posts',
                'id' => 1274,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            453 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 724,
                'foreign_table' => 'posts',
                'id' => 1275,
                'lang' => 'en',
                'translated_text' => '【その他】人づくりを通した国際貢献',
            ),
            454 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 724,
                'foreign_table' => 'posts',
                'id' => 1276,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            455 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 725,
                'foreign_table' => 'posts',
                'id' => 1277,
                'lang' => 'en',
                'translated_text' => '【入札】研究法人室',
            ),
            456 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 725,
                'foreign_table' => 'posts',
                'id' => 1278,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            457 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 726,
                'foreign_table' => 'posts',
                'id' => 1279,
                'lang' => 'en',
                'translated_text' => '【募集】食関連産業室トップページ',
            ),
            458 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 726,
                'foreign_table' => 'posts',
                'id' => 1280,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            459 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 727,
                'foreign_table' => 'posts',
                'id' => 1281,
                'lang' => 'en',
                'translated_text' => '【告知】土木のお仕事のページ',
            ),
            460 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 727,
                'foreign_table' => 'posts',
                'id' => 1282,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            461 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 728,
                'foreign_table' => 'posts',
                'id' => 1283,
                'lang' => 'en',
                'translated_text' => '【告知】自動車税の納期限は５月３１日（金）です',
            ),
            462 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 728,
                'foreign_table' => 'posts',
                'id' => 1284,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            463 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 729,
                'foreign_table' => 'posts',
                'id' => 1285,
                'lang' => 'en',
                'translated_text' => '【その他】食中毒警報発令情報',
            ),
            464 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 729,
                'foreign_table' => 'posts',
                'id' => 1286,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            465 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 730,
                'foreign_table' => 'posts',
                'id' => 1287,
                'lang' => 'en',
                'translated_text' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集',
            ),
            466 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 730,
                'foreign_table' => 'posts',
                'id' => 1288,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            467 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 731,
                'foreign_table' => 'posts',
                'id' => 1289,
                'lang' => 'en',
                'translated_text' => '【入札】H31ベッドサイドモニタ賃貸借契約',
            ),
            468 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 731,
                'foreign_table' => 'posts',
                'id' => 1290,
                'lang' => 'en',
                'translated_text' => 'xyz

abc',
            ),
            469 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 60,
                'foreign_table' => 'weathers',
                'id' => 1291,
                'lang' => 'en',
                'translated_text' => 'Trơi nang nóng qua',
            ),
            470 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 60,
                'foreign_table' => 'weathers',
                'id' => 1292,
                'lang' => 'en',
                'translated_text' => 'Trơi nang nóng qua',
            ),
            471 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 783,
                'foreign_table' => 'posts',
                'id' => 1297,
                'lang' => 'en',
                'translated_text' => 'Post en 1',
            ),
            472 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 783,
                'foreign_table' => 'posts',
                'id' => 1298,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post en 1</span></font>',
            ),
            473 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 784,
                'foreign_table' => 'posts',
                'id' => 1299,
                'lang' => 'en',
                'translated_text' => 'post en 2',
            ),
            474 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 784,
                'foreign_table' => 'posts',
                'id' => 1300,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">post en 2</span></font>',
            ),
            475 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 61,
                'foreign_table' => 'weathers',
                'id' => 1301,
                'lang' => 'en',
                'translated_text' => 'Thơi tiet hom nay that dep en',
            ),
            476 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 61,
                'foreign_table' => 'weathers',
                'id' => 1302,
                'lang' => 'en',
                'translated_text' => 'Thơi tiet hom nay that dep en',
            ),
            477 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 95,
                'foreign_table' => 'tags',
                'id' => 1303,
                'lang' => 'en',
                'translated_text' => '人生',
            ),
            478 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 95,
                'foreign_table' => 'tags',
                'id' => 1304,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_87ac7014-0073-4a10-9e6b-c05e64d8a336',
            ),
            479 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 95,
                'foreign_table' => 'tags',
                'id' => 1305,
                'lang' => 'zh',
                'translated_text' => '人生',
            ),
            480 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 95,
                'foreign_table' => 'tags',
                'id' => 1306,
                'lang' => 'zh',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_00e79948-a0c0-4a44-bbc8-85325e7bf39e',
            ),
            481 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 95,
                'foreign_table' => 'tags',
                'id' => 1307,
                'lang' => 'ko',
                'translated_text' => '人生',
            ),
            482 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 95,
                'foreign_table' => 'tags',
                'id' => 1308,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_d6b5a9ee-db72-4265-aed1-cdec8cfe1a38',
            ),
            483 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 62,
                'foreign_table' => 'weathers',
                'id' => 1309,
                'lang' => 'en',
                'translated_text' => 'khong chon tag en',
            ),
            484 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 62,
                'foreign_table' => 'weathers',
                'id' => 1310,
                'lang' => 'en',
                'translated_text' => 'khong chon tag en',
            ),
            485 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 2211,
                'foreign_table' => 'map_datas',
                'id' => 1311,
                'lang' => 'en',
                'translated_text' => 'Test điểm Giao Thông jen',
            ),
            486 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 869,
                'foreign_table' => 'posts',
                'id' => 1318,
                'lang' => 'en',
                'translated_text' => '広域行政窓口2019年4月1日 11時01分',
            ),
            487 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 869,
                'foreign_table' => 'posts',
                'id' => 1319,
                'lang' => 'en',
                'translated_text' => '広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
            ),
            488 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 870,
                'foreign_table' => 'posts',
                'id' => 1320,
                'lang' => 'en',
                'translated_text' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）2019年4月26日 4時48分',
            ),
            489 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 870,
                'foreign_table' => 'posts',
                'id' => 1321,
                'lang' => 'en',
                'translated_text' => '令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
            ),
            490 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 871,
                'foreign_table' => 'posts',
                'id' => 1322,
                'lang' => 'en',
                'translated_text' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について2019年5月6日 23時30分',
            ),
            491 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 871,
                'foreign_table' => 'posts',
                'id' => 1323,
                'lang' => 'en',
                'translated_text' => '　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
            ),
            492 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 872,
                'foreign_table' => 'posts',
                'id' => 1324,
                'lang' => 'en',
                'translated_text' => '歴民だより　5月号　No.672019年5月7日 0時30分',
            ),
            493 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 872,
                'foreign_table' => 'posts',
                'id' => 1325,
                'lang' => 'en',
                'translated_text' => '歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
            ),
            494 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 873,
                'foreign_table' => 'posts',
                'id' => 1326,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果2019年5月7日 0時30分',
            ),
            495 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 873,
                'foreign_table' => 'posts',
                'id' => 1327,
                'lang' => 'en',
                'translated_text' => '平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
            ),
            496 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 874,
                'foreign_table' => 'posts',
                'id' => 1328,
                'lang' => 'en',
                'translated_text' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント2019年5月23日 4時46分',
            ),
            497 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 874,
                'foreign_table' => 'posts',
                'id' => 1329,
                'lang' => 'en',
                'translated_text' => 'パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/',
            ),
            498 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 875,
                'foreign_table' => 'posts',
                'id' => 1330,
                'lang' => 'en',
                'translated_text' => '予防接種町指定医療機関一覧2019年5月24日 8時24分',
            ),
            499 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 875,
                'foreign_table' => 'posts',
                'id' => 1331,
                'lang' => 'en',
                'translated_text' => '予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/',
            ),
        ));
        \DB::table('translations')->insert(array (
            0 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 876,
                'foreign_table' => 'posts',
                'id' => 1332,
                'lang' => 'en',
                'translated_text' => '日本脳炎2019年5月24日 8時24分',
            ),
            1 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 876,
                'foreign_table' => 'posts',
                'id' => 1333,
                'lang' => 'en',
                'translated_text' => '　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/',
            ),
            2 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 877,
                'foreign_table' => 'posts',
                'id' => 1334,
                'lang' => 'en',
                'translated_text' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ2019年5月24日 8時25分',
            ),
            3 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 877,
                'foreign_table' => 'posts',
                'id' => 1335,
                'lang' => 'en',
                'translated_text' => '　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/',
            ),
            4 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 878,
                'foreign_table' => 'posts',
                'id' => 1336,
                'lang' => 'en',
                'translated_text' => '蔵書検索システム障害2019年5月28日 0時43分',
            ),
            5 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 878,
                'foreign_table' => 'posts',
                'id' => 1337,
                'lang' => 'en',
                'translated_text' => '現在システム障害のため、蔵書予約ができない状況となっております。復旧次第お知らせします。 所蔵の確認、予約は電話でも受け付けております。ご迷惑をおかけして申し訳ありません。      
http://www.town.anpachi.gifu.jp/2019/05/28/%e8%94%b5%e6%9b%b8%e6%a4%9c%e7%b4%a2%e3%82%b7%e3%82%b9%e3%83%86%e3%83%a0%e9%9a%9c%e5%ae%b3/',
            ),
            6 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 36,
                'foreign_table' => 'websites',
                'id' => 1338,
                'lang' => 'ja',
                'translated_text' => 'title webpage ja',
            ),
            7 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 36,
                'foreign_table' => 'websites',
                'id' => 1339,
                'lang' => 'ja',
            'translated_text' => '<p style="box-sizing: border-box; margin: 0px 0px 30px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 18px; line-height: inherit; font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51);">児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっていることをニュースなどで感じている方も多いのではないでしょうか。児童虐待は2017年度に13万件（前年度12万件）を超え過去最高値となりました。また、7人に1人の子どもが貧困状態に置かれています。子どもたちの基盤となる家庭の中で、虐待や貧困に苦しむ子どもたちも少なくありません。</p><p style="box-sizing: border-box; margin: 0px 0px 30px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 18px; line-height: inherit; font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51);">家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どちらも過去最高値となりました。子どもたちにとって主要な居場所であるべき家庭と学校が、安心できる場所ではなく、暴力や暴言、貧困やいじめなどに苦しむ場所になりつつあります</p>',
            ),
            8 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1356,
                'lang' => 'zh',
                'translated_text' => 'Notify 4',
            ),
            9 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1357,
                'lang' => 'zh',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_535c8a4c-9063-4377-9456-c599a1a036df',
            ),
            10 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1358,
                'lang' => 'zh',
                'translated_text' => 'Notify 4',
            ),
            11 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1359,
                'lang' => 'zh',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_535c8a4c-9063-4377-9456-c599a1a036df',
            ),
            12 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1360,
                'lang' => 'pt',
                'translated_text' => 'Notify6',
            ),
            13 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 94,
                'foreign_table' => 'tags',
                'id' => 1361,
                'lang' => 'pt',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_e8cec9f3-d554-43bd-9527-ec2700d871d7',
            ),
            14 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 878,
                'foreign_table' => 'posts',
                'id' => 1362,
                'lang' => 'zh',
                'translated_text' => 'eqwewq',
            ),
            15 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 878,
                'foreign_table' => 'posts',
                'id' => 1363,
                'lang' => 'zh',
                'translated_text' => 'eqwewqe',
            ),
            16 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1368,
                'lang' => 'en',
                'translated_text' => 'fffffffff',
            ),
            17 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1369,
                'lang' => 'en',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_67db75ea-c117-4a28-b56a-5767285b8da7',
            ),
            18 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1370,
                'lang' => 'zh',
                'translated_text' => 'ffffff',
            ),
            19 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1371,
                'lang' => 'zh',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_b3245500-b81f-455c-bcaf-b9e1672b940e',
            ),
            20 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1372,
                'lang' => 'ko',
                'translated_text' => 'ffffff',
            ),
            21 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1373,
                'lang' => 'ko',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_39ee8777-f7e9-46e1-a771-4f92c6a258c1',
            ),
            22 => 
            array (
                'foreign_field' => 'name',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1374,
                'lang' => 'pt',
                'translated_text' => 'fffff',
            ),
            23 => 
            array (
                'foreign_field' => 'topic_arn',
                'foreign_id' => 96,
                'foreign_table' => 'tags',
                'id' => 1375,
                'lang' => 'pt',
                'translated_text' => 'arn:aws:sns:us-east-1:046602778425:myell_local_199_cd6dbf2e-9592-43a2-9260-741b8b1f3304',
            ),
            24 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 879,
                'foreign_table' => 'posts',
                'id' => 1376,
                'lang' => 'en',
                'translated_text' => 'Test 351 en',
            ),
            25 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 879,
                'foreign_table' => 'posts',
                'id' => 1377,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Test 351 en</span></font>',
            ),
            26 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 879,
                'foreign_table' => 'posts',
                'id' => 1378,
                'lang' => 'pt',
                'translated_text' => 'Test 351 pu pu',
            ),
            27 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 879,
                'foreign_table' => 'posts',
                'id' => 1379,
                'lang' => 'pt',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Test 351 pu pu</span></font>',
            ),
            28 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 880,
                'foreign_table' => 'posts',
                'id' => 1380,
                'lang' => 'pt',
                'translated_text' => 'thu  pu pu',
            ),
            29 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 880,
                'foreign_table' => 'posts',
                'id' => 1381,
                'lang' => 'pt',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu  pu pu</span></font>',
            ),
            30 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 882,
                'foreign_table' => 'posts',
                'id' => 1382,
                'lang' => 'en',
                'translated_text' => 'Test publish en',
            ),
            31 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 882,
                'foreign_table' => 'posts',
                'id' => 1383,
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Test publish en</span></font>',
            ),
            32 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 920,
                'foreign_table' => 'posts',
                'id' => 1397,
                'lang' => 'en',
                'translated_text' => 'eqwewqeqe',
            ),
            33 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 920,
                'foreign_table' => 'posts',
                'id' => 1398,
                'lang' => 'en',
            'translated_text' => '<img width="1024" height="749" src="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024" class="attachment-large size-large wp-post-image" alt="" srcset="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024 1024w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=2048 2048w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=150 150w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=300 300w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=768 768w" sizes="(max-width: 1024px) 100vw, 1024px" />',
            ),
            34 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 919,
                'foreign_table' => 'posts',
                'id' => 1399,
                'lang' => 'en',
                'translated_text' => 'eqweqweqw',
            ),
            35 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 919,
                'foreign_table' => 'posts',
                'id' => 1400,
                'lang' => 'en',
            'translated_text' => '<div style=""><font face="Arial, Verdana" style="font-family: Arial, Verdana; font-size: 10pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal;"><span style="font-size: 13.3333px;">img width="1024" height="749" src="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024" class="attachment-large size-large wp-post-image" alt=""&nbsp;</span></font><font face="Arial, Verdana" style="font-family: Arial, Verdana; font-size: 10pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal;"><span style="font-size: 13.3333px;">sizes="(max-width: 1024px) 100vw, 1024px srcset= "</span></font><a href="https://machiyell.s3.amazonaws.com/file/system/VISOR/icon/icon_20181128135246.png" style="font-size: 10pt;">https://machiyell.s3.amazonaws.com/file/system/VISOR/icon/icon_20181128135246.png</a><font face="Arial, Verdana" style="font-size: 10pt;"><span style="font-size: 13.3333px;">"</span></font><font face="Arial, Verdana" style="font-size: 10pt;"><span style="font-size: 13.3333px;">&gt;</span></font></div><div style="font-family: Arial, Verdana; font-size: 10pt; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal;"><br></div>',
            ),
            36 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 921,
                'foreign_table' => 'posts',
                'id' => 1401,
                'lang' => 'en',
                'translated_text' => 'qggggggg',
            ),
            37 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 921,
                'foreign_table' => 'posts',
                'id' => 1402,
                'lang' => 'en',
            'translated_text' => '<img width="1024" height="749" src="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024" class="attachment-large size-large wp-post-image" alt="" srcset="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024 1024w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=2048 2048w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=150 150w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=300 300w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=768 768w" sizes="(max-width: 1024px) 100vw, 1024px" />',
            ),
            38 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 922,
                'foreign_table' => 'posts',
                'id' => 1403,
                'lang' => 'en',
                'translated_text' => 'gq4e',
            ),
            39 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 922,
                'foreign_table' => 'posts',
                'id' => 1404,
                'lang' => 'en',
            'translated_text' => '<img width="1024" height="749" src="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024" class="attachment-large size-large wp-post-image" alt="" srcset="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024 1024w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=2048 2048w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=150 150w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=300 300w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=768 768w" sizes="(max-width: 1024px) 100vw, 1024px" />',
            ),
            40 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 923,
                'foreign_table' => 'posts',
                'id' => 1405,
                'lang' => 'en',
                'translated_text' => 'eqwewqeeqweqweqweq',
            ),
            41 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 923,
                'foreign_table' => 'posts',
                'id' => 1406,
                'lang' => 'en',
            'translated_text' => '<pre class="loom_code prettyprint prettyprinted" style="box-sizing: border-box; overflow: auto; font-family: Consolas, Menlo, Courier, Monaco, monospace, sans-serif; font-size: 13px; padding: 0.8em 1.4em; border: 1px solid rgb(189, 189, 189); line-height: 1.7rem; margin-top: 1.4em; margin-bottom: 1.4em; border-radius: 4px; background-color: rgb(245, 245, 245); color: rgb(34, 34, 34);"><code style="box-sizing: border-box; font-family: Consolas, Menlo, Courier, Monaco, monospace, sans-serif; font-size: 1em;"><span class="tag" style="box-sizing: border-box; color: rgb(0, 0, 136);">&lt;img</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">width</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">"1024"</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">height</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">"749"</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">src</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">"https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024"</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">class</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">"attachment-large size-large wp-post-image"</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">alt</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">""</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">srcset</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">"https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024 1024w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=2048 2048w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=150 150w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=300 300w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=768 768w"</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="atn" style="box-sizing: border-box; color: rgb(102, 0, 102);">sizes</span><span class="pun" style="box-sizing: border-box; color: rgb(102, 102, 0);">=</span><span class="atv" style="box-sizing: border-box; color: rgb(0, 136, 0);">"(max-width: 1024px) 100vw, 1024px"</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span><span class="tag" style="box-sizing: border-box; color: rgb(0, 0, 136);">/&gt;</span><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"> </span></code></pre><div><code style="box-sizing: border-box; font-family: Consolas, Menlo, Courier, Monaco, monospace, sans-serif; font-size: 1em;"><span class="pln" style="box-sizing: border-box; color: rgb(0, 0, 0);"><br></span></code></div>',
            ),
            42 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 924,
                'foreign_table' => 'posts',
                'id' => 1407,
                'lang' => 'en',
                'translated_text' => 'eqwewqewqeq',
            ),
            43 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 924,
                'foreign_table' => 'posts',
                'id' => 1408,
                'lang' => 'en',
            'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">&lt;img width="1024" height="749" src="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024" class="attachment-large size-large wp-post-image" alt="" srcset="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024 1024w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=2048 2048w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=150 150w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=300 300w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=768 768w" sizes="(max-width: 1024px) 100vw, 1024px" /&gt;&nbsp;</span></font>',
            ),
            44 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 925,
                'foreign_table' => 'posts',
                'id' => 1409,
                'lang' => 'en',
                'translated_text' => '112321321312312',
            ),
            45 => 
            array (
                'foreign_field' => 'body',
                'foreign_id' => 925,
                'foreign_table' => 'posts',
                'id' => 1410,
                'lang' => 'en',
                'translated_text' => 'eqweqeqwcasdwqeq???#123',
            ),
            46 => 
            array (
                'foreign_field' => 'title',
                'foreign_id' => 137,
                'foreign_table' => 'files',
                'id' => 1411,
                'lang' => 'en',
                'translated_text' => 'sdasadsdasdas',
            ),
        ));
        
        
    }
}