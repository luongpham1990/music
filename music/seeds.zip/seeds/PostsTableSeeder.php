<?php

use Illuminate\Database\Seeder;

class PostsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('posts')->delete();
        
        \DB::table('posts')->insert(array (
            0 => 
            array (
                'body' => 'fasdfsadf',
                'content_id' => 1,
                'featured_end_at' => '2018-12-26 12:57:51',
                'id' => 1,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2018-12-26 12:57:51',
                'publish_div' => 1,
                'title' => 'sdfds',
            ),
            1 => 
            array (
                'body' => 'bdbdg',
                'content_id' => 9,
                'featured_end_at' => '2018-12-28 16:20:58',
                'id' => 4,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2018-12-28 16:20:58',
                'publish_div' => 1,
                'title' => 'ja_title',
            ),
            2 => 
            array (
                'body' => 'sádf',
                'content_id' => 26,
                'featured_end_at' => NULL,
                'id' => 5,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-07 16:47:00',
                'publish_div' => 1,
                'title' => 'fa',
            ),
            3 => 
            array (
                'body' => 'gsdfg',
                'content_id' => 28,
                'featured_end_at' => NULL,
                'id' => 6,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-07 17:31:00',
                'publish_div' => 1,
                'title' => 'sdfgsd',
            ),
            4 => 
            array (
                'body' => 'dsfsd',
                'content_id' => 29,
                'featured_end_at' => NULL,
                'id' => 7,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-07 18:30:00',
                'publish_div' => 1,
                'title' => 'fd',
            ),
            5 => 
            array (
                'body' => 'asdc',
                'content_id' => 45,
                'featured_end_at' => NULL,
                'id' => 23,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-08 11:07:00',
                'publish_div' => 1,
                'title' => 'dsc',
            ),
            6 => 
            array (
                'body' => 'dasdasasd',
                'content_id' => 85,
                'featured_end_at' => NULL,
                'id' => 28,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-14 10:17:00',
                'publish_div' => 1,
                'title' => 'asdas',
            ),
            7 => 
            array (
                'body' => 'scdas',
                'content_id' => 90,
                'featured_end_at' => NULL,
                'id' => 29,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-14 20:16:00',
                'publish_div' => 1,
                'title' => 'ac',
            ),
            8 => 
            array (
                'body' => 'đá',
                'content_id' => 92,
                'featured_end_at' => '2019-01-16 00:00:00',
                'id' => 30,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-16 12:56:00',
                'publish_div' => 1,
                'title' => 'đá',
            ),
            9 => 
            array (
                'body' => 'eeeeeeeeeee',
                'content_id' => 93,
                'featured_end_at' => '2019-01-29 00:00:00',
                'id' => 31,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-29 12:00:00',
                'publish_div' => 1,
                'title' => 'eeeeeeeeeee',
            ),
            10 => 
            array (
                'body' => 'yyyyyyyyyyyy',
                'content_id' => 94,
                'featured_end_at' => '2019-01-31 00:00:00',
                'id' => 32,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-31 19:37:00',
                'publish_div' => 1,
                'title' => 'thy',
            ),
            11 => 
            array (
                'body' => '1rrrrrrrrrrrr',
                'content_id' => 98,
                'featured_end_at' => '2019-01-29 00:00:00',
                'id' => 34,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-29 13:17:00',
                'publish_div' => 1,
                'title' => '11111111111',
            ),
            12 => 
            array (
                'body' => 'o9<br>',
                'content_id' => 102,
                'featured_end_at' => NULL,
                'id' => 38,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-29 13:39:00',
                'publish_div' => 1,
                'title' => 'uuuuuuuuuuuuuuuuuuu',
            ),
            13 => 
            array (
            'body' => '<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000"><strong><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください。</font><span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#ff0000">ブランチに登録しましたので確認してください</font>。</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></strong></font></span>',
                'content_id' => 108,
                'featured_end_at' => '2019-02-02 00:00:00',
                'id' => 41,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-29 16:58:00',
                'publish_div' => 1,
                'title' => 'Thubeo',
            ),
            14 => 
            array (
                'body' => 'thudieuthudieuthudieu',
                'content_id' => 116,
                'featured_end_at' => '2019-01-31 00:00:00',
                'id' => 43,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-30 10:41:00',
                'publish_div' => 1,
                'title' => 'thudieu',
            ),
            15 => 
            array (
                'body' => 'thuamthuamthuam',
                'content_id' => 117,
                'featured_end_at' => NULL,
                'id' => 44,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-31 12:40:00',
                'publish_div' => 2,
                'title' => 'thuam',
            ),
            16 => 
            array (
                'body' => 'test duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MB',
                'content_id' => 119,
                'featured_end_at' => NULL,
                'id' => 46,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-30 11:10:00',
                'publish_div' => 1,
                'title' => 'test duoi 6MB',
            ),
            17 => 
            array (
                'body' => 'test 7Mb',
                'content_id' => 120,
                'featured_end_at' => NULL,
                'id' => 47,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-30 11:17:00',
                'publish_div' => 1,
                'title' => 'test 7Mb',
            ),
            18 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test trên 7MB</span></font>',
                'content_id' => 126,
                'featured_end_at' => '2019-01-31 00:00:00',
                'id' => 48,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-01-30 15:42:00',
                'publish_div' => 1,
                'title' => 'test trên 7MB',
            ),
            19 => 
            array (
                'body' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">開断ーび前禁ナチ数歳げーて認3長ヱルネ翌氏さみせ率際ンをろ開向更イル場善せだフ毎37樹上像とお。碁クコキユ指香ルぴすぽ不後ハレムセ動懲ねうど川血テヌア都訃ナ歳7像リあへょ合練時透辞サラ替也っ神炎評ワム団一合アニマ究3区リセ戦代技福電がむみつ。去サ無選政へゃ川記ぽ団職ぱ善通まげぶの鈴日ムナ医應ミ観高クリロ最今クモ省努とらつ同連む表震めーもク表会ーもリ月不辞吏じてフは。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">数マツケメ様業ょば人指属ヱセヌマ円自匂ク際明きぎンょ問囲土ソ償一じ将刻モチソ提新はぽじく愛動けイ運純ミ営発ト念均づめろい声聞ヤミタ暮的がす同解曽膨じリ。写従ヌ韓航ゅもリ白気をゅレト意83通十ロエアオ信磯ょ列36将色ラスナサ申献にぴへ予集ニクイ設86克即両69克即両19敢渓窮胡あの。劾メ件会ヲニ税史ばぐトす能入イぎ提価じ水設こごぽラ田掲年勲う回芸テセコア催速んふき米次布益陣むてふ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">声ヨフ情林元ク迂輸ムヒ斜配ストヱ性休38妊舌頃魔8異ずちしぶ第愛ほ川治ラロ度67今更フユ治薬るいばぼ室任提思吏んろ。会みどろ続違ぐ者福ニメヲ理企中一づ幕音リウ新午おがとの経第ずーのば広2記定フキシリ引海ぽ恥離夢みらん。焦ねる建料ゅやせち措訃ルユキ化場トくリ空頑聞が反例ノ見低導ワ編51郎えぽ金兵けス区元ヌ河集ラ応洗ス並大けば方性ぴべづ記大べをず意憂喰杜椿ルッ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">暮もルめ娘良キタル委呈オケ荒別マヘユホ歌精さたしば様6手地リぱかろ毎作はろ断国がに尽環ク画稿やつが変態票特ぱ。禁いぱだろ切事スいみ一投監お外尚岡ヘソト城木おてたク作63府属ば自大レチヒイ回1表不ずきト富投ケヒモニ郎区ウ松完スヘ昨賞花飛んぜだぎ。全ヨ最毎クワシ明立止クサユ救消ミニコヒ重軽ト正費せ普転外がし届集期タ披61感毎ト児紀えば位情ばがれド断45欠ウワニ聞局予現情の。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">入チマムホ村社みるン安滴クたま石記カ成訃ムネナモ民各ンっぴべ江73知きド全足ヱ差薫メカフア市全者サチト航問キハケ意備ニチメル模年でほ内参他ほれわっ。石リょ法営ルづけ飛変ねが豊注スヤナ雲市ハ髄1訪稿づぐぎぼ後声ヤロハタ入住び補2転ほづっ刊運永マヨ介候タカマ一正古26俑ばリび小記購仁借つまう。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">31速どきぱ択到おリ載試報ルリ水浅か澄芸ちわて講1気りだ味影げた勢属ぞりせ志展メ人者ヤホ動賀ナ禁周暮ホムオテ店雇余献だらげべ。会シム東一女ノオネ賞聞びめが鍵特スユ月米モ付増飛コリ導提んあて頻受略ロ一更なうー掲属井ヌマヘ差界師ヤヱシ天事ごよぴづ録息曲燃階みけ。図にをてイ角健だ公植ム冬当ーひぱス載特日ぴ況5断ンぎっ長会ムクレヌ保半図ふいでね心飯オト位楽義ょぴちご。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">断あ他賞車ちげでま積政ッさ材下イ翔山ワウ割和ほクぐ札促チメク作23応べる年月ぐ月麓トノフヲ活北ムヘキ学球購締ぴじ。追レだふス校詰然アネタ中入悲椅ロリカモ媛年むレびク被信トミ力議ハカミ慣係ヌメヤ用14士3幕ド本9重こにっリ。戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">日ぶ山評ス欧供そひ業児ヒキ望暮シノ銀月んす分子めどっ師術告き芸進っ理定ヱヤ帯測キシケク示新アミウ松聖スせりっ治合ネノ像93本フエ記公地映イえン。玉業ラぶめ荻広ごたく循新げ余試ルラカ業企ヲヨニネ暮4引リメイ要8習ツオヌ暮分よりきわ北朝籍華踏麻わめ。援資見へぐな棋活ワオト領方カナケミ間連治長ん確水よおみぎ遺掲もいほぽ厳77万所特5型チレ止急コ申難ねざルわ芸害もラご頭広郎互札く。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">都け保6留メイツヌ会育月ヒ系案ー返74便ょ質使ふ春質むぼ数期き要板植抜いおえ。坂ハ意規マケレナ象護見トサ申果ナシフミ君質ラワテヒ極佐にど三能ろル組労日かびそ酒25好著わ遺載オ専説喫羅踊こほ。写ゃぽ築相ぐぜよ事持ヘアヲヤ料頃でたんと館担ぎく交手わぼド携速ヒ応現ケラロ話堀近チ伴絵ち史45家ろ毎王購歩ょすに。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">案4事岐情ヌソナ未住づびべ選号キ重納なラふ済年セウ足中ほ禁写マセワナ無62壺柱っは潟太がびら定止ッ際庭やざへイ。断主なうぜフ部点チヌ知78洋電ねル誤金しら棋然レフるぽ事占けそぞれ農義ヨモ切人判りこかぱ時特ヲユ以野れ問編い音青ラヱメマ持目ソ嶋接年よはゅ。全地気ナマラ日主オコ海長イケヨア世田へスぱや伸備クロマネ外2消ねえまお暢山オニル週57純ツニウテ示象晶いむ。</span></font></div>',
                'content_id' => 128,
                'featured_end_at' => NULL,
                'id' => 49,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-02-11 17:42:00',
                'publish_div' => 1,
                'title' => '開断ーび前禁ナチ数歳げーて認3長ヱルネ翌氏さみせ率際ンをろ開向更イル場善せだフ毎37樹上像とお。碁クコキユ指香ルぴすぽ不後ハレムセ動懲ねうど川血テヌア都訃',
            ),
            20 => 
            array (
                'body' => 'cascasc',
                'content_id' => 129,
                'featured_end_at' => NULL,
                'id' => 50,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-01-31 21:19:00',
                'publish_div' => 1,
                'title' => 'ddd',
            ),
            21 => 
            array (
                'body' => 'cascasc',
                'content_id' => 148,
                'featured_end_at' => NULL,
                'id' => 58,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'zh',
                'publish_at' => '2019-02-12 13:49:00',
                'publish_div' => 1,
                'title' => 'test validate',
            ),
            22 => 
            array (
                'body' => 'test validate 1',
                'content_id' => 149,
                'featured_end_at' => NULL,
                'id' => 59,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'zh',
                'publish_at' => '2019-02-12 15:26:00',
                'publish_div' => 1,
                'title' => 'test validate  1',
            ),
            23 => 
            array (
                'body' => '12345',
                'content_id' => 150,
                'featured_end_at' => NULL,
                'id' => 60,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'zh',
                'publish_at' => '2019-02-13 12:04:00',
                'publish_div' => 1,
                'title' => 'dsad',
            ),
            24 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu tha thu</span></font>',
                'content_id' => 169,
                'featured_end_at' => '2019-02-13 00:00:00',
                'id' => 61,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-02-13 19:34:00',
                'publish_div' => 1,
                'title' => 'thu tha thu',
            ),
            25 => 
            array (
            'body' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px; color: rgb(255, 0, 0);">本社はベトナムのハノイにあります。 優秀なスタッフと共に、国内外の市場（日本とシンガポール）に高品質で低コストのソフトウェアアウトソーシングと開発サービスを提供することを専門としています。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px; color: rgb(255, 0, 0);"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px; color: rgb(255, 0, 0);">さらに、当社の取締役会の3人のメンバーは全員10年以上日本に住んでおり、仕事をしているので、彼らは仕事の仕方や日本の顧客の品質要求を非常によく理解しています。</span></font></div>',
                'content_id' => 170,
                'featured_end_at' => '2019-02-15 00:00:00',
                'id' => 62,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-02-13 13:18:00',
                'publish_div' => 1,
                'title' => 'finish Test',
            ),
            26 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">本社はベトナムのハノイにあります。</span></font>',
                'content_id' => 172,
                'featured_end_at' => '2019-02-15 00:00:00',
                'id' => 64,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-02-13 13:34:00',
                'publish_div' => 1,
                'title' => '本社はベトナムのハノイにあります。',
            ),
            27 => 
            array (
                'body' => 'csc',
                'content_id' => 181,
                'featured_end_at' => NULL,
                'id' => 65,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-13 19:13:00',
                'publish_div' => 1,
                'title' => 'scscs',
            ),
            28 => 
            array (
                'body' => 'ffffffffffffffff',
                'content_id' => 182,
                'featured_end_at' => NULL,
                'id' => 66,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-13 19:14:00',
                'publish_div' => 1,
                'title' => 'f',
            ),
            29 => 
            array (
                'body' => 'ggggggggggg',
                'content_id' => 184,
                'featured_end_at' => NULL,
                'id' => 68,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-13 19:19:00',
                'publish_div' => 1,
                'title' => 'thu',
            ),
            30 => 
            array (
                'body' => 'hhhhhhhhhhhhh',
                'content_id' => 185,
                'featured_end_at' => NULL,
                'id' => 69,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-13 19:35:00',
                'publish_div' => 1,
                'title' => 'hh',
            ),
            31 => 
            array (
                'body' => '<font color="#ff0000">利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル</font>',
                'content_id' => 186,
                'featured_end_at' => '2019-02-15 00:00:00',
                'id' => 70,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-15 04:25:00',
                'publish_div' => 2,
                'title' => '利用マニュアル',
            ),
            32 => 
            array (
                'body' => '更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。',
                'content_id' => 187,
                'featured_end_at' => NULL,
                'id' => 71,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-14 11:32:00',
                'publish_div' => 1,
                'title' => '更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。更新しました。',
            ),
            33 => 
            array (
                'body' => 'dfffffff',
                'content_id' => 189,
                'featured_end_at' => NULL,
                'id' => 72,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'es',
                'publish_at' => '2019-02-14 12:01:00',
                'publish_div' => 1,
                'title' => 'ddddddddd',
            ),
            34 => 
            array (
                'body' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in',
                'content_id' => 237,
                'featured_end_at' => '2019-03-14 00:00:00',
                'id' => 73,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 12:32:00',
                'publish_div' => 1,
                'title' => '666 Lich nghi 30/4',
            ),
            35 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。</span></font>',
                'content_id' => 242,
                'featured_end_at' => '2019-04-11 00:00:00',
                'id' => 78,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 12:32:00',
                'publish_div' => 1,
                'title' => '5555電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。電話番号英語には有効な電話番号を入力してください。',
            ),
            36 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。</span></font>',
                'content_id' => 243,
                'featured_end_at' => '2019-03-27 00:00:00',
                'id' => 79,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 13:39:00',
                'publish_div' => 1,
                'title' => '444先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。先日確認点を追記しました。111111111',
            ),
            37 => 
            array (
                'body' => '<div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">トランプ氏が戻ったトランプ氏が戻ったトラン</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">プ氏が戻ったトランプ氏が戻ったトランプ氏が戻っ</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">たトランプ氏が戻ったトランプ氏が戻ったトランプ</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトラ</span></font></div><div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">ンプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻ったトランプ氏が戻った</span></font></div>',
                'content_id' => 245,
                'featured_end_at' => '2019-03-28 00:00:00',
                'id' => 81,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 12:31:00',
                'publish_div' => 1,
                'title' => 'Huong den tuong lai3',
            ),
            38 => 
            array (
                'body' => '音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。',
                'content_id' => 253,
                'featured_end_at' => '2019-03-21 00:00:00',
                'id' => 89,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 18:12:00',
                'publish_div' => 1,
                'title' => '22222音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイしない。',
            ),
            39 => 
            array (
                'body' => '第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません',
                'content_id' => 254,
                'featured_end_at' => '2019-03-08 00:00:00',
                'id' => 90,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 20:20:00',
                'publish_div' => 2,
                'title' => '第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません第3回サミットの予定はありません',
            ),
            40 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 255);"><span style="font-weight: bold;">記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました</span></span>',
                'content_id' => 255,
                'featured_end_at' => '2019-03-09 00:00:00',
                'id' => 91,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-08 12:30:00',
                'publish_div' => 1,
                'title' => '111111記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記1111者会見は終ました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者会見は終了しました記者',
            ),
            41 => 
            array (
                'body' => 'Không bật thông báo chú ý',
                'content_id' => 256,
                'featured_end_at' => NULL,
                'id' => 92,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-03 15:25:00',
                'publish_div' => 2,
                'title' => 'Không bật thông báo chú ý va chi đinh ngay cong khai',
            ),
            42 => 
            array (
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
                'content_id' => 257,
                'featured_end_at' => NULL,
                'id' => 93,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-02 14:45:00',
                'publish_div' => 2,
                'title' => 'huydn_batcth',
            ),
            43 => 
            array (
                'body' => '<font color="#3333ff">音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。音声再生」アイコンは、現状では動作しない。</font>',
                'content_id' => 260,
                'featured_end_at' => '2019-03-30 00:00:00',
                'id' => 96,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-01 19:08:00',
                'publish_div' => 1,
                'title' => 'Thong bao1',
            ),
            44 => 
            array (
                'body' => 'asdasd',
                'content_id' => 263,
                'featured_end_at' => NULL,
                'id' => 99,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-01 19:15:00',
                'publish_div' => 1,
                'title' => 'test content file optional 11',
            ),
            45 => 
            array (
                'body' => 'Thong bao 2Thong bao 2Thong bao 2Thong bao 2Thong bao 2Thong bao',
                'content_id' => 264,
                'featured_end_at' => '2019-03-28 00:00:00',
                'id' => 100,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-01 19:20:00',
                'publish_div' => 1,
                'title' => 'Thong bao 2',
            ),
            46 => 
            array (
                'body' => 'Thông báo 3Thông báo 3Thông báo 3Thông báo 3',
                'content_id' => 265,
                'featured_end_at' => '2019-03-24 00:00:00',
                'id' => 101,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-01 19:22:00',
                'publish_div' => 1,
                'title' => 'Thông báo 3',
            ),
            47 => 
            array (
                'body' => '気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く4444444444444444444',
                'content_id' => 266,
                'featured_end_at' => '2019-03-17 00:00:00',
                'id' => 102,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-01 19:26:00',
                'publish_div' => 1,
                'title' => '気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く気付く4444444444444444444',
            ),
            48 => 
            array (
            'body' => 'Body(en)',
                'content_id' => 267,
                'featured_end_at' => NULL,
                'id' => 103,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-05 09:55:00',
                'publish_div' => 2,
            'title' => 'Title(en)',
            ),
            49 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
                'content_id' => 268,
                'featured_end_at' => '2019-03-09 00:00:00',
                'id' => 104,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-05 17:37:00',
                'publish_div' => 1,
                'title' => 'Title Post batch1',
            ),
            50 => 
            array (
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
                'content_id' => 269,
                'featured_end_at' => NULL,
                'id' => 105,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-05 11:50:00',
                'publish_div' => 1,
            'title' => 'Title test batch Tieng Anh (en)',
            ),
            51 => 
            array (
            'body' => '<span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　周辺地域で発生する地震や１８９９年の地震（Ｍ７．０、推定の深さ４０～５０ｋｍ：紀伊大和地震と呼ぶこともあります）や１９５２年の吉野地震（Ｍ６．７、深さ約６０ｋｍ）のように沈み込んだフィリピン海プレート内で発生するやや深い場所で発生した地震によっても被害を受けたことがあります。また、１９６０年の「チリ地震津波」のように外国の地震によっても津波被害を受けたことがあります</span>',
                'content_id' => 294,
                'featured_end_at' => NULL,
                'id' => 106,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-11 13:35:00',
                'publish_div' => 1,
            'title' => 'thu beo dox and ppt_xlsx (en)',
            ),
            52 => 
            array (
                'body' => 'body en',
                'content_id' => 297,
                'featured_end_at' => '2019-03-13 00:00:00',
                'id' => 107,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-11 13:57:00',
                'publish_div' => 1,
                'title' => 'EN',
            ),
            53 => 
            array (
                'body' => 'Body tieng anh',
                'content_id' => 299,
                'featured_end_at' => '2019-03-12 00:00:00',
                'id' => 108,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-03-11 13:59:00',
                'publish_div' => 1,
                'title' => 'CHi co tieng Anh',
            ),
            54 => 
            array (
            'body' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有感地震回数は、最近の１０年間では年平均１９回程度にのぼり、日本で最も有感地震回数の多い地域の一つです。特に１９２０年以降報告回数が増えたことが知られています。近年この地域に大規模な地震の発生は知られていないので、この地震活動は特定の大地震の余震ではありません。その規模は最大でもＭ５程度ですが、震源がごく浅いために、局所的に被害が生じたこともあります。この付近の東側と西側では、フィリピン海プレートの沈み込む角度が違い、この付近の地下構造は複雑になっています。また、この付近の深さ数ｋｍまでの浅いところは、堅いけれども脆い性質を持つ古い時代の岩石が分布しています。これらのことが、和歌山市付近の定常的な地震活動の原因と考えられています。また、地震が</span>',
                'content_id' => 306,
                'featured_end_at' => '2019-03-16 00:00:00',
                'id' => 109,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-11 17:55:00',
                'publish_div' => 1,
                'title' => '111和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小',
            ),
            55 => 
            array (
            'body' => '<span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　また、県内に被害を及ぼす可能性のある海溝型地震には、想定東海地震、東南海地震及び南海地震があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　県北部の紀ノ川河口部や御坊など地盤がやや軟弱な場所では、周辺より揺れが強くなる可能性があります</span><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　また、県内に被害を及ぼす可能性のある海溝型地震には、想定東海地震、東南海地震及び南海地震があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　県北部の紀ノ川河口部や御坊など地盤がやや軟弱な場所では、周辺より揺れが強くなる可能性があります</span>',
                'content_id' => 307,
                'featured_end_at' => '2019-03-30 00:00:00',
                'id' => 110,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 11:09:00',
                'publish_div' => 1,
                'title' => '222最新の情報を見るために、常に再読込（更新）を行ってください最新の情報を見るために、常に再読込（更新）を行ってください最新の情報を見るために、常に再読込（更新）を行ってください',
            ),
            56 => 
            array (
            'body' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">太平洋側沖合では、南海トラフ沿いでＭ８クラスの巨大地震がほぼ１００～２００年間隔で繰り返し発生してきました。和歌山県で</span><span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">太平洋側沖合では、南海トラフ沿いでＭ８クラスの巨大地震がほぼ１００～２００年間隔で繰り返し発生してきました。和歌山県で</span><span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">太平洋側沖合では、南海トラフ沿いでＭ８クラスの巨大地震がほぼ１００～２００年間隔で繰り返し発生してきました。和歌山県で</span><span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">太平洋側沖合では、南海トラフ沿いでＭ８クラスの巨大地震がほぼ１００～２００年間隔で繰り返し発生してきました。和歌山県で</span><span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">太平洋側沖合では、南海トラフ沿いでＭ８クラスの巨大地震がほぼ１００～２００年間隔で繰り返し発生してきました。和歌山県で</span>',
                'content_id' => 308,
                'featured_end_at' => '2019-03-31 00:00:00',
                'id' => 111,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-27 16:05:00',
                'publish_div' => 2,
                'title' => '3333太平洋側沖合では、南海トラフ沿いでＭ８クラスの巨大地震がほぼ１００～２００年間隔で繰り返し発生してきました。和歌山県で',
            ),
            57 => 
            array (
            'body' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">しかし、古い地震の震源の精度や、震源の位置はよく分からないものの紀伊半島南部に被害が生じたとの記録がいくつかあることを考えると、必ずしも県内で発生した地震が少ないかどうかは分かりません。さらに、活断層のない地域や紀伊水道も含めて、県内のところどころで、Ｍ７より小さい規模ですが局所的に被害が生ずる地震が発生することがあります。被害地震としては、明治以降では、１９０６年（Ｍ６．２）と１９２４年（Ｍ５．９）の日高川流域の地震、１９３８年の田辺湾沖の地震（Ｍ６．８）、１９４８年の田辺市付近の地震（Ｍ６．７）などが知られています。</span><br style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　周辺地域で発生する地震や１８９９年の地震（Ｍ７．０、推定の深さ４０～５０ｋｍ：紀伊大和地震と呼ぶこともあります）や１９５２年の吉野地震（Ｍ６．７、深さ約６０ｋｍ）のように沈み込んだフィリピン海プレート内で発生するやや深い場所で発生した地震によっても被害を受けたことがあります。また、１９６０年の「チリ地震津波」のように外国の地震によっても津波被害を受けたことがあります。</span>',
                'content_id' => 314,
                'featured_end_at' => '2019-03-31 00:00:00',
                'id' => 112,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-11 18:35:00',
                'publish_div' => 1,
                'title' => '和歌山県の地震活動の特徴',
            ),
            58 => 
            array (
                'body' => '<span style="color:#009900">孟</span>　そうですね。中国ではなく日本で勉強しようと考えたのは、叔母の影響です。子どもの頃、日本に留学していた叔母が中国に帰ってくる度に、かわいいキャラクターのお土産をもらったり、日本製の高機能なカメラを見せてもらったことがありました。そんな経験から、いつしか日本に対して親しみや憧れを感じるようになったんですよね。ピッチさんは、なぜ日本で勉強しようと思われたんですか？<br>',
                'content_id' => 326,
                'featured_end_at' => '2019-03-31 00:00:00',
                'id' => 114,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 12:29:00',
                'publish_div' => 1,
                'title' => '33333　私は中国の高校を卒業して、日本の大学に留学しました。家庭の方針で、海外の大学に留学しようと決めていたんです。日本を選んだのは、距離的にも文化的にも中国と近いながら、その違いに興味を持ったこと',
            ),
            59 => 
            array (
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
                'content_id' => 327,
                'featured_end_at' => '2019-03-15 00:00:00',
                'id' => 115,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-20 09:15:00',
                'publish_div' => 2,
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
            ),
            60 => 
            array (
                'body' => '大学院に進む場合は留学前に研究テーマを明確にし、その研究を行っている教授の考え方や方法論までも把握しておくといいと思います。研究テーマは留学先を決める上での重要な判断材料ですし、研究方法も知っていれば実際に留学してからも前向きに勉強に取り組めますからね。大学院に進む場合は留学前に研究テーマを明確にし、その研究を行っている教授の考え方や方法論までも把握しておくといいと思います。研究テーマは留学先を決める上での重要な判断材料ですし、研究方法も知っていれば実際に留学してからも前向きに勉強に取り組めますからね。',
                'content_id' => 332,
                'featured_end_at' => '2019-03-14 00:00:00',
                'id' => 116,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 13:58:00',
                'publish_div' => 1,
                'title' => '5555最後に、日本への留学を検討されている方に対して、何かアドバイスができればと思います。留学前の準備として必要なこととして、どんなことが挙げられますか',
            ),
            61 => 
            array (
                'body' => '私は、留学への心構えについて。留学生は日本で勉強することを目的にやって来るわけですが、それ以前に海外に住むことを強く意識することが大切です。中には、知り合いが誰もいないという人もいるでしょう。頼れる人がいない状況でも、問題は自分の力で解決する。そんな覚悟が必要です。その上で日本を選ぶとしたら、事前に日本の文化を知っておいた方がいいですね。母国と日本との文化の違いを知り、その違いを受け入れることができるのか。その可否が、留学を有意義なものにするカギだと思います。慣れない環境で生活することは、決して楽しいことばかりではありません。でも、困難を乗り越えることができれば、母国の大学や大学院に進学して社会に出た場合よりも、より洗練された人間になることができるのではないでしょうか',
                'content_id' => 333,
                'featured_end_at' => '2019-03-15 00:00:00',
                'id' => 117,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-13 13:46:00',
                'publish_div' => 1,
                'title' => '6666志望する大学院を早く決めておくことは、私もおすすめします。日本の大学院には入試があり、その試験日本の大学院には入試があり、その試験',
            ),
            62 => 
            array (
                'body' => 'Chao mung quy khach den voi chung toi',
                'content_id' => 334,
                'featured_end_at' => '2019-03-14 00:00:00',
                'id' => 118,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 15:23:00',
                'publish_div' => 1,
                'title' => 'Thu 1',
            ),
            63 => 
            array (
                'body' => 'body wav',
                'content_id' => 336,
                'featured_end_at' => '2019-03-15 00:00:00',
                'id' => 120,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 16:06:00',
                'publish_div' => 1,
                'title' => 'Test wav',
            ),
            64 => 
            array (
                'body' => 'ddd',
                'content_id' => 343,
                'featured_end_at' => NULL,
                'id' => 127,
                'is_featured' => 0,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 16:55:00',
                'publish_div' => 1,
                'title' => 'config file_url ja',
            ),
            65 => 
            array (
                'body' => 'fashion.<div><br></div>',
                'content_id' => 346,
                'featured_end_at' => NULL,
                'id' => 128,
                'is_featured' => 0,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 20:24:00',
                'publish_div' => 1,
                'title' => 'fashionテスト',
            ),
            66 => 
            array (
                'body' => 'ファッションテスト',
                'content_id' => 347,
                'featured_end_at' => NULL,
                'id' => 129,
                'is_featured' => 0,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-12 20:55:00',
                'publish_div' => 1,
                'title' => 'ファッションテスト',
            ),
            67 => 
            array (
            'body' => '<h2 class="title" style="margin: 0px; padding: 5px 0px; box-sizing: border-box; font-size: 18px; direction: ltr; color: rgb(16, 16, 16); font-family: Helvetica, Arial, sans-serif; text-align: justify; background-color: rgb(255, 255, 255);">Tiệc tất niên mừng Xuân Kỷ Hợi 2019</h2><p style="margin: 0px; padding: 0px; box-sizing: border-box; direction: ltr; font-size: 14px; color: rgb(36, 36, 36); line-height: 24px; font-family: Helvetica, Arial, sans-serif; text-align: justify; background-color: rgb(255, 255, 255);">Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt hái được nhiều thành công và thành quả hết sức ấn tượng của Công ty Cổ phần Tổng hợp Việt Nhật (Vinicorp). Để tổng kết lại một năm làm việc đáng nhớ và chuẩn bị cho một năm mới với càng nhiều thắng lợi rực rỡ, Ban giám đốc Vinicorp đã cùng với các thành viên trong công ty và các vị khách mời tham gia buổi tiệc Tất niên được tổ chức vào ngày 15/01/2019 tại Nhà hàng tiệc Cưới Hoàng Gia - Số 39 Nguyễn Thị Định - Nhân Chính - Thanh Xuân - Hà nội.</p>',
                'content_id' => 357,
                'featured_end_at' => '2019-03-14 00:00:00',
                'id' => 130,
                'is_featured' => 1,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-13 13:16:00',
                'publish_div' => 1,
            'title' => 'Công ty Cổ phần Tổng hợp Việt Nhật (VINICORP) có trụ sở chính tại Hà Nội, Việt Nam. Với đội ngũ nhân viên ưu tú, chúng tôi chuyên cung cấp dịch vụ gia công và phát triển phần mềm chất lượng cao và giá thành thấp cho thị trường trong và ngoài nước (Nhật Bả',
            ),
            68 => 
            array (
                'body' => 'ファッション情報本文',
                'content_id' => 376,
                'featured_end_at' => NULL,
                'id' => 131,
                'is_featured' => 0,
                'is_speech_generated' => 0,
                'lang' => 'ja',
                'publish_at' => '2019-03-13 17:25:00',
                'publish_div' => 1,
                'title' => 'ファッション情報',
            ),
            69 => 
            array (
                'body' => 'body ja',
                'content_id' => 388,
                'featured_end_at' => '2019-03-28 00:00:00',
                'id' => 132,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-27 10:54:00',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            70 => 
            array (
                'body' => 'bodyja2',
                'content_id' => 389,
                'featured_end_at' => NULL,
                'id' => 133,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-27 10:54:00',
                'publish_div' => 1,
                'title' => 'title ja2',
            ),
            71 => 
            array (
                'body' => 'ccccccccccccc',
                'content_id' => 395,
                'featured_end_at' => NULL,
                'id' => 134,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-27 16:35:00',
                'publish_div' => 1,
                'title' => 'xls ja',
            ),
            72 => 
            array (
                'body' => 'hhhhhhhhhhhhhhhh',
                'content_id' => 399,
                'featured_end_at' => NULL,
                'id' => 135,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-03-28 13:28:00',
                'publish_div' => 1,
                'title' => 'hhhhhhhhhh',
            ),
            73 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 18px;">教員の精神疾患による休職者も増加傾向にあります。今の学校は子どもたちにわかりやすく授業を教えたり、子どもたちの悩みに寄り添える余裕はなかなかありません。さらに日本はGDPと比較した行政による教育支出は世界でも最下位になっており、子どもの教育の真の担い手は家庭の意識や経済的余裕、学校外教育にゆだねられているといっても過言ではありません。つまり、どんな家庭で生まれ育ったかによって、学力や進路、さらに言えば学校に居場所を感じられるかについても大きな格差が生じているのです。</span>',
                'content_id' => 514,
                'featured_end_at' => '2019-04-30 00:00:00',
                'id' => 223,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 13:27:00',
                'publish_div' => 1,
                'title' => 'たりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く',
            ),
            74 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 18px;">働いても貧困から脱することができないのが日本の子育て環境の現状です。現にひとり親の場合、8割以上は働いており、世界で最も働いているのに、最も貧困率が高いという状況にあるのです。その結果、家庭環境によって子どもが受けられる教育・愛情にも大きな差が生まれてしまっています。</span>',
                'content_id' => 515,
                'featured_end_at' => '2019-04-30 00:00:00',
                'id' => 224,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 13:33:00',
                'publish_div' => 1,
                'title' => 'さらに、子育てを前提にした就労環境も不十分で2',
            ),
            75 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Test 5 ja</span></font>',
                'content_id' => 521,
                'featured_end_at' => NULL,
                'id' => 226,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 13:45:00',
                'publish_div' => 1,
                'title' => 'Test 5 ja',
            ),
            76 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, " helvsetica="" neue",="" "yu="" gothic",="" yugothic,="" "ヒラギノ角ゴ="" pron="" w3",="" "hiragino="" kaku="" gothic="" pron",="" arial,="" メイリオ,="" meiryo,="" sans-serif;="" font-size:="" 18px;"="">どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どちらも過去最高値となりました。子どもたちにとって主要な居場所であるべき家庭と学校が、安心できる場所ではなく、暴力や暴言、貧困やいじめなどに苦しむ場所になりつつあります。</span>',
                'content_id' => 529,
                'featured_end_at' => NULL,
                'id' => 227,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-11 13:28:00',
                'publish_div' => 1,
                'title' => '家庭に次ぐ子3',
            ),
            77 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; font-size: 18px;">近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、安全な環境が保障されていません。塾や習い事、趣味などを楽しむ場も、家庭の経済的な余裕や親の理解がないと利用できないものが多くなっています。</span>',
                'content_id' => 530,
                'featured_end_at' => NULL,
                'id' => 228,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 15:23:00',
                'publish_div' => 1,
                'title' => 'かつてに比べ4',
            ),
            78 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">子どもたちの多くは十分な学習環境が保障されずに育ちました。進学をあきらめたり、退学してしまったりしないよう、3keysでは児童養護施設や母子生活支援施設などで暮らす子どもたちに、学習ボランティアの派遣や放課後教室の運営を行っています。2017年度には、施設への入所経験は問わない10代後半向けの拠点型学習支援をスタートさせました。</span>',
                'content_id' => 531,
                'featured_end_at' => NULL,
                'id' => 229,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 15:56:00',
                'publish_div' => 1,
                'title' => '虐待で保護された5',
            ),
            79 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">にいない子どもたちは、トラブルに巻き込まれたり、深刻な状態で発見されることも少なくありません。3keysではオンラインでの相談窓口を設け、一緒に解決方法を考えています。また、インターネットに駆け込んだ子どもたちが、安心して頼れる大人とつながるように、10向け支援サービス検索・相談サイト「Mex（ミークス）」を運営しています。</span>',
                'content_id' => 532,
                'featured_end_at' => NULL,
                'id' => 230,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 15:58:00',
                'publish_div' => 1,
                'title' => '相談できる大人が周り',
            ),
            80 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">こんにちはベトナム</span></font>',
                'content_id' => 533,
                'featured_end_at' => NULL,
                'id' => 231,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-10 16:11:00',
                'publish_div' => 1,
                'title' => 'バッチサウンドテスト',
            ),
            81 => 
            array (
                'body' => 'gfgfgfgfgfgfgfgfgfgfgfgfgf',
                'content_id' => 540,
                'featured_end_at' => '2019-04-11 00:00:00',
                'id' => 232,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-11 13:28:00',
                'publish_div' => 1,
                'title' => 'gfgfgfgfgfgf',
            ),
            82 => 
            array (
            'body' => '<ol class="breadcrumb" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 8px 15px; list-style: none; background-color: rgb(238, 238, 238); border-radius: 5px; font-size: 0.8em; color: rgb(51, 51, 51); font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; letter-spacing: 1px; outline: 0px !important;"><li class="active" style="box-sizing: border-box; display: inline-block; outline: 0px !important;">お知らせ作成</li></ol><ol class="breadcrumb" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 8px 15px; list-style: none; background-color: rgb(238, 238, 238); border-radius: 5px; font-size: 0.8em; color: rgb(51, 51, 51); font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; letter-spacing: 1px; outline: 0px !important;"><li class="active" style="box-sizing: border-box; display: inline-block; outline: 0px !important;">お知らせ作成</li></ol><ol class="breadcrumb" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 8px 15px; list-style: none; background-color: rgb(238, 238, 238); border-radius: 5px; font-size: 0.8em; color: rgb(51, 51, 51); font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; letter-spacing: 1px; outline: 0px !important;"><li class="active" style="box-sizing: border-box; display: inline-block; outline: 0px !important;">お知らせ作成</li></ol><ol class="breadcrumb" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 8px 15px; list-style: none; background-color: rgb(238, 238, 238); border-radius: 5px; font-size: 0.8em; color: rgb(51, 51, 51); font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; letter-spacing: 1px; outline: 0px !important;"><li class="active" style="box-sizing: border-box; display: inline-block; outline: 0px !important;">お知らせ作成</li></ol><ol class="breadcrumb" style="box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 8px 15px; list-style: none; background-color: rgb(238, 238, 238); border-radius: 5px; font-size: 0.8em; color: rgb(51, 51, 51); font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; letter-spacing: 1px; outline: 0px !important;"><li class="active" style="box-sizing: border-box; display: inline-block; outline: 0px !important;">お知らせ作成</li></ol>',
                'content_id' => 568,
                'featured_end_at' => NULL,
                'id' => 233,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 15:41:00',
                'publish_div' => 1,
                'title' => 'お知らせ作成',
            ),
            83 => 
            array (
                'body' => 'Welcome&nbsp; to VietNam',
                'content_id' => 569,
                'featured_end_at' => NULL,
                'id' => 234,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 15:45:00',
                'publish_div' => 1,
                'title' => '注目のお知らせ期限',
            ),
            84 => 
            array (
                'body' => 'Test push Notification&nbsp;&nbsp;',
                'content_id' => 571,
                'featured_end_at' => NULL,
                'id' => 235,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 16:03:00',
                'publish_div' => 1,
                'title' => 'Title push notification',
            ),
            85 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">ベトナムへようこそベトナムへようこそ</span></font>',
                'content_id' => 572,
                'featured_end_at' => NULL,
                'id' => 236,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 17:56:00',
                'publish_div' => 1,
                'title' => 'よくベトナムに来て',
            ),
            86 => 
            array (
            'body' => '<span style="color: rgb(34, 34, 34); font-family: &quot;Open Sans&quot;, &quot;Hiragino Sans&quot;, ヒラギノ角ゴシック, &quot;Hiragino Kaku Gothic ProN&quot;, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 13px; background-color: rgb(255, 255, 255);">番下まで表示されてから白色に変わるまで少し時間があるように感じます。</span>',
                'content_id' => 573,
                'featured_end_at' => NULL,
                'id' => 237,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 16:23:00',
                'publish_div' => 1,
                'title' => '番下まで表示されてから白色に変わるまで少し時間があるように感じます。',
            ),
            87 => 
            array (
            'body' => '<h2 class="title" style="box-sizing: border-box; margin: 0px 0px 16px; font-family: -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, Oxygen-Sans, Ubuntu, Cantarell, &quot;Helvetica Neue&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; line-height: 1.2; color: rgb(46, 46, 46); font-size: 2em; padding: 0px; border-bottom: 0px; overflow-wrap: break-word; min-width: 0px; width: 920px; background-color: rgb(255, 255, 255);">制アップデートのダイアログを非表示にしてほしい</h2>',
                'content_id' => 574,
                'featured_end_at' => NULL,
                'id' => 238,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 16:38:00',
                'publish_div' => 1,
                'title' => 'viewContent',
            ),
            88 => 
            array (
            'body' => '<span style="color: rgb(34, 34, 34); font-family: &quot;Open Sans&quot;, &quot;Hiragino Sans&quot;, ヒラギノ角ゴシック, &quot;Hiragino Kaku Gothic ProN&quot;, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 13px; background-color: rgb(255, 255, 255);">10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。</span>',
                'content_id' => 575,
                'featured_end_at' => NULL,
                'id' => 239,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 16:42:00',
                'publish_div' => 1,
                'title' => 'Title PushNotification',
            ),
            89 => 
            array (
            'body' => '<span style="color: rgb(34, 34, 34); font-family: &quot;Open Sans&quot;, &quot;Hiragino Sans&quot;, ヒラギノ角ゴシック, &quot;Hiragino Kaku Gothic ProN&quot;, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 13px; letter-spacing: 1px; background-color: rgb(255, 255, 255);">10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。</span>',
                'content_id' => 576,
                'featured_end_at' => NULL,
                'id' => 240,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 16:57:00',
                'publish_div' => 1,
                'title' => 'Title pushnotification',
            ),
            90 => 
            array (
            'body' => '<span style="color: rgb(34, 34, 34); font-family: &quot;Open Sans&quot;, &quot;Hiragino Sans&quot;, ヒラギノ角ゴシック, &quot;Hiragino Kaku Gothic ProN&quot;, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 13px; letter-spacing: 1px; background-color: rgb(255, 255, 255);">10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。</span>',
                'content_id' => 577,
                'featured_end_at' => NULL,
                'id' => 241,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-16 17:21:00',
                'publish_div' => 1,
                'title' => 'Title push notification',
            ),
            91 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test thong bao</span></font>',
                'content_id' => 632,
                'featured_end_at' => NULL,
                'id' => 244,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-26 15:33:00',
                'publish_div' => 1,
                'title' => 'test thong bao',
            ),
            92 => 
            array (
                'body' => 'dqwewq',
                'content_id' => 643,
                'featured_end_at' => NULL,
                'id' => 252,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-04-26 17:53:00',
                'publish_div' => 1,
                'title' => '認定NPO法人へのご寄付は、様々な税制優遇措置を受けることができます。',
            ),
            93 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 14px; background-color: rgb(254, 243, 236);">1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。</span>',
                'content_id' => 658,
                'featured_end_at' => NULL,
                'id' => 266,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-02 17:46:00',
                'publish_div' => 1,
                'title' => 'すぐにデータに関する情報2/5/2019',
            ),
            94 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 14px; background-color: rgb(254, 243, 236);">講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。</span>',
                'content_id' => 659,
                'featured_end_at' => NULL,
                'id' => 267,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-02 17:48:00',
                'publish_div' => 1,
                'title' => 'すぐにデータに関する情報3/5/2019',
            ),
            95 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; font-size: 14px; background-color: rgb(254, 243, 236);">投影資料は当日USBにて持参いたします。データでの事前送信は原則ご遠慮いただいています。個人情報保護などの観点からもご理解いただけますと幸いです。</span>',
                'content_id' => 660,
                'featured_end_at' => NULL,
                'id' => 268,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:50:00',
                'publish_div' => 1,
                'title' => '2/5/2019にtsunamisに関する最新情報',
            ),
            96 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">「遺贈」とは、遺言書を作成し、ご自身の財産の一部またはすべてを特定の個人や団体に与えることをいいます。近年は「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」などの様々な理由で、社会貢献団体へ遺産を寄付したいと考える方が増えています。遺言書のなかで「特定非営利活動法人3keys」を受取人にご指定いただくことにより、大切な財産を、未来を担う日本の子どもたちへの支援活動に役立てることができます。</span>',
                'content_id' => 707,
                'featured_end_at' => '2019-05-05 00:00:00',
                'id' => 314,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:49:00',
                'publish_div' => 1,
                'title' => 'Thong bao đông đât',
            ),
            97 => 
            array (
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">遺言執行者に作成方法や手続きなどをご相談しながら遺言書をご作成ください。遺言書は一般的に「公正証書遺言」と「自筆証書遺言」がありますが、紛失や偽造のおそれがない「公正証書遺言」をお勧めします。</span>',
                'content_id' => 708,
                'featured_end_at' => NULL,
                'id' => 315,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:29:00',
                'publish_div' => 1,
                'title' => 'Dong dat 2',
            ),
            98 => 
            array (
                'body' => 'hhhhhhhhhhhhhhhh',
                'content_id' => 709,
                'featured_end_at' => NULL,
                'id' => 316,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:51:00',
                'publish_div' => 1,
                'title' => 'hhhhhhhhhhhhh',
            ),
            99 => 
            array (
                'body' => '55555555553w',
                'content_id' => 710,
                'featured_end_at' => NULL,
                'id' => 317,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:51:00',
                'publish_div' => 1,
                'title' => 'h5',
            ),
            100 => 
            array (
                'body' => '44444w',
                'content_id' => 711,
                'featured_end_at' => NULL,
                'id' => 318,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:51:00',
                'publish_div' => 1,
                'title' => 'nr444',
            ),
            101 => 
            array (
                'body' => '13q13q13q13q13q13q13q13q13q',
                'content_id' => 712,
                'featured_end_at' => NULL,
                'id' => 319,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:51:00',
                'publish_div' => 1,
                'title' => 'g13q13q13q13q13q13q',
            ),
            102 => 
            array (
                'body' => '4444444444444',
                'content_id' => 713,
                'featured_end_at' => NULL,
                'id' => 320,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:51:00',
                'publish_div' => 1,
                'title' => 'h24',
            ),
            103 => 
            array (
                'body' => '3434343434343434',
                'content_id' => 714,
                'featured_end_at' => NULL,
                'id' => 321,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:52:00',
                'publish_div' => 1,
                'title' => 'm6jq34',
            ),
            104 => 
            array (
                'body' => 'gggggggggg1',
                'content_id' => 715,
                'featured_end_at' => NULL,
                'id' => 322,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:52:00',
                'publish_div' => 1,
                'title' => 'ytgggg',
            ),
            105 => 
            array (
                'body' => '4444444444444444',
                'content_id' => 716,
                'featured_end_at' => NULL,
                'id' => 323,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-04 18:52:00',
                'publish_div' => 1,
                'title' => 'h2444444',
            ),
            106 => 
            array (
                'body' => 'eqew',
                'content_id' => 720,
                'featured_end_at' => NULL,
                'id' => 327,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-06 12:28:00',
                'publish_div' => 1,
                'title' => 'eqwe',
            ),
            107 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Song than 1</span></font>',
                'content_id' => 726,
                'featured_end_at' => NULL,
                'id' => 331,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 12:49:00',
                'publish_div' => 1,
                'title' => 'Song than 1',
            ),
            108 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Song than 2</span></font>',
                'content_id' => 727,
                'featured_end_at' => NULL,
                'id' => 332,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 12:51:00',
                'publish_div' => 1,
                'title' => 'Song than 2',
            ),
            109 => 
            array (
                'body' => '<span class="tlid-translation translation" lang="ja">5つのリッチタウンレジデンス</span>',
                'content_id' => 728,
                'featured_end_at' => NULL,
                'id' => 333,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 13:01:00',
                'publish_div' => 1,
                'title' => '地震警報',
            ),
            110 => 
            array (
                'body' => '<span class="tlid-translation translation" lang="ja">精神は私達の水に上陸しようとしています</span>',
                'content_id' => 729,
                'featured_end_at' => NULL,
                'id' => 334,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 13:06:00',
                'publish_div' => 1,
                'title' => '緊急のお知らせ',
            ),
            111 => 
            array (
                'body' => '<span class="tlid-translation translation" lang="ja"><span title="" class="">精神は私達の水に上陸しようとしています</span><br><br></span>',
                'content_id' => 730,
                'featured_end_at' => NULL,
                'id' => 335,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 13:12:00',
                'publish_div' => 1,
                'title' => '緊急のお知らせ2',
            ),
            112 => 
            array (
                'body' => 'I am very happy',
                'content_id' => 732,
                'featured_end_at' => NULL,
                'id' => 337,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 13:25:00',
                'publish_div' => 1,
                'title' => 'hello Thu',
            ),
            113 => 
            array (
                'body' => '<span class="tlid-translation translation" lang="ja"><span title="" class="">5つのリッチタウンレジデンス</span></span>',
                'content_id' => 733,
                'featured_end_at' => NULL,
                'id' => 338,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-08 13:26:00',
                'publish_div' => 1,
                'title' => '地震警報',
            ),
            114 => 
            array (
                'body' => 'Atom-Powered Robots Run Amok',
                'content_id' => 2891,
                'featured_end_at' => NULL,
                'id' => 360,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-14 19:30:05',
                'publish_div' => 1,
                'title' => 'eqweqw',
            ),
            115 => 
            array (
                'body' => '
<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>


http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

平成３１年４月２１日　安八町長選挙の開票結果

ewqe',
                'content_id' => 2892,
                'featured_end_at' => NULL,
                'id' => 361,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 11:14:06',
                'publish_div' => 1,
                'title' => 'ac qww',
            ),
            116 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 2893,
                'featured_end_at' => NULL,
                'id' => 362,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 11:51:06',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            117 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2894,
                'featured_end_at' => NULL,
                'id' => 363,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 11:51:06',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            118 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>

http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 2895,
                'featured_end_at' => NULL,
                'id' => 364,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 11:51:06',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            119 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2905,
                'featured_end_at' => NULL,
                'id' => 365,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 15:45:07',
                'publish_div' => 1,
                'title' => 'Rat Vui duoc gap Ban',
            ),
            120 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2906,
                'featured_end_at' => NULL,
                'id' => 366,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 16:00:08',
                'publish_div' => 1,
                'title' => 'well come to Viet Nam',
            ),
            121 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2907,
                'featured_end_at' => NULL,
                'id' => 367,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 17:55:10',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            122 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/',
                'content_id' => 2908,
                'featured_end_at' => NULL,
                'id' => 368,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 17:56:25',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            123 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/',
                'content_id' => 2909,
                'featured_end_at' => NULL,
                'id' => 369,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 17:57:49',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            124 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2910,
                'featured_end_at' => NULL,
                'id' => 370,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 17:59:30',
                'publish_div' => 1,
                'title' => 'Chao nhe',
            ),
            125 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 2911,
                'featured_end_at' => NULL,
                'id' => 371,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:00:53',
                'publish_div' => 1,
                'title' => 'well come to Viet Nam',
            ),
            126 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/',
                'content_id' => 2912,
                'featured_end_at' => NULL,
                'id' => 372,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:02:00',
                'publish_div' => 1,
                'title' => 'well come to Viet Nam',
            ),
            127 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2913,
                'featured_end_at' => NULL,
                'id' => 373,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:03:16',
                'publish_div' => 1,
                'title' => 'well come to Viet Nam',
            ),
            128 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2914,
                'featured_end_at' => NULL,
                'id' => 374,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:20:11',
                'publish_div' => 1,
                'title' => 'Truong hop1 trung khop phan truoc',
            ),
            129 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 2915,
                'featured_end_at' => NULL,
                'id' => 375,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:35:08',
                'publish_div' => 1,
                'title' => 'Truong hop 2 Trung khop Sau',
            ),
            130 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2916,
                'featured_end_at' => NULL,
                'id' => 376,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:35:10',
                'publish_div' => 1,
                'title' => 'Truong hop 3 Trung toan bo',
            ),
            131 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 2917,
                'featured_end_at' => NULL,
                'id' => 377,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:40:19',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            132 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
                'content_id' => 2918,
                'featured_end_at' => NULL,
                'id' => 378,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:41:04',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            133 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2919,
                'featured_end_at' => NULL,
                'id' => 379,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:41:21',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            134 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>

http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 2920,
                'featured_end_at' => NULL,
                'id' => 380,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:42:40',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            135 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 2921,
                'featured_end_at' => NULL,
                'id' => 381,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:44:30',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            136 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/',
                'content_id' => 2922,
                'featured_end_at' => NULL,
                'id' => 382,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:45:43',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            137 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2923,
                'featured_end_at' => NULL,
                'id' => 383,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:47:06',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            138 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/',
                'content_id' => 2924,
                'featured_end_at' => NULL,
                'id' => 384,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:48:20',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            139 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/',
                'content_id' => 2925,
                'featured_end_at' => NULL,
                'id' => 385,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:49:46',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            140 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2926,
                'featured_end_at' => NULL,
                'id' => 386,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 18:51:23',
                'publish_div' => 1,
                'title' => 'Truong Hop 5 Khong Trung',
            ),
            141 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 2927,
                'featured_end_at' => NULL,
                'id' => 387,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:00:22',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            142 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
                'content_id' => 2928,
                'featured_end_at' => NULL,
                'id' => 388,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:01:15',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            143 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2929,
                'featured_end_at' => NULL,
                'id' => 389,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:01:31',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            144 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>

http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 2930,
                'featured_end_at' => NULL,
                'id' => 390,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:02:52',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            145 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 2931,
                'featured_end_at' => NULL,
                'id' => 391,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:04:39',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            146 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/',
                'content_id' => 2932,
                'featured_end_at' => NULL,
                'id' => 392,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:05:53',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            147 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2933,
                'featured_end_at' => NULL,
                'id' => 393,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:07:17',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            148 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/',
                'content_id' => 2934,
                'featured_end_at' => NULL,
                'id' => 394,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:08:29',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            149 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/',
                'content_id' => 2935,
                'featured_end_at' => NULL,
                'id' => 395,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:09:53',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            150 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2936,
                'featured_end_at' => NULL,
                'id' => 396,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:11:36',
                'publish_div' => 1,
                'title' => 'Test Push auto',
            ),
            151 => 
            array (
                'body' => 'sdasdasdasdad',
                'content_id' => 2937,
                'featured_end_at' => NULL,
                'id' => 397,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:15:22',
                'publish_div' => 1,
                'title' => 'ádsadsada',
            ),
            152 => 
            array (
                'body' => 'ewqewqewqe',
                'content_id' => 2938,
                'featured_end_at' => NULL,
                'id' => 398,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-15 19:22:50',
                'publish_div' => 1,
                'title' => 'eqwewqe',
            ),
            153 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 2939,
                'featured_end_at' => NULL,
                'id' => 399,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:25',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            154 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
                'content_id' => 2940,
                'featured_end_at' => NULL,
                'id' => 400,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:32',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            155 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2941,
                'featured_end_at' => NULL,
                'id' => 401,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:37',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            156 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>

http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 2942,
                'featured_end_at' => NULL,
                'id' => 402,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:42',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            157 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 2943,
                'featured_end_at' => NULL,
                'id' => 403,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:47',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            158 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/',
                'content_id' => 2944,
                'featured_end_at' => NULL,
                'id' => 404,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:52',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            159 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2945,
                'featured_end_at' => NULL,
                'id' => 405,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:40:57',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            160 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/',
                'content_id' => 2946,
                'featured_end_at' => NULL,
                'id' => 406,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:41:02',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            161 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/',
                'content_id' => 2947,
                'featured_end_at' => NULL,
                'id' => 407,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:41:07',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            162 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2948,
                'featured_end_at' => NULL,
                'id' => 408,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 10:41:13',
                'publish_div' => 1,
                'title' => 'Test Push Khong Trung Khop',
            ),
            163 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 2949,
                'featured_end_at' => NULL,
                'id' => 409,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:10:15',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            164 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 2950,
                'featured_end_at' => NULL,
                'id' => 410,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:10:21',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            165 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2951,
                'featured_end_at' => NULL,
                'id' => 411,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:10:28',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            166 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>

http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 2952,
                'featured_end_at' => NULL,
                'id' => 412,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:10:33',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            167 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>

http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 2953,
                'featured_end_at' => NULL,
                'id' => 413,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:10:38',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            168 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>

http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 2954,
                'featured_end_at' => NULL,
                'id' => 414,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:10:43',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            169 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2955,
                'featured_end_at' => NULL,
                'id' => 415,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:10:50',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            170 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2956,
                'featured_end_at' => NULL,
                'id' => 416,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:10:54',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            171 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/',
                'content_id' => 2957,
                'featured_end_at' => NULL,
                'id' => 417,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:10:59',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            172 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/',
                'content_id' => 2958,
                'featured_end_at' => NULL,
                'id' => 418,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:11:04',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            173 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/',
                'content_id' => 2959,
                'featured_end_at' => NULL,
                'id' => 419,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:11:10',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            174 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/',
                'content_id' => 2960,
                'featured_end_at' => NULL,
                'id' => 420,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:11:15',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            175 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2961,
                'featured_end_at' => NULL,
                'id' => 421,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:11:20',
                'publish_div' => 1,
                'title' => '222222222',
            ),
            176 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2962,
                'featured_end_at' => NULL,
                'id' => 422,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:11:25',
                'publish_div' => 1,
                'title' => '333333333333',
            ),
            177 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 2963,
                'featured_end_at' => NULL,
                'id' => 423,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:11:32',
                'publish_div' => 1,
                'title' => 'Ennnnnnn',
            ),
            178 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 2964,
                'featured_end_at' => NULL,
                'id' => 424,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:11:36',
                'publish_div' => 1,
                'title' => 'KO0',
            ),
            179 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/',
                'content_id' => 2965,
                'featured_end_at' => NULL,
                'id' => 425,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:11:41',
                'publish_div' => 1,
                'title' => 'Ennnnnnn',
            ),
            180 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/',
                'content_id' => 2966,
                'featured_end_at' => NULL,
                'id' => 426,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:11:46',
                'publish_div' => 1,
                'title' => 'KO0',
            ),
            181 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2967,
                'featured_end_at' => NULL,
                'id' => 427,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:11:50',
                'publish_div' => 1,
                'title' => 'Ennnnnnn',
            ),
            182 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/',
                'content_id' => 2968,
                'featured_end_at' => NULL,
                'id' => 428,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:11:54',
                'publish_div' => 1,
                'title' => 'KO0',
            ),
            183 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2969,
                'featured_end_at' => NULL,
                'id' => 429,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-16 16:12:00',
                'publish_div' => 1,
                'title' => 'Ennnnnnn',
            ),
            184 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>

http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/',
                'content_id' => 2970,
                'featured_end_at' => NULL,
                'id' => 430,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ko',
                'publish_at' => '2019-05-16 16:12:04',
                'publish_div' => 1,
                'title' => 'KO0',
            ),
            185 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果',
                'content_id' => 3091,
                'featured_end_at' => NULL,
                'id' => 540,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:00',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            186 => 
            array (
                'body' => '歴民だより　5月号　No.67',
                'content_id' => 3092,
                'featured_end_at' => NULL,
                'id' => 541,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:07',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            187 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
                'content_id' => 3093,
                'featured_end_at' => NULL,
                'id' => 542,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:12',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            188 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）',
                'content_id' => 3094,
                'featured_end_at' => NULL,
                'id' => 543,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:18',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            189 => 
            array (
                'body' => '広域行政窓口',
                'content_id' => 3095,
                'featured_end_at' => NULL,
                'id' => 544,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:23',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            190 => 
            array (
                'body' => '休日窓口',
                'content_id' => 3096,
                'featured_end_at' => NULL,
                'id' => 545,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:29',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            191 => 
            array (
                'body' => '印鑑登録証明書',
                'content_id' => 3097,
                'featured_end_at' => NULL,
                'id' => 546,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:34',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            192 => 
            array (
                'body' => '戸籍の附票',
                'content_id' => 3098,
                'featured_end_at' => NULL,
                'id' => 547,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:40',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            193 => 
            array (
                'body' => '戸籍謄抄本等',
                'content_id' => 3099,
                'featured_end_at' => NULL,
                'id' => 548,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:46',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            194 => 
            array (
                'body' => '住民票記載事項証明書',
                'content_id' => 3100,
                'featured_end_at' => NULL,
                'id' => 549,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 17:48:51',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            195 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3101,
                'featured_end_at' => NULL,
                'id' => 550,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:23:43',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            196 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3102,
                'featured_end_at' => NULL,
                'id' => 551,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:23:49',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            197 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3103,
                'featured_end_at' => NULL,
                'id' => 552,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:23:54',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            198 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3104,
                'featured_end_at' => NULL,
                'id' => 553,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:23:59',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            199 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3105,
                'featured_end_at' => NULL,
                'id' => 554,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:04',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            200 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
                'content_id' => 3106,
                'featured_end_at' => NULL,
                'id' => 555,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:07',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            201 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
                'content_id' => 3107,
                'featured_end_at' => NULL,
                'id' => 556,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:10',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            202 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3108,
                'featured_end_at' => NULL,
                'id' => 557,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:13',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            203 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
                'content_id' => 3109,
                'featured_end_at' => NULL,
                'id' => 558,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:18',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            204 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3110,
                'featured_end_at' => NULL,
                'id' => 559,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:23',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            205 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3111,
                'featured_end_at' => NULL,
                'id' => 560,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:27',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            206 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3112,
                'featured_end_at' => NULL,
                'id' => 561,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:32',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            207 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3113,
                'featured_end_at' => NULL,
                'id' => 562,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:37',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            208 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3114,
                'featured_end_at' => NULL,
                'id' => 563,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:42',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            209 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3115,
                'featured_end_at' => NULL,
                'id' => 564,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:47',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            210 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
                'content_id' => 3116,
                'featured_end_at' => NULL,
                'id' => 565,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:52',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            211 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
                'content_id' => 3117,
                'featured_end_at' => NULL,
                'id' => 566,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:24:57',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            212 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3118,
                'featured_end_at' => NULL,
                'id' => 567,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:25:00',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            213 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
                'content_id' => 3119,
                'featured_end_at' => NULL,
                'id' => 568,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:25:05',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            214 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3120,
                'featured_end_at' => NULL,
                'id' => 569,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:25:11',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            215 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3121,
                'featured_end_at' => NULL,
                'id' => 570,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:52:54',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            216 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3122,
                'featured_end_at' => NULL,
                'id' => 571,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:00',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            217 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3123,
                'featured_end_at' => NULL,
                'id' => 572,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:05',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            218 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3124,
                'featured_end_at' => NULL,
                'id' => 573,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:10',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            219 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3125,
                'featured_end_at' => NULL,
                'id' => 574,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:15',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            220 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
                'content_id' => 3126,
                'featured_end_at' => NULL,
                'id' => 575,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:19',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            221 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
                'content_id' => 3127,
                'featured_end_at' => NULL,
                'id' => 576,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:24',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            222 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3128,
                'featured_end_at' => NULL,
                'id' => 577,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:29',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            223 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
                'content_id' => 3129,
                'featured_end_at' => NULL,
                'id' => 578,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:34',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            224 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3130,
                'featured_end_at' => NULL,
                'id' => 579,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 18:53:38',
                'publish_div' => 1,
                'title' => 'Test automation ja',
            ),
            225 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3131,
                'featured_end_at' => NULL,
                'id' => 580,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:14',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            226 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3132,
                'featured_end_at' => NULL,
                'id' => 581,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:19',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            227 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3133,
                'featured_end_at' => NULL,
                'id' => 582,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:24',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            228 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3134,
                'featured_end_at' => NULL,
                'id' => 583,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:29',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            229 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3135,
                'featured_end_at' => NULL,
                'id' => 584,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:34',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            230 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
                'content_id' => 3136,
                'featured_end_at' => NULL,
                'id' => 585,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:37',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            231 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
                'content_id' => 3137,
                'featured_end_at' => NULL,
                'id' => 586,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:42',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            232 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3138,
                'featured_end_at' => NULL,
                'id' => 587,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:46',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            233 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
                'content_id' => 3139,
                'featured_end_at' => NULL,
                'id' => 588,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:51',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            234 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3140,
                'featured_end_at' => NULL,
                'id' => 589,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:29:56',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            235 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3141,
                'featured_end_at' => NULL,
                'id' => 590,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:02',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            236 => 
            array (
                'body' => '歴民だより　5月号　No.67
歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3142,
                'featured_end_at' => NULL,
                'id' => 591,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:07',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            237 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3143,
                'featured_end_at' => NULL,
                'id' => 592,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:12',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            238 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3144,
                'featured_end_at' => NULL,
                'id' => 593,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:17',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            239 => 
            array (
                'body' => '広域行政窓口
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3145,
                'featured_end_at' => NULL,
                'id' => 594,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:22',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            240 => 
            array (
                'body' => '休日窓口
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/

<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
                'content_id' => 3146,
                'featured_end_at' => NULL,
                'id' => 595,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:27',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            241 => 
            array (
                'body' => '印鑑登録証明書
印鑑登録証明書交付申請 申請できる方 安八町に住民登録があり、印鑑登録をしている本人 印鑑登録している本人に頼まれた方 申請に必要なもの ○印鑑登録証 ○本人確認書類 ○印鑑（本人以外の方） ※印鑑登録証明書交付申請書に &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2%e8%a8%bc%e6%98%8e%e6%9b%b8-2/

<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
                'content_id' => 3147,
                'featured_end_at' => NULL,
                'id' => 596,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:32',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            242 => 
            array (
                'body' => '戸籍の附票
戸籍の附票について 安八町内に本籍地のある方の住所の異動が記録されているものです。 申請できる方 本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、委任状が必要です。） 申請時に必要なもの ○窓口にみ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e3%81%ae%e9%99%84%e7%a5%a8/

<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3148,
                'featured_end_at' => NULL,
                'id' => 597,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:37',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            243 => 
            array (
                'body' => '戸籍謄抄本等
戸籍証明書などの請求 　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e6%88%b8%e7%b1%8d%e8%ac%84%e6%8a%84%e6%9c%ac%e7%ad%89/

<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
                'content_id' => 3149,
                'featured_end_at' => NULL,
                'id' => 598,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:42',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            244 => 
            array (
                'body' => '住民票記載事項証明書
住民票記載事項証明書について 安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。 申請できる方 本人又は同一世帯の方（代理人の場合は委任状が必要です） 申請に必要なもの &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bd%8f%e6%b0%91%e7%a5%a8%e8%a8%98%e8%bc%89%e4%ba%8b%e9%a0%85%e8%a8%bc%e6%98%8e%e6%9b%b8/

<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3150,
                'featured_end_at' => NULL,
                'id' => 599,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-16 19:30:47',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            245 => 
            array (
                'body' => '
<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3151,
                'featured_end_at' => NULL,
                'id' => 600,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:25:59',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            246 => 
            array (
                'body' => '
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3152,
                'featured_end_at' => NULL,
                'id' => 601,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:06',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            247 => 
            array (
                'body' => '
<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3153,
                'featured_end_at' => NULL,
                'id' => 602,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:11',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            248 => 
            array (
                'body' => '
<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3154,
                'featured_end_at' => NULL,
                'id' => 603,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:16',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            249 => 
            array (
                'body' => '
<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3155,
                'featured_end_at' => NULL,
                'id' => 604,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:21',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            250 => 
            array (
                'body' => '
<h3>休日窓口サービスについて（平日の通常業務と内容が違います）</h3>
<p>住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出）や<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/kennkouhoken/">国民健康保険</a>・<a href="http://www.town.anpachi.gifu.jp/category/kurasi/kenkouhukusi/nenkin-kenkouhukusi/">年金</a>等の手続きはできません。</p>
<p>&nbsp;</p>
<h5>開設日時：毎月　第2日曜日、第4日曜日　午前8時30分～午後5時00分</h5>
<p>○その他の土曜、日曜日は開設しておりません。</p>
<h5>開設場所：安八町役場　1階　住民環境課・税務課の窓口</h5>
<h3>住民環境課の休日窓口でできる手続き</h3>
<p>○個人番号カードの交付</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/be24f5c65c41d0b566263b4a0d3fdc211.pdf">個人番号カード　利用のご案内　</a></p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2016/02/b226be7dab64cc4c293fecf1744e26b12.pdf">電子証明書　利用のご案内</a></p>
<p>○戸籍謄抄本、除籍・改製原戸籍謄抄本、戸籍の附票の交付請求</p>
<p>→請求できる方は、本人または同一戸籍に属する方</p>
<p>○住民票の写し、住民記載事項証明書、印鑑登録証明書の交付請求</p>
<p>→請求できる方は、本人または同一世帯に属する方</p>
<p>→印鑑登録証明書の交付の場合は、印鑑登録証（水色のカード）が必要です。</p>
<p>○身分証明書の交付請求　→　請求できる方は、本人または同一戸籍に属する方（<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a6.pdf">委任状</a>が必要）</p>
<p>○印鑑登録の手続き　→　手続きできるのは、本人のみ</p>
<h3>税務課の休日窓口でできる手続き</h3>
<p>○固定資産評価証明書の交付請求　→　請求できる方は、本人又は相続人のみ</p>
<p>○納税証明書、所得証明書の交付請求　→　請求できる方は、本人又は同一世帯に属する方</p>
<h5>必要なもの</h5>
<p>○各種証明交付請求は、「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等）」と「認印」と「証明手数料」 印鑑登録証明書の請求の場合は、「印鑑登録証（水色のカード）」も必要です。</p>
<p>○印鑑登録の場合は、「登録印」と「顔写真付の公的証明書（運転免許証、パスポート、在留カード等）」</p>
<p>注意：顔写真付の証明が無い方は、手続き方法が違いますので<a href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/">印鑑登録</a>の手続きをご覧ください。</p>
',
                'content_id' => 3156,
                'featured_end_at' => NULL,
                'id' => 605,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:26',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            251 => 
            array (
                'body' => '
<h3>印鑑登録証明書交付申請<strong></strong></h3>
<h5>申請できる方</h5>
<p>安八町に住民登録があり、印鑑登録をしている本人</p>
<p>印鑑登録している本人に頼まれた方</p>
<h5>申請に必要なもの</h5>
<ul>
<li>○印鑑登録証</li>
<li>○本人確認書類</li>
<li>○印鑑（本人以外の方）</li>
</ul>
<p>※印鑑登録証明書交付申請書には、住所、氏名、生年月日を正確に記入していただきます。</p>
<p>※印鑑登録をしていない方、印鑑登録証の提示がない方は、印鑑登録証明の発行はできません。</p>
<p>※印鑑登録証を紛失した方は、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">登録の廃止</a>をしていただき、<a title="印鑑登録" href="http://www.town.anpachi.gifu.jp/2012/08/29/%e5%8d%b0%e9%91%91%e7%99%bb%e9%8c%b2/" target="_blank">新たに登録</a>となります。</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f64.pdf">結郵便局</a></p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
<h5>電話での予約</h5>
<p>受付時間内に役場にお越しいただけない場合は以下の手続きにより、印鑑登録証明書をお渡しできます。</p>
<p>ただし、申請や受取ができるのは、本人または同一世帯の方のみになります。</p>
<p>1　 受付時間内に印鑑登録者の住所、氏名、生年月日、印鑑登録番号、必要な通数を告げてください。</p>
<p>2　本人確認書類、印鑑登録証、印鑑（本人以外の場合）,手数料をお持ちになり、安八町役場で受取をしてください。（結郵便局は不可）</p>
',
                'content_id' => 3157,
                'featured_end_at' => NULL,
                'id' => 606,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:30',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            252 => 
            array (
                'body' => '
<h3>戸籍の附票について<strong></strong></h3>
<p>安八町内に本籍地のある方の住所の異動が記録されているものです。</p>
<h5>申請できる方</h5>
<p>本人、同一戸籍内の者または直系の親族（左記以外の方が申請される場合は、<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a2.pdf">委任状</a>が必要です。）</p>
<h5>申請時に必要なもの</h5>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a3.pdf">委任状</a>（本人、同一戸籍内の者または直系の親族以外の請求の場合）</p>
<p>↓法人による第三者請求の場合は下記の書類も必要です</p>
<p>○必要な附票の方との契約書類のコピー</p>
<p>○社員証又は会社との関係がわかるもの</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>※本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<p>※<a href="#koseki">郵送による戸籍の附票の請求</a>もできますのでご利用ください。</p>
<h5 id="koseki">受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f63.pdf">結郵便局</a></p>
<h3>戸籍の附票の郵送請求について</h3>
<p>戸籍の附票を郵送で請求することもできます。申請されましたら、返送いたします。</p>
<h5>請求に必要なもの（下記のものをまとめて送付してください）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d6.pdf">戸籍謄本等郵送請求書</a></p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<h5>法人による第三者請求の場合は下記のものも同封してください。</h5>
<p>○委任状又は必要な住民票の方との契約書類</p>
<p>○登記事項証明書又は代表者事項証明書のコピー</p>
<p>○社員証のコピー又は会社と請求担当者の関係がわかるもの</p>
<p>○請求担当者の本人確認書類のコピー</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3158,
                'featured_end_at' => NULL,
                'id' => 607,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:35',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            253 => 
            array (
                'body' => '
<h3>戸籍証明書などの請求<strong></strong></h3>
<p>　 戸籍証明書は本籍地での申請となります。本籍地が安八町の戸籍謄抄本・除籍・改製原戸籍謄抄本が必要な方は、請求書に必要事項を記入して、窓口で請求してください。なお、本籍地番がわからないと請求できませんので、前もってご確認ください。また、ご住所が遠方の場合などは、<a href="#koseki">戸籍謄本等を郵送請求</a>することもできます。</p>
<p>　本籍地が安八町でない方は、申請方法等を本籍地にお問い合わせください。本籍地が西濃地域・岐阜地域の方で、本人または戸籍に記載されている人が申請する場合は、<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">広域行政窓口サービス</a>がご利用いただけます。</p>
<h5>本人・配偶者及び直系親族の方が窓口に来る場合の持ち物</h5>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<p>○安八町の戸籍で直系親族等の確認がとれない場合は、関係のわかる戸籍を見せていただく場合があります。</p>
<h5>代理人が窓口に来る場合の持ち物</h5>
<p>○委任者の<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a4.pdf">委任状</a>（代理人が委任者の配偶者、直系親族の場合は不要）</p>
<p>○本人・配偶者及び直系親族以外の方で委任状が得られない場合は疎明資料が必要です。</p>
<p>○代理人の印鑑</p>
<p>○代理人の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（免許証、パスポート等）</p>
<h5>受付窓口</h5>
<p>○安八町役場　住民環境課（本庁舎1階）</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f62.pdf">結郵便局</a></p>
<h5>受付日時</h5>
<p>○月曜日～金曜日（祝祭日、12/29～1/3を除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>○本人または同一戸籍の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h3 id="koseki">戸籍謄本等を郵送で請求する場合</h3>
<p>　戸籍証明書は本籍地への請求となります。戸籍謄本等を郵便で申請される場合は、必要なものを揃えて郵送していただきますと、返信用封筒にてお送りいたします。返送先は、原則、申請者の住所地となります。また、本人・配偶者・直系親族以外の方が申請される場合は、使用目的を詳しくご記入いただくとともに、委任状又は疎明資料が必要です。使用目的の理由によっては、交付できない場合もあります。</p>
<p>なお、身分証明書・独身証明書は本人申請となりますので、代理申請の場合は委任状が必要です。</p>
<h5>必要なもの（下記のものを入れて郵送をお願いします。）</h5>
<p>○「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/3fc83980d2c74e4d4350f65e2a5659d61.pdf">戸籍謄本等郵送請求書</a>」　もれなく記入・押印してください。同じ内容を便箋等に記入・押印していただいたものでも結構です。昼間（8：30～17：15）の連絡先を必ずご記入ください。</p>
<p>○「証明手数料」　郵便局の定額小為替にてご用意ください。（切手や収入印紙では受付できません。）</p>
<p>○「返信用封筒」　申請者の住所、氏名を記入し、切手を貼ってください。</p>
<p>○「<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認資料</a>」運転免許証等の写し</p>
<p>＊請求者と必要な戸籍等に記載されている人との関係が安八町の戸籍でわからない場合は、</p>
<p>関係のわかる戸籍のコピーの添付もお願いしています。</p>
<h5>郵送先（取扱窓口）</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取161番地　安八町役場　住民環境課　戸籍住民係</p>
<p>℡（０５８４）６４－３１１１＜内線２５４＞</p>
<p>電話によるお問い合わせは、窓口時間内（平日8：30～17：15）にお願いします。</p>
<h5>手数料<strong></strong></h5>
<p>○戸籍謄・抄本　1通450円</p>
<p>○除籍・改製原戸籍謄抄本　1通750円</p>
',
                'content_id' => 3159,
                'featured_end_at' => NULL,
                'id' => 608,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:40',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            254 => 
            array (
                'body' => '
<h3>住民票記載事項証明書について<strong></strong></h3>
<p>安八町に住民登録をしている方の住民票の内容の中から、申請者の方が必要とする項目のみを証明するものです。</p>
<h5>申請できる方</h5>
<p>本人又は同一世帯の方（代理人の場合は<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/9493d4c598f8f876514a01f95d126c7a.pdf">委任状</a>が必要です）</p>
<h5>申請に必要なもの</h5>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>→特に指定の様式がなければ、安八町の様式（住所、氏名、性別、生年月日のみを記載）で発行します。</p>
<p>○窓口にみえる方の<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a></p>
<p>○印鑑</p>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a1.pdf">委任状</a>（本人又は同一世帯以外の請求の方）</p>
<h5>受付時間</h5>
<p>月曜日～金曜日（祝祭日及び12/29～1/3は除く）</p>
<p>午前8時30分～午後5時15分</p>
<p>本人または同一世帯の方による申請の場合は<a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">休日窓口サービス</a>もご利用できます。</p>
<h5>受付場所</h5>
<p>安八町役場 住民環境課窓口 又は <a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/03/6f3c1389170153f3596a0186637d15f6.pdf">結郵便局</a></p>
<h3>郵送で請求する場合</h3>
<h5>請求に必要なもの（下記のものをまとめて郵送をお願いします。）</h5>
<p>○<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2011/12/81e97f1a84bda61d4333f5a341bfaa09.pdf">住民票（除票）郵送請求書</a></p>
<p>○提出先から指定されている証明用の書類（必要事項を記入していただいたもの）</p>
<p>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>のコピー</p>
<p>○交付手数料（郵便局で必要な通数分の「定額小為替」を購入してください）</p>
<p>　　※定額小為替の指定受取人欄には何も書かないでください。</p>
<p>○返信用の封筒（切手を貼り、あなたの住所と氏名をはっきり記入してください）</p>
<p>　　※返送先は「住民登録地」または「法人所在地」に限ります。</p>
<h5>送付先</h5>
<p>〒５０３－０１９８</p>
<p>岐阜県安八郡安八町氷取１６１番地</p>
<p>安八町役場　住民環境課　戸籍住民係</p>
<h5>手数料<strong></strong></h5>
<p>１通　２００円</p>
',
                'content_id' => 3160,
                'featured_end_at' => NULL,
                'id' => 609,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-17 15:26:45',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            255 => 
            array (
                'body' => '住民票記載事項証明書

2019年4月1日 7時37分',
                'content_id' => 3161,
                'featured_end_at' => NULL,
                'id' => 610,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:29:29',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            256 => 
            array (
                'body' => '戸籍謄抄本等

2019年4月1日 7時46分',
                'content_id' => 3162,
                'featured_end_at' => NULL,
                'id' => 611,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:29:36',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            257 => 
            array (
                'body' => '戸籍の附票

2019年4月1日 9時04分',
                'content_id' => 3163,
                'featured_end_at' => NULL,
                'id' => 612,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:29:42',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            258 => 
            array (
                'body' => '印鑑登録証明書

2019年4月1日 9時09分',
                'content_id' => 3164,
                'featured_end_at' => NULL,
                'id' => 613,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:29:48',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            259 => 
            array (
                'body' => '休日窓口

2019年4月1日 10時56分',
                'content_id' => 3165,
                'featured_end_at' => NULL,
                'id' => 614,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:29:54',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            260 => 
            array (
                'body' => '広域行政窓口

2019年4月1日 11時01分',
                'content_id' => 3166,
                'featured_end_at' => NULL,
                'id' => 615,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:30:01',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            261 => 
            array (
                'body' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）

2019年4月26日 4時48分',
                'content_id' => 3167,
                'featured_end_at' => NULL,
                'id' => 616,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:30:06',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            262 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について

2019年5月6日 23時30分',
                'content_id' => 3168,
                'featured_end_at' => NULL,
                'id' => 617,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:30:12',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            263 => 
            array (
                'body' => '歴民だより　5月号　No.67

2019年5月7日 0時30分',
                'content_id' => 3169,
                'featured_end_at' => NULL,
                'id' => 618,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:30:19',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            264 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果

2019年5月7日 0時30分',
                'content_id' => 3170,
                'featured_end_at' => NULL,
                'id' => 619,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-20 15:30:25',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            265 => 
            array (
                'body' => '険物施設は消防法及び関係法令により細部にわたり規制基準が示されており、町は、
これらの法令に基づき規制の強化、事業所に対する指導の強化を行う。
また、危険物施設の被害、機能障害を想定したマニュアル作成指導を推進し、マニュ
アルに基づく訓練、啓発などの実施励行による防災意識の高揚を図る。
（１）大規模タンクの安全化
一定規模以下の貯蔵タンクについても不等沈下、移動、配管の切断、亀裂等の事故
防止のため、タンクが設',
                'content_id' => 3171,
                'featured_end_at' => '2019-05-22 00:00:00',
                'id' => 620,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-21 11:46:00',
                'publish_div' => 1,
                'title' => 'test ja',
            ),
            266 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">deeeeeeeee</span></font>',
                'content_id' => 3175,
                'featured_end_at' => NULL,
                'id' => 621,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-21 18:05:00',
                'publish_div' => 1,
                'title' => 'deeeeeeeee',
            ),
            267 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Minh Thu ja</span></font>',
                'content_id' => 3176,
                'featured_end_at' => NULL,
                'id' => 622,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-22 15:19:00',
                'publish_div' => 1,
                'title' => 'Minh Thu ja',
            ),
            268 => 
            array (
                'body' => '必要がある場合は、事業
所の管理者等に対し、災害防止上必要な助言又は指導を行う。',
                'content_id' => 3177,
                'featured_end_at' => NULL,
                'id' => 623,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-23 11:58:00',
                'publish_div' => 1,
                'title' => 'Test P9 ja',
            ),
            269 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3178,
                'featured_end_at' => NULL,
                'id' => 624,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-23 11:29:19',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            270 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3179,
                'featured_end_at' => NULL,
                'id' => 625,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-23 11:29:31',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            271 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3180,
                'featured_end_at' => NULL,
                'id' => 626,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-23 11:29:42',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            272 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月３１日（金）</p>
<p>　　※必着、郵送の場合は５月３１日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd1.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・財金の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3181,
                'featured_end_at' => NULL,
                'id' => 627,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-23 11:29:52',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            273 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果


<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>


2019年5月7日 0時30分',
                'content_id' => 3186,
                'featured_end_at' => NULL,
                'id' => 628,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-23 11:41:44',
                'publish_div' => 1,
                'title' => '平成３１年４月２１日　安八町長選挙の開票結果',
            ),
            274 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Push lan1</span></font>',
                'content_id' => 3225,
                'featured_end_at' => NULL,
                'id' => 629,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 11:27:00',
                'publish_div' => 1,
                'title' => 'Push lan1',
            ),
            275 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Push lan2</span></font>',
                'content_id' => 3226,
                'featured_end_at' => NULL,
                'id' => 630,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 11:27:00',
                'publish_div' => 1,
                'title' => 'Push lan2',
            ),
            276 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Push lan3</span></font>',
                'content_id' => 3227,
                'featured_end_at' => NULL,
                'id' => 631,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 11:28:00',
                'publish_div' => 1,
                'title' => 'Push lan3',
            ),
            277 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Push lan4</span></font>',
                'content_id' => 3228,
                'featured_end_at' => NULL,
                'id' => 632,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 11:29:00',
                'publish_div' => 1,
                'title' => 'Push lan4',
            ),
            278 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test push nhe 1</span></font>',
                'content_id' => 3229,
                'featured_end_at' => NULL,
                'id' => 633,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 11:37:00',
                'publish_div' => 1,
                'title' => 'test push nhe 1',
            ),
            279 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thu la la</span></font>',
                'content_id' => 3230,
                'featured_end_at' => '2019-05-26 00:00:00',
                'id' => 634,
                'is_featured' => 1,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-25 09:55:00',
                'publish_div' => 2,
                'title' => 'Thu la la',
            ),
            280 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thu post 1</span></font>',
                'content_id' => 3231,
                'featured_end_at' => NULL,
                'id' => 635,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 12:40:00',
                'publish_div' => 1,
                'title' => 'Thu post 1',
            ),
            281 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thu post 2</span></font>',
                'content_id' => 3232,
                'featured_end_at' => NULL,
                'id' => 636,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 12:41:00',
                'publish_div' => 1,
                'title' => 'Thu post 2',
            ),
            282 => 
            array (
                'body' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント

2019年5月23日 4時46分',
                'content_id' => 3233,
                'featured_end_at' => NULL,
                'id' => 637,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:01:42',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            283 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3234,
                'featured_end_at' => NULL,
                'id' => 638,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:02:12',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            284 => 
            array (
                'body' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3235,
                'featured_end_at' => NULL,
                'id' => 639,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:02:26',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            285 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3236,
                'featured_end_at' => NULL,
                'id' => 640,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:02:45',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            286 => 
            array (
                'body' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3237,
                'featured_end_at' => NULL,
                'id' => 641,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:02:57',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            287 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3238,
                'featured_end_at' => NULL,
                'id' => 642,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:03:15',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            288 => 
            array (
                'body' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3239,
                'featured_end_at' => NULL,
                'id' => 643,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:03:28',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            289 => 
            array (
                'body' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3240,
                'featured_end_at' => NULL,
                'id' => 644,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:03:45',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            290 => 
            array (
                'body' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3241,
                'featured_end_at' => NULL,
                'id' => 645,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 13:03:57',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            291 => 
            array (
                'body' => '
<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3242,
                'featured_end_at' => NULL,
                'id' => 646,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-24 15:48:11',
                'publish_div' => 1,
                'title' => 'english title',
            ),
            292 => 
            array (
                'body' => '
<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3243,
                'featured_end_at' => NULL,
                'id' => 647,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'en',
                'publish_at' => '2019-05-24 15:48:31',
                'publish_div' => 1,
                'title' => 'english title',
            ),
            293 => 
            array (
                'body' => '
<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3244,
                'featured_end_at' => NULL,
                'id' => 648,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:50:45',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            294 => 
            array (
                'body' => '
<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3245,
                'featured_end_at' => NULL,
                'id' => 649,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:50:59',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            295 => 
            array (
                'body' => '',
                'content_id' => 3246,
                'featured_end_at' => NULL,
                'id' => 650,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:51:12',
                'publish_div' => 1,
                'title' => 'rss 1',
            ),
            296 => 
            array (
                'body' => '【告知】えこ之助と一緒に！「ほっかいどう・省エネ３Ｓキャンペーン」夏の陣



xyz abc',
                'content_id' => 3247,
                'featured_end_at' => NULL,
                'id' => 651,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:51:44',
                'publish_div' => 1,
                'title' => '【告知】えこ之助と一緒に！「ほっかいどう・省エネ３Ｓキャンペーン」夏の陣 [@pubDate]',
            ),
            297 => 
            array (
            'body' => '【催し】令和元年度(2019年度)景観の日パネル展



xyz abc',
                'content_id' => 3248,
                'featured_end_at' => NULL,
                'id' => 652,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:51:49',
                'publish_div' => 1,
            'title' => '【催し】令和元年度(2019年度)景観の日パネル展 [@pubDate]',
            ),
            298 => 
            array (
                'body' => '【その他】公有水面埋立免許（変更）許可申請書等の告示・縦覧のお知らせ



xyz abc',
                'content_id' => 3249,
                'featured_end_at' => NULL,
                'id' => 653,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:51:54',
                'publish_div' => 1,
                'title' => '【その他】公有水面埋立免許（変更）許可申請書等の告示・縦覧のお知らせ [@pubDate]',
            ),
            299 => 
            array (
                'body' => '【催し】ほっかいどうナイスハートフェアのお知らせ（障がい者保健福祉課）



xyz abc',
                'content_id' => 3250,
                'featured_end_at' => NULL,
                'id' => 654,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:51:59',
                'publish_div' => 1,
                'title' => '【催し】ほっかいどうナイスハートフェアのお知らせ（障がい者保健福祉課） [@pubDate]',
            ),
            300 => 
            array (
                'body' => '【告知】北海道ミライノート



xyz abc',
                'content_id' => 3251,
                'featured_end_at' => NULL,
                'id' => 655,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:06',
                'publish_div' => 1,
                'title' => '【告知】北海道ミライノート [@pubDate]',
            ),
            301 => 
            array (
                'body' => '【募集】北海道インフラツアー



xyz abc',
                'content_id' => 3252,
                'featured_end_at' => NULL,
                'id' => 656,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:11',
                'publish_div' => 1,
                'title' => '【募集】北海道インフラツアー [@pubDate]',
            ),
            302 => 
            array (
                'body' => '【その他】道路維持管理　北海道告示（道路関係）



xyz abc',
                'content_id' => 3253,
                'featured_end_at' => NULL,
                'id' => 657,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:16',
                'publish_div' => 1,
                'title' => '【その他】道路維持管理　北海道告示（道路関係） [@pubDate]',
            ),
            303 => 
            array (
                'body' => '【募集】北海道とつながるカフェ参加者募集中



xyz abc',
                'content_id' => 3254,
                'featured_end_at' => NULL,
                'id' => 658,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:21',
                'publish_div' => 1,
                'title' => '【募集】北海道とつながるカフェ参加者募集中 [@pubDate]',
            ),
            304 => 
            array (
                'body' => '【その他】知事定例記者会見（令和元年5月22日）



xyz abc',
                'content_id' => 3255,
                'featured_end_at' => NULL,
                'id' => 659,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:26',
                'publish_div' => 1,
                'title' => '【その他】知事定例記者会見（令和元年5月22日） [@pubDate]',
            ),
            305 => 
            array (
                'body' => '【入札】公募型プロポーザルの実施について（江差高看）



xyz abc',
                'content_id' => 3256,
                'featured_end_at' => NULL,
                'id' => 660,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:31',
                'publish_div' => 1,
                'title' => '【入札】公募型プロポーザルの実施について（江差高看） [@pubDate]',
            ),
            306 => 
            array (
                'body' => '【入札】一般競争入札の実施について（道庁行政情報ネットワーク機器の賃貸借その１）



xyz abc',
                'content_id' => 3257,
                'featured_end_at' => NULL,
                'id' => 661,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:37',
                'publish_div' => 1,
                'title' => '【入札】一般競争入札の実施について（道庁行政情報ネットワーク機器の賃貸借その１） [@pubDate]',
            ),
            307 => 
            array (
                'body' => '【告知】告示（測量法に関する「諸手続」に係る通知）



xyz abc',
                'content_id' => 3258,
                'featured_end_at' => NULL,
                'id' => 662,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:42',
                'publish_div' => 1,
                'title' => '【告知】告示（測量法に関する「諸手続」に係る通知） [@pubDate]',
            ),
            308 => 
            array (
                'body' => '【告知】北海道クールあいらんどキャンペーン



xyz abc',
                'content_id' => 3259,
                'featured_end_at' => NULL,
                'id' => 663,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:47',
                'publish_div' => 1,
                'title' => '【告知】北海道クールあいらんどキャンペーン [@pubDate]',
            ),
            309 => 
            array (
                'body' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）



xyz abc',
                'content_id' => 3260,
                'featured_end_at' => NULL,
                'id' => 664,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:53',
                'publish_div' => 1,
                'title' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報） [@pubDate]',
            ),
            310 => 
            array (
                'body' => '【募集】審議会委員の募集



xyz abc',
                'content_id' => 3261,
                'featured_end_at' => NULL,
                'id' => 665,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 15:52:58',
                'publish_div' => 1,
                'title' => '【募集】審議会委員の募集 [@pubDate]',
            ),
            311 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test push nhe 2</span></font>',
                'content_id' => 3262,
                'featured_end_at' => NULL,
                'id' => 666,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:07:00',
                'publish_div' => 1,
                'title' => 'test push nhe 2',
            ),
            312 => 
            array (
                'body' => '【入札】大学法人室トップページ（公立大学法人に関する情報）



xyz abc',
                'content_id' => 3263,
                'featured_end_at' => NULL,
                'id' => 667,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:14:51',
                'publish_div' => 1,
                'title' => '【入札】大学法人室トップページ（公立大学法人に関する情報） [@pubDate]',
            ),
            313 => 
            array (
                'body' => 'hello

【催し】令和元年度(2019年度)景観の日パネル展

[link]',
                'content_id' => 3264,
                'featured_end_at' => NULL,
                'id' => 668,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:01',
                'publish_div' => 1,
            'title' => '【催し】令和元年度(2019年度)景観の日パネル展 [@dc:date]',
            ),
            314 => 
            array (
                'body' => 'hello

【その他】公有水面埋立免許（変更）許可申請書等の告示・縦覧のお知らせ

[link]',
                'content_id' => 3265,
                'featured_end_at' => NULL,
                'id' => 669,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:07',
                'publish_div' => 1,
                'title' => '【その他】公有水面埋立免許（変更）許可申請書等の告示・縦覧のお知らせ [@dc:date]',
            ),
            315 => 
            array (
                'body' => 'hello

【催し】ほっかいどうナイスハートフェアのお知らせ（障がい者保健福祉課）

[link]',
                'content_id' => 3266,
                'featured_end_at' => NULL,
                'id' => 670,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:12',
                'publish_div' => 1,
                'title' => '【催し】ほっかいどうナイスハートフェアのお知らせ（障がい者保健福祉課） [@dc:date]',
            ),
            316 => 
            array (
                'body' => 'hello

【告知】北海道ミライノート

[link]',
                'content_id' => 3267,
                'featured_end_at' => NULL,
                'id' => 671,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:17',
                'publish_div' => 1,
                'title' => '【告知】北海道ミライノート [@dc:date]',
            ),
            317 => 
            array (
                'body' => 'hello

【募集】北海道インフラツアー

[link]',
                'content_id' => 3268,
                'featured_end_at' => NULL,
                'id' => 672,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:22',
                'publish_div' => 1,
                'title' => '【募集】北海道インフラツアー [@dc:date]',
            ),
            318 => 
            array (
                'body' => 'hello

【その他】道路維持管理　北海道告示（道路関係）

[link]',
                'content_id' => 3269,
                'featured_end_at' => NULL,
                'id' => 673,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:28',
                'publish_div' => 1,
                'title' => '【その他】道路維持管理　北海道告示（道路関係） [@dc:date]',
            ),
            319 => 
            array (
                'body' => 'hello

【募集】北海道とつながるカフェ参加者募集中

[link]',
                'content_id' => 3270,
                'featured_end_at' => NULL,
                'id' => 674,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:33',
                'publish_div' => 1,
                'title' => '【募集】北海道とつながるカフェ参加者募集中 [@dc:date]',
            ),
            320 => 
            array (
                'body' => 'hello

【その他】知事定例記者会見（令和元年5月22日）

[link]',
                'content_id' => 3271,
                'featured_end_at' => NULL,
                'id' => 675,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:38',
                'publish_div' => 1,
                'title' => '【その他】知事定例記者会見（令和元年5月22日） [@dc:date]',
            ),
            321 => 
            array (
                'body' => 'hello

【入札】公募型プロポーザルの実施について（江差高看）

[link]',
                'content_id' => 3272,
                'featured_end_at' => NULL,
                'id' => 676,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:44',
                'publish_div' => 1,
                'title' => '【入札】公募型プロポーザルの実施について（江差高看） [@dc:date]',
            ),
            322 => 
            array (
                'body' => 'hello

【入札】一般競争入札の実施について（道庁行政情報ネットワーク機器の賃貸借その１）

[link]',
                'content_id' => 3273,
                'featured_end_at' => NULL,
                'id' => 677,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:49',
                'publish_div' => 1,
                'title' => '【入札】一般競争入札の実施について（道庁行政情報ネットワーク機器の賃貸借その１） [@dc:date]',
            ),
            323 => 
            array (
                'body' => 'hello

【告知】告示（測量法に関する「諸手続」に係る通知）

[link]',
                'content_id' => 3274,
                'featured_end_at' => NULL,
                'id' => 678,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:54',
                'publish_div' => 1,
                'title' => '【告知】告示（測量法に関する「諸手続」に係る通知） [@dc:date]',
            ),
            324 => 
            array (
                'body' => 'hello

【告知】北海道クールあいらんどキャンペーン

[link]',
                'content_id' => 3275,
                'featured_end_at' => NULL,
                'id' => 679,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:15:59',
                'publish_div' => 1,
                'title' => '【告知】北海道クールあいらんどキャンペーン [@dc:date]',
            ),
            325 => 
            array (
                'body' => 'hello

【入札】大学法人室トップページ（公立大学法人に関する情報）

[link]',
                'content_id' => 3276,
                'featured_end_at' => NULL,
                'id' => 680,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:16:04',
                'publish_div' => 1,
                'title' => '【入札】大学法人室トップページ（公立大学法人に関する情報） [@dc:date]',
            ),
            326 => 
            array (
                'body' => 'hello

【募集】審議会委員の募集

[link]',
                'content_id' => 3277,
                'featured_end_at' => NULL,
                'id' => 681,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:16:09',
                'publish_div' => 1,
                'title' => '【募集】審議会委員の募集 [@dc:date]',
            ),
            327 => 
            array (
                'body' => 'hello

【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）

[link]',
                'content_id' => 3278,
                'featured_end_at' => NULL,
                'id' => 682,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:16:14',
                'publish_div' => 1,
                'title' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報） [@dc:date]',
            ),
            328 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thu dieu 1</span></font>',
                'content_id' => 3279,
                'featured_end_at' => NULL,
                'id' => 683,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:43:00',
                'publish_div' => 1,
                'title' => 'Thu dieu 1',
            ),
            329 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thu Vinh</span></font>',
                'content_id' => 3280,
                'featured_end_at' => NULL,
                'id' => 684,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 16:45:00',
                'publish_div' => 1,
                'title' => 'Thu Vinh',
            ),
            330 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thu Vinh</span></font>',
                'content_id' => 3287,
                'featured_end_at' => NULL,
                'id' => 691,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 17:59:00',
                'publish_div' => 1,
                'title' => 'Thu Vinh',
            ),
            331 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test push nhe 4 - 162</span></font>',
                'content_id' => 3290,
                'featured_end_at' => NULL,
                'id' => 693,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 18:10:00',
                'publish_div' => 1,
                'title' => 'test push nhe 4 - 162',
            ),
            332 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test push nhe 5 - 162</span></font>',
                'content_id' => 3291,
                'featured_end_at' => NULL,
                'id' => 694,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-24 18:11:00',
                'publish_div' => 1,
                'title' => 'test push nhe 5 - 162',
            ),
            333 => 
            array (
                'body' => '予防接種町指定医療機関一覧

2019年5月24日 8時24分',
                'content_id' => 3292,
                'featured_end_at' => NULL,
                'id' => 695,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:24:55',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            334 => 
            array (
                'body' => '日本脳炎

2019年5月24日 8時24分',
                'content_id' => 3293,
                'featured_end_at' => NULL,
                'id' => 696,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:25:08',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            335 => 
            array (
                'body' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ

2019年5月24日 8時25分',
                'content_id' => 3294,
                'featured_end_at' => NULL,
                'id' => 697,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:25:20',
                'publish_div' => 1,
                'title' => 'japan title',
            ),
            336 => 
            array (
                'body' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
                'content_id' => 3295,
                'featured_end_at' => NULL,
                'id' => 698,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:25:36',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            337 => 
            array (
                'body' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
                'content_id' => 3296,
                'featured_end_at' => NULL,
                'id' => 699,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:25:45',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            338 => 
            array (
                'body' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
                'content_id' => 3297,
                'featured_end_at' => NULL,
                'id' => 700,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:25:57',
                'publish_div' => 1,
                'title' => 'Title ja',
            ),
            339 => 
            array (
                'body' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
                'content_id' => 3298,
                'featured_end_at' => NULL,
                'id' => 701,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:26:08',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            340 => 
            array (
                'body' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
                'content_id' => 3299,
                'featured_end_at' => NULL,
                'id' => 702,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:26:20',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            341 => 
            array (
                'body' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
                'content_id' => 3300,
                'featured_end_at' => NULL,
                'id' => 703,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:26:32',
                'publish_div' => 1,
                'title' => 'Chao thu ja',
            ),
            342 => 
            array (
                'body' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
                'content_id' => 3301,
                'featured_end_at' => NULL,
                'id' => 704,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:26:47',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            343 => 
            array (
                'body' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
                'content_id' => 3302,
                'featured_end_at' => NULL,
                'id' => 705,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:27:00',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            344 => 
            array (
                'body' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
                'content_id' => 3303,
                'featured_end_at' => NULL,
                'id' => 706,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:27:13',
                'publish_div' => 1,
                'title' => 'Lan Cuoi Ja',
            ),
            345 => 
            array (
                'body' => '予防接種町指定医療機関一覧
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
                'content_id' => 3304,
                'featured_end_at' => NULL,
                'id' => 707,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:27:27',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            346 => 
            array (
                'body' => '日本脳炎
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
                'content_id' => 3305,
                'featured_end_at' => NULL,
                'id' => 708,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:27:39',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            347 => 
            array (
                'body' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
                'content_id' => 3306,
                'featured_end_at' => NULL,
                'id' => 709,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:27:51',
                'publish_div' => 1,
                'title' => 'Dang nao cung the nhe',
            ),
            348 => 
            array (
                'body' => '
<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
                'content_id' => 3307,
                'featured_end_at' => NULL,
                'id' => 710,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:06',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            349 => 
            array (
                'body' => '
<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
                'content_id' => 3308,
                'featured_end_at' => NULL,
                'id' => 711,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:13',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            350 => 
            array (
                'body' => '
<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
                'content_id' => 3309,
                'featured_end_at' => NULL,
                'id' => 712,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:23',
                'publish_div' => 1,
                'title' => 'alo alo alo',
            ),
            351 => 
            array (
                'body' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ


<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>


2019年5月24日 8時25分',
                'content_id' => 3310,
                'featured_end_at' => NULL,
                'id' => 713,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:35',
                'publish_div' => 1,
                'title' => 'tieng nhat ne',
            ),
            352 => 
            array (
                'body' => '【その他】指定、届出等の告示一覧



xyz abc',
                'content_id' => 3311,
                'featured_end_at' => NULL,
                'id' => 714,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:44',
                'publish_div' => 1,
                'title' => '【その他】指定、届出等の告示一覧 [@pubDate]',
            ),
            353 => 
            array (
                'body' => '【その他】人づくりを通した国際貢献



xyz abc',
                'content_id' => 3312,
                'featured_end_at' => NULL,
                'id' => 715,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:49',
                'publish_div' => 1,
                'title' => '【その他】人づくりを通した国際貢献 [@pubDate]',
            ),
            354 => 
            array (
                'body' => '【入札】研究法人室



xyz abc',
                'content_id' => 3313,
                'featured_end_at' => NULL,
                'id' => 716,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:55',
                'publish_div' => 1,
                'title' => '【入札】研究法人室 [@pubDate]',
            ),
            355 => 
            array (
                'body' => '【募集】食関連産業室トップページ



xyz abc',
                'content_id' => 3314,
                'featured_end_at' => NULL,
                'id' => 717,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:28:59',
                'publish_div' => 1,
                'title' => '【募集】食関連産業室トップページ [@pubDate]',
            ),
            356 => 
            array (
                'body' => '【告知】土木のお仕事のページ



xyz abc',
                'content_id' => 3315,
                'featured_end_at' => NULL,
                'id' => 718,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:05',
                'publish_div' => 1,
                'title' => '【告知】土木のお仕事のページ [@pubDate]',
            ),
            357 => 
            array (
                'body' => '【告知】自動車税の納期限は５月３１日（金）です



xyz abc',
                'content_id' => 3316,
                'featured_end_at' => NULL,
                'id' => 719,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:10',
                'publish_div' => 1,
                'title' => '【告知】自動車税の納期限は５月３１日（金）です [@pubDate]',
            ),
            358 => 
            array (
                'body' => '【その他】食中毒警報発令情報



xyz abc',
                'content_id' => 3317,
                'featured_end_at' => NULL,
                'id' => 720,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:16',
                'publish_div' => 1,
                'title' => '【その他】食中毒警報発令情報 [@pubDate]',
            ),
            359 => 
            array (
                'body' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集



xyz abc',
                'content_id' => 3318,
                'featured_end_at' => NULL,
                'id' => 721,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:21',
                'publish_div' => 1,
                'title' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集 [@pubDate]',
            ),
            360 => 
            array (
                'body' => '【入札】H31ベッドサイドモニタ賃貸借契約



xyz abc',
                'content_id' => 3319,
                'featured_end_at' => NULL,
                'id' => 722,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:26',
                'publish_div' => 1,
                'title' => '【入札】H31ベッドサイドモニタ賃貸借契約 [@pubDate]',
            ),
            361 => 
            array (
                'body' => 'hello

【その他】指定、届出等の告示一覧

[link]',
                'content_id' => 3320,
                'featured_end_at' => NULL,
                'id' => 723,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:32',
                'publish_div' => 1,
                'title' => '【その他】指定、届出等の告示一覧 [@dc:date]',
            ),
            362 => 
            array (
                'body' => 'hello

【その他】人づくりを通した国際貢献

[link]',
                'content_id' => 3321,
                'featured_end_at' => NULL,
                'id' => 724,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:38',
                'publish_div' => 1,
                'title' => '【その他】人づくりを通した国際貢献 [@dc:date]',
            ),
            363 => 
            array (
                'body' => 'hello

【入札】研究法人室

[link]',
                'content_id' => 3322,
                'featured_end_at' => NULL,
                'id' => 725,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:43',
                'publish_div' => 1,
                'title' => '【入札】研究法人室 [@dc:date]',
            ),
            364 => 
            array (
                'body' => 'hello

【募集】食関連産業室トップページ

[link]',
                'content_id' => 3323,
                'featured_end_at' => NULL,
                'id' => 726,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:48',
                'publish_div' => 1,
                'title' => '【募集】食関連産業室トップページ [@dc:date]',
            ),
            365 => 
            array (
                'body' => 'hello

【告知】土木のお仕事のページ

[link]',
                'content_id' => 3324,
                'featured_end_at' => NULL,
                'id' => 727,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:54',
                'publish_div' => 1,
                'title' => '【告知】土木のお仕事のページ [@dc:date]',
            ),
            366 => 
            array (
                'body' => 'hello

【告知】自動車税の納期限は５月３１日（金）です

[link]',
                'content_id' => 3325,
                'featured_end_at' => NULL,
                'id' => 728,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:29:59',
                'publish_div' => 1,
                'title' => '【告知】自動車税の納期限は５月３１日（金）です [@dc:date]',
            ),
            367 => 
            array (
                'body' => 'hello

【その他】食中毒警報発令情報

[link]',
                'content_id' => 3326,
                'featured_end_at' => NULL,
                'id' => 729,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:04',
                'publish_div' => 1,
                'title' => '【その他】食中毒警報発令情報 [@dc:date]',
            ),
            368 => 
            array (
                'body' => 'hello

【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集

[link]',
                'content_id' => 3327,
                'featured_end_at' => NULL,
                'id' => 730,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:10',
                'publish_div' => 1,
                'title' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集 [@dc:date]',
            ),
            369 => 
            array (
                'body' => 'hello

【入札】H31ベッドサイドモニタ賃貸借契約

[link]',
                'content_id' => 3328,
                'featured_end_at' => NULL,
                'id' => 731,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:15',
                'publish_div' => 1,
                'title' => '【入札】H31ベッドサイドモニタ賃貸借契約 [@dc:date]',
            ),
            370 => 
            array (
                'body' => '[@body]
休日窓口サービスについて（平日の通常業務と内容が違います） 住民票等各種証明の発行など、下記の一部のサービスがご利用できます。ただし、ご利用できる方に制限があります。委任状による代理人請求や住民異動届（転入・転居・転出） &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e4%bc%91%e6%97%a5%e7%aa%93%e5%8f%a3-3/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3329,
                'featured_end_at' => NULL,
                'id' => 732,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:21',
                'publish_div' => 1,
                'title' => '休日窓口',
            ),
            371 => 
            array (
                'body' => '[@body]
広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3330,
                'featured_end_at' => NULL,
                'id' => 733,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:34',
                'publish_div' => 1,
                'title' => '広域行政窓口',
            ),
            372 => 
            array (
                'body' => '[@body]
令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3331,
                'featured_end_at' => NULL,
                'id' => 734,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:46',
                'publish_div' => 1,
                'title' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）',
            ),
            373 => 
            array (
                'body' => '[@body]
　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3332,
                'featured_end_at' => NULL,
                'id' => 735,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:30:58',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について',
            ),
            374 => 
            array (
                'body' => '[@body]
歴民だより　H.31 5月号　No.67',
                'content_id' => 3333,
                'featured_end_at' => NULL,
                'id' => 736,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:10',
                'publish_div' => 1,
                'title' => '歴民だより　5月号　No.67',
            ),
            375 => 
            array (
                'body' => '[@body]
平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3334,
                'featured_end_at' => NULL,
                'id' => 737,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:23',
                'publish_div' => 1,
                'title' => '平成３１年４月２１日　安八町長選挙の開票結果',
            ),
            376 => 
            array (
                'body' => '[@body]
パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3335,
                'featured_end_at' => NULL,
                'id' => 738,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:26',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント',
            ),
            377 => 
            array (
                'body' => '[@body]
予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3336,
                'featured_end_at' => NULL,
                'id' => 739,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:28',
                'publish_div' => 1,
                'title' => '予防接種町指定医療機関一覧',
            ),
            378 => 
            array (
                'body' => '[@body]
　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3337,
                'featured_end_at' => NULL,
                'id' => 740,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:30',
                'publish_div' => 1,
                'title' => '日本脳炎',
            ),
            379 => 
            array (
                'body' => '[@body]
　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>',
                'content_id' => 3338,
                'featured_end_at' => NULL,
                'id' => 741,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:33',
                'publish_div' => 1,
                'title' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ',
            ),
            380 => 
            array (
                'body' => '[@dc:date]

【告知】告示（測量法に関する「諸手続」に係る通知）',
                'content_id' => 3339,
                'featured_end_at' => NULL,
                'id' => 742,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:36',
                'publish_div' => 1,
                'title' => '【告知】告示（測量法に関する「諸手続」に係る通知）',
            ),
            381 => 
            array (
                'body' => '[@dc:date]

【告知】北海道クールあいらんどキャンペーン',
                'content_id' => 3340,
                'featured_end_at' => NULL,
                'id' => 743,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:38',
                'publish_div' => 1,
                'title' => '【告知】北海道クールあいらんどキャンペーン',
            ),
            382 => 
            array (
                'body' => '[@dc:date]

【入札】大学法人室トップページ（公立大学法人に関する情報）',
                'content_id' => 3341,
                'featured_end_at' => NULL,
                'id' => 744,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:41',
                'publish_div' => 1,
                'title' => '【入札】大学法人室トップページ（公立大学法人に関する情報）',
            ),
            383 => 
            array (
                'body' => '[@dc:date]

【募集】審議会委員の募集',
                'content_id' => 3342,
                'featured_end_at' => NULL,
                'id' => 745,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:43',
                'publish_div' => 1,
                'title' => '【募集】審議会委員の募集',
            ),
            384 => 
            array (
                'body' => '[@dc:date]

【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）',
                'content_id' => 3343,
                'featured_end_at' => NULL,
                'id' => 746,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:46',
                'publish_div' => 1,
                'title' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）',
            ),
            385 => 
            array (
                'body' => '[@dc:date]

【募集】北海道とつながるカフェ参加者募集中',
                'content_id' => 3344,
                'featured_end_at' => NULL,
                'id' => 747,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:48',
                'publish_div' => 1,
                'title' => '【募集】北海道とつながるカフェ参加者募集中',
            ),
            386 => 
            array (
                'body' => '[@dc:date]

【その他】指定、届出等の告示一覧',
                'content_id' => 3345,
                'featured_end_at' => NULL,
                'id' => 748,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:51',
                'publish_div' => 1,
                'title' => '【その他】指定、届出等の告示一覧',
            ),
            387 => 
            array (
                'body' => '[@dc:date]

【その他】人づくりを通した国際貢献',
                'content_id' => 3346,
                'featured_end_at' => NULL,
                'id' => 749,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:53',
                'publish_div' => 1,
                'title' => '【その他】人づくりを通した国際貢献',
            ),
            388 => 
            array (
                'body' => '[@dc:date]

【入札】研究法人室',
                'content_id' => 3347,
                'featured_end_at' => NULL,
                'id' => 750,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:55',
                'publish_div' => 1,
                'title' => '【入札】研究法人室',
            ),
            389 => 
            array (
                'body' => '[@dc:date]

【募集】食関連産業室トップページ',
                'content_id' => 3348,
                'featured_end_at' => NULL,
                'id' => 751,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:31:58',
                'publish_div' => 1,
                'title' => '【募集】食関連産業室トップページ',
            ),
            390 => 
            array (
                'body' => '[@dc:date]

【告知】土木のお仕事のページ',
                'content_id' => 3349,
                'featured_end_at' => NULL,
                'id' => 752,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:32:00',
                'publish_div' => 1,
                'title' => '【告知】土木のお仕事のページ',
            ),
            391 => 
            array (
                'body' => '[@dc:date]

【告知】自動車税の納期限は５月３１日（金）です',
                'content_id' => 3350,
                'featured_end_at' => NULL,
                'id' => 753,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:32:03',
                'publish_div' => 1,
                'title' => '【告知】自動車税の納期限は５月３１日（金）です',
            ),
            392 => 
            array (
                'body' => '[@dc:date]

【その他】食中毒警報発令情報',
                'content_id' => 3351,
                'featured_end_at' => NULL,
                'id' => 754,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:32:05',
                'publish_div' => 1,
                'title' => '【その他】食中毒警報発令情報',
            ),
            393 => 
            array (
                'body' => '[@dc:date]

【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集',
                'content_id' => 3352,
                'featured_end_at' => NULL,
                'id' => 755,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:32:08',
                'publish_div' => 1,
                'title' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集',
            ),
            394 => 
            array (
                'body' => '[@dc:date]

【入札】H31ベッドサイドモニタ賃貸借契約',
                'content_id' => 3353,
                'featured_end_at' => NULL,
                'id' => 756,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 16:32:10',
                'publish_div' => 1,
                'title' => '【入札】H31ベッドサイドモニタ賃貸借契約',
            ),
            395 => 
            array (
                'body' => '[@body] 

2019年5月24日 9時39分',
                'content_id' => 3354,
                'featured_end_at' => NULL,
                'id' => 757,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:19',
                'publish_div' => 1,
                'title' => '【告知】北海道クールあいらんどキャンペーン',
            ),
            396 => 
            array (
                'body' => '[@body] 

2019年5月24日 15時00分',
                'content_id' => 3355,
                'featured_end_at' => NULL,
                'id' => 758,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:22',
                'publish_div' => 1,
                'title' => '【入札】大学法人室トップページ（公立大学法人に関する情報）',
            ),
            397 => 
            array (
                'body' => '[@body] 

2019年5月24日 15時10分',
                'content_id' => 3356,
                'featured_end_at' => NULL,
                'id' => 759,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:24',
                'publish_div' => 1,
                'title' => '【募集】審議会委員の募集',
            ),
            398 => 
            array (
                'body' => '[@body] 

2019年5月24日 15時10分',
                'content_id' => 3357,
                'featured_end_at' => NULL,
                'id' => 760,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:26',
                'publish_div' => 1,
                'title' => '【その他】消費者安全課（環境生活部くらし安全局）のページ（消費生活に関する施策・情報）',
            ),
            399 => 
            array (
                'body' => '[@body] 

2019年5月24日 16時34分',
                'content_id' => 3358,
                'featured_end_at' => NULL,
                'id' => 761,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:29',
                'publish_div' => 1,
                'title' => '【その他】指定、届出等の告示一覧',
            ),
            400 => 
            array (
                'body' => '[@body] 

2019年5月24日 17時00分',
                'content_id' => 3359,
                'featured_end_at' => NULL,
                'id' => 762,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:31',
                'publish_div' => 1,
                'title' => '【その他】人づくりを通した国際貢献',
            ),
            401 => 
            array (
                'body' => '[@body] 

2019年5月24日 17時14分',
                'content_id' => 3360,
                'featured_end_at' => NULL,
                'id' => 763,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:34',
                'publish_div' => 1,
                'title' => '【入札】研究法人室',
            ),
            402 => 
            array (
                'body' => '[@body] 

2019年5月24日 19時02分',
                'content_id' => 3361,
                'featured_end_at' => NULL,
                'id' => 764,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:36',
                'publish_div' => 1,
                'title' => '【募集】食関連産業室トップページ',
            ),
            403 => 
            array (
                'body' => '[@body] 

2019年5月27日 9時16分',
                'content_id' => 3362,
                'featured_end_at' => NULL,
                'id' => 765,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:38',
                'publish_div' => 1,
                'title' => '【告知】土木のお仕事のページ',
            ),
            404 => 
            array (
                'body' => '[@body] 

2019年5月27日 11時22分',
                'content_id' => 3363,
                'featured_end_at' => NULL,
                'id' => 766,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:41',
                'publish_div' => 1,
                'title' => '【告知】自動車税の納期限は５月３１日（金）です',
            ),
            405 => 
            array (
                'body' => '[@body] 

2019年5月27日 11時28分',
                'content_id' => 3364,
                'featured_end_at' => NULL,
                'id' => 767,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:43',
                'publish_div' => 1,
                'title' => '【その他】食中毒警報発令情報',
            ),
            406 => 
            array (
                'body' => '[@body] 

2019年5月27日 13時55分',
                'content_id' => 3365,
                'featured_end_at' => NULL,
                'id' => 768,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:46',
                'publish_div' => 1,
                'title' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集',
            ),
            407 => 
            array (
                'body' => '[@body] 

2019年5月27日 14時53分',
                'content_id' => 3366,
                'featured_end_at' => NULL,
                'id' => 769,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:48',
                'publish_div' => 1,
                'title' => '【入札】H31ベッドサイドモニタ賃貸借契約',
            ),
            408 => 
            array (
                'body' => '[@body] 

2019年5月27日 17時00分',
                'content_id' => 3367,
                'featured_end_at' => NULL,
                'id' => 770,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:50',
                'publish_div' => 1,
                'title' => '【募集】令和元年度地方職員共済組合北海道支部職員採用試験について',
            ),
            409 => 
            array (
                'body' => '[@body] 

2019年5月27日 17時15分',
                'content_id' => 3368,
                'featured_end_at' => NULL,
                'id' => 771,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:27:53',
                'publish_div' => 1,
                'title' => '【募集】北海道とつながるカフェ参加者募集中',
            ),
            410 => 
            array (
                'body' => '[@link]',
                'content_id' => 3369,
                'featured_end_at' => NULL,
                'id' => 772,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 17:49:34',
                'publish_div' => 1,
                'title' => 'Atom-Powered Robots Run Amok',
            ),
            411 => 
            array (
                'body' => '[@conten]

2004年10月26日 14時06分',
                'content_id' => 3371,
                'featured_end_at' => NULL,
                'id' => 774,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:18:44',
                'publish_div' => 1,
                'title' => 'Recommended Web Based Feed Reader Software',
            ),
            412 => 
            array (
                'body' => '[@conten]

2004年10月26日 14時03分',
                'content_id' => 3372,
                'featured_end_at' => NULL,
                'id' => 775,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:18:47',
                'publish_div' => 1,
                'title' => 'Recommended Desktop Feed Reader Software',
            ),
            413 => 
            array (
                'body' => '[@conten]

2004年10月26日 14時01分',
                'content_id' => 3373,
                'featured_end_at' => NULL,
                'id' => 776,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:18:49',
                'publish_div' => 1,
                'title' => 'RSS Resources',
            ),
            414 => 
            array (
                'body' => '

http://www.pref.hokkaido.lg.jp/sm/zim/topics/noukinai.htm

2019年5月27日 11時22分',
                'content_id' => 3374,
                'featured_end_at' => NULL,
                'id' => 777,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:24:18',
                'publish_div' => 1,
                'title' => '【告知】自動車税の納期限は５月３１日（金）です',
            ),
            415 => 
            array (
                'body' => '

http://www.pref.hokkaido.lg.jp/hf/asc/nyuusatu/H31bedsidemoniter.htm

2019年5月27日 14時53分',
                'content_id' => 3375,
                'featured_end_at' => NULL,
                'id' => 778,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:24:20',
                'publish_div' => 1,
                'title' => '【入札】H31ベッドサイドモニタ賃貸借契約',
            ),
            416 => 
            array (
                'body' => '[@content]

http://www.pref.hokkaido.lg.jp/sm/zim/topics/noukinai.htm

2019年5月27日 11時22分',
                'content_id' => 3376,
                'featured_end_at' => NULL,
                'id' => 779,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:35:06',
                'publish_div' => 1,
                'title' => 'title',
            ),
            417 => 
            array (
                'body' => '[@content]

http://www.pref.hokkaido.lg.jp/hf/asc/nyuusatu/H31bedsidemoniter.htm

2019年5月27日 14時53分',
                'content_id' => 3377,
                'featured_end_at' => NULL,
                'id' => 780,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-27 18:35:08',
                'publish_div' => 1,
                'title' => 'title',
            ),
            418 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post ja1</span></font>',
                'content_id' => 3384,
                'featured_end_at' => NULL,
                'id' => 783,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 10:32:00',
                'publish_div' => 1,
                'title' => 'Post ja1',
            ),
            419 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post ja 2</span></font>',
                'content_id' => 3385,
                'featured_end_at' => NULL,
                'id' => 784,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 10:42:00',
                'publish_div' => 1,
                'title' => 'Post ja 2',
            ),
            420 => 
            array (
                'body' => '[@descripton]

[@content]

http://example.org/2003/12/13/atom03',
                'content_id' => 3390,
                'featured_end_at' => NULL,
                'id' => 785,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 15:17:17',
                'publish_div' => 1,
                'title' => 'Atom-Powered Robots Run Amok',
            ),
            421 => 
            array (
                'body' => '[content]

[dc:date]

http://www.pref.hokkaido.lg.jp/sm/sum/unyou/douyuutibaikyaku/ippankyousou.htm',
                'content_id' => 3391,
                'featured_end_at' => NULL,
                'id' => 786,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 15:17:20',
                'publish_div' => 1,
                'title' => '【入札】【道有地の売却】一般競争入札のお知らせ（総務部総務課）',
            ),
            422 => 
            array (
                'body' => '[content]

2019年5月28日 9時46分

http://www.pref.hokkaido.lg.jp/sm/sum/unyou/douyuutibaikyaku/ippankyousou.htm',
                'content_id' => 3392,
                'featured_end_at' => NULL,
                'id' => 787,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 15:18:55',
                'publish_div' => 1,
                'title' => '【入札】【道有地の売却】一般競争入札のお知らせ（総務部総務課）',
            ),
            423 => 
            array (
                'body' => '道有財産売却（一般競争入札）のお知らせ【総務部 総務課】

2019年5月28日 9時46分

http://www.pref.hokkaido.lg.jp/sm/sum/unyou/douyuutibaikyaku/ippankyousou.htm',
                'content_id' => 3393,
                'featured_end_at' => NULL,
                'id' => 788,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 15:32:55',
                'publish_div' => 1,
                'title' => '【入札】【道有地の売却】一般競争入札のお知らせ（総務部総務課）',
            ),
            424 => 
            array (
                'body' => '[@description]

[@content]

http://example.org/2003/12/13/atom03',
                'content_id' => 3394,
                'featured_end_at' => NULL,
                'id' => 789,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 15:33:56',
                'publish_div' => 1,
                'title' => 'Atom-Powered Robots Run Amok',
            ),
            425 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/bousai/hisaichishien.html',
                'content_id' => 3395,
                'featured_end_at' => NULL,
                'id' => 790,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:05:10',
                'publish_div' => 1,
                'title' => '被災地支援に関する情報（熊本地震、東日本大震災）2017年1月25日 15時06分',
            ),
            426 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/hofuku/hokennenkin/hp/new/iryouhikanpusagi_2_3.html',
                'content_id' => 3396,
                'featured_end_at' => NULL,
                'id' => 791,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:05:27',
                'publish_div' => 1,
                'title' => '【ご注意ください】区役所職員をかたる還付金詐欺事件が発生しています2017年3月3日 7時38分',
            ),
            427 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/hofuku/shokuhinanzen/life/syokuhinanzen-ansin/005_2.html',
                'content_id' => 3397,
                'featured_end_at' => NULL,
                'id' => 792,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:05:42',
                'publish_div' => 1,
                'title' => '1歳未満の乳児には「はちみつ」を食べさせないでください2017年4月13日 4時26分',
            ),
            428 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shisei/shiseiunei/shiseiunei/syokuinbosyuu.html',
                'content_id' => 3398,
                'featured_end_at' => NULL,
                'id' => 793,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:05:57',
                'publish_div' => 1,
                'title' => '市職員（嘱託員、臨時職員など）募集2017年5月12日 15時03分',
            ),
            429 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/bousai/gouu201707.html',
                'content_id' => 3399,
                'featured_end_at' => NULL,
                'id' => 794,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:06:14',
                'publish_div' => 1,
                'title' => '平成29年7月九州北部豪雨への支援について（被災された方へ、支援したい方へ）2017年8月20日 5時00分',
            ),
            430 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/shohiseikatsu/life/syouhiseikatusentauhoumupeiji/kouenjigyou_20180320_3_2.html',
                'content_id' => 3400,
                'featured_end_at' => NULL,
                'id' => 795,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:06:30',
                'publish_div' => 1,
                'title' => '子どもの「水の事故」と「幼児用座席付自転車の事故」に気を付けましょう2018年5月9日 7時01分',
            ),
            431 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/bousai/bousai/tsunagaru_plus.html',
                'content_id' => 3401,
                'featured_end_at' => NULL,
                'id' => 796,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:06:44',
                'publish_div' => 1,
            'title' => '防災アプリ「ツナガル＋(プラス)」のサービス開始2018年5月9日 7時30分',
            ),
            432 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/shohiseikatsu/life/syouhiseikatusentauhoumupeiji/kouenjigyou_20180320_3_2_2_2.html',
                'content_id' => 3402,
                'featured_end_at' => NULL,
                'id' => 797,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:07:00',
                'publish_div' => 1,
                'title' => '町内の集会所などを利用した「催眠商法」が多発しています！2018年5月9日 7時31分',
            ),
            433 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/shohiseikatsu/life/syouhiseikatusentauhoumupeiji/kouenjigyou_20170514_2_2_2_2_2_2_4.html',
                'content_id' => 3403,
                'featured_end_at' => NULL,
                'id' => 798,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:07:15',
                'publish_div' => 1,
                'title' => '架空請求の相談が急増しています！（消費生活センター）2018年6月15日 3時00分',
            ),
            434 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/jutaku-toshi/bid_safe/bousai/burokkubeitenken.html',
                'content_id' => 3404,
                'featured_end_at' => NULL,
                'id' => 799,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:07:31',
                'publish_div' => 1,
                'title' => 'ブロック塀を点検しましょう（除去工事の補助制度もあります）2018年6月20日 4時02分',
            ),
            435 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/bousai/heavyrain.html',
                'content_id' => 3405,
                'featured_end_at' => NULL,
                'id' => 800,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:07:47',
                'publish_div' => 1,
                'title' => '平成30年7月5日からの大雨（平成30年7月豪雨）に関する情報、義援金募集など2018年7月5日 7時30分',
            ),
            436 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/bousai/bousai/Hokkaido_earthquake.html',
                'content_id' => 3406,
                'featured_end_at' => NULL,
                'id' => 801,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:08:02',
                'publish_div' => 1,
                'title' => '平成30年9月6日に発生した北海道胆振（いぶり）東部地震災害義援金を募集します2018年9月2日 9時01分',
            ),
            437 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/nishi/bousai.html',
                'content_id' => 3407,
                'featured_end_at' => NULL,
                'id' => 802,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:08:19',
                'publish_div' => 1,
                'title' => '【ご注意ください】西区内にイノシシが出没しています2018年10月26日 4時01分',
            ),
            438 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/zaisei/propertyuse/shisei/kihu/kifu_top.html',
                'content_id' => 3408,
                'featured_end_at' => NULL,
                'id' => 803,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:08:34',
                'publish_div' => 1,
                'title' => 'ふるさと納税の受付を偽装した詐欺サイトにご注意ください【ふくおか応援寄付】2018年11月22日 15時00分',
            ),
            439 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/hofuku/hokenyobo/health/kansen/husinkoutaikensa.html',
                'content_id' => 3409,
                'featured_end_at' => NULL,
                'id' => 804,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:08:50',
                'publish_div' => 1,
                'title' => '風しんにご注意ください（無料の抗体検査や予防接種の費用助成など）2018年11月24日 15時01分',
            ),
            440 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/seikatsuanzen/shisei/taisetunaokosamawokoutuujikokaramamorimasyou.html',
                'content_id' => 3410,
                'featured_end_at' => NULL,
                'id' => 805,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:09:06',
                'publish_div' => 1,
                'title' => '大切なお子様を交通事故から守りましょう！（特に新小学１年生の保護者の方へ）2019年2月5日 0時00分',
            ),
            441 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/shimin/seikatsuanzen/shisei/nisedenwatyuui.html',
                'content_id' => 3411,
                'featured_end_at' => NULL,
                'id' => 806,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:09:22',
                'publish_div' => 1,
                'title' => 'ニセ電話詐欺（アポイント電話）にご注意ください！2019年3月20日 1時00分',
            ),
            442 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/kyoiku-iinkai/kensyu/ed/201.html',
                'content_id' => 3412,
                'featured_end_at' => NULL,
                'id' => 807,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:09:38',
                'publish_div' => 1,
                'title' => '福岡市立学校の運動会等の日程（小学校、中学校、特別支援学校、高等学校）2019年5月7日 15時02分',
            ),
            443 => 
            array (
                'body' => '[@dc:description]
http://www.city.fukuoka.lg.jp/zaisei/shisanzei/life/keijidosyazeir0105.html',
                'content_id' => 3413,
                'featured_end_at' => NULL,
                'id' => 808,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:09:53',
                'publish_div' => 1,
                'title' => '軽自動車税の軽減税額の適用誤りについて（お詫び）2019年5月14日 6時01分',
            ),
            444 => 
            array (
                'body' => '食中毒警報を発令中です。【保健福祉部 食品衛生課】

2019年5月27日 11時28分

http://www.pref.hokkaido.lg.jp/hf/kse/sho/tyu/hat/keiho_R01.htm',
                'content_id' => 3414,
                'featured_end_at' => NULL,
                'id' => 809,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:12',
                'publish_div' => 1,
                'title' => '【その他】食中毒警報発令情報',
            ),
            445 => 
            array (
                'body' => '【募集】「メッセナゴヤ2019　北海道ブース」出展企業を募集します【経済部 産業振興課】

2019年5月27日 13時55分

http://www.pref.hokkaido.lg.jp/kz/ssg/messe2019bosyu.htm',
                'content_id' => 3415,
                'featured_end_at' => NULL,
                'id' => 810,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:15',
                'publish_div' => 1,
                'title' => '【募集】メッセナゴヤ２０１９　北海道ブース　出展企業募集',
            ),
            446 => 
            array (
                'body' => '一般競争入札のお知らせ（ベッドサイドモニタ）【保健福祉部 旭川肢体不自由児総合療育センター】

2019年5月27日 14時53分

http://www.pref.hokkaido.lg.jp/hf/asc/nyuusatu/H31bedsidemoniter.htm',
                'content_id' => 3416,
                'featured_end_at' => NULL,
                'id' => 811,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:18',
                'publish_div' => 1,
                'title' => '【入札】H31ベッドサイドモニタ賃貸借契約',
            ),
            447 => 
            array (
                'body' => '地方職員共済組合北海道支部職員の募集について【総務部 職員厚生課】

2019年5月27日 17時00分

http://www.pref.hokkaido.lg.jp/sm/sks/R1_siken.htm',
                'content_id' => 3417,
                'featured_end_at' => NULL,
                'id' => 812,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:21',
                'publish_div' => 1,
                'title' => '【募集】令和元年度地方職員共済組合北海道支部職員採用試験について',
            ),
            448 => 
            array (
                'body' => '次回 7/18日開催！北海道とつながるカフェ参加募集中！【総合政策部 地域創生局地域戦略課】

2019年5月27日 17時15分

http://www.pref.hokkaido.lg.jp/ss/csr/tunagaru.htm',
                'content_id' => 3418,
                'featured_end_at' => NULL,
                'id' => 813,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:24',
                'publish_div' => 1,
                'title' => '【募集】北海道とつながるカフェ参加者募集中',
            ),
            449 => 
            array (
                'body' => '地域課題解決型起業支援金の支給対象者の募集開始について【経済部 地域経済局中小企業課】

2019年5月27日 18時45分

http://www.pref.hokkaido.lg.jp/kz/csk/sougyou/chiikikadaikaiketsu2.htm',
                'content_id' => 3419,
                'featured_end_at' => NULL,
                'id' => 814,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:27',
                'publish_div' => 1,
                'title' => '【募集】地域課題解決型起業支援金の支給対象者の募集開始について',
            ),
            450 => 
            array (
                'body' => '一般競争入札の実施（パーソナルコンピュータの売買契約）【総合政策部 情報統計局情報政策課】

2019年5月28日 8時54分

http://www.pref.hokkaido.lg.jp/ss/jsk/R1_nyuusatsu369.htm',
                'content_id' => 3420,
                'featured_end_at' => NULL,
                'id' => 815,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:30',
                'publish_div' => 1,
                'title' => '【入札】パーソナルコンピュータの調達（購入・告示第369号）',
            ),
            451 => 
            array (
                'body' => '一般競争入札の実施（パーソナルコンピュータの賃貸借契約）【総合政策部 情報統計局情報政策課】

2019年5月28日 8時55分

http://www.pref.hokkaido.lg.jp/ss/jsk/R1_nyuusatsu370.htm',
                'content_id' => 3421,
                'featured_end_at' => NULL,
                'id' => 816,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:33',
                'publish_div' => 1,
                'title' => '【入札】パーソナルコンピュータの調達（賃貸借・告示第370号）',
            ),
            452 => 
            array (
                'body' => '【告示】道路の区域の変更について【建設部 維持管理防災課】

2019年5月28日 10時50分

http://www.pref.hokkaido.lg.jp/kn/sbs/doro_iji_03_kokuji.htm',
                'content_id' => 3422,
                'featured_end_at' => NULL,
                'id' => 817,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:36',
                'publish_div' => 1,
                'title' => '【その他】道路維持管理　北海道告示（道路関係）',
            ),
            453 => 
            array (
                'body' => '【告示】令和元年度登録販売者試験の実施について【保健福祉部 地域医療推進局医務薬務課】

2019年5月28日 13時43分

http://www.pref.hokkaido.lg.jp/hf/iyk/iry/yakuji/torokushikenjisshi_R01.htm',
                'content_id' => 3423,
                'featured_end_at' => NULL,
                'id' => 818,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:39',
                'publish_div' => 1,
                'title' => '【告知】令和元年度登録販売者試験の実施について',
            ),
            454 => 
            array (
                'body' => '一般競争入札実施のお知らせ（プリント基板加工システム他１機器【経済部 産業振興局科学技術振興室】

2019年5月28日 15時00分

http://www.pref.hokkaido.lg.jp/kz/kgs/kogi/2019_0614_kikikokoku.htm',
                'content_id' => 3424,
                'featured_end_at' => NULL,
                'id' => 819,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:42',
                'publish_div' => 1,
                'title' => '【入札】一般競争入札の実施について（プリント基板加工システム他１機器）',
            ),
            455 => 
            array (
            'body' => '【公告】災害対策基本法(昭和36年法律223号)第2条第6号の規定に基づく指定地【総務部 危機対策課】

2019年5月28日 15時18分

http://www.pref.hokkaido.lg.jp/sm/ktk/kokoku/communityFM.htm',
                'content_id' => 3425,
                'featured_end_at' => NULL,
                'id' => 820,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:45',
                'publish_div' => 1,
                'title' => '【告知】【公告】指定地方公共機関の指定について',
            ),
            456 => 
            array (
                'body' => '公募型プロポーザルの実施（ものづくり人材技術力強化事業（販路拡大セミナー））【経済部 産業振興課】

2019年5月28日 15時30分

http://www.pref.hokkaido.lg.jp/kz/ssg/monodukurijinzai-seminar-.htm',
                'content_id' => 3426,
                'featured_end_at' => NULL,
                'id' => 821,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:48',
                'publish_div' => 1,
                'title' => '【募集】【公告】ものづくり人材技術力強化事業（販路拡大セミナー）委託業務プロポーザル',
            ),
            457 => 
            array (
            'body' => '公募型プロポーザルの実施(ものづくり人材技術力強化事業(販路開拓展示会出展))【経済部 産業振興課】

2019年5月28日 15時31分

http://www.pref.hokkaido.lg.jp/kz/ssg/monodukurijinzai-messe-.htm',
                'content_id' => 3427,
                'featured_end_at' => NULL,
                'id' => 822,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:51',
                'publish_div' => 1,
                'title' => '【募集】【公告】道内ものづくり企業販路開拓展示会出展委託業務プロポーザル',
            ),
            458 => 
            array (
                'body' => '広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/

<h3>広域行政窓口サービスについて</h3>
<p>西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、15～20分程度かかります。ただし、このサービスを利用できる方には制限があります。</p>
<h5>このサービスにより証明書を請求できる人</h5>
<p>西濃地域（大垣市、海津市、養老町、垂井町、関ヶ原町、神戸町、輪之内町、安八町、揖斐川町、大野町、池田町）及び岐阜地域（岐阜市、羽島市、各務原市、山県市、瑞穂市、本巣市、岐南町、笠松町、北方町）に住民登録や本籍を有する人で次のそれぞれに該当する人</p>
<p>○住民票の写し、印鑑登録証明書、個人の税関係証明書（現年度分）</p>
<p>→本人または同じ世帯に同居している人</p>
<p>○戸籍謄抄本（除籍・改製原戸籍を含む）、戸籍の附票、身分証明書</p>
<p>→本人または戸籍に記載された人（身分証明書のみ本人自署の委任状が必要です。）</p>
<h5>取り扱い窓口</h5>
<p>上記市町の住民担当窓口（安八町は、役場の住民環境課・税務課）</p>
<h5>取り扱い日時</h5>
<p>月曜日～金曜日（祝祭日、12/29～1/3を除く） 午前8時30分～午後5時まで</p>
<h5>必要なもの</h5>
<ul>
<li>○<a title="本人確認について" href="http://www.town.anpachi.gifu.jp/2012/03/13/%e6%9c%ac%e4%ba%ba%e7%a2%ba%e8%aa%8d%e3%81%ab%e3%81%a4%e3%81%84%e3%81%a6/">本人確認書類</a>（運転免許証等写真付の公的証明書をお持ちでないときは、本人確認の聞きとりをさせていただく場合があります。）</li>
<li>○印鑑</li>
<li>○手数料（各市町の手数料徴収条例に基づく金額）</li>
<li>○印鑑登録証明書の場合は「印鑑登録証（カード）」</li>
<li>○身分証明書の代理申請（同一戸籍の方）の場合、は「<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/9493d4c598f8f876514a01f95d126c7a7.pdf">委任状</a>」</li>
</ul>
',
                'content_id' => 3428,
                'featured_end_at' => NULL,
                'id' => 823,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:30:57',
                'publish_div' => 1,
                'title' => '広域行政窓口2019年4月1日 11時01分',
            ),
            459 => 
            array (
                'body' => '令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/

<p>令和２年４月採用の安八町職員を次の要領で募集します。</p>
<h3>１．募集職種・採用予定数・試験区分・受験資格等</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="102">
<p align="center">募集職種</p></td>
<td width="94">
<p align="center">採用予定数</p></td>
<td width="113">
<p align="center">試験区分</p></td>
<td width="321">
<p align="center">受験資格</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">一般行政職</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
<tr>
<td rowspan="2" width="102">
<p align="center">保育士</p></td>
<td rowspan="2" width="94">
<p align="center">若干名</p></td>
<td width="113">
<p align="center">大学卒業程度</p></td>
<td rowspan="2" width="321">
<p>昭和６３年４月２日以降に生まれた方で、保育士及び幼稚園教諭の両方の資格・免許を有する方又は令和元年度中に当該資格・免許を取得する見込みの方</p></td>
</tr>
<tr>
<td width="113">
<p align="center">短大卒業程度</p></td>
</tr>
</tbody></table>
<p>※大学卒業程度：大学卒業又は令和２年３月までに卒業見込の方</p>
<p>※短大卒業程度：短大卒業又は令和２年３月までに卒業見込の方</p>
<p>&nbsp;</p>
<p>○ただし、次の各号の一に該当する者は受験できません。</p>
<p>(1)　日本の国籍を有しない者</p>
<p>(2)　成年被後見人又は被保佐人（準禁治産者を含む。）</p>
<p>(3)　禁錮以上の刑に処せられ、その執行を終わるまで又はその執行を受けることがなくなるまでの者</p>
<p>(4)　安八町において懲戒免職の処分を受け、その処分の日から２年を経過しない者</p>
<p>(5)　日本国憲法施行の日以後において、日本国憲法又はその下に成立した政府を暴力で破壊することを主張する政党その他の団体を結成し、又はこれに加入した者</p>
<p>&nbsp;</p>
<p>○受験資格等の確認について</p>
<p>受験資格の有無、申込書記載事項等の真否について確認を行います。記載内容に虚偽又は不正があることが判明した場合は、合格を取り消します。</p>
<h3>2．試験の日時及び会場</h3>
<p>○第１次試験</p>
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p><strong>令和元年７月２８日（日）</strong></p>
<p>【受付開始】午前８時５０分</p>
<p>【試験終了】午後１時３０分</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>岐阜会場　県立加納高等学校（岐阜市加納南陽町３－１７）</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>教養試験（120分）</p>
<p>事務適性検査（10分）</p>
<p>職場適応性検査（２0分）</p></td>
</tr>
</tbody></table>
<p>○第２次試験</p>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="121">
<p align="center">試験日時</p></td>
<td width="510">
<p>令和元年８月下旬予定</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験会場</p></td>
<td width="510">
<p>安八町役場庁舎</p></td>
</tr>
<tr>
<td width="121">
<p align="center">試験内容</p></td>
<td width="510">
<p>面接試験</p>
<p>論文試験</p></td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<h3>３．受験手続</h3>
<table style="width: 631px;" border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="111">
<p align="center">申込書提出先</p></td>
<td valign="top" width="520">
<p align="left">安八町役場　総務課</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込方法</p></td>
<td valign="top" width="520">
<p>試験申込書に必要事項を記入し、安八町役場総務課へ提出してください。</p>
<p>受験票裏面には、6２円切手を貼ってください。</p>
<p>なお、試験申込書を郵送する場合は、簡易書留又は特定記録郵便とし、封筒の表に「職員採用試験申込書在中」と朱書きして提出してください。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">受付期間</p></td>
<td valign="top" width="520">
<p><strong>令和元年５月７日（火）～６月１４日（金）</strong>（土曜日及び日曜日を除く）<strong></strong></p>
<p>午前８時３０分から午後５時１５分まで</p>
<p>郵送の場合は、６月１４日（金）必着分に限り受付します。</p></td>
</tr>
<tr>
<td width="111">
<p align="center">申込書の配布</p></td>
<td valign="top" width="520">
<p>試験申込書は、役場総務課にて５月７日（火）から配布します。（土曜、日曜日は除く）</p>
<p>郵送で請求する時は、封筒の表に「職員採用試験申込書請求」と朱書きし、120円切手を貼った宛先明記の返信用封筒（角２サイズ）を同封して役場総務課へ請求してください。</p></td>
</tr>
</tbody></table>
<p align="left"></p>
<h3 align="left">４．問い合わせ先</h3>
<p align="left">安八町役場　総務課　TEL：0584-64-3111</p>
<p align="left">〒503-0198　岐阜県安八郡安八町氷取１６１番地</p>
',
                'content_id' => 3429,
                'featured_end_at' => NULL,
                'id' => 824,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:31:14',
                'publish_div' => 1,
                'title' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）2019年4月26日 4時48分',
            ),
            460 => 
            array (
                'body' => '　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/

<p>　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p>&nbsp;</p>
<p>安八町工場立地法に基づく準則を定める条例【骨子案】</p>
<p>&nbsp;</p>
<p>　地方分権により、工場立地法の事務処理権限が町に移譲されたことを活かして、「安八町第五次総合計画」の重要施策でもある企業誘致を促進するため、『安八町工場立地法に基づく準則を定める条例』を制定するにあたり、皆様のご意見を募集します。</p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>　　令和元年５月７日（火）～５月31日（金）</p>
<p>　　※必着、郵送の場合は５月31日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p> 　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/de222756f81bef1e4152c7ed6dc18dd11.pdf">安八町工場立地法に基づく準則を定める条例【骨子案】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>　　・町内に在住・在学・在勤の方</p>
<p>　　・町内に事務所又は事業所を有する個人及び法人その他の団体</p>
<p>　　・利害関係を有する個人及び法人その他の団体</p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3430,
                'featured_end_at' => NULL,
                'id' => 825,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:31:29',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について2019年5月6日 23時30分',
            ),
            461 => 
            array (
                'body' => '歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/

<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/bee4d85e44a03f4d4f69545be742af87.pdf">歴民だより　H.31 5月号　No.67</a></p>
',
                'content_id' => 3431,
                'featured_end_at' => NULL,
                'id' => 826,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:31:45',
                'publish_div' => 1,
                'title' => '歴民だより　5月号　No.672019年5月7日 0時30分',
            ),
            462 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/

<p>平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center;">投票率</td>
<td style="text-align: center;">有権者数</td>
<td style="text-align: center;">投票者数</td>
</tr>
<tr>
<td style="text-align: center;">４７．８４％</td>
<td style="text-align: center;">１２，１００人</td>
<td style="text-align: center;">５，７８９人</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td style="text-align: center;">候補者氏名（得票数順）</td>
<td style="text-align: center;">得　票　数</td>
</tr>
<tr>
<td style="text-align: center;">当選</td>
<td>堀　　正</td>
<td style="text-align: center;">５，００６票</td>
</tr>
<tr>
<td></td>
<td>川畑　たいじ</td>
<td style="text-align: center;">　　６８５票</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
<p style="text-align: center;">安八町選挙管理委員会</p>
',
                'content_id' => 3432,
                'featured_end_at' => NULL,
                'id' => 827,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:32:01',
                'publish_div' => 1,
                'title' => '平成３１年４月２１日　安八町長選挙の開票結果2019年5月7日 0時30分',
            ),
            463 => 
            array (
                'body' => 'パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/

<p><span style="font-size: medium;">パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4>案件名</h4>
<p><span style="font-size: medium;"> 安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">安八スマートインターチェンジ周辺は、企業立地や既存企業の振興とともに雇</span><span style="font-size: 15px;">用機会の拡大を図るべく、工業系土地利用の推進を図る区域として位置づけてお</span><span style="font-size: 15px;">ります。</span><span style="font-size: 15px;">当該地域の地区計画を策定し、不良な街区形成を防止するため、地区整備計画に基づく建築物の制限に関する条例を制定するにあたり、皆様のご意見を募集し</span><span style="font-size: 15px;">ます。</span></p>
<p>&nbsp;</p>
<h4>　募集期間</h4>
<p>&nbsp;</p>
<p>令和元年５月23日（木）～６月５日（水）</p>
<p>　　※必着、郵送の場合は６月５日の消印有効</p>
<p>&nbsp;</p>
<h4>骨子案の閲覧・入手場所</h4>
<p>　　・安八町ホームページ（下記PDFにてご覧いただけます）</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/ed7b1d53a06703845dc1dbda0fc4a6c01.pdf">安八町工業地区地区計画区域内における建築物の制限に関する条例（案）</a></p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/0641ab5678f46ddbd7a8a0dfac41e4dc.pdf">建築物等の制限に関する条例制定について【概要】</a></p>
<p>　　・安八町役場　企画調整課　　※閲覧時間　：　午前9時～午後5時（土･日･祝日除く）</p>
<p>&nbsp;</p>
<h4>意見を提出できる者</h4>
<p>&nbsp;</p>
<p><span style="font-size: 15px;">　町内に在住・在学・在勤の方</span></p>
<p><span style="font-size: 15px;">　町内に事業所などを持つ法人、その他の団体</span></p>
<p>&nbsp;</p>
<h4>意見の受付方法</h4>
<p>　閲覧場所備え付け、もしくは町ホームページよりダウンロードした意見提出様式（または、氏名、住所、連絡先等と意見を明記した書類）を持参、郵送、ファクシミリ及び電子メールのいずれかの方法によって提出されたものを皆さまからのご意見として受け付けます。</p>
<p>　　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/05/08a6dd41ae320e40e7d7f000d5ec6868.docx">意見提出様式</a></p>
<p>&nbsp;</p>
<h4>問い合わせ・提出先</h4>
<p>   安八町企画調整課　〒503-0198　岐阜県安八郡安八町氷取161</p>
<p>　　　　　　　　　　　　　　　TEL　　         0584-64-7101（直通）</p>
<p>　　　　　　　　　　　　　　　FAX　　　　　0584-64-5014</p>
<p>　　　　　　　　　　　　　　　E-mail　　　   <a href="mailto:hoken@toen.anpachi.gifu.jp">kikaku@town.anpachi.lg.jp</a></p>
',
                'content_id' => 3433,
                'featured_end_at' => NULL,
                'id' => 828,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:32:17',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント2019年5月23日 4時46分',
            ),
            464 => 
            array (
                'body' => '予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/

<h3>予防接種を町指定医療機関で受けるとき</h3>
<p><span style="color: #000000;">１）　接種の４日前には町指定医療機関へ電話予約してください。</span></p>
<p><span style="color: #000000;">２）　接種当日は、体調の良いことを確認し、予診票を記入してください。</span></p>
<p><span style="color: #000000;">　　　医療機関へは、<strong>予診票、（母子）健康手帳、体温表（小学生のみ）</strong>をお持ちください。</span></p>
<p>３）　<span style="color: #ff0000;">体調が悪くなった時は、予約解消の電話をしてください。</span><br /><span style="color: #000000;">４）　接種後、３０分くらいはその場で様子をみてください。</span></p>
<p><span style="color: #000000;">　　　２～３週間は副反応の出現に注意し、気になる症状があれば受診してください。</span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;">＜<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466602.xls">町指定医療機関</a>＞</span></p>
<p>※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>&nbsp;</p>
<h3>予防接種　広域化事業についてのお知らせ</h3>
<p>　安八町では、予防接種の広域化により、町外の病院においても予防接種ができるようになりました。かかりつけ医が町外の方や、里帰り・DVにより町内医療機関で接種できない方は、予診票に押印する必要がありますので、保健センターに必ずご連絡ください。なお、病院によって、接種可能な予防接種の種類が異なります。詳しくは岐阜県ホームページをご覧ください。</p>
<p>&nbsp;</p>
<h6>岐阜県ホームページ</h6>
<p>　<a href="http://www.pref.gifu.lg.jp/kodomo/kenko/kansensho/11223/kouikika.html">定期予防接種の広域化について</a></p>
<p>&nbsp;</p>
<table border="0">
<tbody>
<tr>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">お問い合わせ・申請先</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">住所</td>
<td style="text-align: center; background-color: #ccffff; border: #000066 1px solid;">電話番号</td>
</tr>
<tr>
<td style="text-align: center; border: #000066 1px solid;">安八町保健センター</td>
<td style="text-align: center; border: #000066 1px solid;">安八町南今ヶ渕３７５（安八町役場北側）</td>
<td style="text-align: center; border: #000066 1px solid;">（０５８４）６４－３７７５</td>
</tr>
</tbody></table>
<p>&nbsp;</p>
',
                'content_id' => 3434,
                'featured_end_at' => NULL,
                'id' => 829,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:32:33',
                'publish_div' => 1,
                'title' => '予防接種町指定医療機関一覧2019年5月24日 8時24分',
            ),
            465 => 
            array (
                'body' => '　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/

<p>　<strong>平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です</strong></p>
<p>&nbsp;</p>
<p>　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これは平成17～21年度の間、積極的な接種が差し控えられていたためです。</p>
<p>　特に、平成15～18年度に生まれた方は、第1期が終わっていない場合がありますので、母子健康手帳をご確認ください。間隔があいてしまっても、必要な回数を接種することが大切ですので、気づいた時点で接種しましょう。予診票がお手元に無い方は、保健センターまでご連絡ください。</p>
<table border="0">
<tbody>
<tr>
<td></td>
<td>対象者</td>
<td>接種回数および方法</td>
<td>場所・持ち物</td>
</tr>
<tr>
<td rowspan="2">1期</td>
<td>3歳～7歳半未満</td>
<td>
<p>＜初回：2回＞1回目</p>
<p>　　　　　　　　　　　↓　6～28日あける</p>
<p>　　　　　　　　　　2回目</p>
<p>　　　　　　　　　　　↓　概ね1年あける</p>
<p>＜追加：1回＞3回目</p></td>
<td rowspan="4">
<p>&nbsp;</p>
<p>＜場所＞</p>
<p><a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a466601.xls">町指定医療機関</a></p>
<p>&nbsp;</p>
<p>＜持ち物＞</p>
<p>母子健康手帳、予診票</p>
<p>体温表（小学生まで）</p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>①1期を1回も接種していない方は上記のとおり接種してください。</p>
<p>②1期を1回以上接種した方は、6～28日あけて不足分を接種してください。</p></td>
</tr>
<tr>
<td rowspan="2">2期</td>
<td>9～13歳未満</td>
<td>
<p>1回接種してください。（ただし、1期が全部済んでいる場合に可能）</p></td>
</tr>
<tr>
<td>特例対象者</td>
<td>
<p>1回接種してください。</p>
<p>1期終了後6日以上あければ接種できますが、概ね5年あけるのが理想です。</p></td>
</tr>
</tbody></table>
<p> ※かかりつけ医が町外の方は、保健センターへご相談ください。</p>
<p>※特例対象者以外の方は、3～7歳半未満（7歳半を迎える日の前日まで）に1期初回、追加を接種し、9～13歳未満（13歳を迎える日の前日まで）に2期を接種してください。</p>
<p>&nbsp;</p>
<h3>日本脳炎関連情報</h3>
<p>&nbsp;</p>
<p>１．厚生労働省「日本脳炎の予防接種についてのご案内」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou20/annai.html</a></p>
<p>２．厚生労働省「日本脳炎ワクチン予防接種に係るＱ＆Ａ」</p>
<p><a href="http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf">http://www.mhlw.go.jp/bunya/kenkou/kekkaku-kansenshou21/dl/nouen_qa.pdf</a></p>
',
                'content_id' => 3435,
                'featured_end_at' => NULL,
                'id' => 830,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:32:49',
                'publish_div' => 1,
                'title' => '日本脳炎2019年5月24日 8時24分',
            ),
            466 => 
            array (
                'body' => '　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/

<p align="left">　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、<a href="http://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/haienkyukin/index_1.html">厚生労働省ホームページ</a>をご覧ください。不明な点はお問い合わせください。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>１．対象者</p>
<p>　　平成31年度に65歳、70歳、75歳、80歳、85歳、90歳、95歳、100歳以上となる方</p>
<p>&nbsp;</p>
<p>２．期　間</p>
<p>　　平成31年4月1日（月）～翌年3月31日（火）まで</p>
<p>&nbsp;</p>
<p>３．回　数</p>
<p>　　１回のみ　　※過去に接種した方は、定期接種の対象となりません。</p>
<p>&nbsp;</p>
<p>４．持ち物</p>
<p>　　予診票、自己負担金（4,000円）</p>
<p>&nbsp;</p>
<p>５．方　法</p>
<p>　　<a href="http://www.town.anpachi.gifu.jp/wp-content/uploads/2019/04/5a923c015beea7b6e28fc40669a46660.xls">町指定医療機関</a>へ４日前までに予約して接種を受けてください。</p>
',
                'content_id' => 3436,
                'featured_end_at' => NULL,
                'id' => 831,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:33:04',
                'publish_div' => 1,
                'title' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ2019年5月24日 8時25分',
            ),
            467 => 
            array (
                'body' => '現在システム障害のため、蔵書予約ができない状況となっております。復旧次第お知らせします。 所蔵の確認、予約は電話でも受け付けております。ご迷惑をおかけして申し訳ありません。 &#160; &#160; &#160;
http://www.town.anpachi.gifu.jp/2019/05/28/%e8%94%b5%e6%9b%b8%e6%a4%9c%e7%b4%a2%e3%82%b7%e3%82%b9%e3%83%86%e3%83%a0%e9%9a%9c%e5%ae%b3/

<p>現在システム障害のため、蔵書予約ができない状況となっております。復旧次第お知らせします。</p>
<p>所蔵の確認、予約は電話でも受け付けております。ご迷惑をおかけして申し訳ありません。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
',
                'content_id' => 3437,
                'featured_end_at' => NULL,
                'id' => 832,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:33:21',
                'publish_div' => 1,
                'title' => '蔵書検索システム障害2019年5月28日 0時43分',
            ),
            468 => 
            array (
                'body' => '
　
令和元年５月１日現在の秋田県の総人口は 970,496人で、前月に比べ 206人（0.02％）減少しました。
また、世帯数は 389,381世帯で、前月に比べ 1,462世帯増加しました。
詳細については、下記「秋田県の人口と世帯（月報）令和元年5月1日現在」をダウンロードしてご覧ください。
 
◆PDFファイルのダウンロード
　秋田県の人口と世帯（月報）令和元年5月1日現在
 
 
 　
◆Excelファイルのダウンロード
　秋田県の人口と世帯（月報）令和元年5月1日現在
 
 
 
　 


過去データ

　過去の月報はこちらから

...
https://www.pref.akita.lg.jp/pages/archive/9910',
                'content_id' => 3438,
                'featured_end_at' => NULL,
                'id' => 833,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:33:39',
                'publish_div' => 1,
                'title' => '秋田県の人口と世帯（月報）2019年5月24日 9時00分',
            ),
            469 => 
            array (
                'body' => '　国内大手のアウトドア用品メーカー「株式会社モンベル」の創業者である辰野勇氏の講演会を開催します。
　講演では、同社の環境教育における取組等をお話いただきます。環境教育に携わる方、アウトドアに関心がある方、そうでない方にも有意義かつ楽しめる内容ですので、お気軽に御来場ください。
　※入場無料、事前申込不要、先着２５０名とします。
　この講演は、「あきた白神まつり２０１９」の一環として開催するものです。「あきた白神まつり２０１９」の詳細は下記のダウンロードから御覧ください。
１　日時
　令和元年...
https://www.pref.akita.lg.jp/pages/archive/42341',
                'content_id' => 3439,
                'featured_end_at' => NULL,
                'id' => 834,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:33:44',
                'publish_div' => 1,
                'title' => '辰野勇氏（株式会社モンベル創業者）による講演会を開催します！2019年5月24日 9時00分',
            ),
            470 => 
            array (
                'body' => '　「環境大賞（秋田県知事賞）」は、環境保全に関する実践活動が他の模範となる個人又は団体を表彰し、その活動事例を広く県民の皆さんに紹介し環境保全に関する自主的な取組を促進することを目的として、平成１０年度に創設されました。　今年度も「環境大賞」の候補者を次のとおり募集します（自薦、他薦を問いません）。
【募集対象】
（１）個人又は団体が秋田県内で実践している環境保全全般に関する活動事例を募集対象とし、次の部門に分けて表彰を行います。ア　個人イ　学校教育関係ウ　団体
（２）学校教育関係は、保育所...
https://www.pref.akita.lg.jp/pages/archive/25213',
                'content_id' => 3440,
                'featured_end_at' => NULL,
                'id' => 835,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:33:49',
                'publish_div' => 1,
                'title' => '令和元年度「環境大賞」を募集します！2019年5月24日 10時00分',
            ),
            471 => 
            array (
                'body' => '
　果樹の発芽から開花までの初期生態について掲載します。なお、６月から11月まで、毎月１日および15日に行っている生育調査の結果と今後の管理に関する注意点について掲載します。


ダウンロード

・NEW 令和元年度リンゴ結実調査結果（果樹試験場（本場）） [68KB]
・令和元年度果樹初期生態一覧（5月21日） [135KB]
 
・令和元年度果樹の開花に関する情報（5月2日予測） [51KB]
 ・平成31年産リンゴの花芽分化状況 [71KB]
 

 （参考）
・11月15日（最終）果樹定期調査結果一覧表（平成30年） [160KB]
・11月1日　...
https://www.pref.akita.lg.jp/pages/archive/9103',
                'content_id' => 3441,
                'featured_end_at' => NULL,
                'id' => 836,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:33:55',
                'publish_div' => 1,
                'title' => '果樹の生育状況（令和元年度）2019年5月24日 12時00分',
            ),
            472 => 
            array (
                'body' => 'ダウンロード

平成３１年度秋田県公立高等学校入学者選抜一般選抜学力検査の抽出調査

https://www.pref.akita.lg.jp/pages/archive/42493',
                'content_id' => 3442,
                'featured_end_at' => NULL,
                'id' => 837,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:00',
                'publish_div' => 1,
                'title' => '平成３１年度秋田県公立高等学校入学者選抜一般選抜学力検査の抽出調査2019年5月24日 17時00分',
            ),
            473 => 
            array (
                'body' => '　令和元年５月２４日（金）午前８時５０分頃、横手市内の医療機関より、トリカブトを喫食したと思われる患者４名を診察した旨、横手保健所に連絡がありました。　横手保健所による調査の結果、５月２３日（木）に山菜を調理・喫食した４名が倦怠感、しびれ等の症状を呈しており、知人からもらった山菜の中に有毒植物であるトリカブトが混入していたものと推察され、トリカブトによる食中毒と判断しました。
１　発生日時　令和元年５月２３日（木）午後９時３０分２　喫食者　　４名３　患者数　　４名（男性２名、女性２名　５０代...
https://www.pref.akita.lg.jp/pages/archive/36445',
                'content_id' => 3443,
                'featured_end_at' => NULL,
                'id' => 838,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:05',
                'publish_div' => 1,
                'title' => '食中毒の発生について2019年5月25日 13時00分',
            ),
            474 => 
            array (
                'body' => 'ご注意ください！！　日中の気温が非常に高くなっています！！
　気象庁の見込みではこれから6月下旬にかけて、全国的に平均気温が高い確率の地域が多く、秋田県内においても、熱中症の危険がとても高くなっています。
　特に、外出時や屋外での作業時、高齢者、乳幼児、体調のすぐれない方がおられるご家庭では【水分をこまめに補給】【多量に汗をかいた場合は塩分も補給】、【カーテンで日射を遮る】【冷房を適切に利用する】など十分な対策をとるようにしてください。
　家の中でじっとしていても室温や湿度が高いために、体から...
https://www.pref.akita.lg.jp/pages/archive/24728',
                'content_id' => 3444,
                'featured_end_at' => NULL,
                'id' => 839,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:10',
                'publish_div' => 1,
                'title' => '熱中症に注意をしましょう！2019年5月27日 9時00分',
            ),
            475 => 
            array (
                'body' => '秋田県鉱工業生産指数月報（平成３１年３月分）について
　平成３１年３月の秋田県鉱工業生産指数は、季節調整済指数が９６．６（前月比３．１％減）で、２か月ぶりの低下となりました。また、原指数は１０１．４で前年同月比４．６％の低下となりました。
　全国の季節調整済指数は１０２．２で前月比０．６％の低下、東北は１００．１で前月比２．２％の低下となりました。
　　
ダウンロードpdf

秋田県鉱工業生産指数月報（平成３１年３月分） [597KB]
秋田県鉱工業生産指数月報（平成３１年２月分） [482KB]
秋田県鉱工業...
https://www.pref.akita.lg.jp/pages/archive/6645',
                'content_id' => 3445,
                'featured_end_at' => NULL,
                'id' => 840,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:16',
                'publish_div' => 1,
                'title' => '秋田県鉱工業生産指数（月報）2019年5月27日 10時00分',
            ),
            476 => 
            array (
                'body' => '神秘の絶景「八幡平ドラゴンアイ」それは、大自然の奇跡が生み出す龍の瞳。
English Ver. ➡　 The information center of "Hachimantai Dragon Eye" 繁體中文　  ➡ 　「八幡平龍眼」通訊局 　　
　
「八幡平ドラゴンアイ」が「ＣＯＯＬ  ＪＡＰＡＮ  ＡＷＡＲＤ  ２０１９」を受賞しました！「COOL JAPAN AWARD」についてはこちら（外部リンク）　
「八幡平ドラゴンアイ」は、秋田県と岩手県にまたがる八幡平（はちまんたい）の頂上付近で見ることができる、幻の絶景です。
　雪と氷が織りなす神秘的な瞳は、沼、空、天候といった...
https://www.pref.akita.lg.jp/pages/archive/40618',
                'content_id' => 3446,
                'featured_end_at' => NULL,
                'id' => 841,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:21',
                'publish_div' => 1,
                'title' => '「八幡平ドラゴンアイ」発信局2019年5月27日 10時00分',
            ),
            477 => 
            array (
                'body' => ' 
現在、動物愛護センターにいる犬を家族に迎え、生涯可愛がってくださる方を募集しています。
 
 



写真


情報




 




 
①


犬種
ポメラニアン


性別
メス


年齢
推定５歳


検査等

寄生虫卵陰性、フィラリア陰性
６種混合ワクチン接種済み



性格

・かまってもらうことは好きですが、怖がりな一面もあります。
・新しい環境に慣れるのに時間がかかると思われます。温かく迎えてくれるご家族を募集します。




 




    
掲載期間は令和元年５月２７日（月）...
https://www.pref.akita.lg.jp/pages/archive/24376',
                'content_id' => 3447,
                'featured_end_at' => NULL,
                'id' => 842,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:26',
                'publish_div' => 1,
                'title' => '『犬を家族に迎えてくれる方を募集しています』2019年5月27日 10時00分',
            ),
            478 => 
            array (
                'body' => '「とうほく・北海道 新技術・新工法展示商談会 」の開催及び出展者募集について
　東北の産学官で組織する「とうほく自動車産業集積連携会議」では、令和２年１月３０日(木)・３１日(金)にトヨタ自動車株式会社「本館ホール」(愛知県豊田市）を会場に、「とうほく・北海道 新技術・新工法展示商談会」を開催します。
　この展示商談会は、トヨタ自動車株式会社をはじめとするトヨタグループ各社様に対して、東北・北海道の企業の持つ新技術や新工法を提案・アピールすることで、具体的取引や協力関係の構築を目指すものです。
　つ...
https://www.pref.akita.lg.jp/pages/archive/24925',
                'content_id' => 3448,
                'featured_end_at' => NULL,
                'id' => 843,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:31',
                'publish_div' => 1,
                'title' => '「とうほく・北海道 新技術・新工法展示商談会」の開催及び出展者募集について2019年5月27日 13時00分',
            ),
            479 => 
            array (
                'body' => '　自転車による事故で、加害者が高額な損害賠償を求められることがあります。　事故に備え、自転車保険に加入しましょう。
〇主な保険の例　・保険会社等で取り扱う自転車向け保険　・傷害保険、火災保険、自動車保険等の個人賠償責任特約　・自転車安全整備店で加入できる「ＴＳマーク付帯保険」　※コンビニエンスストアやインターネット等で加入できる保険もありま　　　　　す。
まずは、チェックシートで自転車保険加入状況を確認しましょう。　加入状況チェックシート [216KB]
 

https://www.pref.akita.lg.jp/pages/archive/42453',
                'content_id' => 3449,
                'featured_end_at' => NULL,
                'id' => 844,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:36',
                'publish_div' => 1,
                'title' => '自転車保険に加入しましょう！2019年5月27日 14時00分',
            ),
            480 => 
            array (
                'body' => '　新卒者（大卒者）の採用に意欲的な県内企業を対象に、新卒者の採用力の向上を図るため、専門講師から採用の重要なポイントや全国の採用動向等を学んでいただくためのセミナーを開催します。ご参加をお待ちしています。
１　経営者・人事責任者向けセミナー
　　　対　象：新卒者（大卒者）の採用に意欲的な県内企業の経営者・人事部門の責任者等
　　　日　時：令和元年６月１８日（火）１３時から１５時まで
　　　場　所：秋田県庁第二庁舎　８階　大会議室　　　
　　　内　容：会社発展につながる新卒採用のあり方、業績向...
https://www.pref.akita.lg.jp/pages/archive/42563',
                'content_id' => 3450,
                'featured_end_at' => NULL,
                'id' => 845,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:41',
                'publish_div' => 1,
                'title' => '「県内企業における新卒採用力強化セミナー」を開催します。2019年5月28日 1時00分',
            ),
            481 => 
            array (
                'body' => '　県では、県内外に進学した大学生等に、就職先として県内企業が選択肢となるよう、学生向けセミナー及び県内企業見学会等を実施します。
　つきましては、この業務を委託する候補者を選定するため、次により企画提案競技を実施しますので、添付ファイルをご確認のうえ、ご応募くださるようお願いいたします。
業務名
大学生等県内就職促進事業
仕様等
【資料２】業務委託仕様書のとおり
委託業務の履行期間
契約締結の日から令和２年２月２８日（金）まで
委託業務の契約上限額
１１，０７６，２０６円（消費税及び地方消費...
https://www.pref.akita.lg.jp/pages/archive/34303',
                'content_id' => 3451,
                'featured_end_at' => NULL,
                'id' => 846,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:46',
                'publish_div' => 1,
                'title' => '大学生等県内就職促進事業業務委託に係る企画提案競技の実施について 2019年5月28日 8時00分',
            ),
            482 => 
            array (
                'body' => '　令和元年10月の消費税引き上げやインバウンドの更なる誘客を見据え、県内の商業・サービス業に関わる事業者の皆様に、「キャッシュレス・ポイント還元事業」や「キャッシュレス決済導入のメリット」について学んでいただくためのセミナーを開催します。
１　日　時
　令和元年７月９日（火）　午後１時～３時３０分
２　場　所
　秋田県庁第二庁舎　８階　大会議室（秋田市山王三丁目１－１）
３　対　象
　県内の商業・サービス業事業者、商工団体、行政関係者
４　お申込み
　参加申込書に必要事項をご記入の上、メールま...
https://www.pref.akita.lg.jp/pages/archive/42448',
                'content_id' => 3452,
                'featured_end_at' => NULL,
                'id' => 847,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:52',
                'publish_div' => 1,
                'title' => '「秋田県キャッシュレス推進セミナー」を開催します！2019年5月28日 9時00分',
            ),
            483 => 
            array (
                'body' => '　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　１　試験の日時・場所



日　時
場　所


令和元年８月2８日（水）　 午前１０時３０分から午後４時まで
秋田ビューホテル （〒010-0001秋田市中通二丁目６番１号） ※地図・アクセス：秋田ビューホテル



※会場の収容人数の都合により、受験者多数の場合には、他の会場での受験とする...
https://www.pref.akita.lg.jp/pages/archive/25255',
                'content_id' => 3453,
                'featured_end_at' => NULL,
                'id' => 848,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:34:57',
                'publish_div' => 1,
                'title' => '令和元年度秋田県登録販売者試験について2019年5月28日 9時00分',
            ),
            484 => 
            array (
                'body' => '防除対策情報　第２号　令和元年５月２８日　りんご黒星病について [123KB]
https://www.pref.akita.lg.jp/pages/archive/42570',
                'content_id' => 3454,
                'featured_end_at' => NULL,
                'id' => 849,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:35:02',
                'publish_div' => 1,
                'title' => '農作物病害虫発生予察情報（防除対策情報第２号を発表しました） 2019年5月28日 15時00分',
            ),
            485 => 
            array (
                'body' => '発生予報　第２号（令和元年５月２８日）424KB]
https://www.pref.akita.lg.jp/pages/archive/42569',
                'content_id' => 3455,
                'featured_end_at' => NULL,
                'id' => 850,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:35:07',
                'publish_div' => 1,
                'title' => ' 農作物病害虫発生予察情報（発生予報第２号を発表しました）2019年5月28日 15時00分',
            ),
            486 => 
            array (
                'body' => '
　
令和元年５月１日現在の秋田県の総人口は 970,496人で、前月に比べ 206人（0.02％）減少しました。
また、世帯数は 389,381世帯で、前月に比べ 1,462世帯増加しました。
詳細については、下記「秋田県の人口と世帯（月報）令和元年5月1日現在」をダウンロードしてご覧ください。
 
◆PDFファイルのダウンロード
　秋田県の人口と世帯（月報）令和元年5月1日現在
 
 
 　
◆Excelファイルのダウンロード
　秋田県の人口と世帯（月報）令和元年5月1日現在
 
 
 
　 


過去データ

　過去の月報はこちらから

...
https://www.pref.akita.lg.jp/pages/archive/9910',
                'content_id' => 3456,
                'featured_end_at' => NULL,
                'id' => 851,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 16:40:16',
                'publish_div' => 1,
                'title' => '秋田県の人口と世帯（月報）2019年5月24日 9時00分',
            ),
            487 => 
            array (
                'body' => '広域行政窓口サービスについて 西濃地域と岐阜地域の20市町村のどこの窓口でも、「住民票の写し」「戸籍の謄抄本」「地方税に関する証明書」などの各種証明書の交付が受けられます。該当の市町間とファックスで送受信を行いますので、 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 3458,
                'featured_end_at' => NULL,
                'id' => 853,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:10:39',
                'publish_div' => 1,
                'title' => '広域行政窓口2019年4月1日 11時01分',
            ),
            488 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">demo</span></font>',
                'content_id' => 3459,
                'featured_end_at' => NULL,
                'id' => 854,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:10:00',
                'publish_div' => 1,
                'title' => 'demo',
            ),
            489 => 
            array (
                'body' => '令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 3460,
                'featured_end_at' => NULL,
                'id' => 855,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:10:56',
                'publish_div' => 1,
                'title' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）2019年4月26日 4時48分',
            ),
            490 => 
            array (
                'body' => '　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 3461,
                'featured_end_at' => NULL,
                'id' => 856,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:11:13',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について2019年5月6日 23時30分',
            ),
            491 => 
            array (
                'body' => '歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
                'content_id' => 3462,
                'featured_end_at' => NULL,
                'id' => 857,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:11:29',
                'publish_div' => 1,
                'title' => '歴民だより　5月号　No.672019年5月7日 0時30分',
            ),
            492 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人 &#160; 候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 3463,
                'featured_end_at' => NULL,
                'id' => 858,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:11:45',
                'publish_div' => 1,
                'title' => '平成３１年４月２１日　安八町長選挙の開票結果2019年5月7日 0時30分',
            ),
            493 => 
            array (
                'body' => 'パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/',
                'content_id' => 3464,
                'featured_end_at' => NULL,
                'id' => 859,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:12:00',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント2019年5月23日 4時46分',
            ),
            494 => 
            array (
                'body' => '予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/',
                'content_id' => 3465,
                'featured_end_at' => NULL,
                'id' => 860,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:12:16',
                'publish_div' => 1,
                'title' => '予防接種町指定医療機関一覧2019年5月24日 8時24分',
            ),
            495 => 
            array (
                'body' => '　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/',
                'content_id' => 3466,
                'featured_end_at' => NULL,
                'id' => 861,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:12:31',
                'publish_div' => 1,
                'title' => '日本脳炎2019年5月24日 8時24分',
            ),
            496 => 
            array (
                'body' => '　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/',
                'content_id' => 3467,
                'featured_end_at' => NULL,
                'id' => 862,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:12:47',
                'publish_div' => 1,
                'title' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ2019年5月24日 8時25分',
            ),
            497 => 
            array (
                'body' => '現在システム障害のため、蔵書予約ができない状況となっております。復旧次第お知らせします。 所蔵の確認、予約は電話でも受け付けております。ご迷惑をおかけして申し訳ありません。 &#160; &#160; &#160;
http://www.town.anpachi.gifu.jp/2019/05/28/%e8%94%b5%e6%9b%b8%e6%a4%9c%e7%b4%a2%e3%82%b7%e3%82%b9%e3%83%86%e3%83%a0%e9%9a%9c%e5%ae%b3/',
                'content_id' => 3468,
                'featured_end_at' => NULL,
                'id' => 863,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:13:03',
                'publish_div' => 1,
                'title' => '蔵書検索システム障害2019年5月28日 0時43分',
            ),
            498 => 
            array (
                'body' => '　国内大手のアウトドア用品メーカー「株式会社モンベル」の創業者である辰野勇氏の講演会を開催します。
　講演では、同社の環境教育における取組等をお話いただきます。環境教育に携わる方、アウトドアに関心がある方、そうでない方にも有意義かつ楽しめる内容ですので、お気軽に御来場ください。
　※入場無料、事前申込不要、先着２５０名とします。
　この講演は、「あきた白神まつり２０１９」の一環として開催するものです。「あきた白神まつり２０１９」の詳細は下記のダウンロードから御覧ください。
１　日時
　令和元年...
https://www.pref.akita.lg.jp/pages/archive/42341',
                'content_id' => 3469,
                'featured_end_at' => NULL,
                'id' => 864,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:36:25',
                'publish_div' => 1,
                'title' => '辰野勇氏（株式会社モンベル創業者）による講演会を開催します！2019年5月24日 9時00分',
            ),
            499 => 
            array (
                'body' => '発生予報　第２号（令和元年５月２８日）424KB]
https://www.pref.akita.lg.jp/pages/archive/42569',
                'content_id' => 3471,
                'featured_end_at' => NULL,
                'id' => 866,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:42:34',
                'publish_div' => 1,
                'title' => ' 農作物病害虫発生予察情報（発生予報第２号を発表しました）2019年5月28日 15時00分',
            ),
        ));
        \DB::table('posts')->insert(array (
            0 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/04/01/%e5%ba%83%e5%9f%9f%e8%a1%8c%e6%94%bf%e7%aa%93%e5%8f%a3-2/',
                'content_id' => 3474,
                'featured_end_at' => NULL,
                'id' => 869,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:47:48',
                'publish_div' => 1,
                'title' => '広域行政窓口2019年4月1日 11時01分',
            ),
            1 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 3475,
                'featured_end_at' => NULL,
                'id' => 870,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:48:04',
                'publish_div' => 1,
                'title' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）2019年4月26日 4時48分',
            ),
            2 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 3476,
                'featured_end_at' => NULL,
                'id' => 871,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:48:19',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について2019年5月6日 23時30分',
            ),
            3 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
                'content_id' => 3477,
                'featured_end_at' => NULL,
                'id' => 872,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:48:33',
                'publish_div' => 1,
                'title' => '歴民だより　5月号　No.672019年5月7日 0時30分',
            ),
            4 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 3478,
                'featured_end_at' => NULL,
                'id' => 873,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:48:47',
                'publish_div' => 1,
                'title' => '平成３１年４月２１日　安八町長選挙の開票結果2019年5月7日 0時30分',
            ),
            5 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/',
                'content_id' => 3479,
                'featured_end_at' => NULL,
                'id' => 874,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:49:02',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント2019年5月23日 4時46分',
            ),
            6 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/',
                'content_id' => 3480,
                'featured_end_at' => NULL,
                'id' => 875,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:49:18',
                'publish_div' => 1,
                'title' => '予防接種町指定医療機関一覧2019年5月24日 8時24分',
            ),
            7 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/',
                'content_id' => 3481,
                'featured_end_at' => NULL,
                'id' => 876,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:49:33',
                'publish_div' => 1,
                'title' => '日本脳炎2019年5月24日 8時24分',
            ),
            8 => 
            array (
                'body' => '[@descriptipon]
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/',
                'content_id' => 3482,
                'featured_end_at' => NULL,
                'id' => 877,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 17:49:48',
                'publish_div' => 1,
                'title' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ2019年5月24日 8時25分',
            ),
            9 => 
            array (
                'body' => '[@czxczxc]
http://www.town.anpachi.gifu.jp/2019/05/28/%e8%94%b5%e6%9b%b8%e6%a4%9c%e7%b4%a2%e3%82%b7%e3%82%b9%e3%83%86%e3%83%a0%e9%9a%9c%e5%ae%b3/',
                'content_id' => 3483,
                'featured_end_at' => NULL,
                'id' => 878,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 18:59:00',
                'publish_div' => 1,
                'title' => '蔵書検索システム障害2019年5月28日 0時43分',
            ),
            10 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Test 351 ja</span></font>',
                'content_id' => 3484,
                'featured_end_at' => NULL,
                'id' => 879,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-28 19:21:00',
                'publish_div' => 1,
                'title' => 'Test 351 ja',
            ),
            11 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu ja</span></font>',
                'content_id' => 3485,
                'featured_end_at' => NULL,
                'id' => 880,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-29 20:35:00',
                'publish_div' => 2,
                'title' => 'thu ja11111',
            ),
            12 => 
            array (
                'body' => 'eqweqw',
                'content_id' => 3488,
                'featured_end_at' => NULL,
                'id' => 881,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-29 18:20:00',
                'publish_div' => 1,
                'title' => 'test',
            ),
            13 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Test publish ja</span></font>',
                'content_id' => 3489,
                'featured_end_at' => NULL,
                'id' => 882,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-29 18:27:00',
                'publish_div' => 1,
                'title' => 'Test publish ja',
            ),
            14 => 
            array (
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu2222222222</span></font>',
                'content_id' => 3490,
                'featured_end_at' => NULL,
                'id' => 883,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-29 20:30:00',
                'publish_div' => 2,
                'title' => 'thu2222222222',
            ),
            15 => 
            array (
                'body' => '【告示】農用地利用配分計画の認可の申請について【農政部 農業経営課】

2019年5月30日 16時06分',
                'content_id' => 3532,
                'featured_end_at' => NULL,
                'id' => 891,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 18:47:44',
                'publish_div' => 1,
            'title' => '【告知】農用地利用配分計画の認可の申請について(令和元年5月28日)',
            ),
            16 => 
            array (
                'body' => '令和２年４月採用の安八町職員を次の要領で募集します。 １．募集職種・採用予定数・試験区分・受験資格等 募集職種 採用予定数 試験区分 受験資格 一般行政職 若干名 大学卒業程度 昭和６３年４月２日以降に生まれた方 短大卒 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/04/26/%e4%bb%a4%e5%92%8c%e5%85%83%e5%b9%b4%e5%ba%a6%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e8%81%b7%e5%93%a1%e6%8e%a1%e7%94%a8%e8%a9%a6%e9%a8%93%e6%a1%88%e5%86%85%ef%bc%88%e4%b8%80%e8%88%ac%e8%a1%8c%e6%94%bf/',
                'content_id' => 3533,
                'featured_end_at' => NULL,
                'id' => 892,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:05:10',
                'publish_div' => 1,
                'title' => '令和元年度　安八町職員採用試験案内（一般行政職･保育士）2019年4月26日 4時48分',
            ),
            17 => 
            array (
                'body' => '　パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;n &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%ae%89%e5%85%ab%e7%94%ba%e5%b7%a5%e5%a0%b4%e7%ab%8b%e5%9c%b0%e6%b3%95%e3%81%ab%e5%9f%ba%e3%81%a5%e3%81%8f%e6%ba%96%e5%89%87%e3%82%92%e5%ae%9a%e3%82%81%e3%82%8b%e6%9d%a1%e4%be%8b%e3%80%90%e9%aa%a8/',
                'content_id' => 3534,
                'featured_end_at' => NULL,
                'id' => 893,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:05:36',
                'publish_div' => 1,
                'title' => '安八町工場立地法に基づく準則を定める条例【骨子案】のパブリックコメントの実施について2019年5月6日 23時30分',
            ),
            18 => 
            array (
                'body' => '歴民だより　H.31 5月号　No.67
http://www.town.anpachi.gifu.jp/2019/05/07/%e6%ad%b4%e6%b0%91%e3%81%a0%e3%82%88%e3%82%8a%e3%80%805%e6%9c%88%e5%8f%b7%e3%80%80no-67/',
                'content_id' => 3535,
                'featured_end_at' => NULL,
                'id' => 894,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:05:55',
                'publish_div' => 1,
                'title' => '歴民だより　5月号　No.672019年5月7日 0時30分',
            ),
            19 => 
            array (
                'body' => '平成３１年４月２１日　安八町長選挙の開票結果をお知らせします。 投票率 有権者数 投票者数 ４７．８４％ １２，１００人 ５，７８９人   候補者氏名（得票数順） 得　票　数 当選 堀　　正 ５，００６票 川畑 … <a href="http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/">続きを読む <span class="meta-nav">→</span></a>
http://www.town.anpachi.gifu.jp/2019/05/07/%e5%b9%b3%e6%88%90%ef%bc%93%ef%bc%91%e5%b9%b4%ef%bc%94%e6%9c%88%ef%bc%92%ef%bc%91%e6%97%a5%e3%80%80%e5%ae%89%e5%85%ab%e7%94%ba%e9%95%b7%e9%81%b8%e6%8c%99%e3%81%ae%e9%96%8b%e7%a5%a8%e7%b5%90%e6%9e%9c/',
                'content_id' => 3536,
                'featured_end_at' => NULL,
                'id' => 895,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:07:00',
                'publish_div' => 1,
                'title' => '平成３１年４月２１日　安八町長選挙の開票結果2019年5月7日 0時30分',
            ),
            20 => 
            array (
                'body' => 'パブリックコメント制度（町民意見の募集手続き制度）は、安八町の基本的な政策等を定める際に、事前に政策等の案や関連資料を公表し、町民の皆さんから意見を募り、それらの意見を参考に政策等を定める制度です。 &#160; &#038;nb &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/23/%e5%ae%89%e5%85%ab%e7%94%ba-%e5%b7%a5%e6%a5%ad%e5%9c%b0%e5%8c%ba%e5%9c%b0%e5%8c%ba%e8%a8%88%e7%94%bb%e5%8c%ba%e5%9f%9f%e5%86%85%e3%81%ab%e3%81%8a%e3%81%91%e3%82%8b-%e5%bb%ba%e7%af%89%e7%89%a9%e3%81%ae/',
                'content_id' => 3537,
                'featured_end_at' => NULL,
                'id' => 896,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:06:33',
                'publish_div' => 1,
                'title' => '安八町 工業地区地区計画区域内における 建築物の制限に関する条例【 案】に関するパブリックコメント2019年5月23日 4時46分',
            ),
            21 => 
            array (
                'body' => '予防接種を町指定医療機関で受けるとき １）　接種の４日前には町指定医療機関へ電話予約してください。 ２）　接種当日は、体調の良いことを確認し、予診票を記入してください。 　　　医療機関へは、予診票、（母子）健康手帳、体温 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e7%94%ba%e6%8c%87%e5%ae%9a%e5%8c%bb%e7%99%82%e6%a9%9f%e9%96%a2%e4%b8%80%e8%a6%a7-2/',
                'content_id' => 3538,
                'featured_end_at' => NULL,
                'id' => 897,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:06:55',
                'publish_div' => 1,
                'title' => '予防接種町指定医療機関一覧2019年5月24日 8時24分',
            ),
            22 => 
            array (
                'body' => '　平成7年4月2日～平成19年4月1日生まれで20歳未満の人は特例対象者です &#160; 　日本脳炎第1期の標準的な接種年齢は3～4歳、第2期は9～10歳ですが、特例対象者に限り20歳を迎える前日まで接種可能です。これ &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e6%97%a5%e6%9c%ac%e8%84%b3%e7%82%8e-3/',
                'content_id' => 3539,
                'featured_end_at' => NULL,
                'id' => 898,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:07:16',
                'publish_div' => 1,
                'title' => '日本脳炎2019年5月24日 8時24分',
            ),
            23 => 
            array (
                'body' => '　対象の方には個別に通知をいたしますので、希望される方は接種を受けてください。ワクチンに関する詳しい情報は、厚生労働省ホームページをご覧ください。不明な点はお問い合わせください。 &#160; &#160; １．対象者  &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/24/%e5%b9%b3%e6%88%9031%e5%b9%b4%e5%ba%a6%e3%80%80%e9%ab%98%e9%bd%a2%e8%80%85%e3%81%ae%e8%82%ba%e7%82%8e%e7%90%83%e8%8f%8c%e6%84%9f%e6%9f%93%e7%97%87%e4%ba%88%e9%98%b2%e6%8e%a5%e7%a8%ae%e3%81%ae%e3%81%-4/',
                'content_id' => 3540,
                'featured_end_at' => NULL,
                'id' => 899,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:07:34',
                'publish_div' => 1,
                'title' => '平成31年度　高齢者の肺炎球菌感染症予防接種のお知らせ2019年5月24日 8時25分',
            ),
            24 => 
            array (
                'body' => '現在システム障害のため、蔵書予約ができない状況となっております。復旧次第お知らせします。 所蔵の確認、予約は電話でも受け付けております。ご迷惑をおかけして申し訳ありません。 &#160; &#160; &#160;
http://www.town.anpachi.gifu.jp/2019/05/28/%e8%94%b5%e6%9b%b8%e6%a4%9c%e7%b4%a2%e3%82%b7%e3%82%b9%e3%83%86%e3%83%a0%e9%9a%9c%e5%ae%b3/',
                'content_id' => 3541,
                'featured_end_at' => NULL,
                'id' => 900,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:07:55',
                'publish_div' => 1,
                'title' => '蔵書検索システム障害2019年5月28日 0時43分',
            ),
            25 => 
            array (
                'body' => '町は、消費税・地方消費税率の１０％への引き上げが低所得者・子育て世帯の消費に与える影響を緩和するとともに、地域における消費を喚起・下支えすることを目的として『安八町プレミアム付商品券』を販売します。 &#160; 購入対 &#8230; <a href="http://www.town.anpachi.gifu.jp/2019/05/29/%e3%83%97%e3%83%ac%e3%83%9f%e3%82%a2%e3%83%a0%e4%bb%98%e5%95%86%e5%93%81%e5%88%b8%e3%80%80%ef%bd%9e%e6%ba%96%e5%82%99%e3%82%92%e9%80%b2%e3%82%81%e3%81%a6%e3%81%84%e3%81%be%e3%81%99%ef%bd%9e/">続きを読む <span class="meta-nav">&#8594;</span></a>
http://www.town.anpachi.gifu.jp/2019/05/29/%e3%83%97%e3%83%ac%e3%83%9f%e3%82%a2%e3%83%a0%e4%bb%98%e5%95%86%e5%93%81%e5%88%b8%e3%80%80%ef%bd%9e%e6%ba%96%e5%82%99%e3%82%92%e9%80%b2%e3%82%81%e3%81%a6%e3%81%84%e3%81%be%e3%81%99%ef%bd%9e/',
                'content_id' => 3542,
                'featured_end_at' => NULL,
                'id' => 901,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-30 19:08:15',
                'publish_div' => 1,
                'title' => 'プレミアム付商品券　～準備を進めています～2019年5月29日 1時28分',
            ),
            26 => 
            array (
                'body' => '開発ツール / 言語 / プログラミング',
                'content_id' => 3543,
                'featured_end_at' => NULL,
                'id' => 902,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 11:45:07',
                'publish_div' => 1,
                'title' => 'eqweq',
            ),
            27 => 
            array (
                'body' => 'RDB / NoSQL / ミドルウェア
[@content]',
                'content_id' => 3544,
                'featured_end_at' => NULL,
                'id' => 903,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:00:07',
                'publish_div' => 1,
                'title' => '「Cloudflare Workers KV」正式版がリリース。約180個所のグローバルなCDNエッジで提供される大規模分散キーバリューストア2019年5月29日 15時11分',
            ),
            28 => 
            array (
                'body' => 'Web技術 / JavaScript',
                'content_id' => 3545,
                'featured_end_at' => NULL,
                'id' => 904,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:31:52',
                'publish_div' => 1,
                'title' => 'Fastly CTOに聞く、同社がWebAssembly実行環境の「Lucet」をエッジコンピューティング環境として開発している理由とは？2019年5月13日 15時47分',
            ),
            29 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3546,
                'featured_end_at' => NULL,
                'id' => 905,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:32:13',
                'publish_div' => 1,
                'title' => '［速報］Google、本日から大阪GCPリージョン正式運用開始を発表。東京に続いて国内2カ所目。日本語による24時間365日のサポートも開始2019年5月14日 1時45分',
            ),
            30 => 
            array (
                'body' => 'Docker / コンテナ / 仮想化',
                'content_id' => 3547,
                'featured_end_at' => NULL,
                'id' => 906,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:32:33',
                'publish_div' => 1,
                'title' => '自由に再配布可能なRed Hat Enterprise Linux 8ベースのコンテナ用OSイメージ「Red Hat Universal Base Image」が公開2019年5月14日 15時17分',
            ),
            31 => 
            array (
                'body' => '開発ツール / 言語 / プログラミング',
                'content_id' => 3548,
                'featured_end_at' => NULL,
                'id' => 907,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:32:51',
                'publish_div' => 1,
                'title' => 'GraalVM、ついに本番利用可能なバージョン「GraalVM 19.0」登場、JavaやJavaScriptなど多言語対応ランタイム。商用版のGraalVM Enterprise Editionもリリース2019年5月15日 16時07分',
            ),
            32 => 
            array (
                'body' => 'Docker / コンテナ / 仮想化',
                'content_id' => 3549,
                'featured_end_at' => NULL,
                'id' => 908,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:33:13',
                'publish_div' => 1,
                'title' => 'Kubernetesに特化した軽量なLinux「k3OS」。Kubernetesが自動起動、Kubernetesクラスタ構成も自動で。Rancher Labsが公開2019年5月19日 15時46分',
            ),
            33 => 
            array (
                'body' => '編集後記 / おもしろ',
                'content_id' => 3550,
                'featured_end_at' => NULL,
                'id' => 909,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:33:32',
                'publish_div' => 1,
                'title' => 'PublickeyのWebページをレスポンシブ対応にしました2019年5月20日 6時19分',
            ),
            34 => 
            array (
                'body' => 'Web技術 / JavaScript',
                'content_id' => 3551,
                'featured_end_at' => NULL,
                'id' => 910,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:33:52',
                'publish_div' => 1,
                'title' => 'JavaScriptエンジンのV8、WebAssemblyのコンパイル済みモジュールをキャッシュすることで2度目の訪問からは即実行可能に。V8 r7.5で2019年5月20日 16時24分',
            ),
            35 => 
            array (
                'body' => 'Docker / コンテナ / 仮想化',
                'content_id' => 3552,
                'featured_end_at' => NULL,
                'id' => 911,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:34:12',
                'publish_div' => 1,
                'title' => 'マイクロソフトやHashiCorpらが「Service Mesh Interface」（SMI）を発表。Kubernetes上のサービスメッシュAPIが標準化へ2019年5月21日 16時46分',
            ),
            36 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3553,
                'featured_end_at' => NULL,
                'id' => 912,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:34:33',
                'publish_div' => 1,
                'title' => 'Google Kubernetes EngineとAzure Kubernetes Engineが相次いでWindows Serverコンテナのサポートを開始2019年5月22日 15時55分',
            ),
            37 => 
            array (
                'body' => 'サーバ  / ストレージ / ネットワーク',
                'content_id' => 3554,
                'featured_end_at' => NULL,
                'id' => 913,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:34:53',
                'publish_div' => 1,
                'title' => '昨年破綻したティントリが復活後、国内初の発表会。「人を雇いすぎていたのが間違いの1つだった」2019年5月23日 19時36分',
            ),
            38 => 
            array (
                'body' => 'RDB / NoSQL / ミドルウェア',
                'content_id' => 3555,
                'featured_end_at' => NULL,
                'id' => 914,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:35:12',
                'publish_div' => 1,
                'title' => 'DataStaxが新サービス「Constellation」を発表。「Cassandra-as-a-Service」としてNoSQLのCassandraをクラウドサービスで提供2019年5月26日 16時37分',
            ),
            39 => 
            array (
                'body' => 'RDB / NoSQL / ミドルウェア',
                'content_id' => 3556,
                'featured_end_at' => NULL,
                'id' => 915,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:35:30',
                'publish_div' => 1,
                'title' => 'PostgreSQL 12β1が公開。Bツリーインデックス周りの性能向上や、インデックスの並列処理による再構成が可能に2019年5月27日 14時48分',
            ),
            40 => 
            array (
                'body' => 'Web技術 / JavaScript',
                'content_id' => 3557,
                'featured_end_at' => NULL,
                'id' => 916,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:35:50',
                'publish_div' => 1,
                'title' => 'HTML標準仕様の策定についてW3CとWHATWGが合意発表。今後はWHATWGのリビングスタンダードが唯一のHTML標準仕様に2019年5月28日 16時33分',
            ),
            41 => 
            array (
                'body' => 'RDB / NoSQL / ミドルウェア',
                'content_id' => 3558,
                'featured_end_at' => NULL,
                'id' => 917,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:36:08',
                'publish_div' => 1,
                'title' => '「Cloudflare Workers KV」正式版がリリース。約180個所のグローバルなCDNエッジで提供される大規模分散キーバリューストア2019年5月29日 15時11分',
            ),
            42 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3559,
                'featured_end_at' => NULL,
                'id' => 918,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:36:27',
                'publish_div' => 1,
                'title' => '「Azure NetApp Files」が正式版に。Azure上でNetAppを用いたスケーラブルなNFS/SMBストレージが利用可能2019年5月30日 16時12分',
            ),
            43 => 
            array (
                'body' => 'クラウド
[@content]',
                'content_id' => 3560,
                'featured_end_at' => NULL,
                'id' => 919,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:41:00',
                'publish_div' => 1,
                'title' => '「Azure NetApp Files」が正式版に。Azure上でNetAppを用いたスケーラブルなNFS/SMBストレージが利用可能2019年5月30日 16時12分',
            ),
            44 => 
            array (
                'body' => 'RDB / NoSQL / ミドルウェア
[@content]',
                'content_id' => 3561,
                'featured_end_at' => NULL,
                'id' => 920,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 12:45:00',
                'publish_div' => 1,
                'title' => '「Cloudflare Workers KV」正式版がリリース。約180個所のグローバルなCDNエッジで提供される大規模分散キーバリューストア2019年5月29日 15時11分',
            ),
            45 => 
            array (
                'body' => 'ggggggggg',
                'content_id' => 3563,
                'featured_end_at' => NULL,
                'id' => 921,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 18:59:00',
                'publish_div' => 1,
                'title' => 'g',
            ),
            46 => 
            array (
                'body' => 'hhh',
                'content_id' => 3564,
                'featured_end_at' => NULL,
                'id' => 922,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 18:59:00',
                'publish_div' => 1,
                'title' => 'hhhhhhhhh',
            ),
            47 => 
            array (
                'body' => 'ưewqeqweqw',
                'content_id' => 3565,
                'featured_end_at' => NULL,
                'id' => 923,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 19:08:00',
                'publish_div' => 1,
                'title' => 'eqwewqe',
            ),
            48 => 
            array (
                'body' => 'ewqeqweqe',
                'content_id' => 3566,
                'featured_end_at' => NULL,
                'id' => 924,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 19:08:00',
                'publish_div' => 1,
                'title' => 'eqwewqe',
            ),
            49 => 
            array (
            'body' => '<img width="1024" height="749" src="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024" class="attachment-large size-large wp-post-image" alt="" srcset="https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=1024 1024w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=2048 2048w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=150 150w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=300 300w, https://techcrunchjp.files.wordpress.com/2019/05/aikasa-ueno_main.jpg?w=768 768w" sizes="(max-width: 1024px) 100vw, 1024px" /> ',
                'content_id' => 3567,
                'featured_end_at' => NULL,
                'id' => 925,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-05-31 19:09:00',
                'publish_div' => 1,
                'title' => 'eqeqwewewq',
            ),
            50 => 
            array (
                'body' => '開発ツール / 言語 / プログラミング',
                'content_id' => 3570,
                'featured_end_at' => NULL,
                'id' => 927,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-03 10:25:10',
                'publish_div' => 1,
                'title' => 'Pivotal、OpenJDKディストリビューションやSpring Frameworkの商用サポートを含む「Pivotal Spring Runtime」リリース2019年6月2日 15時42分',
            ),
            51 => 
            array (
                'body' => '開発ツール / 言語 / プログラミング',
                'content_id' => 3571,
                'featured_end_at' => NULL,
                'id' => 928,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-03 10:25:32',
                'publish_div' => 1,
                'title' => 'Angular 8正式版リリース。高速レンダリングエンジン「Ivy」、モダンブラウザ用と非モダンブラウザ用のJSコードを動的に使い分ける「Differential Loading」など2019年6月2日 15時48分',
            ),
            52 => 
            array (
                'body' => '業界動向 / IoT /  その他',
                'content_id' => 3573,
                'featured_end_at' => NULL,
                'id' => 929,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-03 12:05:09',
                'publish_div' => 1,
                'title' => 'VRやチャットボット、ITヘルスケアベンチャーで福祉にイノベーションを。福祉×IT「福祉Tech」― AIIT起業塾 #12 ―［PR］2019年6月3日 3時00分',
            ),
            53 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3580,
                'featured_end_at' => NULL,
                'id' => 930,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-04 00:05:09',
                'publish_div' => 1,
                'title' => '「日本で100のマルチテナントSaaS構築を」、AWSやCircleCIらが認証や決済、DevOps基盤などを提供するSaaS構築支援策を発表2019年6月3日 15時59分',
            ),
            54 => 
            array (
                'body' => '編集後記 / おもしろ',
                'content_id' => 3584,
                'featured_end_at' => NULL,
                'id' => 931,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-04 12:55:10',
                'publish_div' => 1,
                'title' => 'マイクロソフト、「Windows Terminal」発表／Windows上でフル互換のLinuxシステムコールを実現する「WSL 2」／Webブラウザで動作する「Visual Studio Online」発表ほか、2019年5月の人気記事2019年6月4日 3時49分',
            ),
            55 => 
            array (
                'body' => '開発ツール / 言語 / プログラミング',
                'content_id' => 3587,
                'featured_end_at' => NULL,
                'id' => 932,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-04 14:10:07',
                'publish_div' => 1,
                'title' => 'Apple、新フレームワーク「Swift UI」発表。簡潔なコードとドラッグ＆ドロップでUIを構築、デバイスでの即時プレビュー。WWDC192019年6月4日 4時58分',
            ),
            56 => 
            array (
                'body' => '機械学習 / AI / ビッグデータ',
                'content_id' => 3590,
                'featured_end_at' => NULL,
                'id' => 933,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-05 16:45:07',
                'publish_div' => 1,
                'title' => 'MapRが大規模レイオフの理由を説明。間接販売に切り替えたため営業関連を整理2019年6月4日 16時36分',
            ),
            57 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3591,
                'featured_end_at' => NULL,
                'id' => 934,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-05 16:45:10',
                'publish_div' => 1,
                'title' => '国内エンタープライズITの市場規模は10兆円を突破、クラウド関連の割合は現在の2割から5年後に5割を超える。IDC Japan2019年6月5日 3時46分',
            ),
            58 => 
            array (
                'body' => '運用ツール / システム運用',
                'content_id' => 3592,
                'featured_end_at' => NULL,
                'id' => 935,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-05 16:45:12',
                'publish_div' => 1,
                'title' => 'NTPサーバと同期する「NTPクロック」に無線LAN＆電池駆動の新モデルが登場。配線不要で普通の掛け時計のように設置可能2019年6月5日 6時18分',
            ),
            59 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3599,
                'featured_end_at' => NULL,
                'id' => 936,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-06 00:25:07',
                'publish_div' => 1,
                'title' => 'Google CloudやYouTubeの障害は「数台のサーバへの設定変更のつもりが、誤って複数リージョンの多数のサーバに適用されてしまった」。Googleが説明2019年6月5日 15時20分',
            ),
            60 => 
            array (
                'body' => 'クラウド',
                'content_id' => 3600,
                'featured_end_at' => NULL,
                'id' => 937,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-06 02:45:08',
                'publish_div' => 1,
                'title' => '［速報］マイクロソフトとオラクル、クラウドの相互接続で合意。クロスクラウドのシングルサインオン、AzureからOracle Cloud Databaseへの接続などが可能に2019年6月5日 17時24分',
            ),
            61 => 
            array (
                'body' => 'サーバ  / ストレージ / ネットワーク',
                'content_id' => 3610,
                'featured_end_at' => NULL,
                'id' => 938,
                'is_featured' => 0,
                'is_speech_generated' => 1,
                'lang' => 'ja',
                'publish_at' => '2019-06-07 00:40:08',
                'publish_div' => 1,
                'title' => 'オープンなプロセッサやハードウェアの開発を促進する「OpenHW」グループ発足。RISC-VベースのSoC対応「CORE-Vファミリー」発表2019年6月6日 15時37分',
            ),
        ));
        
        
    }
}