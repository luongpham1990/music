<?php

use Illuminate\Database\Seeder;

class TutorialsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('tutorials')->delete();
        
        \DB::table('tutorials')->insert(array (
            0 => 
            array (
                'client_id' => 1,
                'id' => 2,
                'position' => 2,
                'slide_image_id' => 567,
            ),
            1 => 
            array (
                'client_id' => 1,
                'id' => 3,
                'position' => 3,
                'slide_image_id' => 568,
            ),
            2 => 
            array (
                'client_id' => 1,
                'id' => 4,
                'position' => 4,
                'slide_image_id' => 569,
            ),
            3 => 
            array (
                'client_id' => 1,
                'id' => 5,
                'position' => 5,
                'slide_image_id' => 573,
            ),
            4 => 
            array (
                'client_id' => 1,
                'id' => 6,
                'position' => 1,
                'slide_image_id' => 572,
            ),
            5 => 
            array (
                'client_id' => 72,
                'id' => 7,
                'position' => 1,
                'slide_image_id' => 769,
            ),
            6 => 
            array (
                'client_id' => 72,
                'id' => 8,
                'position' => 2,
                'slide_image_id' => 770,
            ),
            7 => 
            array (
                'client_id' => 72,
                'id' => 9,
                'position' => 3,
                'slide_image_id' => 771,
            ),
            8 => 
            array (
                'client_id' => 72,
                'id' => 10,
                'position' => 4,
                'slide_image_id' => 772,
            ),
            9 => 
            array (
                'client_id' => 72,
                'id' => 11,
                'position' => 5,
                'slide_image_id' => 773,
            ),
            10 => 
            array (
                'client_id' => 73,
                'id' => 12,
                'position' => 1,
                'slide_image_id' => 1001,
            ),
            11 => 
            array (
                'client_id' => 182,
                'id' => 13,
                'position' => 1,
                'slide_image_id' => 1003,
            ),
            12 => 
            array (
                'client_id' => 183,
                'id' => 14,
                'position' => 1,
                'slide_image_id' => 1005,
            ),
            13 => 
            array (
                'client_id' => 73,
                'id' => 15,
                'position' => 2,
                'slide_image_id' => 1006,
            ),
            14 => 
            array (
                'client_id' => 73,
                'id' => 16,
                'position' => 3,
                'slide_image_id' => 1007,
            ),
            15 => 
            array (
                'client_id' => 73,
                'id' => 17,
                'position' => 4,
                'slide_image_id' => 1008,
            ),
            16 => 
            array (
                'client_id' => 73,
                'id' => 18,
                'position' => 5,
                'slide_image_id' => 1009,
            ),
            17 => 
            array (
                'client_id' => 183,
                'id' => 19,
                'position' => 2,
                'slide_image_id' => 1010,
            ),
            18 => 
            array (
                'client_id' => 183,
                'id' => 20,
                'position' => 3,
                'slide_image_id' => 1011,
            ),
            19 => 
            array (
                'client_id' => 183,
                'id' => 21,
                'position' => 4,
                'slide_image_id' => 1012,
            ),
            20 => 
            array (
                'client_id' => 184,
                'id' => 22,
                'position' => 1,
                'slide_image_id' => 1014,
            ),
            21 => 
            array (
                'client_id' => 184,
                'id' => 23,
                'position' => 2,
                'slide_image_id' => 1015,
            ),
            22 => 
            array (
                'client_id' => 184,
                'id' => 24,
                'position' => 3,
                'slide_image_id' => 1016,
            ),
            23 => 
            array (
                'client_id' => 184,
                'id' => 25,
                'position' => 4,
                'slide_image_id' => 1017,
            ),
            24 => 
            array (
                'client_id' => 184,
                'id' => 26,
                'position' => 5,
                'slide_image_id' => 1018,
            ),
            25 => 
            array (
                'client_id' => 185,
                'id' => 27,
                'position' => 1,
                'slide_image_id' => 1020,
            ),
            26 => 
            array (
                'client_id' => 185,
                'id' => 28,
                'position' => 2,
                'slide_image_id' => 1021,
            ),
            27 => 
            array (
                'client_id' => 185,
                'id' => 30,
                'position' => 4,
                'slide_image_id' => 1023,
            ),
            28 => 
            array (
                'client_id' => 187,
                'id' => 32,
                'position' => 1,
                'slide_image_id' => 1034,
            ),
            29 => 
            array (
                'client_id' => 187,
                'id' => 33,
                'position' => 2,
                'slide_image_id' => 1035,
            ),
            30 => 
            array (
                'client_id' => 187,
                'id' => 34,
                'position' => 3,
                'slide_image_id' => 1036,
            ),
            31 => 
            array (
                'client_id' => 189,
                'id' => 35,
                'position' => 1,
                'slide_image_id' => 1040,
            ),
            32 => 
            array (
                'client_id' => 189,
                'id' => 36,
                'position' => 2,
                'slide_image_id' => 1041,
            ),
            33 => 
            array (
                'client_id' => 189,
                'id' => 37,
                'position' => 3,
                'slide_image_id' => 1042,
            ),
            34 => 
            array (
                'client_id' => 190,
                'id' => 38,
                'position' => 1,
                'slide_image_id' => 1050,
            ),
            35 => 
            array (
                'client_id' => 190,
                'id' => 39,
                'position' => 2,
                'slide_image_id' => 1051,
            ),
            36 => 
            array (
                'client_id' => 199,
                'id' => 40,
                'position' => 1,
                'slide_image_id' => 1316,
            ),
            37 => 
            array (
                'client_id' => 199,
                'id' => 41,
                'position' => 2,
                'slide_image_id' => 1317,
            ),
            38 => 
            array (
                'client_id' => 199,
                'id' => 42,
                'position' => 3,
                'slide_image_id' => 1318,
            ),
            39 => 
            array (
                'client_id' => 199,
                'id' => 43,
                'position' => 4,
                'slide_image_id' => 1319,
            ),
            40 => 
            array (
                'client_id' => 199,
                'id' => 44,
                'position' => 5,
                'slide_image_id' => 1320,
            ),
            41 => 
            array (
                'client_id' => 198,
                'id' => 45,
                'position' => 1,
                'slide_image_id' => 1358,
            ),
            42 => 
            array (
                'client_id' => 198,
                'id' => 46,
                'position' => 2,
                'slide_image_id' => 1359,
            ),
            43 => 
            array (
                'client_id' => 197,
                'id' => 47,
                'position' => 1,
                'slide_image_id' => 1473,
            ),
            44 => 
            array (
                'client_id' => 197,
                'id' => 48,
                'position' => 2,
                'slide_image_id' => 1474,
            ),
            45 => 
            array (
                'client_id' => 196,
                'id' => 49,
                'position' => 1,
                'slide_image_id' => 1480,
            ),
            46 => 
            array (
                'client_id' => 211,
                'id' => 57,
                'position' => 1,
                'slide_image_id' => 3103,
            ),
            47 => 
            array (
                'client_id' => 211,
                'id' => 58,
                'position' => 2,
                'slide_image_id' => 3104,
            ),
            48 => 
            array (
                'client_id' => 211,
                'id' => 59,
                'position' => 3,
                'slide_image_id' => 3105,
            ),
            49 => 
            array (
                'client_id' => 210,
                'id' => 60,
                'position' => 1,
                'slide_image_id' => 3107,
            ),
        ));
        
        
    }
}