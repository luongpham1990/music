<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientLanguagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('client_languages', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->string('lang', 10); // ja：日本語, en：英語, ko：韓国語, zh：中国語（簡体字), pt：ポルトガル語, es：スペイン語, tl：タガログ語, ja-easy：やさしい日本語
            $table->unsignedInteger('position');
            $table->unique(['client_id', 'lang'], 'client_languages_client_id_lang');
            $table->unique(['client_id', 'position'], 'client_languages_client_id_position');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('client_languages');
    }
}
