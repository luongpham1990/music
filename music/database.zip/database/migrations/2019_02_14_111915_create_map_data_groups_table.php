<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMapDataGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('map_data_groups', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->unsignedInteger('position')->default(0);
            $table->string('name', 255);
            $table->unsignedInteger('map_data_div'); // 1: 点, 2: 線, 3: 図形
            $table->unsignedInteger('icon_id');
            $table->string('color_code', 7);
            $table->string('stroke_color_code', 7)->nullable();
            $table->unsignedInteger('stroke_width_px')->nullable();
            $table->float('stroke_transparency_ratio')->unsigned()->nullable();
            $table->string('fill_color_code', 7)->nullable();
            $table->float('fill_transparency_ratio')->unsigned()->nullable();
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('map_data_groups');
    }
}
