<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStorageFilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('storage_files', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->unsignedInteger('storage_div')->default(1); // 1:S3
            $table->unsignedInteger('file_div')->default(1); // 1:スプラッシュ画像, 2:ヘッダ画像, 3:チュートリアル画像, 4:アイコン画像, 5:コンテンツ添付ファイル
            $table->string('file_path'); // S3のパス。AWS-SDKなどで使用することを想定。非公開ファイルなども扱うため公開URLは格納しない。
            $table->string('file_type', 100); // image/jpeg, application/xml, application/json
            $table->unsignedInteger('file_size')->default(0);
            $table->string('file_url', 1017)->nullable(); // 公開用のURL。エンドユーザなどにそのまま渡すことが可能。非公開ファイルの場合はNULL。
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
            $table->index(['client_id'], 'storage_files_client_id_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('storage_files');
    }
}
