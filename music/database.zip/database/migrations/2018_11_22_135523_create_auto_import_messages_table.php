<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAutoImportMessagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('auto_import_messages', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('auto_import_id');
            $table->string('lang', 10);
            $table->string('title')->nullable();
            $table->text('body')->nullable();
            $table->unique(['auto_import_id', 'lang'], 'auto_import_messages_export_id_lang');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('auto_import_messages');
    }
}
