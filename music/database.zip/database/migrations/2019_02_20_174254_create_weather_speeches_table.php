<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWeatherSpeechesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('weather_speeches', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('weather_id');
            $table->string('lang', 10)->charset('ascii')->collation('ascii_general_ci')->default('ja');
            $table->unsignedInteger('storage_file_id');
            $table->dateTime('weather_updated_at');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('weather_speeches');
    }
}
