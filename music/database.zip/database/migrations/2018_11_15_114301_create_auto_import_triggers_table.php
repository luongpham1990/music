<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAutoImportTriggersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('auto_import_triggers', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('auto_import_id');
            $table->unsignedInteger('match_div'); // 0:前方一致, 1:後方一致, 2:完全一致
            $table->text('trigger_str');
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('auto_import_triggers');
    }
}
