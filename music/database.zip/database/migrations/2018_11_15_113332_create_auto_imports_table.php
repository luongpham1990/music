<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAutoImportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('auto_imports', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->unsignedInteger('status')->default(0); // 0:無効, 1:有効
            $table->string('name');
            $table->unsignedInteger('import_div'); // 0: rss/atom, 1: api, 2: ical
            $table->text('note')->nullable();
            $table->string('setting_value', 2000); // import_divによって取り込み元URLやAPIキーが入る
            $table->unsignedInteger('content_group_id');
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('auto_imports');
    }
}
