<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->increments('id');
            $table->string('username', 80)->charset('ascii')->collation('ascii_bin');
            $table->string('password', 160)->charset('ascii')->collation('ascii_bin');
            $table->integer('role_div')->unsigned()->default(1); // 1:管理者, 2:承認者, 3:配信者, 4:作成者, 101:特権, 102:サポーター
            $table->string('name', 30);
            $table->string('email', 255)->charset('ascii')->collation('ascii_general_ci');
            $table->rememberToken()->charset('ascii')->collation('ascii_bin');
            $table->integer('usage_status')->unsigned()->default(1);
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
            $table->unique(['username'], 'accounts_username_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accounts');
    }
}
