<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DropIsDropLatest extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('auto_imports', function (Blueprint $table) {
            $table->dropColumn('is_drop_latest');
        });
        Schema::table('weathers', function (Blueprint $table) {
            $table->dropColumn('is_latest');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('auto_imports', function (Blueprint $table) {
            $table->boolean('is_drop_latest')->default(false)->after('content_group_id');
        });
        Schema::table('weathers', function (Blueprint $table) {
            $table->boolean('is_latest')->default(false);
        });
    }
}
