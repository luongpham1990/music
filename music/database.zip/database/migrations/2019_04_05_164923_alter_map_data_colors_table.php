<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterMapDataColorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('map_data_colors', function (Blueprint $table) {
            $table->dropColumn('base_color_code');
            $table->unsignedInteger('position')->after('client_id')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('map_data_colors', function (Blueprint $table) {
            $table->string('base_color_code', 7);
            $table->dropColumn('position');
        });
    }
}
