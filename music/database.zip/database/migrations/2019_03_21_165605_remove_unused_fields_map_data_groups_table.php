<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveUnusedFieldsMapDataGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('map_data_groups', function (Blueprint $table) {
            $table->dropColumn('color_code');
            $table->dropColumn('stroke_color_code');
            $table->dropColumn('stroke_width_px');
            $table->dropColumn('stroke_transparency_ratio');
            $table->dropColumn('fill_color_code');
            $table->dropColumn('fill_transparency_ratio');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('map_data_groups', function (Blueprint $table) {
            $table->string('color_code', 7);
            $table->string('stroke_color_code', 7)->nullable();
            $table->unsignedInteger('stroke_width_px')->nullable();
            $table->float('stroke_transparency_ratio')->unsigned()->nullable();
            $table->string('fill_color_code', 7)->nullable();
            $table->float('fill_transparency_ratio')->unsigned()->nullable();
        });
    }
}
