<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMapDatasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('map_datas', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('content_id');
            $table->unsignedInteger('map_data_group_id');
            $table->geometry('location');
            $table->float('elevation')->nullable();
            $table->string('lang', 10);
            $table->string('title', 255);
            $table->text('body')->nullable();
            $table->string('address', 255)->nullable();
            $table->string('tel', 255)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('map_datas');
    }
}
