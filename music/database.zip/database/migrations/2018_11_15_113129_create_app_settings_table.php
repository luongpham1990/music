<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_settings', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->boolean('is_disaster_mode')->default(false);
            $table->unsignedInteger('splash_id')->nullable();
            $table->text('policy_body')->nullable();
            $table->unsignedInteger('theme_div')->default(0);
            $table->unsignedInteger('header_image_id')->nullable();
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
            $table->unique(['client_id'], 'app_settings_client_id');
            $table->unique(['splash_id'], 'app_settings_normal_splash_id');
            $table->unique(['header_image_id'], 'app_settings_header_image_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_settings');
    }
}
