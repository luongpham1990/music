<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterTemplateSubTitleOnTemplates extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('translation_replacement_templates', function (Blueprint $table) {
            $table->string('template_sub_title')->after('template_title');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('translation_replacement_templates', function (Blueprint $table) {
            $table->dropColumn('template_sub_title');
        });
    }
}
