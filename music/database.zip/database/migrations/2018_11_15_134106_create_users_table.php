<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->unsignedInteger('mobile_platform')->default(0);
            $table->unsignedInteger('member_no'); // 表示は、0埋めの7桁で行う。最大値は、9999999
            $table->string('device_token');
            $table->string('endpoint_arn');
            $table->dateTime('registered_at');
            $table->string('lang', 10)->charset('ascii')->collation('ascii_general_ci')->default('ja');
            $table->unsignedInteger('user_status')->default(1); // 1:運用中, 2:本人による解約済み, 3:管理者による解約済み, 4:自動解約済み
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
            $table->index(['client_id'], 'client_user_uniq');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
