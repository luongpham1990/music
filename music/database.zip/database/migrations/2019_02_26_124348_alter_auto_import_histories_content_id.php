<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterAutoImportHistoriesContentId extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('auto_import_histories', function (Blueprint $table) {
            $table->renameColumn('content_id', 'content_group_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('auto_import_histories', function (Blueprint $table) {
            $table->renameColumn('content_group_id', 'content_id');
        });
    }
}
