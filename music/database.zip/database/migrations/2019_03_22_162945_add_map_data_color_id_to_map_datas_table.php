<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddMapDataColorIdToMapDatasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('map_datas', function (Blueprint $table) {
            $table->unsignedInteger('map_data_color_id')->after('map_data_group_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('map_datas', function (Blueprint $table) {
            $table->dropColumn('map_data_color_id');
        });
    }
}
