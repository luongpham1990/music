<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMapBodyStorageFilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('map_body_storage_files', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('map_data_id');
            $table->string('lang', 10)->nullable();
            $table->unsignedInteger('storage_file_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('map_body_storage_files');
    }
}
