<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterMapDataGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('map_data_groups', function (Blueprint $table) {
            $table->boolean('init_display')->after('name')->default(false);
            $table->string('base_color_code', 7)->after('icon_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('map_data_groups', function (Blueprint $table) {
            $table->dropColumn('base_color_code');
            $table->dropColumn('init_display');
        });
    }
}
