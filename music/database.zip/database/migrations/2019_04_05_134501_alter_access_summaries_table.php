<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterAccessSummariesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('access_summaries', function (Blueprint $table) {
            $table->integer('access_count')->default(1)->change();
            $table->unique(['client_id', 'menu_id', 'content_group_id', 'content_id', 'access_date', 'access_hour'], 'access_summaries_uniq');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('access_summaries', function (Blueprint $table) {
            $table->integer('access_count');
        });
    }
}
