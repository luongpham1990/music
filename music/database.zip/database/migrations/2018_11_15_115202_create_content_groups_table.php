<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateContentGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('content_groups', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('client_id');
            $table->unsignedInteger('status')->default(0); // 0: 非表示, 1: 表示
            $table->unsignedInteger('menu_id');
            $table->unsignedInteger('position')->default(0);
            $table->string('name', 30);
            $table->unsignedInteger('group_div'); // 1:お知らせ, 2:地図, 3:カレンダー, 4:Webページ, 5:リンク, 6:時系列データ, 7:ユーザー投稿, 8:ファイル
            $table->unsignedInteger('tag_group_id')->nullable();
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();
            $table->unique(['menu_id', 'position'], 'content_collection_menu_id_position');
            $table->unique(['tag_group_id'], 'content_groups_tag_group_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('content_groups');
    }
}
