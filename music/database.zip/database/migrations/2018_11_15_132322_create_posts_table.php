<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('content_id');
            $table->boolean('is_featured')->default(false);
            $table->dateTime('featured_end_at')->nullable();
            $table->string('lang', 10);
            $table->string('title');
            $table->text('body');
            $table->unsignedInteger('publish_div')->default(0); // 0: 即時公開, 1: 公開日指定
            $table->dateTime('publish_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
