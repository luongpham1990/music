<?php

use Illuminate\Database\Seeder;

class AutoImportTriggersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_triggers')->delete();
        
        \DB::table('auto_import_triggers')->insert(array (
            0 => 
            array (
                'id' => 82,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'dendi',
                'created_at' => '2019-01-05 19:50:30',
                'updated_at' => '2019-01-05 19:50:30',
            ),
            1 => 
            array (
                'id' => 83,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'iceiceice',
                'created_at' => '2019-01-05 19:50:35',
                'updated_at' => '2019-01-05 19:50:35',
            ),
            2 => 
            array (
                'id' => 84,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'icice',
                'created_at' => '2019-01-05 19:50:39',
                'updated_at' => '2019-01-05 19:50:39',
            ),
            3 => 
            array (
                'id' => 87,
                'auto_import_id' => 39,
                'match_div' => 0,
                'trigger_str' => 'sdsd',
                'created_at' => '2019-01-14 18:59:56',
                'updated_at' => '2019-01-14 18:59:56',
            ),
            4 => 
            array (
                'id' => 88,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'dfdfd',
                'created_at' => '2019-01-14 19:02:18',
                'updated_at' => '2019-01-14 19:02:18',
            ),
            5 => 
            array (
                'id' => 89,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'hahahaha',
                'created_at' => '2019-01-14 19:14:16',
                'updated_at' => '2019-01-14 19:14:16',
            ),
            6 => 
            array (
                'id' => 90,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'hahahaha',
                'created_at' => '2019-01-14 19:14:45',
                'updated_at' => '2019-01-14 19:14:45',
            ),
            7 => 
            array (
                'id' => 91,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'hahahaha',
                'created_at' => '2019-01-14 19:15:04',
                'updated_at' => '2019-01-14 19:15:04',
            ),
            8 => 
            array (
                'id' => 92,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'rgrgf',
                'created_at' => '2019-01-14 21:38:40',
                'updated_at' => '2019-01-14 21:38:40',
            ),
            9 => 
            array (
                'id' => 93,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'fdfdfdfdf',
                'created_at' => '2019-01-15 10:47:52',
                'updated_at' => '2019-01-15 10:47:52',
            ),
            10 => 
            array (
                'id' => 95,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'hahahahaaaaaaaaa',
                'created_at' => '2019-01-15 12:02:50',
                'updated_at' => '2019-01-15 12:02:50',
            ),
            11 => 
            array (
                'id' => 99,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'fsfsfs',
                'created_at' => '2019-01-15 13:56:47',
                'updated_at' => '2019-01-15 13:56:47',
            ),
            12 => 
            array (
                'id' => 100,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'fdsfdf',
                'created_at' => '2019-01-15 13:57:19',
                'updated_at' => '2019-01-15 13:57:19',
            ),
            13 => 
            array (
                'id' => 101,
                'auto_import_id' => 1,
                'match_div' => 1,
                'trigger_str' => 'dsfsff',
                'created_at' => '2019-01-15 13:58:24',
                'updated_at' => '2019-01-15 13:58:24',
            ),
            14 => 
            array (
                'id' => 102,
                'auto_import_id' => 1,
                'match_div' => 1,
                'trigger_str' => 'hahahahhdhah  kakdkad',
                'created_at' => '2019-01-15 13:59:38',
                'updated_at' => '2019-01-15 13:59:38',
            ),
            15 => 
            array (
                'id' => 104,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'ff

fff

ff',
                'created_at' => '2019-01-17 13:15:45',
                'updated_at' => '2019-01-17 13:15:45',
            ),
            16 => 
            array (
                'id' => 105,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'dffdff',
                'created_at' => '2019-01-21 16:05:25',
                'updated_at' => '2019-01-21 16:05:25',
            ),
            17 => 
            array (
                'id' => 106,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'ghghghghhhhh',
                'created_at' => '2019-01-21 16:07:10',
                'updated_at' => '2019-01-21 16:07:10',
            ),
            18 => 
            array (
                'id' => 107,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'dscđdd',
                'created_at' => '2019-01-21 16:41:13',
                'updated_at' => '2019-01-21 16:41:13',
            ),
            19 => 
            array (
                'id' => 108,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'dscđdd',
                'created_at' => '2019-01-21 16:41:56',
                'updated_at' => '2019-01-21 16:41:56',
            ),
            20 => 
            array (
                'id' => 109,
                'auto_import_id' => 39,
                'match_div' => 1,
                'trigger_str' => 'dscđdd',
                'created_at' => '2019-01-21 16:42:08',
                'updated_at' => '2019-01-21 16:42:08',
            ),
            21 => 
            array (
                'id' => 110,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'fgfhfhf',
                'created_at' => '2019-01-21 16:44:50',
                'updated_at' => '2019-01-21 16:44:50',
            ),
            22 => 
            array (
                'id' => 111,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'dfgdgrfgrfgr',
                'created_at' => '2019-01-24 13:15:45',
                'updated_at' => '2019-01-24 13:15:45',
            ),
            23 => 
            array (
                'id' => 113,
                'auto_import_id' => 39,
                'match_div' => 2,
                'trigger_str' => 'fggfdfgdfg',
                'created_at' => '2019-01-24 13:20:23',
                'updated_at' => '2019-01-24 13:20:23',
            ),
            24 => 
            array (
                'id' => 114,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'dfdfdfdfdf',
                'created_at' => '2019-01-24 13:26:09',
                'updated_at' => '2019-01-24 13:26:09',
            ),
            25 => 
            array (
                'id' => 116,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'hhahahd

dsds

xdsds',
                'created_at' => '2019-01-25 12:46:34',
                'updated_at' => '2019-01-25 12:46:34',
            ),
            26 => 
            array (
                'id' => 117,
                'auto_import_id' => 1,
                'match_div' => 1,
                'trigger_str' => 'tesst datat

登録しました。
登録しました。',
                'created_at' => '2019-01-25 12:46:55',
                'updated_at' => '2019-01-25 12:46:55',
            ),
            27 => 
            array (
                'id' => 121,
                'auto_import_id' => 3,
                'match_div' => 2,
                'trigger_str' => 'testt datta servee',
                'created_at' => '2019-01-25 12:48:28',
                'updated_at' => '2019-01-25 12:48:28',
            ),
            28 => 
            array (
                'id' => 122,
                'auto_import_id' => 3,
                'match_div' => 0,
                'trigger_str' => 'testlddddddddddddddddddd',
                'created_at' => '2019-01-25 12:48:35',
                'updated_at' => '2019-01-25 12:48:35',
            ),
            29 => 
            array (
                'id' => 123,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'grgr',
                'created_at' => '2019-01-29 19:45:12',
                'updated_at' => '2019-01-29 19:45:12',
            ),
            30 => 
            array (
                'id' => 124,
                'auto_import_id' => 1,
                'match_div' => 0,
                'trigger_str' => 'thutesst',
                'created_at' => '2019-02-01 17:30:49',
                'updated_at' => '2019-02-01 17:30:49',
            ),
            31 => 
            array (
                'id' => 125,
                'auto_import_id' => 1,
                'match_div' => 2,
                'trigger_str' => 'test on serve
test on serve

test on serve',
                'created_at' => '2019-02-01 17:32:37',
                'updated_at' => '2019-02-01 17:32:37',
            ),
            32 => 
            array (
                'id' => 126,
                'auto_import_id' => 10,
                'match_div' => 1,
                'trigger_str' => 'test abc',
                'created_at' => '2019-02-14 11:57:25',
                'updated_at' => '2019-02-14 11:57:25',
            ),
            33 => 
            array (
                'id' => 127,
                'auto_import_id' => 24,
                'match_div' => 2,
                'trigger_str' => 'năm mới',
                'created_at' => '2019-02-14 12:44:34',
                'updated_at' => '2019-02-14 12:44:34',
            ),
            34 => 
            array (
                'id' => 128,
                'auto_import_id' => 24,
                'match_div' => 1,
                'trigger_str' => 'Kỷ Hợi',
                'created_at' => '2019-02-14 12:45:11',
                'updated_at' => '2019-02-14 12:45:11',
            ),
            35 => 
            array (
                'id' => 129,
                'auto_import_id' => 24,
                'match_div' => 0,
                'trigger_str' => 'Nam con nhợn',
                'created_at' => '2019-02-14 12:45:27',
                'updated_at' => '2019-02-14 12:45:27',
            ),
            36 => 
            array (
                'id' => 131,
                'auto_import_id' => 24,
                'match_div' => 0,
                'trigger_str' => 'Phúc như đông hải',
                'created_at' => '2019-02-14 12:46:55',
                'updated_at' => '2019-02-14 12:46:55',
            ),
            37 => 
            array (
                'id' => 132,
                'auto_import_id' => 24,
                'match_div' => 1,
                'trigger_str' => 'Niềm vui ngập tràn',
                'created_at' => '2019-02-14 12:52:07',
                'updated_at' => '2019-02-14 12:52:07',
            ),
            38 => 
            array (
                'id' => 133,
                'auto_import_id' => 24,
                'match_div' => 2,
                'trigger_str' => 'IE',
                'created_at' => '2019-02-14 12:55:23',
                'updated_at' => '2019-02-14 12:55:23',
            ),
        ));
        
        
    }
}