<?php

use Illuminate\Database\Seeder;

class AutoNotificationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_notifications')->delete();
        
        \DB::table('auto_notifications')->insert(array (
            0 => 
            array (
                'id' => 1,
                'client_id' => 1,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Trang chu',
                'content_group_id' => 51,
                'created_at' => '2019-01-29 13:33:32',
                'updated_at' => '2019-01-29 13:33:32',
            ),
            1 => 
            array (
                'id' => 2,
                'client_id' => 1,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'News',
                'content_group_id' => 54,
                'created_at' => '2019-01-29 13:33:55',
                'updated_at' => '2019-01-29 13:33:55',
            ),
            2 => 
            array (
                'id' => 3,
                'client_id' => 1,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Gioi Thieu',
                'content_group_id' => 24,
                'created_at' => '2019-01-29 13:34:29',
                'updated_at' => '2019-01-29 13:34:29',
            ),
            3 => 
            array (
                'id' => 4,
                'client_id' => 1,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Thien tai',
                'content_group_id' => 57,
                'created_at' => '2019-01-29 13:35:02',
                'updated_at' => '2019-01-29 13:35:02',
            ),
            4 => 
            array (
                'id' => 5,
                'client_id' => 1,
                'status' => 0,
                'auto_notification_div' => 0,
                'name' => 'VISOR VNC',
                'content_group_id' => 28,
                'created_at' => '2019-01-31 21:17:53',
                'updated_at' => '2019-01-31 21:17:53',
            ),
            5 => 
            array (
                'id' => 6,
                'client_id' => 1,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Dendi',
                'content_group_id' => 2,
                'created_at' => '2019-01-31 21:23:15',
                'updated_at' => '2019-01-31 21:23:15',
            ),
            6 => 
            array (
                'id' => 7,
                'client_id' => 1,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Test Thien Tai',
                'content_group_id' => 63,
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            7 => 
            array (
                'id' => 12,
                'client_id' => 199,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Thông báo Post',
                'content_group_id' => 102,
                'created_at' => '2019-04-10 13:43:51',
                'updated_at' => '2019-04-10 13:43:51',
            ),
            8 => 
            array (
                'id' => 13,
                'client_id' => 199,
                'status' => 1,
                'auto_notification_div' => 0,
                'name' => 'Thong Bao Khi Tuong',
                'content_group_id' => 165,
                'created_at' => '2019-04-26 15:48:53',
                'updated_at' => '2019-04-26 15:48:53',
            ),
        ));
        
        
    }
}