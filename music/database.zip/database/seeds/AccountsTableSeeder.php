<?php

use Illuminate\Database\Seeder;

class AccountsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('accounts')->delete();
        
        \DB::table('accounts')->insert(array (
            0 => 
            array (
                'id' => 1,
                'username' => 'visor',
                'password' => '$2y$10$FHYUG5Eta0MnrjwuuvwhUOnwQzmyV8DwgSNWJcQeGmyCQ3jt9wIq.',
                'role_div' => 101,
                'name' => 'Admin',
                'email' => 'sgm@ml.visor.co.jp',
                'remember_token' => 'K2Lk8PStWpDkdyXMVYD1voanUKXVCy7Ljg1m0OPPGogteKiZb12enHqYlHEI',
                'usage_status' => 1,
                'created_at' => '2018-11-27 12:34:48',
                'updated_at' => '2018-11-27 12:34:48',
            ),
            1 => 
            array (
                'id' => 3,
                'username' => 'tientt2',
                'password' => '$2y$10$HQEcjvnSykaE2zmD2BYNvO61K0zyX9llUGq67hNKKI8.ix83F6.C2',
                'role_div' => 101,
                'name' => 'Thuy Tien Thuy Tien Thuy Tien',
                'email' => 'tran.thuy.tien@vinicorp.com.vn',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2018-11-28 11:47:16',
                'updated_at' => '2018-12-06 17:35:09',
            ),
            2 => 
            array (
                'id' => 4,
                'username' => 'huydn',
                'password' => '$2y$10$eKieZf29wxUAqY6KL7UKQeT1VpwJvu4AdpP01KgxwZXD1UrMKp64a',
                'role_div' => 101,
                'name' => 'DO Huy',
                'email' => 'huydn@vinicorp.com.vn',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2018-11-29 17:59:44',
                'updated_at' => '2018-11-29 17:59:54',
            ),
            3 => 
            array (
                'id' => 6,
                'username' => 'huydn31',
                'password' => '$2y$10$lNRJ501.skcw8e1z551UVOEn0DFuE/.loRGYVO6i3OBz4JPqDTSTW',
                'role_div' => 101,
                'name' => 'ten ten111',
                'email' => 'huydn1186@gmail.tk',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2018-11-29 18:02:03',
                'updated_at' => '2018-11-29 18:26:16',
            ),
            4 => 
            array (
                'id' => 7,
                'username' => 'huydn5',
                'password' => '$2y$10$WwSHIsatqU3HSI5.EXXWKOXDLoweYMLNuW8puB7tHQ8bjK7HnT8Pm',
                'role_div' => 101,
                'name' => 'huydn5',
                'email' => 'huadhs@gmail.com',
                'remember_token' => 'tuLmD5LVQk9OHehS7MYgK0aBo7ZfcfLMYnTWhEqs7eUHSrl053GgaCaoHJnL',
                'usage_status' => 1,
                'created_at' => '2018-11-29 18:09:03',
                'updated_at' => '2018-11-29 18:40:33',
            ),
            5 => 
            array (
                'id' => 8,
                'username' => 'thainh',
                'password' => '$2y$10$Ee9YhqqzdotdHFo4/zH81.rnj.5GSE1CJw/DneSDUMbCWbbczgXbS',
                'role_div' => 101,
                'name' => 'ThaiNH1991',
                'email' => 'thai@gmail.com',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2018-11-29 19:05:58',
                'updated_at' => '2018-12-06 17:42:59',
            ),
            6 => 
            array (
                'id' => 9,
                'username' => '223334',
                'password' => '$2y$10$CU0aAQaJtZ7xme82QDHnQeMCqisq4Hjv9tOEV.bZwu7mGaujKeCHW',
                'role_div' => 1,
                'name' => 'thu',
                'email' => 'nguyenminhthu.utc@gmail.com',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2018-12-05 11:56:55',
                'updated_at' => '2018-12-05 15:19:36',
            ),
            7 => 
            array (
                'id' => 15,
                'username' => 'thuntm',
                'password' => '$2y$10$XhHHBqSzN4A9Y2idObqR.equhb739RgN1SsqOEcl68P7tZcTik5IS',
                'role_div' => 1,
                'name' => 'thuntm',
                'email' => 'thu@gmail.com',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2018-12-07 10:26:11',
                'updated_at' => '2018-12-07 10:26:11',
            ),
            8 => 
            array (
                'id' => 16,
                'username' => 'minhthunguyenthi',
                'password' => '$2y$10$FQnAiHZzV6cc3jlsj97Fn.Ft4AslVuMZE4qQtu./NuC8IqRZLErGi',
                'role_div' => 101,
                'name' => 'Minh Thu',
                'email' => 'nguyenminhthu.utc@gmail.com',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2019-01-30 18:38:57',
                'updated_at' => '2019-01-30 18:39:29',
            ),
            9 => 
            array (
                'id' => 17,
                'username' => 'lasdasdasdasd',
                'password' => '$2y$10$AriiF2TAM5SPyCzktEEQAuohjLbh2AtjD9mPzkyReB2pr7uwVS7zm',
                'role_div' => 1,
                'name' => 'adsdd',
                'email' => 'huy@gmail.com',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2019-02-11 11:24:03',
                'updated_at' => '2019-02-11 11:24:03',
            ),
            10 => 
            array (
                'id' => 18,
                'username' => 'khanhngoc',
                'password' => '$2y$10$Qf1kZTZUtgmokpWSTfyMae9kyIqIOZrZRbcatAfvq4Hwu8BJok44e',
                'role_div' => 1,
                'name' => 'Ngoc',
                'email' => 'ngoc@gmail.com',
                'remember_token' => NULL,
                'usage_status' => 1,
                'created_at' => '2019-03-01 16:47:31',
                'updated_at' => '2019-03-01 18:38:43',
            ),
        ));
        
        
    }
}