<?php

use Illuminate\Database\Seeder;

class TranslationReplacementsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('translation_replacements')->delete();
        
        
        
    }
}