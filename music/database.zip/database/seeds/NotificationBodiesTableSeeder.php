<?php

use Illuminate\Database\Seeder;

class NotificationBodiesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('notification_bodies')->delete();
        
        \DB::table('notification_bodies')->insert(array (
            0 => 
            array (
                'id' => 26,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            1 => 
            array (
                'id' => 27,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            2 => 
            array (
                'id' => 28,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            3 => 
            array (
                'id' => 29,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            4 => 
            array (
                'id' => 30,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            5 => 
            array (
                'id' => 31,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            6 => 
            array (
                'id' => 32,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            7 => 
            array (
                'id' => 33,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            8 => 
            array (
                'id' => 34,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            9 => 
            array (
                'id' => 35,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            10 => 
            array (
                'id' => 36,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            11 => 
            array (
                'id' => 37,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            12 => 
            array (
                'id' => 38,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            13 => 
            array (
                'id' => 39,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            14 => 
            array (
                'id' => 40,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            15 => 
            array (
                'id' => 41,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            16 => 
            array (
                'id' => 42,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            17 => 
            array (
                'id' => 43,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            18 => 
            array (
                'id' => 44,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            19 => 
            array (
                'id' => 45,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            20 => 
            array (
                'id' => 46,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            21 => 
            array (
                'id' => 47,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            22 => 
            array (
                'id' => 48,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            23 => 
            array (
                'id' => 49,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            24 => 
            array (
                'id' => 50,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            25 => 
            array (
                'id' => 51,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            26 => 
            array (
                'id' => 52,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            27 => 
            array (
                'id' => 53,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            28 => 
            array (
                'id' => 54,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            29 => 
            array (
                'id' => 55,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            30 => 
            array (
                'id' => 56,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            31 => 
            array (
                'id' => 57,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            32 => 
            array (
                'id' => 58,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            33 => 
            array (
                'id' => 59,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            34 => 
            array (
                'id' => 60,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            35 => 
            array (
                'id' => 61,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            36 => 
            array (
                'id' => 62,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            37 => 
            array (
                'id' => 63,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            38 => 
            array (
                'id' => 64,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            39 => 
            array (
                'id' => 65,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            40 => 
            array (
                'id' => 66,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            41 => 
            array (
                'id' => 67,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            42 => 
            array (
                'id' => 68,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            43 => 
            array (
                'id' => 69,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            44 => 
            array (
                'id' => 70,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            45 => 
            array (
                'id' => 71,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            46 => 
            array (
                'id' => 72,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            47 => 
            array (
                'id' => 73,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            48 => 
            array (
                'id' => 74,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            49 => 
            array (
                'id' => 75,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            50 => 
            array (
                'id' => 76,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            51 => 
            array (
                'id' => 77,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            52 => 
            array (
                'id' => 78,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            53 => 
            array (
                'id' => 79,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            54 => 
            array (
                'id' => 80,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            55 => 
            array (
                'id' => 81,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            56 => 
            array (
                'id' => 82,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            57 => 
            array (
                'id' => 83,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            58 => 
            array (
                'id' => 84,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            59 => 
            array (
                'id' => 85,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            60 => 
            array (
                'id' => 86,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            61 => 
            array (
                'id' => 87,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            62 => 
            array (
                'id' => 88,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            63 => 
            array (
                'id' => 89,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            64 => 
            array (
                'id' => 90,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            65 => 
            array (
                'id' => 91,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            66 => 
            array (
                'id' => 92,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            67 => 
            array (
                'id' => 93,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            68 => 
            array (
                'id' => 94,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            69 => 
            array (
                'id' => 95,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            70 => 
            array (
                'id' => 96,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            71 => 
            array (
                'id' => 97,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            72 => 
            array (
                'id' => 98,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            73 => 
            array (
                'id' => 99,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            74 => 
            array (
                'id' => 100,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            75 => 
            array (
                'id' => 101,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            76 => 
            array (
                'id' => 102,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            77 => 
            array (
                'id' => 103,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            78 => 
            array (
                'id' => 104,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            79 => 
            array (
                'id' => 105,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            80 => 
            array (
                'id' => 106,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            81 => 
            array (
                'id' => 107,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            82 => 
            array (
                'id' => 108,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            83 => 
            array (
                'id' => 109,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            84 => 
            array (
                'id' => 110,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            85 => 
            array (
                'id' => 111,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            86 => 
            array (
                'id' => 112,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            87 => 
            array (
                'id' => 113,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            88 => 
            array (
                'id' => 114,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            89 => 
            array (
                'id' => 115,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            90 => 
            array (
                'id' => 116,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            91 => 
            array (
                'id' => 117,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            92 => 
            array (
                'id' => 118,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            93 => 
            array (
                'id' => 119,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            94 => 
            array (
                'id' => 120,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            95 => 
            array (
                'id' => 121,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            96 => 
            array (
                'id' => 122,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            97 => 
            array (
                'id' => 123,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            98 => 
            array (
                'id' => 124,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            99 => 
            array (
                'id' => 125,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            100 => 
            array (
                'id' => 126,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            101 => 
            array (
                'id' => 127,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            102 => 
            array (
                'id' => 128,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            103 => 
            array (
                'id' => 129,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            104 => 
            array (
                'id' => 130,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            105 => 
            array (
                'id' => 131,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            106 => 
            array (
                'id' => 132,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            107 => 
            array (
                'id' => 133,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            108 => 
            array (
                'id' => 134,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            109 => 
            array (
                'id' => 135,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            110 => 
            array (
                'id' => 136,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            111 => 
            array (
                'id' => 137,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            112 => 
            array (
                'id' => 138,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            113 => 
            array (
                'id' => 139,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            114 => 
            array (
                'id' => 140,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            115 => 
            array (
                'id' => 141,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            116 => 
            array (
                'id' => 142,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            117 => 
            array (
                'id' => 143,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            118 => 
            array (
                'id' => 144,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            119 => 
            array (
                'id' => 145,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            120 => 
            array (
                'id' => 146,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            121 => 
            array (
                'id' => 147,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            122 => 
            array (
                'id' => 148,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            123 => 
            array (
                'id' => 149,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            124 => 
            array (
                'id' => 150,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            125 => 
            array (
                'id' => 151,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            126 => 
            array (
                'id' => 152,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            127 => 
            array (
                'id' => 153,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            128 => 
            array (
                'id' => 154,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            129 => 
            array (
                'id' => 155,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            130 => 
            array (
                'id' => 156,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            131 => 
            array (
                'id' => 157,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            132 => 
            array (
                'id' => 158,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            133 => 
            array (
                'id' => 159,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            134 => 
            array (
                'id' => 160,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            135 => 
            array (
                'id' => 161,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            136 => 
            array (
                'id' => 162,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            137 => 
            array (
                'id' => 163,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            138 => 
            array (
                'id' => 164,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            139 => 
            array (
                'id' => 165,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            140 => 
            array (
                'id' => 166,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            141 => 
            array (
                'id' => 167,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            142 => 
            array (
                'id' => 168,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            143 => 
            array (
                'id' => 169,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            144 => 
            array (
                'id' => 170,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            145 => 
            array (
                'id' => 171,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            146 => 
            array (
                'id' => 172,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            147 => 
            array (
                'id' => 173,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            148 => 
            array (
                'id' => 174,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            149 => 
            array (
                'id' => 175,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            150 => 
            array (
                'id' => 176,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            151 => 
            array (
                'id' => 177,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            152 => 
            array (
                'id' => 178,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            153 => 
            array (
                'id' => 179,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            154 => 
            array (
                'id' => 180,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            155 => 
            array (
                'id' => 181,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            156 => 
            array (
                'id' => 182,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            157 => 
            array (
                'id' => 183,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            158 => 
            array (
                'id' => 184,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            159 => 
            array (
                'id' => 185,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            160 => 
            array (
                'id' => 186,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            161 => 
            array (
                'id' => 187,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            162 => 
            array (
                'id' => 188,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            163 => 
            array (
                'id' => 189,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            164 => 
            array (
                'id' => 193,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            165 => 
            array (
                'id' => 194,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            166 => 
            array (
                'id' => 195,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            167 => 
            array (
                'id' => 196,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            168 => 
            array (
                'id' => 197,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            169 => 
            array (
                'id' => 198,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            170 => 
            array (
                'id' => 217,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            171 => 
            array (
                'id' => 218,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            172 => 
            array (
                'id' => 219,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            173 => 
            array (
                'id' => 220,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            174 => 
            array (
                'id' => 221,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            175 => 
            array (
                'id' => 222,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            176 => 
            array (
                'id' => 226,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            177 => 
            array (
                'id' => 227,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            178 => 
            array (
                'id' => 228,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            179 => 
            array (
                'id' => 229,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            180 => 
            array (
                'id' => 230,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            181 => 
            array (
                'id' => 231,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            182 => 
            array (
                'id' => 247,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            183 => 
            array (
                'id' => 248,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            184 => 
            array (
                'id' => 249,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            185 => 
            array (
                'id' => 250,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => 'asdasdd',
            ),
            186 => 
            array (
                'id' => 251,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'dasd',
            ),
            187 => 
            array (
                'id' => 252,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => 'sdasdasddasd',
            ),
            188 => 
            array (
                'id' => 253,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            189 => 
            array (
                'id' => 254,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            190 => 
            array (
                'id' => 255,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            191 => 
            array (
                'id' => 256,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            192 => 
            array (
                'id' => 257,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            193 => 
            array (
                'id' => 258,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            194 => 
            array (
                'id' => 259,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            195 => 
            array (
                'id' => 260,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            196 => 
            array (
                'id' => 261,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            197 => 
            array (
                'id' => 262,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            198 => 
            array (
                'id' => 263,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            199 => 
            array (
                'id' => 264,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            200 => 
            array (
                'id' => 265,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            201 => 
            array (
                'id' => 266,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            202 => 
            array (
                'id' => 267,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            203 => 
            array (
                'id' => 268,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            204 => 
            array (
                'id' => 269,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            205 => 
            array (
                'id' => 270,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            206 => 
            array (
                'id' => 271,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            207 => 
            array (
                'id' => 272,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            208 => 
            array (
                'id' => 273,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            209 => 
            array (
                'id' => 274,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            210 => 
            array (
                'id' => 275,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            211 => 
            array (
                'id' => 276,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            212 => 
            array (
                'id' => 277,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            213 => 
            array (
                'id' => 278,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            214 => 
            array (
                'id' => 279,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            215 => 
            array (
                'id' => 465,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            216 => 
            array (
                'id' => 466,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            217 => 
            array (
                'id' => 467,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            218 => 
            array (
                'id' => 468,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            219 => 
            array (
                'id' => 469,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            220 => 
            array (
                'id' => 470,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            221 => 
            array (
                'id' => 471,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            222 => 
            array (
                'id' => 472,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            223 => 
            array (
                'id' => 473,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            224 => 
            array (
                'id' => 474,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            225 => 
            array (
                'id' => 475,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            226 => 
            array (
                'id' => 476,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            227 => 
            array (
                'id' => 477,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            228 => 
            array (
                'id' => 478,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            229 => 
            array (
                'id' => 479,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            230 => 
            array (
                'id' => 486,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            231 => 
            array (
                'id' => 487,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            232 => 
            array (
                'id' => 488,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            233 => 
            array (
                'id' => 489,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            234 => 
            array (
                'id' => 490,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            235 => 
            array (
                'id' => 491,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            236 => 
            array (
                'id' => 501,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            237 => 
            array (
                'id' => 502,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            238 => 
            array (
                'id' => 503,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            239 => 
            array (
                'id' => 504,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            240 => 
            array (
                'id' => 505,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            241 => 
            array (
                'id' => 506,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            242 => 
            array (
                'id' => 507,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            243 => 
            array (
                'id' => 508,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            244 => 
            array (
                'id' => 509,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            245 => 
            array (
                'id' => 510,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            246 => 
            array (
                'id' => 511,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            247 => 
            array (
                'id' => 512,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            248 => 
            array (
                'id' => 513,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            249 => 
            array (
                'id' => 514,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            250 => 
            array (
                'id' => 515,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            251 => 
            array (
                'id' => 516,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            252 => 
            array (
                'id' => 517,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            253 => 
            array (
                'id' => 518,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            254 => 
            array (
                'id' => 519,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            255 => 
            array (
                'id' => 520,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            256 => 
            array (
                'id' => 521,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            257 => 
            array (
                'id' => 522,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            258 => 
            array (
                'id' => 523,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            259 => 
            array (
                'id' => 524,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            260 => 
            array (
                'id' => 525,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            261 => 
            array (
                'id' => 526,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            262 => 
            array (
                'id' => 527,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            263 => 
            array (
                'id' => 528,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            264 => 
            array (
                'id' => 529,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            265 => 
            array (
                'id' => 530,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            266 => 
            array (
                'id' => 531,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            267 => 
            array (
                'id' => 532,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            268 => 
            array (
                'id' => 533,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            269 => 
            array (
                'id' => 534,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            270 => 
            array (
                'id' => 535,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            271 => 
            array (
                'id' => 536,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            272 => 
            array (
                'id' => 537,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            273 => 
            array (
                'id' => 538,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            274 => 
            array (
                'id' => 539,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            275 => 
            array (
                'id' => 540,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            276 => 
            array (
                'id' => 541,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            277 => 
            array (
                'id' => 542,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            278 => 
            array (
                'id' => 543,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            279 => 
            array (
                'id' => 544,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            280 => 
            array (
                'id' => 545,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            281 => 
            array (
                'id' => 549,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            282 => 
            array (
                'id' => 550,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            283 => 
            array (
                'id' => 551,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            284 => 
            array (
                'id' => 552,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            285 => 
            array (
                'id' => 553,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            286 => 
            array (
                'id' => 554,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            287 => 
            array (
                'id' => 555,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            288 => 
            array (
                'id' => 556,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            289 => 
            array (
                'id' => 557,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            290 => 
            array (
                'id' => 558,
                'push_notification_id' => 45,
                'lang' => 'en',
                'title' => 'huydn_batcth',
                'body' => '<span style="font-size: 13.3333px;">English Body</span>',
            ),
            291 => 
            array (
                'id' => 559,
                'push_notification_id' => 45,
                'lang' => 'es',
                'title' => 'huydn_batcth2',
                'body' => 'Spain Body',
            ),
            292 => 
            array (
                'id' => 560,
                'push_notification_id' => 45,
                'lang' => 'ko',
                'title' => 'huydn_batcth2',
                'body' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            293 => 
            array (
                'id' => 561,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            294 => 
            array (
                'id' => 562,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            295 => 
            array (
                'id' => 563,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            296 => 
            array (
                'id' => 564,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            297 => 
            array (
                'id' => 565,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            298 => 
            array (
                'id' => 566,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            299 => 
            array (
                'id' => 567,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            300 => 
            array (
                'id' => 568,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            301 => 
            array (
                'id' => 569,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            302 => 
            array (
                'id' => 570,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            303 => 
            array (
                'id' => 571,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            304 => 
            array (
                'id' => 572,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            305 => 
            array (
                'id' => 573,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            306 => 
            array (
                'id' => 574,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            307 => 
            array (
                'id' => 575,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            308 => 
            array (
                'id' => 576,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            309 => 
            array (
                'id' => 577,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            310 => 
            array (
                'id' => 578,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            311 => 
            array (
                'id' => 579,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            312 => 
            array (
                'id' => 580,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            313 => 
            array (
                'id' => 581,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            314 => 
            array (
                'id' => 582,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            315 => 
            array (
                'id' => 583,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            316 => 
            array (
                'id' => 584,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            317 => 
            array (
                'id' => 585,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            318 => 
            array (
                'id' => 586,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            319 => 
            array (
                'id' => 587,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            320 => 
            array (
                'id' => 588,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            321 => 
            array (
                'id' => 589,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            322 => 
            array (
                'id' => 590,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            323 => 
            array (
                'id' => 591,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            324 => 
            array (
                'id' => 592,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            325 => 
            array (
                'id' => 593,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            326 => 
            array (
                'id' => 594,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            327 => 
            array (
                'id' => 595,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            328 => 
            array (
                'id' => 596,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            329 => 
            array (
                'id' => 597,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            330 => 
            array (
                'id' => 598,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            331 => 
            array (
                'id' => 599,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            332 => 
            array (
                'id' => 600,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            333 => 
            array (
                'id' => 601,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            334 => 
            array (
                'id' => 602,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            335 => 
            array (
                'id' => 603,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            336 => 
            array (
                'id' => 604,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            337 => 
            array (
                'id' => 605,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            338 => 
            array (
                'id' => 606,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            339 => 
            array (
                'id' => 607,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            340 => 
            array (
                'id' => 608,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            341 => 
            array (
                'id' => 609,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            342 => 
            array (
                'id' => 610,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            343 => 
            array (
                'id' => 611,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            344 => 
            array (
                'id' => 612,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            345 => 
            array (
                'id' => 613,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            346 => 
            array (
                'id' => 614,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            347 => 
            array (
                'id' => 615,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            348 => 
            array (
                'id' => 616,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            349 => 
            array (
                'id' => 617,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            350 => 
            array (
                'id' => 618,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            351 => 
            array (
                'id' => 619,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            352 => 
            array (
                'id' => 620,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            353 => 
            array (
                'id' => 621,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            354 => 
            array (
                'id' => 622,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            355 => 
            array (
                'id' => 623,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            356 => 
            array (
                'id' => 624,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            357 => 
            array (
                'id' => 625,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            358 => 
            array (
                'id' => 626,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            359 => 
            array (
                'id' => 627,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            360 => 
            array (
                'id' => 628,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            361 => 
            array (
                'id' => 629,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            362 => 
            array (
                'id' => 630,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            363 => 
            array (
                'id' => 631,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            364 => 
            array (
                'id' => 632,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            365 => 
            array (
                'id' => 633,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            366 => 
            array (
                'id' => 634,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            367 => 
            array (
                'id' => 635,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            368 => 
            array (
                'id' => 636,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            369 => 
            array (
                'id' => 637,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            370 => 
            array (
                'id' => 638,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            371 => 
            array (
                'id' => 639,
                'push_notification_id' => 1,
                'lang' => 'es',
                'title' => 'sdfds',
                'body' => 'fasdfsadf',
            ),
            372 => 
            array (
                'id' => 640,
                'push_notification_id' => 1,
                'lang' => 'ja_easy',
                'title' => 'sdfasd',
                'body' => 'fasdf',
            ),
            373 => 
            array (
                'id' => 641,
                'push_notification_id' => 1,
                'lang' => 'en',
                'title' => 'sdfds',
                'body' => 'fasdfsadf',
            ),
            374 => 
            array (
                'id' => 642,
                'push_notification_id' => 1,
                'lang' => 'es',
                'title' => 'sdfds',
                'body' => 'fasdfsadf',
            ),
            375 => 
            array (
                'id' => 643,
                'push_notification_id' => 1,
                'lang' => 'ko',
                'title' => 'sdfds',
                'body' => 'fasdfsadf',
            ),
            376 => 
            array (
                'id' => 644,
                'push_notification_id' => 12,
                'lang' => 'es',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            377 => 
            array (
                'id' => 645,
                'push_notification_id' => 12,
                'lang' => 'ja_easy',
                'title' => 'sdf',
                'body' => 'fgsdf',
            ),
            378 => 
            array (
                'id' => 646,
                'push_notification_id' => 12,
                'lang' => 'en',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            379 => 
            array (
                'id' => 647,
                'push_notification_id' => 12,
                'lang' => 'es',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            380 => 
            array (
                'id' => 648,
                'push_notification_id' => 12,
                'lang' => 'ko',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            381 => 
            array (
                'id' => 649,
                'push_notification_id' => 13,
                'lang' => 'es',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            382 => 
            array (
                'id' => 650,
                'push_notification_id' => 13,
                'lang' => 'ja_easy',
                'title' => 'sdf',
                'body' => 'sdfsdf',
            ),
            383 => 
            array (
                'id' => 651,
                'push_notification_id' => 13,
                'lang' => 'en',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            384 => 
            array (
                'id' => 652,
                'push_notification_id' => 13,
                'lang' => 'es',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            385 => 
            array (
                'id' => 653,
                'push_notification_id' => 13,
                'lang' => 'ko',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            386 => 
            array (
                'id' => 654,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            387 => 
            array (
                'id' => 655,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            388 => 
            array (
                'id' => 656,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            389 => 
            array (
                'id' => 657,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            390 => 
            array (
                'id' => 658,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            391 => 
            array (
                'id' => 659,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            392 => 
            array (
                'id' => 660,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            393 => 
            array (
                'id' => 661,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            394 => 
            array (
                'id' => 662,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            395 => 
            array (
                'id' => 663,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            396 => 
            array (
                'id' => 664,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            397 => 
            array (
                'id' => 665,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            398 => 
            array (
                'id' => 666,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            399 => 
            array (
                'id' => 667,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            400 => 
            array (
                'id' => 668,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            401 => 
            array (
                'id' => 669,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            402 => 
            array (
                'id' => 670,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            403 => 
            array (
                'id' => 671,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            404 => 
            array (
                'id' => 672,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            405 => 
            array (
                'id' => 673,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            406 => 
            array (
                'id' => 674,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            407 => 
            array (
                'id' => 675,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            408 => 
            array (
                'id' => 676,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            409 => 
            array (
                'id' => 677,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            410 => 
            array (
                'id' => 678,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            411 => 
            array (
                'id' => 679,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            412 => 
            array (
                'id' => 680,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            413 => 
            array (
                'id' => 681,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            414 => 
            array (
                'id' => 682,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            415 => 
            array (
                'id' => 683,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            416 => 
            array (
                'id' => 684,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            417 => 
            array (
                'id' => 685,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            418 => 
            array (
                'id' => 686,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            419 => 
            array (
                'id' => 687,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            420 => 
            array (
                'id' => 688,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            421 => 
            array (
                'id' => 689,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            422 => 
            array (
                'id' => 690,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            423 => 
            array (
                'id' => 691,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            424 => 
            array (
                'id' => 692,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            425 => 
            array (
                'id' => 693,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            426 => 
            array (
                'id' => 694,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            427 => 
            array (
                'id' => 695,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            428 => 
            array (
                'id' => 696,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            429 => 
            array (
                'id' => 697,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            430 => 
            array (
                'id' => 698,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            431 => 
            array (
                'id' => 699,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            432 => 
            array (
                'id' => 700,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            433 => 
            array (
                'id' => 701,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 body</span></font>',
            ),
            434 => 
            array (
                'id' => 705,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            435 => 
            array (
                'id' => 706,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            436 => 
            array (
                'id' => 707,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            437 => 
            array (
                'id' => 708,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            438 => 
            array (
                'id' => 709,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            439 => 
            array (
                'id' => 710,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            440 => 
            array (
                'id' => 711,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            441 => 
            array (
                'id' => 712,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            442 => 
            array (
                'id' => 713,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            443 => 
            array (
                'id' => 723,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            444 => 
            array (
                'id' => 724,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            445 => 
            array (
                'id' => 725,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            446 => 
            array (
                'id' => 726,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            447 => 
            array (
                'id' => 727,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            448 => 
            array (
                'id' => 728,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            449 => 
            array (
                'id' => 729,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            450 => 
            array (
                'id' => 730,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            451 => 
            array (
                'id' => 731,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            452 => 
            array (
                'id' => 738,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            453 => 
            array (
                'id' => 739,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            454 => 
            array (
                'id' => 740,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            455 => 
            array (
                'id' => 759,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            456 => 
            array (
                'id' => 760,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            457 => 
            array (
                'id' => 761,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            458 => 
            array (
                'id' => 768,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            459 => 
            array (
                'id' => 769,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            460 => 
            array (
                'id' => 770,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            461 => 
            array (
                'id' => 771,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            462 => 
            array (
                'id' => 772,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            463 => 
            array (
                'id' => 773,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            464 => 
            array (
                'id' => 774,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            465 => 
            array (
                'id' => 775,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            466 => 
            array (
                'id' => 776,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            467 => 
            array (
                'id' => 777,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            468 => 
            array (
                'id' => 778,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            469 => 
            array (
                'id' => 779,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            470 => 
            array (
                'id' => 780,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            471 => 
            array (
                'id' => 781,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            472 => 
            array (
                'id' => 782,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            473 => 
            array (
                'id' => 783,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            474 => 
            array (
                'id' => 784,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            475 => 
            array (
                'id' => 785,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            476 => 
            array (
                'id' => 786,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            477 => 
            array (
                'id' => 787,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            478 => 
            array (
                'id' => 788,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            479 => 
            array (
                'id' => 789,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            480 => 
            array (
                'id' => 790,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            481 => 
            array (
                'id' => 791,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            482 => 
            array (
                'id' => 792,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            483 => 
            array (
                'id' => 793,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            484 => 
            array (
                'id' => 794,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            485 => 
            array (
                'id' => 795,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            486 => 
            array (
                'id' => 796,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            487 => 
            array (
                'id' => 797,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            488 => 
            array (
                'id' => 798,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            489 => 
            array (
                'id' => 799,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            490 => 
            array (
                'id' => 800,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            491 => 
            array (
                'id' => 801,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            492 => 
            array (
                'id' => 802,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            493 => 
            array (
                'id' => 803,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            494 => 
            array (
                'id' => 804,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            495 => 
            array (
                'id' => 805,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            496 => 
            array (
                'id' => 806,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            497 => 
            array (
                'id' => 807,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            498 => 
            array (
                'id' => 808,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            499 => 
            array (
                'id' => 809,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
        ));
        \DB::table('notification_bodies')->insert(array (
            0 => 
            array (
                'id' => 810,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            1 => 
            array (
                'id' => 811,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            2 => 
            array (
                'id' => 812,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            3 => 
            array (
                'id' => 813,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            4 => 
            array (
                'id' => 814,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            5 => 
            array (
                'id' => 815,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            6 => 
            array (
                'id' => 816,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            7 => 
            array (
                'id' => 817,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            8 => 
            array (
                'id' => 818,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            9 => 
            array (
                'id' => 819,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            10 => 
            array (
                'id' => 820,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            11 => 
            array (
                'id' => 821,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            12 => 
            array (
                'id' => 822,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            13 => 
            array (
                'id' => 823,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            14 => 
            array (
                'id' => 824,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            15 => 
            array (
                'id' => 825,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            16 => 
            array (
                'id' => 826,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            17 => 
            array (
                'id' => 827,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            18 => 
            array (
                'id' => 828,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            19 => 
            array (
                'id' => 829,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            20 => 
            array (
                'id' => 830,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            21 => 
            array (
                'id' => 831,
                'push_notification_id' => 50,
                'lang' => 'en',
            'title' => 'Title(en)',
            'body' => 'Body(en)',
            ),
            22 => 
            array (
                'id' => 832,
                'push_notification_id' => 50,
                'lang' => 'es',
            'title' => 'Title(es)',
            'body' => 'Body(es)',
            ),
            23 => 
            array (
                'id' => 833,
                'push_notification_id' => 50,
                'lang' => 'ko',
            'title' => 'Title(ko)',
            'body' => 'Body(ko)',
            ),
            24 => 
            array (
                'id' => 834,
                'push_notification_id' => 51,
                'lang' => 'en',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            25 => 
            array (
                'id' => 835,
                'push_notification_id' => 51,
                'lang' => 'es',
                'title' => 'Post batch1 ngon ngu 2',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            26 => 
            array (
                'id' => 836,
                'push_notification_id' => 51,
                'lang' => 'ko',
                'title' => 'Title Post batch1',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Post batch1 body</span></font>',
            ),
            27 => 
            array (
                'id' => 837,
                'push_notification_id' => 52,
                'lang' => 'en',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            28 => 
            array (
                'id' => 838,
                'push_notification_id' => 52,
                'lang' => 'es',
            'title' => 'Title test batch Tây Ban Nha (es)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            29 => 
            array (
                'id' => 839,
                'push_notification_id' => 52,
                'lang' => 'ko',
            'title' => 'Title test batch Tieng Anh (en)',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tieng Anh (en)</span></font>',
            ),
            30 => 
            array (
                'id' => 840,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            31 => 
            array (
                'id' => 841,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            32 => 
            array (
                'id' => 842,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            33 => 
            array (
                'id' => 843,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            34 => 
            array (
                'id' => 844,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            35 => 
            array (
                'id' => 845,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            36 => 
            array (
                'id' => 846,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            37 => 
            array (
                'id' => 847,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            38 => 
            array (
                'id' => 848,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            39 => 
            array (
                'id' => 849,
                'push_notification_id' => 62,
                'lang' => 'ja',
                'title' => '5555最後に、日本への留学を検討されている方に対して、何かアドバイスができればと思います。留学前の準備として必要なこととして、どんなことが挙げられますか',
                'body' => '大学院に進む場合は留学前に研究テーマを明確にし、その研究を行っている教授の考え方や方法論までも把握しておくといいと思います。研究テーマは留学先を決める上での重要な判断材料ですし、研究方法も知っていれば実際に留学してからも前向きに勉強に取り組めますからね。大学院に進む場合は留学前に研究テーマを明確にし、その研究を行っている教授の考え方や方法論までも把握しておくといいと思います。研究テーマは留学先を決める上での重要な判断材料ですし、研究方法も知っていれば実際に留学してからも前向きに勉強に取り組めますからね。',
            ),
            40 => 
            array (
                'id' => 850,
                'push_notification_id' => 62,
                'lang' => 'en',
                'title' => '555If you are going to graduate school, you should clarify your research theme before you study abroad, and also',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">If you are going to graduate school, you should clarify your research theme before you study abroad, and also understand the thinking and methodology of the professor doing the research. A research theme is an important decision factor in deciding where to study abroad, and if you know how to study, you will be able to work proactively even after you actually study abroad.</span></font>',
            ),
            41 => 
            array (
                'id' => 851,
                'push_notification_id' => 62,
                'lang' => 'ko',
                'title' => '5555最後に、日本への留学を検討されている方に対して、何かアドバイスができればと思います。留学前の準備として必要なこととして、どんなことが挙げられますか',
                'body' => '大学院に進む場合は留学前に研究テーマを明確にし、その研究を行っている教授の考え方や方法論までも把握しておくといいと思います。研究テーマは留学先を決める上での重要な判断材料ですし、研究方法も知っていれば実際に留学してからも前向きに勉強に取り組めますからね。大学院に進む場合は留学前に研究テーマを明確にし、その研究を行っている教授の考え方や方法論までも把握しておくといいと思います。研究テーマは留学先を決める上での重要な判断材料ですし、研究方法も知っていれば実際に留学してからも前向きに勉強に取り組めますからね。',
            ),
            42 => 
            array (
                'id' => 852,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            43 => 
            array (
                'id' => 853,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            44 => 
            array (
                'id' => 854,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            45 => 
            array (
                'id' => 855,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            46 => 
            array (
                'id' => 856,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            47 => 
            array (
                'id' => 857,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            48 => 
            array (
                'id' => 858,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            49 => 
            array (
                'id' => 859,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            50 => 
            array (
                'id' => 860,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            51 => 
            array (
                'id' => 861,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            52 => 
            array (
                'id' => 862,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            53 => 
            array (
                'id' => 863,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            54 => 
            array (
                'id' => 864,
                'push_notification_id' => 61,
                'lang' => 'ja',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            55 => 
            array (
                'id' => 865,
                'push_notification_id' => 61,
                'lang' => 'en',
            'title' => '444 Title (en)',
                'body' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            56 => 
            array (
                'id' => 866,
                'push_notification_id' => 61,
                'lang' => 'ko',
                'title' => '4444留学する前、最も心配していたことは言葉の違いです。私自身、日本に住んだことがあると言っても小さい頃でしたし、それ以降は10',
                'body' => '<span style="color:#FF6600">李</span>　それでも、早く自立しようと来日から1ヶ月後にはアルバイトを始める決意をしました。街中に置いてあるアルバイト情報誌を手にとっては、電話で「働かせてください」と電話をかけ続けましたね。でも、言葉が満足に話せないことから、なかなかいい返事はもらえず。中国人の先輩から紹介してもらえるチャンスもあったんですけど、そこは中国人が多い職場。日本人だけの環境のほうが早く言葉を覚えられますし、日本の社会にも馴染むことができるので、日本人が働いている職場を自分でひたすら探しました。',
            ),
            57 => 
            array (
                'id' => 867,
                'push_notification_id' => 63,
                'lang' => 'ja',
                'title' => '6666志望する大学院を ...',
                'body' => '私は、留学への心構えについて。留学生は日本で勉強することを目的にやって来るわけですが、それ以前に海外 ...',
            ),
            58 => 
            array (
                'id' => 868,
                'push_notification_id' => 63,
                'lang' => 'en',
                'title' => '666A research theme ...',
                'body' => '&nbsp;if you know how to study, you will be able to work proactively even after you actually study a ...',
            ),
            59 => 
            array (
                'id' => 869,
                'push_notification_id' => 63,
                'lang' => 'ko',
                'title' => '6666志望する大学院を ...',
                'body' => '私は、留学への心構えについて。留学生は日本で勉強することを目的にやって来るわけですが、それ以前に海外 ...',
            ),
            60 => 
            array (
                'id' => 870,
                'push_notification_id' => 64,
                'lang' => 'ja',
                'title' => 'Thu 1',
                'body' => 'Chao mung quy khach den voi chung toi',
            ),
            61 => 
            array (
                'id' => 871,
                'push_notification_id' => 64,
                'lang' => 'en',
                'title' => 'Thu 2',
                'body' => 'hello every body',
            ),
            62 => 
            array (
                'id' => 872,
                'push_notification_id' => 64,
                'lang' => 'ko',
                'title' => 'Thu 1',
                'body' => 'Chao mung quy khach den voi chung toi',
            ),
            63 => 
            array (
                'id' => 873,
                'push_notification_id' => 65,
                'lang' => 'ja',
                'title' => 'Test wav',
                'body' => 'body wav',
            ),
            64 => 
            array (
                'id' => 874,
                'push_notification_id' => 65,
                'lang' => 'en',
                'title' => 'Test wav',
                'body' => 'body wav',
            ),
            65 => 
            array (
                'id' => 875,
                'push_notification_id' => 65,
                'lang' => 'ko',
                'title' => 'Test wav',
                'body' => 'body wav',
            ),
            66 => 
            array (
                'id' => 876,
                'push_notification_id' => 67,
                'lang' => 'ja',
                'title' => 'fashionテスト',
                'body' => 'fashion.',
            ),
            67 => 
            array (
                'id' => 877,
                'push_notification_id' => 67,
                'lang' => 'en',
                'title' => 'fashionテスト',
                'body' => 'fashion.',
            ),
            68 => 
            array (
                'id' => 878,
                'push_notification_id' => 67,
                'lang' => 'ko',
                'title' => 'fashionテスト',
                'body' => 'fashion.',
            ),
            69 => 
            array (
                'id' => 879,
                'push_notification_id' => 68,
                'lang' => 'ja',
                'title' => 'ファッションテスト',
                'body' => 'ファッションテスト',
            ),
            70 => 
            array (
                'id' => 880,
                'push_notification_id' => 68,
                'lang' => 'en',
                'title' => 'ファッションテスト',
                'body' => 'ファッションテスト',
            ),
            71 => 
            array (
                'id' => 881,
                'push_notification_id' => 68,
                'lang' => 'ko',
                'title' => 'ファッションテスト',
                'body' => 'ファッションテスト',
            ),
            72 => 
            array (
                'id' => 882,
                'push_notification_id' => 67,
                'lang' => 'ja',
                'title' => 'fashionテスト',
                'body' => 'fashion.',
            ),
            73 => 
            array (
                'id' => 883,
                'push_notification_id' => 67,
                'lang' => 'en',
                'title' => 'fashionテスト',
                'body' => 'fashion.',
            ),
            74 => 
            array (
                'id' => 884,
                'push_notification_id' => 67,
                'lang' => 'ko',
                'title' => 'fashionテスト',
                'body' => 'fashion.',
            ),
            75 => 
            array (
                'id' => 885,
                'push_notification_id' => 68,
                'lang' => 'ja',
                'title' => 'ファッションテスト',
                'body' => 'ファッションテスト',
            ),
            76 => 
            array (
                'id' => 886,
                'push_notification_id' => 68,
                'lang' => 'en',
                'title' => 'ファッションテスト',
                'body' => 'ファッションテスト',
            ),
            77 => 
            array (
                'id' => 887,
                'push_notification_id' => 68,
                'lang' => 'ko',
                'title' => 'ファッションテスト',
                'body' => 'ファッションテスト',
            ),
            78 => 
            array (
                'id' => 888,
                'push_notification_id' => 69,
                'lang' => 'ja',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            79 => 
            array (
                'id' => 889,
                'push_notification_id' => 69,
                'lang' => 'en',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            80 => 
            array (
                'id' => 890,
                'push_notification_id' => 69,
                'lang' => 'ko',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            81 => 
            array (
                'id' => 891,
                'push_notification_id' => 69,
                'lang' => 'ja',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            82 => 
            array (
                'id' => 892,
                'push_notification_id' => 69,
                'lang' => 'en',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            83 => 
            array (
                'id' => 893,
                'push_notification_id' => 69,
                'lang' => 'ko',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            84 => 
            array (
                'id' => 894,
                'push_notification_id' => 69,
                'lang' => 'ja',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            85 => 
            array (
                'id' => 895,
                'push_notification_id' => 69,
                'lang' => 'en',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            86 => 
            array (
                'id' => 896,
                'push_notification_id' => 69,
                'lang' => 'ko',
                'title' => 'Công ty Cổ phần Tổng ...',
                'body' => 'Tiệc tất niên mừng Xuân Kỷ Hợi 2019Một năm nữa lại chuẩn bị qua đi, năm Mậu Tuất 2018 là một năm gặt ...',
            ),
            87 => 
            array (
                'id' => 897,
                'push_notification_id' => 71,
                'lang' => 'ja',
                'title' => '13事前にご予約いただ ...',
                'body' => '入館登録等の関係上、連絡先等をご登録頂きます。人数の関係等で御参加いただけない場合や開催場所等に変更 ...',
            ),
            88 => 
            array (
                'id' => 898,
                'push_notification_id' => 71,
                'lang' => 'en',
                'title' => '13 christmas',
                'body' => 'Merry happy ',
            ),
            89 => 
            array (
                'id' => 899,
                'push_notification_id' => 71,
                'lang' => 'ko',
                'title' => '13事前にご予約いただ ...',
                'body' => '入館登録等の関係上、連絡先等をご登録頂きます。人数の関係等で御参加いただけない場合や開催場所等に変更 ...',
            ),
            90 => 
            array (
                'id' => 900,
                'push_notification_id' => 72,
                'lang' => 'ja',
                'title' => '14日本の子どもの7人 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            91 => 
            array (
                'id' => 901,
                'push_notification_id' => 72,
                'lang' => 'en',
                'title' => '14 Title en',
                'body' => 'There may be many who feel in the news that the current situation surrounding children and young peo ...',
            ),
            92 => 
            array (
                'id' => 902,
                'push_notification_id' => 72,
                'lang' => 'ko',
                'title' => 'test KO title',
                'body' => 'test KO body',
            ),
            93 => 
            array (
                'id' => 903,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            94 => 
            array (
                'id' => 904,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            95 => 
            array (
                'id' => 905,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            96 => 
            array (
                'id' => 906,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            97 => 
            array (
                'id' => 907,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            98 => 
            array (
                'id' => 908,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            99 => 
            array (
                'id' => 909,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            100 => 
            array (
                'id' => 910,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            101 => 
            array (
                'id' => 911,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            102 => 
            array (
                'id' => 912,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            103 => 
            array (
                'id' => 913,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            104 => 
            array (
                'id' => 914,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            105 => 
            array (
                'id' => 915,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            106 => 
            array (
                'id' => 916,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            107 => 
            array (
                'id' => 917,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            108 => 
            array (
                'id' => 918,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            109 => 
            array (
                'id' => 919,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            110 => 
            array (
                'id' => 920,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            111 => 
            array (
                'id' => 921,
                'push_notification_id' => 72,
                'lang' => 'ja',
                'title' => '14日本の子どもの7人 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            112 => 
            array (
                'id' => 922,
                'push_notification_id' => 72,
                'lang' => 'en',
                'title' => '14 Title en',
                'body' => 'There may be many who feel in the news that the current situation surrounding children and young peo ...',
            ),
            113 => 
            array (
                'id' => 923,
                'push_notification_id' => 72,
                'lang' => 'ko',
                'title' => 'test KO title',
                'body' => 'test KO body',
            ),
            114 => 
            array (
                'id' => 924,
                'push_notification_id' => 73,
                'lang' => 'ja',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            115 => 
            array (
                'id' => 925,
                'push_notification_id' => 73,
                'lang' => 'en',
                'title' => '15 there is a big di ...',
                'body' => 'In schools as well, the number of working hours and types of work per teacher in Japan and the numbe ...',
            ),
            116 => 
            array (
                'id' => 926,
                'push_notification_id' => 73,
                'lang' => 'ko',
                'title' => '15子どもを取り巻く環 ...',
                'body' => '学校においても日本の教員ひとりあたりの勤務時間や業務の種類、担当する生徒数も世界的にも非常に多く、教 ...',
            ),
            117 => 
            array (
                'id' => 939,
                'push_notification_id' => 86,
                'lang' => 'ja',
                'title' => 'Test tong the 2',
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">はい、当法人では学生インターンも募集しています。内容によっては有償（最低賃金以上）でお願いする場合もございます。まずは現在募集しているインターンの内容をご確認ください。</span>',
            ),
            118 => 
            array (
                'id' => 940,
                'push_notification_id' => 86,
                'lang' => 'en',
                'title' => 'Test tong the 2',
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">はい、当法人では学生インターンも募集しています。内容によっては有償（最低賃金以上）でお願いする場合もございます。まずは現在募集しているインターンの内容をご確認ください。</span>',
            ),
            119 => 
            array (
                'id' => 941,
                'push_notification_id' => 86,
                'lang' => 'ko',
                'title' => 'Test tong the 2',
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">はい、当法人では学生インターンも募集しています。内容によっては有償（最低賃金以上）でお願いする場合もございます。まずは現在募集しているインターンの内容をご確認ください。</span>',
            ),
            120 => 
            array (
                'id' => 942,
                'push_notification_id' => 86,
                'lang' => 'ja',
                'title' => 'Test tong the 2',
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">はい、当法人では学生インターンも募集しています。内容によっては有償（最低賃金以上）でお願いする場合もございます。まずは現在募集しているインターンの内容をご確認ください。</span>',
            ),
            121 => 
            array (
                'id' => 943,
                'push_notification_id' => 86,
                'lang' => 'en',
                'title' => 'Test tong the 2',
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">はい、当法人では学生インターンも募集しています。内容によっては有償（最低賃金以上）でお願いする場合もございます。まずは現在募集しているインターンの内容をご確認ください。</span>',
            ),
            122 => 
            array (
                'id' => 944,
                'push_notification_id' => 86,
                'lang' => 'ko',
                'title' => 'Test tong the 2',
            'body' => '<span style="color: rgb(51, 51, 51); font-family: -apple-system, BlinkMacSystemFont, &quot;Helvsetica Neue&quot;, &quot;Yu Gothic&quot;, YuGothic, &quot;ヒラギノ角ゴ ProN W3&quot;, &quot;Hiragino Kaku Gothic ProN&quot;, Arial, メイリオ, Meiryo, sans-serif; font-size: 16px;">はい、当法人では学生インターンも募集しています。内容によっては有償（最低賃金以上）でお願いする場合もございます。まずは現在募集しているインターンの内容をご確認ください。</span>',
            ),
            123 => 
            array (
                'id' => 945,
                'push_notification_id' => 82,
                'lang' => 'ja',
                'title' => 'ベトナムホーチミン',
                'body' => 'こんにちは',
            ),
            124 => 
            array (
                'id' => 946,
                'push_notification_id' => 82,
                'lang' => 'en',
                'title' => 'Vietnam Ho Chi Minh',
                'body' => 'country is very beautiful',
            ),
            125 => 
            array (
                'id' => 947,
                'push_notification_id' => 82,
                'lang' => 'ko',
                'title' => 'ベトナムホーチミン',
                'body' => '안녕하세요',
            ),
            126 => 
            array (
                'id' => 948,
                'push_notification_id' => 75,
                'lang' => 'ja',
                'title' => 'こんにちはみんな ハ ...',
                'body' => '私はベトナムから来ました',
            ),
            127 => 
            array (
                'id' => 949,
                'push_notification_id' => 75,
                'lang' => 'en',
                'title' => 'こんにちはみんな ハ ...',
                'body' => '私はベトナムから来ました',
            ),
            128 => 
            array (
                'id' => 950,
                'push_notification_id' => 75,
                'lang' => 'ko',
                'title' => 'こんにちはみんな ハ ...',
                'body' => '私はベトナムから来ました',
            ),
            129 => 
            array (
                'id' => 951,
                'push_notification_id' => 87,
                'lang' => 'en',
                'title' => 'CHi co tieng Anh',
                'body' => 'CHi co tieng Anh',
            ),
            130 => 
            array (
                'id' => 952,
                'push_notification_id' => 87,
                'lang' => 'es',
                'title' => 'CHi co tieng Anh',
                'body' => 'CHi co tieng Anh',
            ),
            131 => 
            array (
                'id' => 953,
                'push_notification_id' => 87,
                'lang' => 'ko',
                'title' => 'CHi co tieng Anh',
                'body' => 'CHi co tieng Anh',
            ),
            132 => 
            array (
                'id' => 954,
                'push_notification_id' => 88,
                'lang' => 'ja',
                'title' => 'Push ja Push ja  Pus ...',
                'body' => '近年は、「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」など様々な理由で、社会貢献団体へ ...',
            ),
            133 => 
            array (
                'id' => 955,
                'push_notification_id' => 88,
                'lang' => 'en',
                'title' => 'Push en Push en Push ...',
                'body' => '近年は、「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」など様々な理由で、社会貢献団体へ ...',
            ),
            134 => 
            array (
                'id' => 956,
                'push_notification_id' => 88,
                'lang' => 'ko',
                'title' => 'Push ja Push ja  Pus ...',
                'body' => '近年は、「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」など様々な理由で、社会貢献団体へ ...',
            ),
            135 => 
            array (
                'id' => 957,
                'push_notification_id' => 89,
                'lang' => 'ja',
                'title' => 'Test push 2222222222 ...',
                'body' => '3keysは多くの企業や団体のみなさまとともに支援活動を実施しています。企業や団体のみなさまが行動して下 ...',
            ),
            136 => 
            array (
                'id' => 958,
                'push_notification_id' => 89,
                'lang' => 'en',
                'title' => 'Test push 2222222222 ...',
                'body' => '3keys carries out support activities with many companies and organizations. The actions of companies ...',
            ),
            137 => 
            array (
                'id' => 959,
                'push_notification_id' => 89,
                'lang' => 'ko',
                'title' => 'Test push 2222222222 ...',
                'body' => '3keysは多くの企業や団体のみなさまとともに支援活動を実施しています。企業や団体のみなさまが行動して下 ...',
            ),
            138 => 
            array (
                'id' => 960,
                'push_notification_id' => 90,
                'lang' => 'ja',
                'title' => 'Android 2',
                'body' => '3keys carries out support activities with many companies and organizations. The actions of companies ...',
            ),
            139 => 
            array (
                'id' => 961,
                'push_notification_id' => 90,
                'lang' => 'en',
                'title' => 'Android 2',
                'body' => '3keys carries out support activities with many companies and organizations. The actions of companies ...',
            ),
            140 => 
            array (
                'id' => 962,
                'push_notification_id' => 90,
                'lang' => 'ko',
                'title' => 'Android 2',
                'body' => '3keys carries out support activities with many companies and organizations. The actions of companies ...',
            ),
            141 => 
            array (
                'id' => 963,
                'push_notification_id' => 91,
                'lang' => 'ja',
                'title' => 'Android 1',
                'body' => '近年は、「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」など様々な理由で、社会貢献団体へ ...',
            ),
            142 => 
            array (
                'id' => 964,
                'push_notification_id' => 91,
                'lang' => 'en',
                'title' => 'Android 1',
                'body' => '近年は、「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」など様々な理由で、社会貢献団体へ ...',
            ),
            143 => 
            array (
                'id' => 965,
                'push_notification_id' => 91,
                'lang' => 'ko',
                'title' => 'Android 1',
                'body' => '近年は、「社会に恩返しがしたい」「日本の子どもたちに何かを残したい」など様々な理由で、社会貢献団体へ ...',
            ),
            144 => 
            array (
                'id' => 966,
                'push_notification_id' => 92,
                'lang' => 'ja',
                'title' => 'Test push 1',
                'body' => '社会課題を解決する活動の輪が更に広がり、大きな支援につながります。子どもたちにより細かい網目のセーフ ...',
            ),
            145 => 
            array (
                'id' => 967,
                'push_notification_id' => 92,
                'lang' => 'en',
                'title' => 'Title push en',
                'body' => '社会課題を解決する活動の輪が更に広がり、大きな支援につながります。子どもたちにより細かい網目のセーフ ...',
            ),
            146 => 
            array (
                'id' => 968,
                'push_notification_id' => 92,
                'lang' => 'ko',
                'title' => 'Test push 1',
                'body' => '社会課題を解決する活動の輪が更に広がり、大きな支援につながります。子どもたちにより細かい網目のセーフ ...',
            ),
            147 => 
            array (
                'id' => 969,
                'push_notification_id' => 93,
                'lang' => 'ja',
                'title' => 'Test push 1',
                'body' => '3keysは多くの企業や団体のみなさまとともに支援活動を実施しています。企業や団体のみなさまが行動して下 ...',
            ),
            148 => 
            array (
                'id' => 970,
                'push_notification_id' => 93,
                'lang' => 'en',
                'title' => 'Title push en',
                'body' => '3keysは多くの企業や団体のみなさまとともに支援活動を実施しています。企業や団体のみなさまが行動して下 ...',
            ),
            149 => 
            array (
                'id' => 971,
                'push_notification_id' => 93,
                'lang' => 'ko',
                'title' => 'Test push 1',
                'body' => '3keysは多くの企業や団体のみなさまとともに支援活動を実施しています。企業や団体のみなさまが行動して下 ...',
            ),
            150 => 
            array (
                'id' => 972,
                'push_notification_id' => 94,
                'lang' => 'ja',
                'title' => 'test demo',
                'body' => 'vvvvvvvvvvvvvvvvvvvvvvvvv',
            ),
            151 => 
            array (
                'id' => 973,
                'push_notification_id' => 94,
                'lang' => 'en',
                'title' => 'test demo',
                'body' => 'vvvvvvvvvvvvvvvvvvvvvvvvv',
            ),
            152 => 
            array (
                'id' => 974,
                'push_notification_id' => 94,
                'lang' => 'ko',
                'title' => 'test demo',
                'body' => 'vvvvvvvvvvvvvvvvvvvvvvvvv',
            ),
            153 => 
            array (
                'id' => 975,
                'push_notification_id' => 95,
                'lang' => 'ja',
                'title' => 'teddt demo2',
                'body' => 'cccccccccccccccc',
            ),
            154 => 
            array (
                'id' => 976,
                'push_notification_id' => 95,
                'lang' => 'en',
                'title' => 'teddt demo2',
                'body' => 'cccccccccccccccc',
            ),
            155 => 
            array (
                'id' => 977,
                'push_notification_id' => 95,
                'lang' => 'ko',
                'title' => 'teddt demo2',
                'body' => 'cccccccccccccccc',
            ),
            156 => 
            array (
                'id' => 978,
                'push_notification_id' => 96,
                'lang' => 'ja',
                'title' => 'content offline 162 ...',
                'body' => 'content offline 162 - ja - 1',
            ),
            157 => 
            array (
                'id' => 979,
                'push_notification_id' => 96,
                'lang' => 'en',
                'title' => 'content offline 162 ...',
                'body' => 'content offline 162 - ja - 1',
            ),
            158 => 
            array (
                'id' => 980,
                'push_notification_id' => 96,
                'lang' => 'ko',
                'title' => 'content offline 162 ...',
                'body' => 'content offline 162 - ja - 1',
            ),
            159 => 
            array (
                'id' => 993,
                'push_notification_id' => 96,
                'lang' => 'ja',
                'title' => 'content offline 162 ...',
                'body' => 'content offline 162 - ja - 1',
            ),
            160 => 
            array (
                'id' => 994,
                'push_notification_id' => 96,
                'lang' => 'en',
                'title' => 'content offline 162 ...',
                'body' => 'content offline 162 - ja - 1',
            ),
            161 => 
            array (
                'id' => 995,
                'push_notification_id' => 96,
                'lang' => 'ko',
                'title' => 'content offline 162 ...',
                'body' => 'content offline 162 - ja - 1',
            ),
            162 => 
            array (
                'id' => 1020,
                'push_notification_id' => 102,
                'lang' => 'ja',
                'title' => 'setvisible action me ...',
                'body' => 'setvisible action menu setting android',
            ),
            163 => 
            array (
                'id' => 1021,
                'push_notification_id' => 102,
                'lang' => 'en',
                'title' => 'setvisible action me ...',
                'body' => 'setvisible action menu setting android',
            ),
            164 => 
            array (
                'id' => 1022,
                'push_notification_id' => 102,
                'lang' => 'ko',
                'title' => 'setvisible action me ...',
                'body' => 'setvisible action menu setting android',
            ),
            165 => 
            array (
                'id' => 1023,
                'push_notification_id' => 103,
                'lang' => 'ja',
                'title' => 'fafas tion someFunct ...',
                'body' => 'Indeed, because HOF is inlined, all “return” statements inside it will actually return from the func ...',
            ),
            166 => 
            array (
                'id' => 1024,
                'push_notification_id' => 103,
                'lang' => 'en',
                'title' => 'fafas tion someFunct ...',
                'body' => 'Indeed, because HOF is inlined, all “return” statements inside it will actually return from the func ...',
            ),
            167 => 
            array (
                'id' => 1025,
                'push_notification_id' => 103,
                'lang' => 'ko',
                'title' => 'fafas tion someFunct ...',
                'body' => 'Indeed, because HOF is inlined, all “return” statements inside it will actually return from the func ...',
            ),
            168 => 
            array (
                'id' => 1026,
                'push_notification_id' => 104,
                'lang' => 'ja',
                'title' => 'well come to Viet Na ...',
                'body' => 'vbbbbbbbbbbbbbbbbbb',
            ),
            169 => 
            array (
                'id' => 1027,
                'push_notification_id' => 104,
                'lang' => 'en',
                'title' => 'well come to Viet Na ...',
                'body' => 'vbbbbbbbbbbbbbbbbbb',
            ),
            170 => 
            array (
                'id' => 1028,
                'push_notification_id' => 104,
                'lang' => 'ko',
                'title' => 'well come to Viet Na ...',
                'body' => 'vbbbbbbbbbbbbbbbbbb',
            ),
            171 => 
            array (
                'id' => 1029,
                'push_notification_id' => 105,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            172 => 
            array (
                'id' => 1030,
                'push_notification_id' => 105,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            173 => 
            array (
                'id' => 1031,
                'push_notification_id' => 105,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            174 => 
            array (
                'id' => 1032,
                'push_notification_id' => 106,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            175 => 
            array (
                'id' => 1033,
                'push_notification_id' => 106,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            176 => 
            array (
                'id' => 1034,
                'push_notification_id' => 106,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            177 => 
            array (
                'id' => 1035,
                'push_notification_id' => 107,
                'lang' => 'ja',
                'title' => 'Test lai tags Test l ...',
                'body' => 'Moreover, the 3 members of the company\'s Board of Directors all live and work in Japan for over 10 y ...',
            ),
            178 => 
            array (
                'id' => 1036,
                'push_notification_id' => 107,
                'lang' => 'en',
                'title' => 'Title en Title en  T ...',
                'body' => 'Moreover, the 3 members of the company\'s Board of Directors all live and work in Japan for over 10 y ...',
            ),
            179 => 
            array (
                'id' => 1037,
                'push_notification_id' => 107,
                'lang' => 'ko',
                'title' => 'Test lai tags Test l ...',
                'body' => 'Moreover, the 3 members of the company\'s Board of Directors all live and work in Japan for over 10 y ...',
            ),
            180 => 
            array (
                'id' => 1038,
                'push_notification_id' => 108,
                'lang' => 'ja',
                'title' => 'fffffffffffff',
                'body' => 'ffffffffffffffffffffffffffffffffffffff',
            ),
            181 => 
            array (
                'id' => 1039,
                'push_notification_id' => 108,
                'lang' => 'en',
                'title' => 'fffffffffffff',
                'body' => 'ffffffffffffffffffffffffffffffffffffff',
            ),
            182 => 
            array (
                'id' => 1040,
                'push_notification_id' => 108,
                'lang' => 'ko',
                'title' => 'fffffffffffff',
                'body' => 'ffffffffffffffffffffffffffffffffffffff',
            ),
            183 => 
            array (
                'id' => 1041,
                'push_notification_id' => 109,
                'lang' => 'ja',
                'title' => 'an noi bat',
                'body' => 'bbdededededededededede',
            ),
            184 => 
            array (
                'id' => 1042,
                'push_notification_id' => 109,
                'lang' => 'en',
                'title' => 'an noi bat',
                'body' => 'bbdededededededededede',
            ),
            185 => 
            array (
                'id' => 1043,
                'push_notification_id' => 109,
                'lang' => 'ko',
                'title' => 'an noi bat',
                'body' => 'bbdededededededededede',
            ),
            186 => 
            array (
                'id' => 1044,
                'push_notification_id' => 110,
                'lang' => 'ja',
                'title' => 'SerializedName',
                'body' => 'SerializedName SerializedName SerializedName',
            ),
            187 => 
            array (
                'id' => 1045,
                'push_notification_id' => 110,
                'lang' => 'en',
                'title' => 'SerializedName',
                'body' => 'SerializedName SerializedName SerializedName',
            ),
            188 => 
            array (
                'id' => 1046,
                'push_notification_id' => 110,
                'lang' => 'ko',
                'title' => 'SerializedName',
                'body' => 'SerializedName SerializedName SerializedName',
            ),
            189 => 
            array (
                'id' => 1047,
                'push_notification_id' => 111,
                'lang' => 'ja',
                'title' => 'Noi Bat 1',
                'body' => 'Noi Bat 1',
            ),
            190 => 
            array (
                'id' => 1048,
                'push_notification_id' => 111,
                'lang' => 'en',
                'title' => 'Noi Bat 1',
                'body' => 'Noi Bat 1',
            ),
            191 => 
            array (
                'id' => 1049,
                'push_notification_id' => 111,
                'lang' => 'ko',
                'title' => 'Noi Bat 1',
                'body' => 'Noi Bat 1',
            ),
            192 => 
            array (
                'id' => 1050,
                'push_notification_id' => 112,
                'lang' => 'ja',
                'title' => 'Noi bat 2',
                'body' => 'Noi bat 2',
            ),
            193 => 
            array (
                'id' => 1051,
                'push_notification_id' => 112,
                'lang' => 'en',
                'title' => 'Noi bat 2',
                'body' => 'Noi bat 2',
            ),
            194 => 
            array (
                'id' => 1052,
                'push_notification_id' => 112,
                'lang' => 'ko',
                'title' => 'Noi bat 2',
                'body' => 'Noi bat 2',
            ),
            195 => 
            array (
                'id' => 1053,
                'push_notification_id' => 113,
                'lang' => 'ja',
                'title' => 'Noi Bat 3',
                'body' => 'Noi Bat 3',
            ),
            196 => 
            array (
                'id' => 1054,
                'push_notification_id' => 113,
                'lang' => 'en',
                'title' => 'Noi Bat 3',
                'body' => 'Noi Bat 3',
            ),
            197 => 
            array (
                'id' => 1055,
                'push_notification_id' => 113,
                'lang' => 'ko',
                'title' => 'Noi Bat 3',
                'body' => 'Noi Bat 3',
            ),
            198 => 
            array (
                'id' => 1056,
                'push_notification_id' => 114,
                'lang' => 'ja',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            199 => 
            array (
                'id' => 1057,
                'push_notification_id' => 114,
                'lang' => 'en',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            200 => 
            array (
                'id' => 1058,
                'push_notification_id' => 114,
                'lang' => 'ko',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            201 => 
            array (
                'id' => 1059,
                'push_notification_id' => 115,
                'lang' => 'ja',
                'title' => 'Noi bat 4',
                'body' => 'Noi bat 4',
            ),
            202 => 
            array (
                'id' => 1060,
                'push_notification_id' => 115,
                'lang' => 'en',
                'title' => 'Noi bat 4',
                'body' => 'Noi bat 4',
            ),
            203 => 
            array (
                'id' => 1061,
                'push_notification_id' => 115,
                'lang' => 'ko',
                'title' => 'Noi bat 4',
                'body' => 'Noi bat 4',
            ),
            204 => 
            array (
                'id' => 1068,
                'push_notification_id' => 116,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            205 => 
            array (
                'id' => 1069,
                'push_notification_id' => 116,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            206 => 
            array (
                'id' => 1070,
                'push_notification_id' => 116,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            207 => 
            array (
                'id' => 1071,
                'push_notification_id' => 117,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            208 => 
            array (
                'id' => 1072,
                'push_notification_id' => 117,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            209 => 
            array (
                'id' => 1073,
                'push_notification_id' => 117,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            210 => 
            array (
                'id' => 1074,
                'push_notification_id' => 117,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            211 => 
            array (
                'id' => 1075,
                'push_notification_id' => 117,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            212 => 
            array (
                'id' => 1076,
                'push_notification_id' => 117,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            213 => 
            array (
                'id' => 1077,
                'push_notification_id' => 117,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            214 => 
            array (
                'id' => 1078,
                'push_notification_id' => 117,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            215 => 
            array (
                'id' => 1079,
                'push_notification_id' => 117,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            216 => 
            array (
                'id' => 1080,
                'push_notification_id' => 118,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            217 => 
            array (
                'id' => 1081,
                'push_notification_id' => 118,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            218 => 
            array (
                'id' => 1082,
                'push_notification_id' => 118,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            219 => 
            array (
                'id' => 1083,
                'push_notification_id' => 105,
                'lang' => 'ja',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            220 => 
            array (
                'id' => 1084,
                'push_notification_id' => 105,
                'lang' => 'en',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            221 => 
            array (
                'id' => 1085,
                'push_notification_id' => 105,
                'lang' => 'ko',
                'title' => 'Sort collection by m ...',
                'body' => 'Sort collection by multiple fields in Kotlin - Stack Overflow',
            ),
            222 => 
            array (
                'id' => 1089,
                'push_notification_id' => 115,
                'lang' => 'ja',
                'title' => 'Noi bat 4',
                'body' => 'Noi bat 4',
            ),
            223 => 
            array (
                'id' => 1090,
                'push_notification_id' => 115,
                'lang' => 'en',
                'title' => 'Noi bat 4',
                'body' => 'Noi bat 4',
            ),
            224 => 
            array (
                'id' => 1091,
                'push_notification_id' => 115,
                'lang' => 'ko',
                'title' => 'Noi bat 4',
                'body' => 'Noi bat 4',
            ),
            225 => 
            array (
                'id' => 1095,
                'push_notification_id' => 119,
                'lang' => 'ja',
                'title' => 'test',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            226 => 
            array (
                'id' => 1096,
                'push_notification_id' => 119,
                'lang' => 'en',
                'title' => 'test',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            227 => 
            array (
                'id' => 1097,
                'push_notification_id' => 119,
                'lang' => 'ko',
                'title' => 'test',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            228 => 
            array (
                'id' => 1098,
                'push_notification_id' => 119,
                'lang' => 'ja',
                'title' => 'test',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            229 => 
            array (
                'id' => 1099,
                'push_notification_id' => 119,
                'lang' => 'en',
                'title' => 'test',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            230 => 
            array (
                'id' => 1100,
                'push_notification_id' => 119,
                'lang' => 'ko',
                'title' => 'test',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            231 => 
            array (
                'id' => 1101,
                'push_notification_id' => 71,
                'lang' => 'ja',
                'title' => '13事前にご予約いただ ...',
                'body' => '入館登録等の関係上、連絡先等をご登録頂きます。人数の関係等で御参加いただけない場合や開催場所等に変更 ...',
            ),
            232 => 
            array (
                'id' => 1102,
                'push_notification_id' => 71,
                'lang' => 'en',
                'title' => '13 christmas',
                'body' => 'Merry happy ',
            ),
            233 => 
            array (
                'id' => 1103,
                'push_notification_id' => 71,
                'lang' => 'ko',
                'title' => '13事前にご予約いただ ...',
                'body' => '入館登録等の関係上、連絡先等をご登録頂きます。人数の関係等で御参加いただけない場合や開催場所等に変更 ...',
            ),
            234 => 
            array (
                'id' => 1104,
                'push_notification_id' => 120,
                'lang' => 'ja',
                'title' => 'test thu',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            235 => 
            array (
                'id' => 1105,
                'push_notification_id' => 120,
                'lang' => 'en',
                'title' => 'test thu',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            236 => 
            array (
                'id' => 1106,
                'push_notification_id' => 120,
                'lang' => 'ko',
                'title' => 'test thu',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            237 => 
            array (
                'id' => 1107,
                'push_notification_id' => 121,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            238 => 
            array (
                'id' => 1108,
                'push_notification_id' => 121,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            239 => 
            array (
                'id' => 1109,
                'push_notification_id' => 121,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            240 => 
            array (
                'id' => 1110,
                'push_notification_id' => 122,
                'lang' => 'ja',
                'title' => 'Test 4',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            241 => 
            array (
                'id' => 1111,
                'push_notification_id' => 122,
                'lang' => 'en',
                'title' => 'Test 4',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            242 => 
            array (
                'id' => 1112,
                'push_notification_id' => 122,
                'lang' => 'ko',
                'title' => 'Test 4',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            243 => 
            array (
                'id' => 1113,
                'push_notification_id' => 123,
                'lang' => 'ja',
                'title' => 'Test 5',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            244 => 
            array (
                'id' => 1114,
                'push_notification_id' => 123,
                'lang' => 'en',
                'title' => 'Test 5',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            245 => 
            array (
                'id' => 1115,
                'push_notification_id' => 123,
                'lang' => 'ko',
                'title' => 'Test 5',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            246 => 
            array (
                'id' => 1116,
                'push_notification_id' => 124,
                'lang' => 'ja',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            247 => 
            array (
                'id' => 1117,
                'push_notification_id' => 124,
                'lang' => 'en',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            248 => 
            array (
                'id' => 1118,
                'push_notification_id' => 124,
                'lang' => 'ko',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            249 => 
            array (
                'id' => 1119,
                'push_notification_id' => 125,
                'lang' => 'ja',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            250 => 
            array (
                'id' => 1120,
                'push_notification_id' => 125,
                'lang' => 'en',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            251 => 
            array (
                'id' => 1121,
                'push_notification_id' => 125,
                'lang' => 'ko',
                'title' => 'Content thuong',
                'body' => 'Content thuong',
            ),
            252 => 
            array (
                'id' => 1122,
                'push_notification_id' => 126,
                'lang' => 'ja',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            253 => 
            array (
                'id' => 1123,
                'push_notification_id' => 126,
                'lang' => 'en',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            254 => 
            array (
                'id' => 1124,
                'push_notification_id' => 126,
                'lang' => 'ko',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            255 => 
            array (
                'id' => 1125,
                'push_notification_id' => 127,
                'lang' => 'ja',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成',
            ),
            256 => 
            array (
                'id' => 1126,
                'push_notification_id' => 127,
                'lang' => 'en',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成',
            ),
            257 => 
            array (
                'id' => 1127,
                'push_notification_id' => 127,
                'lang' => 'ko',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成',
            ),
            258 => 
            array (
                'id' => 1128,
                'push_notification_id' => 128,
                'lang' => 'ja',
                'title' => 'テクノロジー',
                'body' => 'テクノロジー',
            ),
            259 => 
            array (
                'id' => 1129,
                'push_notification_id' => 128,
                'lang' => 'en',
                'title' => 'テクノロジー',
                'body' => 'テクノロジー',
            ),
            260 => 
            array (
                'id' => 1130,
                'push_notification_id' => 128,
                'lang' => 'ko',
                'title' => 'テクノロジー',
                'body' => 'テクノロジー',
            ),
            261 => 
            array (
                'id' => 1131,
                'push_notification_id' => 129,
                'lang' => 'ja',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            262 => 
            array (
                'id' => 1132,
                'push_notification_id' => 129,
                'lang' => 'en',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            263 => 
            array (
                'id' => 1133,
                'push_notification_id' => 129,
                'lang' => 'ko',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            264 => 
            array (
                'id' => 1134,
                'push_notification_id' => 130,
                'lang' => 'ja',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            265 => 
            array (
                'id' => 1135,
                'push_notification_id' => 130,
                'lang' => 'en',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            266 => 
            array (
                'id' => 1136,
                'push_notification_id' => 130,
                'lang' => 'ko',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            267 => 
            array (
                'id' => 1137,
                'push_notification_id' => 131,
                'lang' => 'ja',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            268 => 
            array (
                'id' => 1138,
                'push_notification_id' => 131,
                'lang' => 'en',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            269 => 
            array (
                'id' => 1139,
                'push_notification_id' => 131,
                'lang' => 'ko',
                'title' => 'Content thuong1111',
                'body' => 'Content thuong1111',
            ),
            270 => 
            array (
                'id' => 1140,
                'push_notification_id' => 132,
                'lang' => 'ja',
                'title' => 'Content thuong1111',
                'body' => 'The approach is just the difference here',
            ),
            271 => 
            array (
                'id' => 1141,
                'push_notification_id' => 132,
                'lang' => 'en',
                'title' => 'Content thuong1111',
                'body' => 'The approach is just the difference here',
            ),
            272 => 
            array (
                'id' => 1142,
                'push_notification_id' => 132,
                'lang' => 'ko',
                'title' => 'Content thuong1111',
                'body' => 'The approach is just the difference here',
            ),
            273 => 
            array (
                'id' => 1143,
                'push_notification_id' => 133,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            274 => 
            array (
                'id' => 1144,
                'push_notification_id' => 133,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            275 => 
            array (
                'id' => 1145,
                'push_notification_id' => 133,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            276 => 
            array (
                'id' => 1146,
                'push_notification_id' => 134,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            277 => 
            array (
                'id' => 1147,
                'push_notification_id' => 134,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            278 => 
            array (
                'id' => 1148,
                'push_notification_id' => 134,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            279 => 
            array (
                'id' => 1149,
                'push_notification_id' => 135,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            280 => 
            array (
                'id' => 1150,
                'push_notification_id' => 135,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            281 => 
            array (
                'id' => 1151,
                'push_notification_id' => 135,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            282 => 
            array (
                'id' => 1152,
                'push_notification_id' => 136,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            283 => 
            array (
                'id' => 1153,
                'push_notification_id' => 136,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            284 => 
            array (
                'id' => 1154,
                'push_notification_id' => 136,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            285 => 
            array (
                'id' => 1155,
                'push_notification_id' => 137,
                'lang' => 'ja',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            286 => 
            array (
                'id' => 1156,
                'push_notification_id' => 137,
                'lang' => 'en',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            287 => 
            array (
                'id' => 1157,
                'push_notification_id' => 137,
                'lang' => 'ko',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            288 => 
            array (
                'id' => 1158,
                'push_notification_id' => 138,
                'lang' => 'ja',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            289 => 
            array (
                'id' => 1159,
                'push_notification_id' => 138,
                'lang' => 'en',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            290 => 
            array (
                'id' => 1160,
                'push_notification_id' => 138,
                'lang' => 'ko',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            291 => 
            array (
                'id' => 1161,
                'push_notification_id' => 139,
                'lang' => 'ja',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            292 => 
            array (
                'id' => 1162,
                'push_notification_id' => 139,
                'lang' => 'en',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            293 => 
            array (
                'id' => 1163,
                'push_notification_id' => 139,
                'lang' => 'ko',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            294 => 
            array (
                'id' => 1164,
                'push_notification_id' => 136,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            295 => 
            array (
                'id' => 1165,
                'push_notification_id' => 136,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            296 => 
            array (
                'id' => 1166,
                'push_notification_id' => 136,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            297 => 
            array (
                'id' => 1167,
                'push_notification_id' => 137,
                'lang' => 'ja',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            298 => 
            array (
                'id' => 1168,
                'push_notification_id' => 137,
                'lang' => 'en',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            299 => 
            array (
                'id' => 1169,
                'push_notification_id' => 137,
                'lang' => 'ko',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            300 => 
            array (
                'id' => 1170,
                'push_notification_id' => 138,
                'lang' => 'ja',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            301 => 
            array (
                'id' => 1171,
                'push_notification_id' => 138,
                'lang' => 'en',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            302 => 
            array (
                'id' => 1172,
                'push_notification_id' => 138,
                'lang' => 'ko',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            303 => 
            array (
                'id' => 1173,
                'push_notification_id' => 139,
                'lang' => 'ja',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            304 => 
            array (
                'id' => 1174,
                'push_notification_id' => 139,
                'lang' => 'en',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            305 => 
            array (
                'id' => 1175,
                'push_notification_id' => 139,
                'lang' => 'ko',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            306 => 
            array (
                'id' => 1176,
                'push_notification_id' => 136,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            307 => 
            array (
                'id' => 1177,
                'push_notification_id' => 136,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            308 => 
            array (
                'id' => 1178,
                'push_notification_id' => 136,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            309 => 
            array (
                'id' => 1179,
                'push_notification_id' => 137,
                'lang' => 'ja',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            310 => 
            array (
                'id' => 1180,
                'push_notification_id' => 137,
                'lang' => 'en',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            311 => 
            array (
                'id' => 1181,
                'push_notification_id' => 137,
                'lang' => 'ko',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            312 => 
            array (
                'id' => 1182,
                'push_notification_id' => 138,
                'lang' => 'ja',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            313 => 
            array (
                'id' => 1183,
                'push_notification_id' => 138,
                'lang' => 'en',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            314 => 
            array (
                'id' => 1184,
                'push_notification_id' => 138,
                'lang' => 'ko',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            315 => 
            array (
                'id' => 1185,
                'push_notification_id' => 139,
                'lang' => 'ja',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            316 => 
            array (
                'id' => 1186,
                'push_notification_id' => 139,
                'lang' => 'en',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            317 => 
            array (
                'id' => 1187,
                'push_notification_id' => 139,
                'lang' => 'ko',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            318 => 
            array (
                'id' => 1188,
                'push_notification_id' => 128,
                'lang' => 'ja',
                'title' => 'テクノロジー',
                'body' => 'テクノロジー',
            ),
            319 => 
            array (
                'id' => 1189,
                'push_notification_id' => 128,
                'lang' => 'en',
                'title' => 'テクノロジー',
                'body' => 'テクノロジー',
            ),
            320 => 
            array (
                'id' => 1190,
                'push_notification_id' => 128,
                'lang' => 'ko',
                'title' => 'テクノロジー',
                'body' => 'テクノロジー',
            ),
            321 => 
            array (
                'id' => 1191,
                'push_notification_id' => 136,
                'lang' => 'ja',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            322 => 
            array (
                'id' => 1192,
                'push_notification_id' => 136,
                'lang' => 'en',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            323 => 
            array (
                'id' => 1193,
                'push_notification_id' => 136,
                'lang' => 'ko',
                'title' => 'daubv test push noti ...',
                'body' => 'daubv test push notificaation',
            ),
            324 => 
            array (
                'id' => 1194,
                'push_notification_id' => 137,
                'lang' => 'ja',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            325 => 
            array (
                'id' => 1195,
                'push_notification_id' => 137,
                'lang' => 'en',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            326 => 
            array (
                'id' => 1196,
                'push_notification_id' => 137,
                'lang' => 'ko',
                'title' => 'Thu Push',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            327 => 
            array (
                'id' => 1197,
                'push_notification_id' => 138,
                'lang' => 'ja',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            328 => 
            array (
                'id' => 1198,
                'push_notification_id' => 138,
                'lang' => 'en',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            329 => 
            array (
                'id' => 1199,
                'push_notification_id' => 138,
                'lang' => 'ko',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            330 => 
            array (
                'id' => 1200,
                'push_notification_id' => 139,
                'lang' => 'ja',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            331 => 
            array (
                'id' => 1201,
                'push_notification_id' => 139,
                'lang' => 'en',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            332 => 
            array (
                'id' => 1202,
                'push_notification_id' => 139,
                'lang' => 'ko',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            333 => 
            array (
                'id' => 1203,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            334 => 
            array (
                'id' => 1204,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            335 => 
            array (
                'id' => 1205,
                'push_notification_id' => 140,
                'lang' => 'ko',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            336 => 
            array (
                'id' => 1206,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            337 => 
            array (
                'id' => 1207,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            338 => 
            array (
                'id' => 1208,
                'push_notification_id' => 141,
                'lang' => 'ko',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            339 => 
            array (
                'id' => 1209,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            340 => 
            array (
                'id' => 1210,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            341 => 
            array (
                'id' => 1211,
                'push_notification_id' => 142,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            342 => 
            array (
                'id' => 1212,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            343 => 
            array (
                'id' => 1213,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            344 => 
            array (
                'id' => 1214,
                'push_notification_id' => 141,
                'lang' => 'ko',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            345 => 
            array (
                'id' => 1215,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            346 => 
            array (
                'id' => 1216,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            347 => 
            array (
                'id' => 1217,
                'push_notification_id' => 142,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            348 => 
            array (
                'id' => 1218,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            349 => 
            array (
                'id' => 1219,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            350 => 
            array (
                'id' => 1220,
                'push_notification_id' => 141,
                'lang' => 'ko',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            351 => 
            array (
                'id' => 1221,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            352 => 
            array (
                'id' => 1222,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            353 => 
            array (
                'id' => 1223,
                'push_notification_id' => 142,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            354 => 
            array (
                'id' => 1224,
                'push_notification_id' => 139,
                'lang' => 'ja',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            355 => 
            array (
                'id' => 1225,
                'push_notification_id' => 139,
                'lang' => 'en',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            356 => 
            array (
                'id' => 1226,
                'push_notification_id' => 139,
                'lang' => 'ko',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            357 => 
            array (
                'id' => 1227,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            358 => 
            array (
                'id' => 1228,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            359 => 
            array (
                'id' => 1229,
                'push_notification_id' => 140,
                'lang' => 'ko',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            360 => 
            array (
                'id' => 1230,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            361 => 
            array (
                'id' => 1231,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            362 => 
            array (
                'id' => 1232,
                'push_notification_id' => 140,
                'lang' => 'ko',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            363 => 
            array (
                'id' => 1233,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            364 => 
            array (
                'id' => 1234,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            365 => 
            array (
                'id' => 1235,
                'push_notification_id' => 141,
                'lang' => 'ko',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            366 => 
            array (
                'id' => 1236,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            367 => 
            array (
                'id' => 1237,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            368 => 
            array (
                'id' => 1238,
                'push_notification_id' => 142,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            369 => 
            array (
                'id' => 1239,
                'push_notification_id' => 138,
                'lang' => 'ja',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            370 => 
            array (
                'id' => 1240,
                'push_notification_id' => 138,
                'lang' => 'en',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            371 => 
            array (
                'id' => 1241,
                'push_notification_id' => 138,
                'lang' => 'ko',
                'title' => 'Thu push 222222',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            372 => 
            array (
                'id' => 1242,
                'push_notification_id' => 139,
                'lang' => 'ja',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            373 => 
            array (
                'id' => 1243,
                'push_notification_id' => 139,
                'lang' => 'en',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            374 => 
            array (
                'id' => 1244,
                'push_notification_id' => 139,
                'lang' => 'ko',
                'title' => 'Thu push 3 Thu push ...',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            375 => 
            array (
                'id' => 1245,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            376 => 
            array (
                'id' => 1246,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            377 => 
            array (
                'id' => 1247,
                'push_notification_id' => 140,
                'lang' => 'ko',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            378 => 
            array (
                'id' => 1248,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            379 => 
            array (
                'id' => 1249,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            380 => 
            array (
                'id' => 1250,
                'push_notification_id' => 141,
                'lang' => 'ko',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            381 => 
            array (
                'id' => 1251,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            382 => 
            array (
                'id' => 1252,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            383 => 
            array (
                'id' => 1253,
                'push_notification_id' => 142,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            384 => 
            array (
                'id' => 1254,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            385 => 
            array (
                'id' => 1255,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            386 => 
            array (
                'id' => 1256,
                'push_notification_id' => 140,
                'lang' => 'ko',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            387 => 
            array (
                'id' => 1257,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            388 => 
            array (
                'id' => 1258,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            389 => 
            array (
                'id' => 1259,
                'push_notification_id' => 141,
                'lang' => 'ko',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            390 => 
            array (
                'id' => 1260,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            391 => 
            array (
                'id' => 1261,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            392 => 
            array (
                'id' => 1262,
                'push_notification_id' => 142,
                'lang' => 'ko',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            393 => 
            array (
                'id' => 1263,
                'push_notification_id' => 143,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            394 => 
            array (
                'id' => 1264,
                'push_notification_id' => 143,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Viet Nam',
            ),
            395 => 
            array (
                'id' => 1265,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            396 => 
            array (
                'id' => 1266,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            397 => 
            array (
                'id' => 1267,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            398 => 
            array (
                'id' => 1268,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            399 => 
            array (
                'id' => 1269,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            400 => 
            array (
                'id' => 1270,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            401 => 
            array (
                'id' => 1271,
                'push_notification_id' => 143,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            402 => 
            array (
                'id' => 1272,
                'push_notification_id' => 143,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Viet Nam',
            ),
            403 => 
            array (
                'id' => 1273,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            404 => 
            array (
                'id' => 1274,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            405 => 
            array (
                'id' => 1275,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            406 => 
            array (
                'id' => 1276,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            407 => 
            array (
                'id' => 1277,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            408 => 
            array (
                'id' => 1278,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            409 => 
            array (
                'id' => 1279,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            410 => 
            array (
                'id' => 1280,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            411 => 
            array (
                'id' => 1281,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            412 => 
            array (
                'id' => 1282,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            413 => 
            array (
                'id' => 1283,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            414 => 
            array (
                'id' => 1284,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            415 => 
            array (
                'id' => 1285,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            416 => 
            array (
                'id' => 1286,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            417 => 
            array (
                'id' => 1287,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            418 => 
            array (
                'id' => 1288,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            419 => 
            array (
                'id' => 1289,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            420 => 
            array (
                'id' => 1290,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            421 => 
            array (
                'id' => 1291,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            422 => 
            array (
                'id' => 1292,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            423 => 
            array (
                'id' => 1293,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            424 => 
            array (
                'id' => 1294,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            425 => 
            array (
                'id' => 1295,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            426 => 
            array (
                'id' => 1296,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            427 => 
            array (
                'id' => 1297,
                'push_notification_id' => 140,
                'lang' => 'ja',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            428 => 
            array (
                'id' => 1298,
                'push_notification_id' => 140,
                'lang' => 'en',
                'title' => 'Test 1',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            429 => 
            array (
                'id' => 1299,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            430 => 
            array (
                'id' => 1300,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            431 => 
            array (
                'id' => 1301,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            432 => 
            array (
                'id' => 1302,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            433 => 
            array (
                'id' => 1303,
                'push_notification_id' => 146,
                'lang' => 'ja',
                'title' => 'test push',
                'body' => 'dfc',
            ),
            434 => 
            array (
                'id' => 1304,
                'push_notification_id' => 146,
                'lang' => 'en',
                'title' => 'test push',
                'body' => 'dfc',
            ),
            435 => 
            array (
                'id' => 1305,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            436 => 
            array (
                'id' => 1306,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            437 => 
            array (
                'id' => 1307,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            438 => 
            array (
                'id' => 1308,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            439 => 
            array (
                'id' => 1309,
                'push_notification_id' => 143,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            440 => 
            array (
                'id' => 1310,
                'push_notification_id' => 143,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Viet Nam',
            ),
            441 => 
            array (
                'id' => 1311,
                'push_notification_id' => 147,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            442 => 
            array (
                'id' => 1312,
                'push_notification_id' => 147,
                'lang' => 'en',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            443 => 
            array (
                'id' => 1313,
                'push_notification_id' => 141,
                'lang' => 'ja',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            444 => 
            array (
                'id' => 1314,
                'push_notification_id' => 141,
                'lang' => 'en',
                'title' => 'Test 2',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            445 => 
            array (
                'id' => 1315,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            446 => 
            array (
                'id' => 1316,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            447 => 
            array (
                'id' => 1317,
                'push_notification_id' => 143,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            448 => 
            array (
                'id' => 1318,
                'push_notification_id' => 143,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Viet Nam',
            ),
            449 => 
            array (
                'id' => 1319,
                'push_notification_id' => 142,
                'lang' => 'ja',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            450 => 
            array (
                'id' => 1320,
                'push_notification_id' => 142,
                'lang' => 'en',
                'title' => 'Test 3',
                'body' => '家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万 ...',
            ),
            451 => 
            array (
                'id' => 1321,
                'push_notification_id' => 143,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => '児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっ ...',
            ),
            452 => 
            array (
                'id' => 1322,
                'push_notification_id' => 143,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Viet Nam',
            ),
            453 => 
            array (
                'id' => 1323,
                'push_notification_id' => 148,
                'lang' => 'ja',
                'title' => 'You may use chrome c ...',
                'body' => 'You may use chrome custom tabs instead To',
            ),
            454 => 
            array (
                'id' => 1324,
                'push_notification_id' => 148,
                'lang' => 'en',
                'title' => 'You may use chrome c ...',
                'body' => 'You may use chrome custom tabs instead To',
            ),
            455 => 
            array (
                'id' => 1325,
                'push_notification_id' => 149,
                'lang' => 'ja',
                'title' => '131311You may use ch ...',
                'body' => '131311You may use chrome custom tabs instead To',
            ),
            456 => 
            array (
                'id' => 1326,
                'push_notification_id' => 149,
                'lang' => 'en',
                'title' => '131311You may use ch ...',
                'body' => '131311You may use chrome custom tabs instead To',
            ),
            457 => 
            array (
                'id' => 1327,
                'push_notification_id' => 150,
                'lang' => 'ja',
                'title' => '241252 may use chrom ...',
                'body' => '241252 may use chrome custom tabs instead To',
            ),
            458 => 
            array (
                'id' => 1328,
                'push_notification_id' => 150,
                'lang' => 'en',
                'title' => '241252 may use chrom ...',
                'body' => '241252 may use chrome custom tabs instead To',
            ),
            459 => 
            array (
                'id' => 1329,
                'push_notification_id' => 151,
                'lang' => 'ja',
                'title' => '241252 may use chrom ...',
                'body' => '241252 may use chrome custom tabs instead To',
            ),
            460 => 
            array (
                'id' => 1330,
                'push_notification_id' => 151,
                'lang' => 'en',
                'title' => '241252 may use chrom ...',
                'body' => '241252 may use chrome custom tabs instead To',
            ),
            461 => 
            array (
                'id' => 1331,
                'push_notification_id' => 152,
                'lang' => 'ja',
                'title' => '222222222222',
                'body' => 'Hello vinicorp',
            ),
            462 => 
            array (
                'id' => 1332,
                'push_notification_id' => 152,
                'lang' => 'en',
                'title' => '222222222222',
                'body' => 'Hello vinicorp',
            ),
            463 => 
            array (
                'id' => 1333,
                'push_notification_id' => 153,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            464 => 
            array (
                'id' => 1334,
                'push_notification_id' => 153,
                'lang' => 'en',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            465 => 
            array (
                'id' => 1335,
                'push_notification_id' => 154,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            466 => 
            array (
                'id' => 1336,
                'push_notification_id' => 154,
                'lang' => 'en',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            467 => 
            array (
                'id' => 1337,
                'push_notification_id' => 155,
                'lang' => 'ja',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            468 => 
            array (
                'id' => 1338,
                'push_notification_id' => 155,
                'lang' => 'en',
                'title' => 'オーディオバッチを確 ...',
                'body' => 'オーディオバッチを確認する',
            ),
            469 => 
            array (
                'id' => 1339,
                'push_notification_id' => 11,
                'lang' => 'es',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            470 => 
            array (
                'id' => 1340,
                'push_notification_id' => 11,
                'lang' => 'ja_easy',
                'title' => 'à',
                'body' => 'sdfasd',
            ),
            471 => 
            array (
                'id' => 1341,
                'push_notification_id' => 11,
                'lang' => 'en',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            472 => 
            array (
                'id' => 1342,
                'push_notification_id' => 11,
                'lang' => 'ko',
                'title' => 'fa',
                'body' => 'sádf',
            ),
            473 => 
            array (
                'id' => 1343,
                'push_notification_id' => 12,
                'lang' => 'es',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            474 => 
            array (
                'id' => 1344,
                'push_notification_id' => 12,
                'lang' => 'ja_easy',
                'title' => 'sdf',
                'body' => 'fgsdf',
            ),
            475 => 
            array (
                'id' => 1345,
                'push_notification_id' => 12,
                'lang' => 'en',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            476 => 
            array (
                'id' => 1346,
                'push_notification_id' => 12,
                'lang' => 'ko',
                'title' => 'sdfgsd',
                'body' => 'gsdfg',
            ),
            477 => 
            array (
                'id' => 1347,
                'push_notification_id' => 13,
                'lang' => 'es',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            478 => 
            array (
                'id' => 1348,
                'push_notification_id' => 13,
                'lang' => 'ja_easy',
                'title' => 'sdf',
                'body' => 'sdfsdf',
            ),
            479 => 
            array (
                'id' => 1349,
                'push_notification_id' => 13,
                'lang' => 'en',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            480 => 
            array (
                'id' => 1350,
                'push_notification_id' => 13,
                'lang' => 'ko',
                'title' => 'fd',
                'body' => 'dsfsd',
            ),
            481 => 
            array (
                'id' => 1351,
                'push_notification_id' => 14,
                'lang' => 'es',
                'title' => 'dsc',
                'body' => 'asdc',
            ),
            482 => 
            array (
                'id' => 1352,
                'push_notification_id' => 14,
                'lang' => 'ja_easy',
                'title' => 'sdc',
                'body' => 'sdcsdc',
            ),
            483 => 
            array (
                'id' => 1353,
                'push_notification_id' => 14,
                'lang' => 'en',
                'title' => 'dsc',
                'body' => 'asdc',
            ),
            484 => 
            array (
                'id' => 1354,
                'push_notification_id' => 14,
                'lang' => 'ko',
                'title' => 'dsc',
                'body' => 'asdc',
            ),
            485 => 
            array (
                'id' => 1355,
                'push_notification_id' => 156,
                'lang' => 'ja',
                'title' => 'Test 5 ja',
                'body' => 'Test 5 ja',
            ),
            486 => 
            array (
                'id' => 1356,
                'push_notification_id' => 156,
                'lang' => 'en',
                'title' => 'Test 5 en',
                'body' => 'Test 5 ja',
            ),
            487 => 
            array (
                'id' => 1357,
                'push_notification_id' => 156,
                'lang' => 'ko',
                'title' => 'Test 5 ja',
                'body' => 'Test 5 ja',
            ),
            488 => 
            array (
                'id' => 1358,
                'push_notification_id' => 157,
                'lang' => 'ja',
                'title' => '家庭に次ぐ子3',
                'body' => 'どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どち ...',
            ),
            489 => 
            array (
                'id' => 1359,
                'push_notification_id' => 157,
                'lang' => 'en',
                'title' => 'In the school 3',
                'body' => 'どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どち ...',
            ),
            490 => 
            array (
                'id' => 1360,
                'push_notification_id' => 157,
                'lang' => 'ko',
                'title' => '家庭に次ぐ子3',
                'body' => 'どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どち ...',
            ),
            491 => 
            array (
                'id' => 1361,
                'push_notification_id' => 158,
                'lang' => 'ja',
                'title' => 'かつてに比べ4',
                'body' => '近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、 ...',
            ),
            492 => 
            array (
                'id' => 1362,
                'push_notification_id' => 158,
                'lang' => 'en',
                'title' => '4 compared to the pa ...',
                'body' => '近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、 ...',
            ),
            493 => 
            array (
                'id' => 1363,
                'push_notification_id' => 158,
                'lang' => 'ko',
                'title' => 'かつてに比べ4',
                'body' => '近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、 ...',
            ),
            494 => 
            array (
                'id' => 1364,
                'push_notification_id' => 159,
                'lang' => 'ja',
                'title' => '虐待で保護された5',
                'body' => '子どもたちの多くは十分な学習環境が保障されずに育ちました。進学をあきらめたり、退学してしまったりしな ...',
            ),
            495 => 
            array (
                'id' => 1365,
                'push_notification_id' => 159,
                'lang' => 'en',
                'title' => '虐待で保護された5',
                'body' => 'Many abuse-protected children grew up without a sufficient learning environment. In order to avoid g ...',
            ),
            496 => 
            array (
                'id' => 1366,
                'push_notification_id' => 159,
                'lang' => 'ko',
                'title' => '虐待で保護された5',
                'body' => '子どもたちの多くは十分な学習環境が保障されずに育ちました。進学をあきらめたり、退学してしまったりしな ...',
            ),
            497 => 
            array (
                'id' => 1367,
                'push_notification_id' => 157,
                'lang' => 'ja',
                'title' => '家庭に次ぐ子3',
                'body' => 'どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どち ...',
            ),
            498 => 
            array (
                'id' => 1368,
                'push_notification_id' => 157,
                'lang' => 'en',
                'title' => 'In the school 3',
                'body' => 'どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どち ...',
            ),
            499 => 
            array (
                'id' => 1369,
                'push_notification_id' => 157,
                'lang' => 'ko',
                'title' => '家庭に次ぐ子3',
                'body' => 'どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どち ...',
            ),
        ));
        \DB::table('notification_bodies')->insert(array (
            0 => 
            array (
                'id' => 1370,
                'push_notification_id' => 158,
                'lang' => 'ja',
                'title' => 'かつてに比べ4',
                'body' => '近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、 ...',
            ),
            1 => 
            array (
                'id' => 1371,
                'push_notification_id' => 158,
                'lang' => 'en',
                'title' => '4 compared to the pa ...',
                'body' => '近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、 ...',
            ),
            2 => 
            array (
                'id' => 1372,
                'push_notification_id' => 158,
                'lang' => 'ko',
                'title' => 'かつてに比べ4',
                'body' => '近所づきあいや親戚づきあいも減ってきていたり、新たな居場所となりつつあるインターネットやSNSなどは、 ...',
            ),
            3 => 
            array (
                'id' => 1373,
                'push_notification_id' => 159,
                'lang' => 'ja',
                'title' => '虐待で保護された5',
                'body' => '子どもたちの多くは十分な学習環境が保障されずに育ちました。進学をあきらめたり、退学してしまったりしな ...',
            ),
            4 => 
            array (
                'id' => 1374,
                'push_notification_id' => 159,
                'lang' => 'en',
                'title' => '虐待で保護された5',
                'body' => 'Many abuse-protected children grew up without a sufficient learning environment. In order to avoid g ...',
            ),
            5 => 
            array (
                'id' => 1375,
                'push_notification_id' => 159,
                'lang' => 'ko',
                'title' => '虐待で保護された5',
                'body' => '子どもたちの多くは十分な学習環境が保障されずに育ちました。進学をあきらめたり、退学してしまったりしな ...',
            ),
            6 => 
            array (
                'id' => 1376,
                'push_notification_id' => 160,
                'lang' => 'ja',
                'title' => '相談できる大人が周り',
                'body' => 'にいない子どもたちは、トラブルに巻き込まれたり、深刻な状態で発見されることも少なくありません。3keys ...',
            ),
            7 => 
            array (
                'id' => 1377,
                'push_notification_id' => 160,
                'lang' => 'en',
                'title' => 'Children who do not ...',
                'body' => 'adults who can consult can often get into trouble and be found in serious condition. 3keys has set u ...',
            ),
            8 => 
            array (
                'id' => 1378,
                'push_notification_id' => 160,
                'lang' => 'ko',
                'title' => '相談できる大人が周り',
                'body' => 'にいない子どもたちは、トラブルに巻き込まれたり、深刻な状態で発見されることも少なくありません。3keys ...',
            ),
            9 => 
            array (
                'id' => 1379,
                'push_notification_id' => 161,
                'lang' => 'ja',
                'title' => 'バッチサウンドテスト',
                'body' => 'こんにちはベトナム',
            ),
            10 => 
            array (
                'id' => 1380,
                'push_notification_id' => 161,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Vietnam',
            ),
            11 => 
            array (
                'id' => 1381,
                'push_notification_id' => 161,
                'lang' => 'ko',
                'title' => 'バッチサウンドテスト',
                'body' => 'こんにちはベトナム',
            ),
            12 => 
            array (
                'id' => 1385,
                'push_notification_id' => 160,
                'lang' => 'ja',
                'title' => '相談できる大人が周り',
                'body' => 'にいない子どもたちは、トラブルに巻き込まれたり、深刻な状態で発見されることも少なくありません。3keys ...',
            ),
            13 => 
            array (
                'id' => 1386,
                'push_notification_id' => 160,
                'lang' => 'en',
                'title' => 'Children who do not ...',
                'body' => 'adults who can consult can often get into trouble and be found in serious condition. 3keys has set u ...',
            ),
            14 => 
            array (
                'id' => 1387,
                'push_notification_id' => 160,
                'lang' => 'ko',
                'title' => '相談できる大人が周り',
                'body' => 'にいない子どもたちは、トラブルに巻き込まれたり、深刻な状態で発見されることも少なくありません。3keys ...',
            ),
            15 => 
            array (
                'id' => 1388,
                'push_notification_id' => 161,
                'lang' => 'ja',
                'title' => 'バッチサウンドテスト',
                'body' => 'こんにちはベトナム',
            ),
            16 => 
            array (
                'id' => 1389,
                'push_notification_id' => 161,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Vietnam,&nbsp;we love your country',
            ),
            17 => 
            array (
                'id' => 1390,
                'push_notification_id' => 161,
                'lang' => 'ko',
                'title' => 'バッチサウンドテスト',
                'body' => 'こんにちはベトナム',
            ),
            18 => 
            array (
                'id' => 1391,
                'push_notification_id' => 163,
                'lang' => 'ja',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成お知らせ作成お知らせ作成お知らせ作成お知らせ作成',
            ),
            19 => 
            array (
                'id' => 1392,
                'push_notification_id' => 163,
                'lang' => 'en',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成お知らせ作成お知らせ作成お知らせ作成お知らせ作成',
            ),
            20 => 
            array (
                'id' => 1393,
                'push_notification_id' => 163,
                'lang' => 'ko',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成お知らせ作成お知らせ作成お知らせ作成お知らせ作成',
            ),
            21 => 
            array (
                'id' => 1394,
                'push_notification_id' => 161,
                'lang' => 'ja',
                'title' => 'バッチサウンドテスト',
                'body' => 'こんにちはベトナム',
            ),
            22 => 
            array (
                'id' => 1395,
                'push_notification_id' => 161,
                'lang' => 'en',
                'title' => 'Batch sound test',
                'body' => 'Hello Vietnam,&nbsp;we love your country',
            ),
            23 => 
            array (
                'id' => 1396,
                'push_notification_id' => 161,
                'lang' => 'ko',
                'title' => 'バッチサウンドテスト',
                'body' => 'こんにちはベトナム',
            ),
            24 => 
            array (
                'id' => 1397,
                'push_notification_id' => 163,
                'lang' => 'ja',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成お知らせ作成お知らせ作成お知らせ作成お知らせ作成',
            ),
            25 => 
            array (
                'id' => 1398,
                'push_notification_id' => 163,
                'lang' => 'en',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成お知らせ作成お知らせ作成お知らせ作成お知らせ作成',
            ),
            26 => 
            array (
                'id' => 1399,
                'push_notification_id' => 163,
                'lang' => 'ko',
                'title' => 'お知らせ作成',
                'body' => 'お知らせ作成お知らせ作成お知らせ作成お知らせ作成お知らせ作成',
            ),
            27 => 
            array (
                'id' => 1400,
                'push_notification_id' => 164,
                'lang' => 'ja',
                'title' => '注目のお知らせ期限',
                'body' => 'Welcome&nbsp; to VietNam',
            ),
            28 => 
            array (
                'id' => 1401,
                'push_notification_id' => 164,
                'lang' => 'en',
                'title' => '注目のお知らせ期限',
                'body' => 'Welcome&nbsp; to VietNam',
            ),
            29 => 
            array (
                'id' => 1402,
                'push_notification_id' => 164,
                'lang' => 'ko',
                'title' => '注目のお知らせ期限',
                'body' => 'Welcome&nbsp; to VietNam',
            ),
            30 => 
            array (
                'id' => 1403,
                'push_notification_id' => 165,
                'lang' => 'ja',
                'title' => 'Title push notificat ...',
                'body' => 'Test push Notification&nbsp;&nbsp;',
            ),
            31 => 
            array (
                'id' => 1404,
                'push_notification_id' => 165,
                'lang' => 'en',
                'title' => 'Title push notificat ...',
                'body' => 'Test push Notification&nbsp;&nbsp;',
            ),
            32 => 
            array (
                'id' => 1405,
                'push_notification_id' => 165,
                'lang' => 'ko',
                'title' => 'Title push notificat ...',
                'body' => 'Test push Notification&nbsp;&nbsp;',
            ),
            33 => 
            array (
                'id' => 1406,
                'push_notification_id' => 166,
                'lang' => 'ja',
                'title' => 'well come to Viet Na ...',
                'body' => 'well come to Viet Nam&nbsp;well come to Viet Nam&nbsp;',
            ),
            34 => 
            array (
                'id' => 1407,
                'push_notification_id' => 166,
                'lang' => 'en',
                'title' => 'well come to Viet Na ...',
                'body' => 'well come to Viet Nam&nbsp;well come to Viet Nam&nbsp;',
            ),
            35 => 
            array (
                'id' => 1408,
                'push_notification_id' => 166,
                'lang' => 'ko',
                'title' => 'well come to Viet Na ...',
                'body' => 'well come to Viet Nam&nbsp;well come to Viet Nam&nbsp;',
            ),
            36 => 
            array (
                'id' => 1409,
                'push_notification_id' => 167,
                'lang' => 'ja',
                'title' => '番下まで表示されてか ...',
                'body' => '番下まで表示されてから白色に変わるまで少し時間があるように感じます。',
            ),
            37 => 
            array (
                'id' => 1410,
                'push_notification_id' => 167,
                'lang' => 'en',
                'title' => '番下まで表示されてか ...',
                'body' => '番下まで表示されてから白色に変わるまで少し時間があるように感じます。',
            ),
            38 => 
            array (
                'id' => 1411,
                'push_notification_id' => 167,
                'lang' => 'ko',
                'title' => '番下まで表示されてか ...',
                'body' => '番下まで表示されてから白色に変わるまで少し時間があるように感じます。',
            ),
            39 => 
            array (
                'id' => 1412,
                'push_notification_id' => 168,
                'lang' => 'ja',
                'title' => 'viewContent',
                'body' => '制アップデートのダイアログを非表示にしてほしい',
            ),
            40 => 
            array (
                'id' => 1413,
                'push_notification_id' => 168,
                'lang' => 'en',
                'title' => 'viewContent',
                'body' => '制アップデートのダイアログを非表示にしてほしい',
            ),
            41 => 
            array (
                'id' => 1414,
                'push_notification_id' => 168,
                'lang' => 'ko',
                'title' => 'viewContent',
                'body' => '制アップデートのダイアログを非表示にしてほしい',
            ),
            42 => 
            array (
                'id' => 1415,
                'push_notification_id' => 169,
                'lang' => 'ja',
                'title' => 'Title PushNotificati ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            43 => 
            array (
                'id' => 1416,
                'push_notification_id' => 169,
                'lang' => 'en',
                'title' => 'Title PushNotificati ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            44 => 
            array (
                'id' => 1417,
                'push_notification_id' => 169,
                'lang' => 'ko',
                'title' => 'Title PushNotificati ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            45 => 
            array (
                'id' => 1418,
                'push_notification_id' => 170,
                'lang' => 'ja',
                'title' => 'Title pushnotificati ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            46 => 
            array (
                'id' => 1419,
                'push_notification_id' => 170,
                'lang' => 'en',
                'title' => 'Title pushnotificati ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            47 => 
            array (
                'id' => 1420,
                'push_notification_id' => 170,
                'lang' => 'ko',
                'title' => 'Title pushnotificati ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            48 => 
            array (
                'id' => 1421,
                'push_notification_id' => 171,
                'lang' => 'ja',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            49 => 
            array (
                'id' => 1422,
                'push_notification_id' => 171,
                'lang' => 'en',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            50 => 
            array (
                'id' => 1423,
                'push_notification_id' => 171,
                'lang' => 'ko',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            51 => 
            array (
                'id' => 1424,
                'push_notification_id' => 172,
                'lang' => 'ja',
                'title' => 'ミスベトナム2019',
                'body' => 'グエンデューフォン',
            ),
            52 => 
            array (
                'id' => 1425,
                'push_notification_id' => 172,
                'lang' => 'en',
                'title' => 'Miss Vietnam 2019',
                'body' => 'Nguyen Dieu Huong',
            ),
            53 => 
            array (
                'id' => 1426,
                'push_notification_id' => 172,
                'lang' => 'ko',
                'title' => 'ミスベトナム2019',
                'body' => 'グエンデューフォン',
            ),
            54 => 
            array (
                'id' => 1427,
                'push_notification_id' => 171,
                'lang' => 'ja',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            55 => 
            array (
                'id' => 1428,
                'push_notification_id' => 171,
                'lang' => 'en',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            56 => 
            array (
                'id' => 1429,
                'push_notification_id' => 171,
                'lang' => 'ko',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            57 => 
            array (
                'id' => 1430,
                'push_notification_id' => 172,
                'lang' => 'ja',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            58 => 
            array (
                'id' => 1431,
                'push_notification_id' => 172,
                'lang' => 'en',
                'title' => 'Miss Vietnam 2019',
                'body' => 'Nguyen Dieu Huong has won the crown',
            ),
            59 => 
            array (
                'id' => 1432,
                'push_notification_id' => 172,
                'lang' => 'ko',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            60 => 
            array (
                'id' => 1433,
                'push_notification_id' => 171,
                'lang' => 'ja',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            61 => 
            array (
                'id' => 1434,
                'push_notification_id' => 171,
                'lang' => 'en',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            62 => 
            array (
                'id' => 1435,
                'push_notification_id' => 171,
                'lang' => 'ko',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            63 => 
            array (
                'id' => 1436,
                'push_notification_id' => 172,
                'lang' => 'ja',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            64 => 
            array (
                'id' => 1437,
                'push_notification_id' => 172,
                'lang' => 'en',
                'title' => 'Miss Vietnam 2019',
                'body' => 'Nguyen Dieu Huong has won the crown',
            ),
            65 => 
            array (
                'id' => 1438,
                'push_notification_id' => 172,
                'lang' => 'ko',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            66 => 
            array (
                'id' => 1439,
                'push_notification_id' => 171,
                'lang' => 'ja',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            67 => 
            array (
                'id' => 1440,
                'push_notification_id' => 171,
                'lang' => 'en',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            68 => 
            array (
                'id' => 1441,
                'push_notification_id' => 171,
                'lang' => 'ko',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            69 => 
            array (
                'id' => 1442,
                'push_notification_id' => 172,
                'lang' => 'ja',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            70 => 
            array (
                'id' => 1443,
                'push_notification_id' => 172,
                'lang' => 'en',
                'title' => 'Miss Vietnam 2019',
                'body' => 'Nguyen Dieu Huong has won the crown',
            ),
            71 => 
            array (
                'id' => 1444,
                'push_notification_id' => 172,
                'lang' => 'ko',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            72 => 
            array (
                'id' => 1445,
                'push_notification_id' => 171,
                'lang' => 'ja',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            73 => 
            array (
                'id' => 1446,
                'push_notification_id' => 171,
                'lang' => 'en',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            74 => 
            array (
                'id' => 1447,
                'push_notification_id' => 171,
                'lang' => 'ko',
                'title' => 'Title push notificat ...',
                'body' => '10.2.1でご確認いただいたエビデンスを添付していただけないでしょうか。',
            ),
            75 => 
            array (
                'id' => 1448,
                'push_notification_id' => 172,
                'lang' => 'ja',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            76 => 
            array (
                'id' => 1449,
                'push_notification_id' => 172,
                'lang' => 'en',
                'title' => 'Miss Vietnam 2019',
                'body' => 'Nguyen Dieu Huong has won the crown',
            ),
            77 => 
            array (
                'id' => 1450,
                'push_notification_id' => 172,
                'lang' => 'ko',
                'title' => 'ミスベトナム2019',
                'body' => 'Nguyen Dieu Huongが冠を獲得しました',
            ),
            78 => 
            array (
                'id' => 1451,
                'push_notification_id' => 173,
                'lang' => 'ja',
                'title' => 'hello',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">hello</span></font>',
            ),
            79 => 
            array (
                'id' => 1452,
                'push_notification_id' => 173,
                'lang' => 'en',
                'title' => 'hello',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">hello</span></font>',
            ),
            80 => 
            array (
                'id' => 1453,
                'push_notification_id' => 173,
                'lang' => 'ko',
                'title' => 'hello',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">hello</span></font>',
            ),
            81 => 
            array (
                'id' => 1454,
                'push_notification_id' => 174,
                'lang' => 'ja',
                'title' => 'test thong bao',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test thong bao</span></font>',
            ),
            82 => 
            array (
                'id' => 1455,
                'push_notification_id' => 174,
                'lang' => 'en',
                'title' => 'test thong bao',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test thong bao</span></font>',
            ),
            83 => 
            array (
                'id' => 1456,
                'push_notification_id' => 174,
                'lang' => 'ko',
                'title' => 'test thong bao',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test thong bao</span></font>',
            ),
            84 => 
            array (
                'id' => 1457,
                'push_notification_id' => 175,
                'lang' => 'ja',
                'title' => 'thu hay hay',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu hay hay</span></font>',
            ),
            85 => 
            array (
                'id' => 1458,
                'push_notification_id' => 175,
                'lang' => 'en',
                'title' => 'thu hay hay',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu hay hay</span></font>',
            ),
            86 => 
            array (
                'id' => 1459,
                'push_notification_id' => 175,
                'lang' => 'ko',
                'title' => 'thu hay hay',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">thu hay hay</span></font>',
            ),
            87 => 
            array (
                'id' => 1460,
                'push_notification_id' => 176,
                'lang' => 'ja',
                'title' => 'hello hieu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">hello hieu</span></font>',
            ),
            88 => 
            array (
                'id' => 1461,
                'push_notification_id' => 176,
                'lang' => 'en',
                'title' => 'hello hieu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">hello hieu</span></font>',
            ),
            89 => 
            array (
                'id' => 1462,
                'push_notification_id' => 176,
                'lang' => 'ko',
                'title' => 'hello hieu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">hello hieu</span></font>',
            ),
            90 => 
            array (
                'id' => 1463,
                'push_notification_id' => 177,
                'lang' => 'ja',
                'title' => 'Tag Hieu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Tag Hieu</span></font>',
            ),
            91 => 
            array (
                'id' => 1464,
                'push_notification_id' => 177,
                'lang' => 'en',
                'title' => 'Tag Hieu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Tag Hieu</span></font>',
            ),
            92 => 
            array (
                'id' => 1465,
                'push_notification_id' => 177,
                'lang' => 'ko',
                'title' => 'Tag Hieu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Tag Hieu</span></font>',
            ),
            93 => 
            array (
                'id' => 1466,
                'push_notification_id' => 178,
                'lang' => 'ja',
                'title' => 'Thuthu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thuthu</span></font>',
            ),
            94 => 
            array (
                'id' => 1467,
                'push_notification_id' => 178,
                'lang' => 'en',
                'title' => 'Thuthu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thuthu</span></font>',
            ),
            95 => 
            array (
                'id' => 1468,
                'push_notification_id' => 178,
                'lang' => 'ko',
                'title' => 'Thuthu',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Thuthu</span></font>',
            ),
            96 => 
            array (
                'id' => 1469,
                'push_notification_id' => 180,
                'lang' => 'ja',
                'title' => 'eqweqwe',
                'body' => 'ewqeqweqw',
            ),
            97 => 
            array (
                'id' => 1470,
                'push_notification_id' => 180,
                'lang' => 'en',
                'title' => 'eqweqwe',
                'body' => 'ewqeqweqw',
            ),
            98 => 
            array (
                'id' => 1471,
                'push_notification_id' => 180,
                'lang' => 'ko',
                'title' => 'eqweqwe',
                'body' => 'ewqeqweqw',
            ),
            99 => 
            array (
                'id' => 1472,
                'push_notification_id' => 181,
                'lang' => 'ja',
                'title' => 'eqwewq',
                'body' => 'eqweqe',
            ),
            100 => 
            array (
                'id' => 1473,
                'push_notification_id' => 181,
                'lang' => 'en',
                'title' => 'eqwewq',
                'body' => 'eqweqe',
            ),
            101 => 
            array (
                'id' => 1474,
                'push_notification_id' => 181,
                'lang' => 'ko',
                'title' => 'eqwewq',
                'body' => 'eqweqe',
            ),
            102 => 
            array (
                'id' => 1475,
                'push_notification_id' => 182,
                'lang' => 'ja',
                'title' => 'eqweqw',
                'body' => 'eqwewq',
            ),
            103 => 
            array (
                'id' => 1476,
                'push_notification_id' => 182,
                'lang' => 'en',
                'title' => 'eqweqw',
                'body' => 'eqwewq',
            ),
            104 => 
            array (
                'id' => 1477,
                'push_notification_id' => 182,
                'lang' => 'ko',
                'title' => 'eqweqw',
                'body' => 'eqwewq',
            ),
            105 => 
            array (
                'id' => 1478,
                'push_notification_id' => 184,
                'lang' => 'ja',
                'title' => 'eqwewqe',
                'body' => 'zxzdasdad',
            ),
            106 => 
            array (
                'id' => 1479,
                'push_notification_id' => 184,
                'lang' => 'en',
                'title' => 'eqwewqe',
                'body' => 'zxzdasdad',
            ),
            107 => 
            array (
                'id' => 1480,
                'push_notification_id' => 184,
                'lang' => 'ko',
                'title' => 'eqwewqe',
                'body' => 'zxzdasdad',
            ),
            108 => 
            array (
                'id' => 1481,
                'push_notification_id' => 186,
                'lang' => 'ja',
                'title' => 'Chon Tag',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Chon Tag</span></font>',
            ),
            109 => 
            array (
                'id' => 1482,
                'push_notification_id' => 186,
                'lang' => 'en',
                'title' => 'Chon Tag',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Chon Tag</span></font>',
            ),
            110 => 
            array (
                'id' => 1483,
                'push_notification_id' => 186,
                'lang' => 'ko',
                'title' => 'Chon Tag',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Chon Tag</span></font>',
            ),
            111 => 
            array (
                'id' => 1484,
                'push_notification_id' => 188,
                'lang' => 'ja',
                'title' => 'Mua',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Mua</span></font>',
            ),
            112 => 
            array (
                'id' => 1485,
                'push_notification_id' => 188,
                'lang' => 'en',
                'title' => 'Mua',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Mua</span></font>',
            ),
            113 => 
            array (
                'id' => 1486,
                'push_notification_id' => 188,
                'lang' => 'ko',
                'title' => 'Mua',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body Mua</span></font>',
            ),
            114 => 
            array (
                'id' => 1487,
                'push_notification_id' => 189,
                'lang' => 'ja',
                'title' => 'Demo demo',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Demo demo2</span></font>',
            ),
            115 => 
            array (
                'id' => 1488,
                'push_notification_id' => 189,
                'lang' => 'en',
                'title' => 'Demo demo',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Demo demo2</span></font>',
            ),
            116 => 
            array (
                'id' => 1489,
                'push_notification_id' => 189,
                'lang' => 'ko',
                'title' => 'Demo demo',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Demo demo2</span></font>',
            ),
            117 => 
            array (
                'id' => 1490,
                'push_notification_id' => 192,
                'lang' => 'ja',
                'title' => 'Q Test1',
                'body' => 'dasdads',
            ),
            118 => 
            array (
                'id' => 1491,
                'push_notification_id' => 192,
                'lang' => 'en',
                'title' => 'Q Test1',
                'body' => 'dasdads',
            ),
            119 => 
            array (
                'id' => 1492,
                'push_notification_id' => 192,
                'lang' => 'ko',
                'title' => 'Q Test1',
                'body' => 'dasdads',
            ),
            120 => 
            array (
                'id' => 1493,
                'push_notification_id' => 191,
                'lang' => 'ja',
                'title' => 'test 309',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test 309</span></font>',
            ),
            121 => 
            array (
                'id' => 1494,
                'push_notification_id' => 191,
                'lang' => 'en',
                'title' => 'test 309',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test 309</span></font>',
            ),
            122 => 
            array (
                'id' => 1495,
                'push_notification_id' => 191,
                'lang' => 'ko',
                'title' => 'test 309',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test 309</span></font>',
            ),
            123 => 
            array (
                'id' => 1496,
                'push_notification_id' => 193,
                'lang' => 'ja',
                'title' => 'QTest2',
                'body' => 'adasd',
            ),
            124 => 
            array (
                'id' => 1497,
                'push_notification_id' => 193,
                'lang' => 'en',
                'title' => 'QTest2',
                'body' => 'adasd',
            ),
            125 => 
            array (
                'id' => 1498,
                'push_notification_id' => 193,
                'lang' => 'ko',
                'title' => 'QTest2',
                'body' => 'adasd',
            ),
        ));
        
        
    }
}