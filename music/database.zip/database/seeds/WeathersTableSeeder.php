<?php

use Illuminate\Database\Seeder;

class WeathersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('weathers')->delete();
        
        \DB::table('weathers')->insert(array (
            0 => 
            array (
                'id' => 1,
                'content_id' => 605,
                'weather_div' => 1,
                'lang' => 'ja',
                'title' => '土砂崩れがありました',
                'body' => '土砂崩れがありました',
                'is_speech_generated' => 1,
            ),
            1 => 
            array (
                'id' => 2,
                'content_id' => 606,
                'weather_div' => 1,
                'lang' => 'ja',
                'title' => '222222222',
                'body' => '222222222',
                'is_speech_generated' => 1,
            ),
            2 => 
            array (
                'id' => 3,
                'content_id' => 607,
                'weather_div' => 3,
                'lang' => 'ja',
                'title' => '3333333333333',
                'body' => '3333333333333',
                'is_speech_generated' => 1,
            ),
            3 => 
            array (
                'id' => 4,
                'content_id' => 608,
                'weather_div' => 3,
                'lang' => 'ja',
                'title' => '444444444444',
                'body' => '444444444444444444444444444',
                'is_speech_generated' => 1,
            ),
            4 => 
            array (
                'id' => 5,
                'content_id' => 609,
                'weather_div' => 3,
                'lang' => 'ja',
                'title' => '55555555555',
                'body' => '5555555555555555555555555555555555555555',
                'is_speech_generated' => 1,
            ),
            5 => 
            array (
                'id' => 6,
                'content_id' => 610,
                'weather_div' => 4,
                'lang' => 'ja',
                'title' => '666666',
                'body' => '666666666666666666666666',
                'is_speech_generated' => 1,
            ),
            6 => 
            array (
                'id' => 7,
                'content_id' => 611,
                'weather_div' => 6,
                'lang' => 'ja',
                'title' => '77777777',
                'body' => '777777777777777777777777777777777',
                'is_speech_generated' => 1,
            ),
            7 => 
            array (
                'id' => 8,
                'content_id' => 612,
                'weather_div' => 6,
                'lang' => 'ja',
                'title' => '8888888888888',
                'body' => '888888888888888888888888',
                'is_speech_generated' => 1,
            ),
            8 => 
            array (
                'id' => 9,
                'content_id' => 613,
                'weather_div' => 7,
                'lang' => 'ja',
                'title' => '9999',
                'body' => '99999999999999999999999999999',
                'is_speech_generated' => 1,
            ),
            9 => 
            array (
                'id' => 10,
                'content_id' => 614,
                'weather_div' => 9,
                'lang' => 'ja',
                'title' => '10000000000',
                'body' => '1000000000010000000000',
                'is_speech_generated' => 1,
            ),
            10 => 
            array (
                'id' => 11,
                'content_id' => 615,
                'weather_div' => 9,
                'lang' => 'ja',
                'title' => '1111111111111111111',
                'body' => '11111111111111111111111111111111111',
                'is_speech_generated' => 1,
            ),
            11 => 
            array (
                'id' => 12,
                'content_id' => 616,
                'weather_div' => 13,
                'lang' => 'ja',
                'title' => '122222222222222222222',
                'body' => '22222222222222',
                'is_speech_generated' => 1,
            ),
            12 => 
            array (
                'id' => 13,
                'content_id' => 617,
                'weather_div' => 6,
                'lang' => 'ja',
                'title' => '1444444444444444444444444444',
                'body' => '1444444444444444444444444444144444444444444444444444444',
                'is_speech_generated' => 1,
            ),
            13 => 
            array (
                'id' => 14,
                'content_id' => 618,
                'weather_div' => 7,
                'lang' => 'ja',
                'title' => '津波注意',
                'body' => '津波注意
津波注意
津波注意
津波注意
津波注意
津波注意
津波注意
津波注意',
                'is_speech_generated' => 1,
            ),
            14 => 
            array (
                'id' => 15,
                'content_id' => 619,
                'weather_div' => 9,
                'lang' => 'ja',
                'title' => '1777777777777',
                'body' => '17777777777771777777777777',
                'is_speech_generated' => 1,
            ),
            15 => 
            array (
                'id' => 16,
                'content_id' => 620,
                'weather_div' => 5,
                'lang' => 'ja',
                'title' => '18888888888188888888881888888888818888888888',
                'body' => '1888888888818888888888',
                'is_speech_generated' => 1,
            ),
            16 => 
            array (
                'id' => 17,
                'content_id' => 630,
                'weather_div' => 1,
                'lang' => 'ja',
                'title' => 'ffff',
                'body' => 'fffffffffffffffffffffff',
                'is_speech_generated' => 1,
            ),
            17 => 
            array (
                'id' => 18,
                'content_id' => 633,
                'weather_div' => 2,
                'lang' => 'ja',
                'title' => 'cư',
                'body' => 'wwwwwwwwwww',
                'is_speech_generated' => 1,
            ),
            18 => 
            array (
                'id' => 19,
                'content_id' => 634,
                'weather_div' => 3,
                'lang' => 'ja',
                'title' => 'ggggg',
                'body' => 'ggggggggg',
                'is_speech_generated' => 1,
            ),
            19 => 
            array (
                'id' => 20,
                'content_id' => 654,
                'weather_div' => 2,
                'lang' => 'ja',
                'title' => 'thu day',
                'body' => 'thu day',
                'is_speech_generated' => 1,
            ),
        ));
        
        
    }
}