<?php

use Illuminate\Database\Seeder;

class WeatherSpeechesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('weather_speeches')->delete();
        
        \DB::table('weather_speeches')->insert(array (
            0 => 
            array (
                'id' => 1,
                'weather_id' => 1,
                'lang' => 'ja',
                'storage_file_id' => 2538,
                'weather_updated_at' => '2019-04-22 19:20:04',
                'created_at' => '2019-04-22 19:21:12',
                'updated_at' => '2019-04-22 19:21:12',
            ),
            1 => 
            array (
                'id' => 2,
                'weather_id' => 2,
                'lang' => 'ja',
                'storage_file_id' => 2539,
                'weather_updated_at' => '2019-04-22 19:20:19',
                'created_at' => '2019-04-22 19:21:17',
                'updated_at' => '2019-04-22 19:21:17',
            ),
            2 => 
            array (
                'id' => 3,
                'weather_id' => 3,
                'lang' => 'ja',
                'storage_file_id' => 2540,
                'weather_updated_at' => '2019-04-22 19:20:28',
                'created_at' => '2019-04-22 19:21:21',
                'updated_at' => '2019-04-22 19:21:21',
            ),
            3 => 
            array (
                'id' => 4,
                'weather_id' => 4,
                'lang' => 'ja',
                'storage_file_id' => 2541,
                'weather_updated_at' => '2019-04-22 19:20:37',
                'created_at' => '2019-04-22 19:21:26',
                'updated_at' => '2019-04-22 19:21:26',
            ),
            4 => 
            array (
                'id' => 5,
                'weather_id' => 5,
                'lang' => 'ja',
                'storage_file_id' => 2542,
                'weather_updated_at' => '2019-04-22 19:20:47',
                'created_at' => '2019-04-22 19:21:31',
                'updated_at' => '2019-04-22 19:21:31',
            ),
            5 => 
            array (
                'id' => 6,
                'weather_id' => 6,
                'lang' => 'ja',
                'storage_file_id' => 2543,
                'weather_updated_at' => '2019-04-22 19:20:56',
                'created_at' => '2019-04-22 19:21:35',
                'updated_at' => '2019-04-22 19:21:35',
            ),
            6 => 
            array (
                'id' => 7,
                'weather_id' => 7,
                'lang' => 'ja',
                'storage_file_id' => 2544,
                'weather_updated_at' => '2019-04-22 19:21:08',
                'created_at' => '2019-04-22 19:22:10',
                'updated_at' => '2019-04-22 19:22:10',
            ),
            7 => 
            array (
                'id' => 8,
                'weather_id' => 8,
                'lang' => 'ja',
                'storage_file_id' => 2545,
                'weather_updated_at' => '2019-04-22 19:21:16',
                'created_at' => '2019-04-22 19:22:15',
                'updated_at' => '2019-04-22 19:22:15',
            ),
            8 => 
            array (
                'id' => 9,
                'weather_id' => 9,
                'lang' => 'ja',
                'storage_file_id' => 2546,
                'weather_updated_at' => '2019-04-22 19:21:25',
                'created_at' => '2019-04-22 19:22:19',
                'updated_at' => '2019-04-22 19:22:19',
            ),
            9 => 
            array (
                'id' => 10,
                'weather_id' => 10,
                'lang' => 'ja',
                'storage_file_id' => 2547,
                'weather_updated_at' => '2019-04-22 19:21:39',
                'created_at' => '2019-04-22 19:22:23',
                'updated_at' => '2019-04-22 19:22:23',
            ),
            10 => 
            array (
                'id' => 11,
                'weather_id' => 11,
                'lang' => 'ja',
                'storage_file_id' => 2548,
                'weather_updated_at' => '2019-04-22 19:21:48',
                'created_at' => '2019-04-22 19:22:28',
                'updated_at' => '2019-04-22 19:22:28',
            ),
            11 => 
            array (
                'id' => 12,
                'weather_id' => 12,
                'lang' => 'ja',
                'storage_file_id' => 2549,
                'weather_updated_at' => '2019-04-22 19:21:58',
                'created_at' => '2019-04-22 19:22:32',
                'updated_at' => '2019-04-22 19:22:32',
            ),
            12 => 
            array (
                'id' => 13,
                'weather_id' => 13,
                'lang' => 'ja',
                'storage_file_id' => 2550,
                'weather_updated_at' => '2019-04-22 19:22:39',
                'created_at' => '2019-04-22 19:23:15',
                'updated_at' => '2019-04-22 19:23:15',
            ),
            13 => 
            array (
                'id' => 14,
                'weather_id' => 14,
                'lang' => 'ja',
                'storage_file_id' => 2551,
                'weather_updated_at' => '2019-04-22 19:23:09',
                'created_at' => '2019-04-22 19:24:10',
                'updated_at' => '2019-04-22 19:24:10',
            ),
            14 => 
            array (
                'id' => 15,
                'weather_id' => 15,
                'lang' => 'ja',
                'storage_file_id' => 2552,
                'weather_updated_at' => '2019-04-22 19:27:08',
                'created_at' => '2019-04-22 19:28:11',
                'updated_at' => '2019-04-22 19:28:11',
            ),
            15 => 
            array (
                'id' => 16,
                'weather_id' => 16,
                'lang' => 'ja',
                'storage_file_id' => 2553,
                'weather_updated_at' => '2019-04-22 19:27:32',
                'created_at' => '2019-04-22 19:28:17',
                'updated_at' => '2019-04-22 19:28:17',
            ),
            16 => 
            array (
                'id' => 17,
                'weather_id' => 17,
                'lang' => 'ja',
                'storage_file_id' => 2575,
                'weather_updated_at' => '2019-04-26 15:17:31',
                'created_at' => '2019-04-26 15:18:10',
                'updated_at' => '2019-04-26 15:18:10',
            ),
            17 => 
            array (
                'id' => 18,
                'weather_id' => 18,
                'lang' => 'ja',
                'storage_file_id' => 2578,
                'weather_updated_at' => '2019-04-26 15:36:08',
                'created_at' => '2019-04-26 15:37:10',
                'updated_at' => '2019-04-26 15:37:10',
            ),
            18 => 
            array (
                'id' => 19,
                'weather_id' => 19,
                'lang' => 'ja',
                'storage_file_id' => 2579,
                'weather_updated_at' => '2019-04-26 15:37:45',
                'created_at' => '2019-04-26 15:38:09',
                'updated_at' => '2019-04-26 15:38:09',
            ),
            19 => 
            array (
                'id' => 20,
                'weather_id' => 20,
                'lang' => 'ja',
                'storage_file_id' => 2613,
                'weather_updated_at' => '2019-05-02 13:45:45',
                'created_at' => '2019-05-02 13:46:10',
                'updated_at' => '2019-05-02 13:46:10',
            ),
        ));
        
        
    }
}