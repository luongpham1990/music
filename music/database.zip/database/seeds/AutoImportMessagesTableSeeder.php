<?php

use Illuminate\Database\Seeder;

class AutoImportMessagesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_messages')->delete();
        
        \DB::table('auto_import_messages')->insert(array (
            0 => 
            array (
                'id' => 1,
                'auto_import_id' => 1,
                'lang' => 'es',
                'title' => 'spa_tittle',
                'body' => '[@pubDate]
[@ categories]',
            ),
            1 => 
            array (
                'id' => 2,
                'auto_import_id' => 1,
                'lang' => 'ja_easy',
                'title' => 'ja_easy',
                'body' => '[@title]
[@body]',
            ),
            2 => 
            array (
                'id' => 5,
                'auto_import_id' => 9,
                'lang' => 'ja',
                'title' => 'eded',
                'body' => '[@link]
[@body]',
            ),
            3 => 
            array (
                'id' => 6,
                'auto_import_id' => 9,
                'lang' => 'ko',
                'title' => 'ggggggghhhh',
                'body' => 'hd
fdfd
f
f
ds
f',
            ),
            4 => 
            array (
                'id' => 7,
                'auto_import_id' => 10,
                'lang' => 'ko',
                'title' => '2323',
                'body' => '23',
            ),
            5 => 
            array (
                'id' => 8,
                'auto_import_id' => 10,
                'lang' => 'ja',
                'title' => '32',
                'body' => '2',
            ),
            6 => 
            array (
                'id' => 9,
                'auto_import_id' => 1,
                'lang' => 'ja',
                'title' => 'dsfsf',
                'body' => 'contentf

fsdf
sfa
[@pubDate]
[@link]
[@body]',
            ),
            7 => 
            array (
                'id' => 10,
                'auto_import_id' => 1,
                'lang' => 'ko',
                'title' => ';l;lk;',
                'body' => '[@Link]
[@title]

[@Link]
[@body]
[@categories]
[@categories]
[@link]
[@categories]',
            ),
            8 => 
            array (
                'id' => 11,
                'auto_import_id' => 12,
                'lang' => 'ko',
                'title' => 'Content 1',
                'body' => 'e
e

[@title]
[@Link]
[@Link]
[@Link]
[@Link]
[@title]
[@title]
[@title]',
            ),
            9 => 
            array (
                'id' => 12,
                'auto_import_id' => 12,
                'lang' => 'ja',
                'title' => 'Content 2',
                'body' => '1
2
3
[@title]
[@Link]',
            ),
            10 => 
            array (
                'id' => 13,
                'auto_import_id' => 13,
                'lang' => 'ko',
                'title' => '件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名 件名',
                'body' => '[@title]
[@Link]
[@Link]
[@title]
[@pubDate]
[@pubDate]
[@categories]
[@categories]
[@body]',
            ),
            11 => 
            array (
                'id' => 14,
                'auto_import_id' => 13,
                'lang' => 'ja',
                'title' => '名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名',
                'body' => '名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名
名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名名',
            ),
            12 => 
            array (
                'id' => 15,
                'auto_import_id' => 14,
                'lang' => 'ja',
                'title' => 'dfdsf',
                'body' => 'dfdsfsd',
            ),
            13 => 
            array (
                'id' => 16,
                'auto_import_id' => 14,
                'lang' => 'tl',
                'title' => 'sfdsf',
                'body' => 'dsfdsf',
            ),
            14 => 
            array (
                'id' => 17,
                'auto_import_id' => 15,
                'lang' => 'ja',
                'title' => 'demooooooooooooooooooooooooooooooooooooooooooooooo',
                'body' => NULL,
            ),
            15 => 
            array (
                'id' => 18,
                'auto_import_id' => 15,
                'lang' => 'tl',
                'title' => 'testtttttttttttttttttttttttttttttttttttt',
                'body' => NULL,
            ),
            16 => 
            array (
                'id' => 21,
                'auto_import_id' => 17,
                'lang' => 'ja',
                'title' => 'ádas',
                'body' => 'dasdasd',
            ),
            17 => 
            array (
                'id' => 22,
                'auto_import_id' => 17,
                'lang' => 'en',
                'title' => 'asdasdad',
                'body' => 'dasdsdad',
            ),
            18 => 
            array (
                'id' => 25,
                'auto_import_id' => 19,
                'lang' => 'ja',
                'title' => 'sdasd',
                'body' => 'd
[@link]
[@link]',
            ),
            19 => 
            array (
                'id' => 26,
                'auto_import_id' => 19,
                'lang' => 'en',
                'title' => 'ddddd',
                'body' => 'dasd',
            ),
            20 => 
            array (
                'id' => 27,
                'auto_import_id' => 20,
                'lang' => 'ja',
                'title' => 'ja_title',
                'body' => '[@title]
[@body]
[@link]',
            ),
            21 => 
            array (
                'id' => 28,
                'auto_import_id' => 20,
                'lang' => 'en',
                'title' => 'en_title',
                'body' => '[@categories]
[@pubDate]',
            ),
            22 => 
            array (
                'id' => 29,
                'auto_import_id' => 21,
                'lang' => 'ja',
                'title' => 'ja_title',
                'body' => 'dfdfdfd
[@title]',
            ),
            23 => 
            array (
                'id' => 30,
                'auto_import_id' => 21,
                'lang' => 'en',
                'title' => 'en_title',
                'body' => '[@title]',
            ),
            24 => 
            array (
                'id' => 37,
                'auto_import_id' => 23,
                'lang' => 'es',
                'title' => 'spa_tittle',
                'body' => '[@pubDate]',
            ),
            25 => 
            array (
                'id' => 38,
                'auto_import_id' => 23,
                'lang' => 'ja_easy',
                'title' => 'ja_easy',
                'body' => '[@body]
[@title]',
            ),
            26 => 
            array (
                'id' => 39,
                'auto_import_id' => 24,
                'lang' => 'es',
                'title' => 'ngôn ngữ',
                'body' => '[@title]
[@pubDate]',
            ),
            27 => 
            array (
                'id' => 40,
                'auto_import_id' => 24,
                'lang' => 'ja_easy',
                'title' => 'fd',
                'body' => 'fdf

[@title]',
            ),
            28 => 
            array (
                'id' => 53,
                'auto_import_id' => 29,
                'lang' => 'ja',
                'title' => 'title webpage ja',
                'body' => NULL,
            ),
            29 => 
            array (
                'id' => 54,
                'auto_import_id' => 29,
                'lang' => 'en',
                'title' => NULL,
                'body' => NULL,
            ),
            30 => 
            array (
                'id' => 55,
                'auto_import_id' => 29,
                'lang' => 'ko',
                'title' => NULL,
                'body' => NULL,
            ),
            31 => 
            array (
                'id' => 56,
                'auto_import_id' => 30,
                'lang' => 'ja',
                'title' => 'ggggggg',
                'body' => NULL,
            ),
            32 => 
            array (
                'id' => 57,
                'auto_import_id' => 30,
                'lang' => 'en',
                'title' => NULL,
                'body' => NULL,
            ),
            33 => 
            array (
                'id' => 58,
                'auto_import_id' => 30,
                'lang' => 'ko',
                'title' => NULL,
                'body' => NULL,
            ),
        ));
        
        
    }
}