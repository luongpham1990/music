<?php

use Illuminate\Database\Seeder;

class WebsitesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('websites')->delete();
        
        \DB::table('websites')->insert(array (
            0 => 
            array (
                'id' => 8,
                'content_id' => 125,
                'lang' => 'es',
                'title' => 'colen khong',
                'body' => 'colen khong',
            ),
            1 => 
            array (
                'id' => 12,
                'content_id' => 156,
                'lang' => 'zh',
                'title' => 'test validate webpage required 1',
                'body' => 'test validate webpage required 1',
            ),
            2 => 
            array (
                'id' => 17,
                'content_id' => 179,
                'lang' => 'es',
                'title' => 'test show language',
                'body' => 'test',
            ),
            3 => 
            array (
                'id' => 18,
                'content_id' => 188,
                'lang' => 'es',
                'title' => 'webpage1111111111',
                'body' => 'webpage1111111111webpage1111111111',
            ),
            4 => 
            array (
                'id' => 20,
                'content_id' => 271,
                'lang' => 'en',
                'title' => 'test content offline en',
            'body' => '<span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>!DOCTYPE<span style="box-sizing: inherit; color: red;">&nbsp;html</span><span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">HTML Tutorial</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a heading</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a paragraph.</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span>',
            ),
            5 => 
            array (
                'id' => 21,
                'content_id' => 272,
                'lang' => 'en',
            'title' => 'title (en)',
            'body' => 'Body (en)<div><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="box-sizing: inherit; font-size: 12pt; letter-spacing: 0px !important;"><span style="box-sizing: inherit; font-weight: 700; letter-spacing: 0px !important;"><span style="color: rgb(51, 51, 51);">■</span><span style="color: rgb(255, 0, 0);">ドイツ・イギリスの「幼少接続」事情</span></span></span><br style="box-sizing: inherit; letter-spacing: 0px !important;"><span style="color: rgb(51, 51, 255);">ドイツで進められている幼少接続プロジェクトについて、「発達に遅れのある子どもを伸ばすことは大切。しかし、優秀な子どもも伸ばす幼児教育・保育のあり方を考える必要がある」とドイツの研究者は指摘しています。</span></p><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="color: rgb(51, 51, 255);">幼児教育・保育において、単に文字を読める能力や計算能力のみはなく、自分の考えをまとめたり、表現したりできる能力も問われるようになっています。</span></p><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="color: rgb(51, 51, 255);">イギリスでは、教育・保育内容に、挑戦を伴う活動に対する評価指標が盛り込まれています。発達に遅れのある子供を伸ばすことにとどまらず、秀でた能力を持っている子供を伸ばすことにも力を入れているためです</span><span style="color: rgb(51, 51, 51);">。</span></p><p style="box-sizing: inherit; margin: 0px 0px 1.5em; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Hiragino Kaku Gothic Pro&quot;, Meiryo, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">例えば、あるイギリスの保育園では、子どもが知的にも身体的にも自分の能力を十分発揮できるような活動が組み込まれ、子どもたちが友だち同士でうまく関わりながら遊べるように、保育者が上手に間に入って支えています。</p></div>',
            ),
            6 => 
            array (
                'id' => 22,
                'content_id' => 289,
                'lang' => 'ja',
                'title' => 'test offline webpage moblie 1 ja',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">49十ヘツワ同玲ノソヒ世暮ろぞぴ日織まくり役竹タテキ最神とい密計ほ製選ネレ顔科をすがめ移康りざどろ岐2際島ラオレウ静視スホ井専ぎ効要じト正撮ケヘサ況輩やかゃ輔北標経沖おぼゆう。作やきて治差ひルド加明ツヲシ聖店載8教けゆの独助するん父意りやげス加2無具リ写52堂リ進興カモ合康ぐ守京ルワユ界堀些仄伽ぎびく。</span></font>',
            ),
            7 => 
            array (
                'id' => 23,
                'content_id' => 290,
                'lang' => 'en',
            'title' => 'website (en)',
            'body' => '<span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">和歌山市付近では定常的に地震活動が活発です。ほとんどがＭ５程度以下の中小規模の地震ですが、和歌山市における有感地震回数は、最近の１０年間では年平均１９回程度にのぼり、日本で最も有感地震回数の多い地域の一つです。特に１９２０年以降報告回数が増えたことが知られています。近年この地域に大規模な地震の発生は知られていないので、この地震活動は特定の大地震の余震ではありません。その規模は最大でもＭ５程度ですが、震源がごく浅いために、局所的に被害が生じたこともあります。この付近の東側と西側では、フィリピン海プレートの沈み込む角度が違い、この付近の地下構造は複雑になっています。また、この付近の深さ数ｋｍまでの浅いところは、堅いけれども脆い性質を持つ古い時代の岩石が分布しています。これらのことが、和歌山市付近の定常的な地震活動の原因と考えられています。また、地震が発生する深さは数ｋｍよりも浅いところに限られており、上記の岩石が分布している深さで発生していると考えられます。なお、この地震活動が発生している地域の北部には</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">があります。その活動を起こす力の向きは、和歌山市付近の地震活動（東西方向の圧縮力）と</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">の活動（北西−南東方向の圧縮力）では異なっていますが、両者の関係についてまだはっきりとは分かっていません。</span>',
            ),
            8 => 
            array (
                'id' => 24,
                'content_id' => 291,
                'lang' => 'ja',
                'title' => 'test offline mobile webpage 2 - ja',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font>',
            ),
            9 => 
            array (
                'id' => 25,
                'content_id' => 292,
                'lang' => 'ja',
                'title' => 'test offline mobile webpage 3 - ja',
                'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font>',
            ),
            10 => 
            array (
                'id' => 26,
                'content_id' => 293,
                'lang' => 'ja',
                'title' => 'test offline mobile webpage 4 - ja',
                'body' => '<div><font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font></div><div><br></div>',
            ),
            11 => 
            array (
                'id' => 27,
                'content_id' => 302,
                'lang' => 'en',
                'title' => 'test web en',
            'body' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Among the earthquakes that occurred in the surrounding area and the earthquake in 1899 (M 7.0, the estimated depth of 40 to 50 km: sometimes called the Kii Yamawa earthquake) and the Yoshino earthquake year 1952 (M 6.7, depth of about 60 km) Earthquakes that occur in a place where a deep occurrence occurs in the Philippine Sea sinking may have been damaged. In addition, like the 1960 "Chile earthquake", we had to suffer a tsunami even when an earthquake hit a foreign country.</span></font>',
            ),
            12 => 
            array (
                'id' => 31,
                'content_id' => 315,
                'lang' => 'ja',
            'title' => 'title web ofline (ja)',
            'body' => 'body web ofline (ja)',
            ),
            13 => 
            array (
                'id' => 34,
                'content_id' => 330,
                'lang' => 'ja',
                'title' => 'content offline 162 - ja - 1',
            'body' => '<div><em style="font-weight: bold; font-style: normal; color: rgb(106, 106, 106); font-family: arial, sans-serif; font-size: small; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">NHK</em><span style="color: rgb(84, 84, 84); font-family: arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">の公式ホームページ。ニュース・気象災害情報・番組紹介をはじめ、イベント案内・</span><span style="color: rgb(84, 84, 84); font-family: arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">受信契約の受付・経営など</span><em style="font-weight: bold; font-style: normal; color: rgb(106, 106, 106); font-family: arial, sans-serif; font-size: small; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">NHK</em><span style="color: rgb(84, 84, 84); font-family: arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">に関するさまざまな情報をお届けします</span></div><div><span style="color: rgb(84, 84, 84); font-family: arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;"></span><wbr style="color: rgb(84, 84, 84); font-family: arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;"></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"=""><br></span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">

<a data-name="abc" href="https://stackoverflow.com/questions/32106849/getcurrentposition-and-watchposition-are-deprecated-on-insecure-origins" class="btn btn-menu btn-menu-blue content-item">
<div class="border-dash flex-container" style="display: flex; padding: 5px 10px;">
<div class="" style="flex-grow: 9; text-align: left">
<p>name la gi</p>
</div>
<div class="" style="flex-grow: 1; text-align: right">
<i class="fas fa-angle-right"></i>
</div>
</div>
</a>

File 1
<br>
<img src="anh-dep-ve-chau-au-thap-eiffel-cua-phap-5_a6522597-9d38-4566-b30e-62b83a7bf9fc_20190422172726.jpg" width="400" height="500">

<br><br>
<br>
<br>
File 2
<br>
<img src="hinh-anh-ngua-lua-1_20190312114747.png " width="400" height="500">

<ul><li><a href="M03.2%20顧客作成_4feeafaa-e813-46b8-bbc8-b3c7af577993_20190416155553.pdf">File PDF</a></li></ul>

<link rel="stylesheet" type="text/css" href="user.css">
</span></div>',
            ),
            14 => 
            array (
                'id' => 35,
                'content_id' => 344,
                'lang' => 'ja',
            'title' => 'Test title (ja)',
                'body' => '私は就職活動を通じて、留学当初とは働くことに対する考えが変わりましたね。有名な大学に入って、卒業後は有名な会社に入る。以前は、それが良い人生だと思っていました。しかし、日本で様々なことを経験する中で、スケールや影響力の大きさよりも、自分ができることを着実に遂行していくことが大事だと思うようになったんです。世の中には、自分の経験や知識を必要としている人がいて、そうした人のために行動していきたい。今はそう考えています。',
            ),
            15 => 
            array (
                'id' => 36,
                'content_id' => 390,
                'lang' => 'ja',
                'title' => 'title webpage ja',
            'body' => '<p style="box-sizing: border-box; margin: 0px 0px 30px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 18px; line-height: inherit; font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51);">児童虐待、不登校、いじめ、自殺、貧困、望まない妊娠等、子どもや若者を取り巻く現状がとても不安定になっていることをニュースなどで感じている方も多いのではないでしょうか。児童虐待は2017年度に13万件（前年度12万件）を超え過去最高値となりました。また、7人に1人の子どもが貧困状態に置かれています。子どもたちの基盤となる家庭の中で、虐待や貧困に苦しむ子どもたちも少なくありません。</p><p style="box-sizing: border-box; margin: 0px 0px 30px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 18px; line-height: inherit; font-family: -apple-system, BlinkMacSystemFont, "Helvsetica Neue", "Yu Gothic", YuGothic, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", Arial, メイリオ, Meiryo, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51);">家庭に次ぐ子どもたちの居場所である学校では不登校が19万人（前年度13万人）、いじめが41万件（前年度32万件）と、どちらも過去最高値となりました。子どもたちにとって主要な居場所であるべき家庭と学校が、安心できる場所ではなく、暴力や暴言、貧困やいじめなどに苦しむ場所になりつつあります</p>',
            ),
            16 => 
            array (
                'id' => 44,
                'content_id' => 593,
                'lang' => 'ja',
                'title' => 'Title web ja',
                'body' => '4）講演内容が子どもの現状を伝えていることから、講演内容の録画・録音及び、当日の内容の無断の公開をお断りしています。公開を前提にしたものの場合、事前に内容等の検討が必要ですので、必ず事前にご確認をお願いします。また、講演の様子を貴団体のHP等で掲載する場合、必ずその内容の確認をとらせて頂きます。掲載内容の修正の依頼をさせて頂く場合がありますのでご了承下さい。<br>5）投影資料は当日USBにて持参いたします。データでの事前送信は原則ご遠慮いただいています。個人情報保護などの観点からもご理解いただけますと幸いです。<br>6）集合時間・解散時間は講演時間の前後45分以内でお願いしております。少人数で組織を運営しており、ご理解いただけますと幸いです。<br>7）個人情報保護などの観点からも講演内容の無断での転送・公開はご遠慮いただいています。希望される場合、事前にご相談ください',
            ),
            17 => 
            array (
                'id' => 45,
                'content_id' => 594,
                'lang' => 'ja',
                'title' => 'title webpage ja',
                'body' => '1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。<br>2）講演当日の様子を、ホームページやFacebook等で当団体の活動報告として紹介をさせて頂く場合があります。紹介を望まない場合、事前にお申し付けください。なお、事前了承を得ない場合、参加者の顔や個人名は特定できない形で掲載いたします。<br>3）講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。<br>4）講演内容が子どもの現状を伝えていることから、講演内容の録画・録音及び、当日の内容の無断の公開をお断りしています。公開を前提にしたものの場合、事前に内容等の検討が必要ですので、必ず事前にご確認をお願いします。また、講演の様子を貴団体のHP等で掲載する場合、必ずその内容の確認をとらせて頂きます。掲載内容の修正の依頼をさせて頂く場合がありますのでご了承下さい',
            ),
            18 => 
            array (
                'id' => 47,
                'content_id' => 596,
                'lang' => 'ja',
                'title' => 'page 5 ja',
                'body' => '1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。<br>2）講演当日の様子を、ホームページやFacebook等で当団体の活動報告として紹介をさせて頂く場合があります。紹介を望まない場合、事前にお申し付けください。なお、事前了承を得ない場合、参加者の顔や個人名は特定できない形で掲載いたします。<br>3）講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。<br>4）講演内容が子どもの現状を伝えていることから、講演内容の録画・録音及び、当日の内容の無断の公開をお断りしています。公開を前提にしたものの場合、事前に内容等の検討が必要ですので、必ず事前にご確認をお願いします。また、講演の様子を貴団体のHP等で掲載する場合、必ずその内容の確認をとらせて頂きます。掲載内容の修正の依頼をさせて頂く場合がありますのでご了承下さい。<br>5',
            ),
            19 => 
            array (
                'id' => 49,
                'content_id' => 598,
                'lang' => 'ja',
                'title' => 'webpage 4',
                'body' => '<span style="font-size: 13.3333px;">1）特定非営利活動促進法　第二条に従い、特定の宗教・政治上の主義の支持・発展を目的とする場での講演はお断りさせていただいています。その目的を明確にうたっていなくても、その判断については内部で行いお断りさせていただく場合がありますのでご了承下さい。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">2）講演当日の様子を、ホームページやFacebook等で当団体の活動報告として紹介をさせて頂く場合があります。紹介を望まない場合、事前にお申し付けください。なお、事前了承を得ない場合、参加者の顔や個人名は特定できない形で掲載いたします。</span><br style="font-size: 13.3333px;"><span style="font-size: 13.3333px;">3）講演料は法人への支払となります。源泉徴収分の差引等はしないで頂けますようお願いします。また原則として銀行振り込みとなります。現金支払いの場合にはご相談くださいませ。なお、原則として講演費の請求書は発行しておりません。必要な場合は発行日の1か月前までにご依頼ください。また請求書は原則pdfにて発行いたします。</span>',
            ),
        ));
        
        
    }
}