<?php

use Illuminate\Database\Seeder;

class ClientSettingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('client_settings')->delete();
        
        \DB::table('client_settings')->insert(array (
            0 => 
            array (
                'id' => 1,
                'client_id' => 1,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyDXWUSlt71lXYTR4jAQeQNIx5G2jIMWjd4',
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            1 => 
            array (
                'id' => 2,
                'client_id' => 182,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 16:58:37',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            2 => 
            array (
                'id' => 3,
                'client_id' => 182,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 16:58:37',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            3 => 
            array (
                'id' => 4,
                'client_id' => 182,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 16:58:37',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            4 => 
            array (
                'id' => 5,
                'client_id' => 183,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 17:09:17',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            5 => 
            array (
                'id' => 6,
                'client_id' => 183,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 17:09:17',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            6 => 
            array (
                'id' => 7,
                'client_id' => 183,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 17:09:17',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            7 => 
            array (
                'id' => 8,
                'client_id' => 184,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 17:16:50',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            8 => 
            array (
                'id' => 9,
                'client_id' => 184,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 17:16:50',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            9 => 
            array (
                'id' => 10,
                'client_id' => 184,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 17:16:50',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            10 => 
            array (
                'id' => 11,
                'client_id' => 185,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:00:59',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            11 => 
            array (
                'id' => 12,
                'client_id' => 185,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:00:59',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            12 => 
            array (
                'id' => 13,
                'client_id' => 185,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:00:59',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            13 => 
            array (
                'id' => 14,
                'client_id' => 186,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:04:35',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            14 => 
            array (
                'id' => 15,
                'client_id' => 186,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:04:35',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            15 => 
            array (
                'id' => 16,
                'client_id' => 186,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:04:35',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            16 => 
            array (
                'id' => 17,
                'client_id' => 187,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:24:12',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            17 => 
            array (
                'id' => 18,
                'client_id' => 187,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:24:12',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            18 => 
            array (
                'id' => 19,
                'client_id' => 187,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:24:12',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            19 => 
            array (
                'id' => 20,
                'client_id' => 188,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:29:49',
                'updated_at' => '2019-03-01 18:29:49',
            ),
            20 => 
            array (
                'id' => 21,
                'client_id' => 188,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:29:49',
                'updated_at' => '2019-03-01 18:29:49',
            ),
            21 => 
            array (
                'id' => 22,
                'client_id' => 188,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:29:49',
                'updated_at' => '2019-03-01 18:29:49',
            ),
            22 => 
            array (
                'id' => 23,
                'client_id' => 189,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:33:11',
                'updated_at' => '2019-03-01 18:33:11',
            ),
            23 => 
            array (
                'id' => 24,
                'client_id' => 189,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:33:11',
                'updated_at' => '2019-03-01 18:33:11',
            ),
            24 => 
            array (
                'id' => 25,
                'client_id' => 189,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:33:11',
                'updated_at' => '2019-03-01 18:33:11',
            ),
            25 => 
            array (
                'id' => 26,
                'client_id' => 190,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:59:44',
                'updated_at' => '2019-03-01 18:59:44',
            ),
            26 => 
            array (
                'id' => 27,
                'client_id' => 190,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:59:44',
                'updated_at' => '2019-03-01 18:59:44',
            ),
            27 => 
            array (
                'id' => 28,
                'client_id' => 190,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 18:59:44',
                'updated_at' => '2019-03-01 18:59:44',
            ),
            28 => 
            array (
                'id' => 29,
                'client_id' => 191,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-01 19:33:25',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            29 => 
            array (
                'id' => 30,
                'client_id' => 191,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-01 19:33:25',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            30 => 
            array (
                'id' => 31,
                'client_id' => 191,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-01 19:33:25',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            31 => 
            array (
                'id' => 32,
                'client_id' => 192,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-05 13:03:04',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            32 => 
            array (
                'id' => 33,
                'client_id' => 192,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-05 13:03:04',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            33 => 
            array (
                'id' => 34,
                'client_id' => 192,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-05 13:03:04',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            34 => 
            array (
                'id' => 35,
                'client_id' => 1,
                'setting_div' => 102,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/APNS_SANDBOX/Machiyell-iOS',
                'created_at' => '2019-03-05 13:03:04',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            35 => 
            array (
                'id' => 36,
                'client_id' => 193,
                'setting_div' => 101,
                'setting_value' => 'Zd9itsbJhI20vYvShuiZek8ntBKSBROqVNze6ANe',
                'created_at' => '2019-03-06 16:56:30',
                'updated_at' => '2019-03-06 17:02:35',
            ),
            36 => 
            array (
                'id' => 37,
                'client_id' => 193,
                'setting_div' => 102,
                'setting_value' => 'BjC55n6hr5dS5N6MTOPH0bv3Cs8fPDPhMhcIv9QM',
                'created_at' => '2019-03-06 16:56:30',
                'updated_at' => '2019-03-06 17:19:58',
            ),
            37 => 
            array (
                'id' => 38,
                'client_id' => 193,
                'setting_div' => 103,
                'setting_value' => 'g5ZAMS9XQZkVsIaq4lz8L8Ph8dhlawbhs0H5JHSp',
                'created_at' => '2019-03-06 16:56:30',
                'updated_at' => '2019-03-06 17:20:12',
            ),
            38 => 
            array (
                'id' => 39,
                'client_id' => 1,
                'setting_div' => 101,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/GCM/Machiyell-Android',
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            39 => 
            array (
                'id' => 40,
                'client_id' => 194,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:40:07',
                'updated_at' => '2019-03-11 13:40:07',
            ),
            40 => 
            array (
                'id' => 41,
                'client_id' => 194,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:40:07',
                'updated_at' => '2019-03-11 13:40:07',
            ),
            41 => 
            array (
                'id' => 42,
                'client_id' => 194,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:40:07',
                'updated_at' => '2019-03-11 13:40:07',
            ),
            42 => 
            array (
                'id' => 43,
                'client_id' => 195,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:51:29',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            43 => 
            array (
                'id' => 44,
                'client_id' => 195,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:51:29',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            44 => 
            array (
                'id' => 45,
                'client_id' => 195,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:51:29',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            45 => 
            array (
                'id' => 46,
                'client_id' => 196,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:55:19',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            46 => 
            array (
                'id' => 47,
                'client_id' => 196,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:55:19',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            47 => 
            array (
                'id' => 48,
                'client_id' => 196,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyDXWUSlt71lXYTR4jAQeQNIx5G2jIMWjd4',
                'created_at' => '2019-03-11 13:55:19',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            48 => 
            array (
                'id' => 49,
                'client_id' => 197,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:59:54',
                'updated_at' => '2019-03-11 13:59:54',
            ),
            49 => 
            array (
                'id' => 50,
                'client_id' => 197,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-11 13:59:54',
                'updated_at' => '2019-03-11 13:59:54',
            ),
            50 => 
            array (
                'id' => 51,
                'client_id' => 197,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyBJjMqBHpHbBqS-FjW9aCCK6jTZSd4sNVw',
                'created_at' => '2019-03-11 13:59:54',
                'updated_at' => '2019-03-11 13:59:54',
            ),
            51 => 
            array (
                'id' => 52,
                'client_id' => 198,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-11 15:10:22',
                'updated_at' => '2019-03-11 15:10:22',
            ),
            52 => 
            array (
                'id' => 53,
                'client_id' => 198,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-11 15:10:22',
                'updated_at' => '2019-03-11 15:10:22',
            ),
            53 => 
            array (
                'id' => 54,
                'client_id' => 198,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyBNkH_Qvk6uSyG8g_slFLxAxJqjNqShHEo',
                'created_at' => '2019-03-11 15:10:22',
                'updated_at' => '2019-03-11 15:10:22',
            ),
            54 => 
            array (
                'id' => 55,
                'client_id' => 199,
                'setting_div' => 101,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/GCM/Machiyell-Android-VNC',
                'created_at' => '2019-03-11 16:52:23',
                'updated_at' => '2019-03-11 16:52:23',
            ),
            55 => 
            array (
                'id' => 56,
                'client_id' => 199,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyDXWUSlt71lXYTR4jAQeQNIx5G2jIMWjd4',
                'created_at' => '2019-03-11 16:52:23',
                'updated_at' => '2019-03-11 16:52:23',
            ),
            56 => 
            array (
                'id' => 57,
                'client_id' => 199,
                'setting_div' => 102,
                'setting_value' => 'arn:aws:sns:us-east-1:046602778425:app/APNS_SANDBOX/Machiyell-iOS',
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            57 => 
            array (
                'id' => 58,
                'client_id' => 199,
                'setting_div' => 104,
                'setting_value' => '2.6',
                'created_at' => NULL,
                'updated_at' => '2019-04-22 18:30:22',
            ),
            58 => 
            array (
                'id' => 59,
                'client_id' => 199,
                'setting_div' => 105,
                'setting_value' => '1.0',
                'created_at' => NULL,
                'updated_at' => '2019-04-22 16:35:11',
            ),
            59 => 
            array (
                'id' => 60,
                'client_id' => 200,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-03-25 17:50:56',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            60 => 
            array (
                'id' => 61,
                'client_id' => 200,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-25 17:50:56',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            61 => 
            array (
                'id' => 62,
                'client_id' => 200,
                'setting_div' => 103,
                'setting_value' => 'AIzaSyCkUOdZ5y7hMm0yrcCQoCvLwzdM6M8s5qk',
                'created_at' => '2019-03-25 17:50:56',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            62 => 
            array (
                'id' => 63,
                'client_id' => 200,
                'setting_div' => 104,
                'setting_value' => '1.3',
                'created_at' => '2019-03-25 17:50:56',
                'updated_at' => '2019-03-25 17:51:22',
            ),
            63 => 
            array (
                'id' => 64,
                'client_id' => 200,
                'setting_div' => 105,
                'setting_value' => '',
                'created_at' => '2019-03-25 17:50:56',
                'updated_at' => '2019-03-25 17:50:56',
            ),
            64 => 
            array (
                'id' => 65,
                'client_id' => 201,
                'setting_div' => 101,
                'setting_value' => 'setting value',
                'created_at' => '2019-03-26 19:15:26',
                'updated_at' => '2019-03-27 13:36:57',
            ),
            65 => 
            array (
                'id' => 66,
                'client_id' => 201,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-03-26 19:15:26',
                'updated_at' => '2019-03-26 19:15:26',
            ),
            66 => 
            array (
                'id' => 67,
                'client_id' => 201,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-03-26 19:15:26',
                'updated_at' => '2019-03-26 19:15:26',
            ),
            67 => 
            array (
                'id' => 68,
                'client_id' => 201,
                'setting_div' => 104,
                'setting_value' => '100.00',
                'created_at' => '2019-03-26 19:15:26',
                'updated_at' => '2019-03-27 15:13:05',
            ),
            68 => 
            array (
                'id' => 69,
                'client_id' => 201,
                'setting_div' => 105,
                'setting_value' => '1.1',
                'created_at' => '2019-03-26 19:15:26',
                'updated_at' => '2019-03-27 13:48:30',
            ),
            69 => 
            array (
                'id' => 70,
                'client_id' => 202,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-04-09 15:45:48',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            70 => 
            array (
                'id' => 71,
                'client_id' => 202,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-04-09 15:45:48',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            71 => 
            array (
                'id' => 72,
                'client_id' => 202,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-04-09 15:45:48',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            72 => 
            array (
                'id' => 73,
                'client_id' => 202,
                'setting_div' => 104,
                'setting_value' => '',
                'created_at' => '2019-04-09 15:45:48',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            73 => 
            array (
                'id' => 74,
                'client_id' => 202,
                'setting_div' => 105,
                'setting_value' => '',
                'created_at' => '2019-04-09 15:45:48',
                'updated_at' => '2019-04-09 15:45:48',
            ),
            74 => 
            array (
                'id' => 75,
                'client_id' => 205,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:29:07',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            75 => 
            array (
                'id' => 76,
                'client_id' => 205,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:29:07',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            76 => 
            array (
                'id' => 77,
                'client_id' => 205,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:29:07',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            77 => 
            array (
                'id' => 78,
                'client_id' => 205,
                'setting_div' => 104,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:29:07',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            78 => 
            array (
                'id' => 79,
                'client_id' => 205,
                'setting_div' => 105,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:29:07',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            79 => 
            array (
                'id' => 80,
                'client_id' => 206,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:31:12',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            80 => 
            array (
                'id' => 81,
                'client_id' => 206,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:31:12',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            81 => 
            array (
                'id' => 82,
                'client_id' => 206,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:31:12',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            82 => 
            array (
                'id' => 83,
                'client_id' => 206,
                'setting_div' => 104,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:31:12',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            83 => 
            array (
                'id' => 84,
                'client_id' => 206,
                'setting_div' => 105,
                'setting_value' => '',
                'created_at' => '2019-04-10 12:31:12',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            84 => 
            array (
                'id' => 85,
                'client_id' => 207,
                'setting_div' => 101,
                'setting_value' => '',
                'created_at' => '2019-04-10 13:02:30',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            85 => 
            array (
                'id' => 86,
                'client_id' => 207,
                'setting_div' => 102,
                'setting_value' => '',
                'created_at' => '2019-04-10 13:02:30',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            86 => 
            array (
                'id' => 87,
                'client_id' => 207,
                'setting_div' => 103,
                'setting_value' => '',
                'created_at' => '2019-04-10 13:02:30',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            87 => 
            array (
                'id' => 88,
                'client_id' => 207,
                'setting_div' => 104,
                'setting_value' => '',
                'created_at' => '2019-04-10 13:02:30',
                'updated_at' => '2019-04-10 13:02:30',
            ),
            88 => 
            array (
                'id' => 89,
                'client_id' => 207,
                'setting_div' => 105,
                'setting_value' => '',
                'created_at' => '2019-04-10 13:02:30',
                'updated_at' => '2019-04-10 13:02:30',
            ),
        ));
        
        
    }
}