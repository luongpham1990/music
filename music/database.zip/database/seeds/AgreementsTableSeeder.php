<?php

use Illuminate\Database\Seeder;

class AgreementsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('agreements')->delete();
        
        \DB::table('agreements')->insert(array (
            0 => 
            array (
                'client_id' => 1,
                'user_id' => 24,
                'created_at' => '2019-01-30 19:58:07',
            ),
            1 => 
            array (
                'client_id' => 1,
                'user_id' => 25,
                'created_at' => '2019-01-30 19:58:34',
            ),
            2 => 
            array (
                'client_id' => 1,
                'user_id' => 29,
                'created_at' => '2019-01-31 16:49:31',
            ),
            3 => 
            array (
                'client_id' => 1,
                'user_id' => 30,
                'created_at' => '2019-01-31 16:55:41',
            ),
            4 => 
            array (
                'client_id' => 1,
                'user_id' => 31,
                'created_at' => '2019-01-31 16:58:25',
            ),
            5 => 
            array (
                'client_id' => 1,
                'user_id' => 32,
                'created_at' => '2019-01-31 16:58:26',
            ),
            6 => 
            array (
                'client_id' => 1,
                'user_id' => 33,
                'created_at' => '2019-01-31 17:00:13',
            ),
            7 => 
            array (
                'client_id' => 1,
                'user_id' => 34,
                'created_at' => '2019-01-31 17:01:30',
            ),
            8 => 
            array (
                'client_id' => 199,
                'user_id' => 523,
                'created_at' => '2019-04-10 12:49:46',
            ),
            9 => 
            array (
                'client_id' => 199,
                'user_id' => 524,
                'created_at' => '2019-04-10 13:20:07',
            ),
            10 => 
            array (
                'client_id' => 199,
                'user_id' => 525,
                'created_at' => '2019-04-10 13:20:08',
            ),
            11 => 
            array (
                'client_id' => 199,
                'user_id' => 526,
                'created_at' => '2019-04-10 13:35:03',
            ),
            12 => 
            array (
                'client_id' => 199,
                'user_id' => 527,
                'created_at' => '2019-04-10 13:38:57',
            ),
            13 => 
            array (
                'client_id' => 199,
                'user_id' => 528,
                'created_at' => '2019-04-10 13:49:02',
            ),
            14 => 
            array (
                'client_id' => 199,
                'user_id' => 529,
                'created_at' => '2019-04-10 15:14:41',
            ),
            15 => 
            array (
                'client_id' => 199,
                'user_id' => 530,
                'created_at' => '2019-04-10 15:14:42',
            ),
            16 => 
            array (
                'client_id' => 199,
                'user_id' => 531,
                'created_at' => '2019-04-10 15:27:59',
            ),
            17 => 
            array (
                'client_id' => 199,
                'user_id' => 532,
                'created_at' => '2019-04-10 15:31:43',
            ),
            18 => 
            array (
                'client_id' => 199,
                'user_id' => 533,
                'created_at' => '2019-04-10 15:46:03',
            ),
            19 => 
            array (
                'client_id' => 199,
                'user_id' => 534,
                'created_at' => '2019-04-12 11:42:44',
            ),
            20 => 
            array (
                'client_id' => 199,
                'user_id' => 535,
                'created_at' => '2019-04-12 13:41:37',
            ),
            21 => 
            array (
                'client_id' => 199,
                'user_id' => 536,
                'created_at' => '2019-04-12 13:42:21',
            ),
            22 => 
            array (
                'client_id' => 199,
                'user_id' => 537,
                'created_at' => '2019-04-16 13:08:10',
            ),
            23 => 
            array (
                'client_id' => 199,
                'user_id' => 538,
                'created_at' => '2019-04-16 13:11:54',
            ),
            24 => 
            array (
                'client_id' => 199,
                'user_id' => 539,
                'created_at' => '2019-04-16 13:21:28',
            ),
            25 => 
            array (
                'client_id' => 199,
                'user_id' => 540,
                'created_at' => '2019-04-16 13:27:35',
            ),
            26 => 
            array (
                'client_id' => 199,
                'user_id' => 541,
                'created_at' => '2019-04-16 14:24:50',
            ),
            27 => 
            array (
                'client_id' => 199,
                'user_id' => 542,
                'created_at' => '2019-04-16 15:39:21',
            ),
            28 => 
            array (
                'client_id' => 199,
                'user_id' => 543,
                'created_at' => '2019-04-16 16:56:07',
            ),
            29 => 
            array (
                'client_id' => 199,
                'user_id' => 544,
                'created_at' => '2019-04-16 17:18:36',
            ),
            30 => 
            array (
                'client_id' => 199,
                'user_id' => 545,
                'created_at' => '2019-04-16 17:44:28',
            ),
            31 => 
            array (
                'client_id' => 199,
                'user_id' => 546,
                'created_at' => '2019-04-17 12:36:25',
            ),
            32 => 
            array (
                'client_id' => 199,
                'user_id' => 547,
                'created_at' => '2019-04-17 15:11:02',
            ),
            33 => 
            array (
                'client_id' => 199,
                'user_id' => 548,
                'created_at' => '2019-04-17 15:23:29',
            ),
            34 => 
            array (
                'client_id' => 199,
                'user_id' => 549,
                'created_at' => '2019-04-17 15:39:35',
            ),
            35 => 
            array (
                'client_id' => 199,
                'user_id' => 550,
                'created_at' => '2019-04-17 15:58:33',
            ),
            36 => 
            array (
                'client_id' => 199,
                'user_id' => 551,
                'created_at' => '2019-04-17 16:02:58',
            ),
            37 => 
            array (
                'client_id' => 199,
                'user_id' => 552,
                'created_at' => '2019-04-17 16:04:33',
            ),
            38 => 
            array (
                'client_id' => 199,
                'user_id' => 553,
                'created_at' => '2019-04-18 11:14:35',
            ),
            39 => 
            array (
                'client_id' => 199,
                'user_id' => 554,
                'created_at' => '2019-04-18 11:44:14',
            ),
            40 => 
            array (
                'client_id' => 199,
                'user_id' => 555,
                'created_at' => '2019-04-18 11:45:24',
            ),
            41 => 
            array (
                'client_id' => 199,
                'user_id' => 556,
                'created_at' => '2019-04-18 12:00:18',
            ),
            42 => 
            array (
                'client_id' => 199,
                'user_id' => 557,
                'created_at' => '2019-04-18 16:51:39',
            ),
            43 => 
            array (
                'client_id' => 199,
                'user_id' => 558,
                'created_at' => '2019-04-18 16:58:11',
            ),
            44 => 
            array (
                'client_id' => 199,
                'user_id' => 559,
                'created_at' => '2019-04-18 17:27:23',
            ),
            45 => 
            array (
                'client_id' => 199,
                'user_id' => 560,
                'created_at' => '2019-04-18 17:30:53',
            ),
            46 => 
            array (
                'client_id' => 199,
                'user_id' => 561,
                'created_at' => '2019-04-18 17:35:23',
            ),
            47 => 
            array (
                'client_id' => 199,
                'user_id' => 562,
                'created_at' => '2019-04-18 17:54:08',
            ),
            48 => 
            array (
                'client_id' => 199,
                'user_id' => 563,
                'created_at' => '2019-04-18 18:15:00',
            ),
            49 => 
            array (
                'client_id' => 199,
                'user_id' => 564,
                'created_at' => '2019-04-18 18:25:18',
            ),
            50 => 
            array (
                'client_id' => 199,
                'user_id' => 565,
                'created_at' => '2019-04-18 18:32:12',
            ),
            51 => 
            array (
                'client_id' => 199,
                'user_id' => 566,
                'created_at' => '2019-04-18 18:45:17',
            ),
            52 => 
            array (
                'client_id' => 199,
                'user_id' => 567,
                'created_at' => '2019-04-18 19:12:28',
            ),
            53 => 
            array (
                'client_id' => 199,
                'user_id' => 568,
                'created_at' => '2019-04-18 19:15:53',
            ),
            54 => 
            array (
                'client_id' => 199,
                'user_id' => 569,
                'created_at' => '2019-04-18 19:23:37',
            ),
            55 => 
            array (
                'client_id' => 199,
                'user_id' => 570,
                'created_at' => '2019-04-19 11:51:42',
            ),
            56 => 
            array (
                'client_id' => 199,
                'user_id' => 571,
                'created_at' => '2019-04-19 15:06:09',
            ),
            57 => 
            array (
                'client_id' => 199,
                'user_id' => 572,
                'created_at' => '2019-04-19 17:01:08',
            ),
            58 => 
            array (
                'client_id' => 199,
                'user_id' => 573,
                'created_at' => '2019-04-19 17:32:05',
            ),
            59 => 
            array (
                'client_id' => 199,
                'user_id' => 574,
                'created_at' => '2019-04-19 17:45:15',
            ),
            60 => 
            array (
                'client_id' => 199,
                'user_id' => 575,
                'created_at' => '2019-04-19 18:01:38',
            ),
            61 => 
            array (
                'client_id' => 199,
                'user_id' => 576,
                'created_at' => '2019-04-19 18:45:01',
            ),
            62 => 
            array (
                'client_id' => 199,
                'user_id' => 577,
                'created_at' => '2019-04-19 18:49:02',
            ),
            63 => 
            array (
                'client_id' => 199,
                'user_id' => 578,
                'created_at' => '2019-04-19 18:54:04',
            ),
            64 => 
            array (
                'client_id' => 199,
                'user_id' => 579,
                'created_at' => '2019-04-19 19:05:29',
            ),
            65 => 
            array (
                'client_id' => 199,
                'user_id' => 580,
                'created_at' => '2019-04-19 19:24:02',
            ),
            66 => 
            array (
                'client_id' => 199,
                'user_id' => 581,
                'created_at' => '2019-04-19 19:25:56',
            ),
            67 => 
            array (
                'client_id' => 199,
                'user_id' => 582,
                'created_at' => '2019-04-22 10:54:32',
            ),
            68 => 
            array (
                'client_id' => 199,
                'user_id' => 583,
                'created_at' => '2019-04-22 11:18:56',
            ),
            69 => 
            array (
                'client_id' => 199,
                'user_id' => 584,
                'created_at' => '2019-04-22 11:52:14',
            ),
            70 => 
            array (
                'client_id' => 199,
                'user_id' => 585,
                'created_at' => '2019-04-22 11:52:27',
            ),
            71 => 
            array (
                'client_id' => 199,
                'user_id' => 586,
                'created_at' => '2019-04-22 11:58:36',
            ),
            72 => 
            array (
                'client_id' => 199,
                'user_id' => 587,
                'created_at' => '2019-04-22 13:44:39',
            ),
            73 => 
            array (
                'client_id' => 199,
                'user_id' => 588,
                'created_at' => '2019-04-22 13:46:49',
            ),
            74 => 
            array (
                'client_id' => 199,
                'user_id' => 589,
                'created_at' => '2019-04-22 13:55:09',
            ),
            75 => 
            array (
                'client_id' => 199,
                'user_id' => 590,
                'created_at' => '2019-04-22 13:59:12',
            ),
            76 => 
            array (
                'client_id' => 199,
                'user_id' => 591,
                'created_at' => '2019-04-22 15:14:50',
            ),
            77 => 
            array (
                'client_id' => 199,
                'user_id' => 592,
                'created_at' => '2019-04-22 15:39:19',
            ),
            78 => 
            array (
                'client_id' => 199,
                'user_id' => 593,
                'created_at' => '2019-04-22 15:40:42',
            ),
            79 => 
            array (
                'client_id' => 199,
                'user_id' => 594,
                'created_at' => '2019-04-22 15:52:44',
            ),
            80 => 
            array (
                'client_id' => 199,
                'user_id' => 595,
                'created_at' => '2019-04-22 16:04:39',
            ),
            81 => 
            array (
                'client_id' => 199,
                'user_id' => 596,
                'created_at' => '2019-04-22 16:35:46',
            ),
            82 => 
            array (
                'client_id' => 199,
                'user_id' => 597,
                'created_at' => '2019-04-22 16:57:51',
            ),
            83 => 
            array (
                'client_id' => 199,
                'user_id' => 598,
                'created_at' => '2019-04-22 18:38:04',
            ),
            84 => 
            array (
                'client_id' => 199,
                'user_id' => 599,
                'created_at' => '2019-04-22 19:32:10',
            ),
            85 => 
            array (
                'client_id' => 199,
                'user_id' => 600,
                'created_at' => '2019-04-22 20:04:19',
            ),
            86 => 
            array (
                'client_id' => 199,
                'user_id' => 601,
                'created_at' => '2019-04-23 12:21:11',
            ),
            87 => 
            array (
                'client_id' => 199,
                'user_id' => 602,
                'created_at' => '2019-04-23 13:17:01',
            ),
            88 => 
            array (
                'client_id' => 199,
                'user_id' => 603,
                'created_at' => '2019-04-23 13:35:41',
            ),
            89 => 
            array (
                'client_id' => 199,
                'user_id' => 604,
                'created_at' => '2019-04-23 13:39:59',
            ),
            90 => 
            array (
                'client_id' => 199,
                'user_id' => 605,
                'created_at' => '2019-04-23 13:55:04',
            ),
            91 => 
            array (
                'client_id' => 199,
                'user_id' => 606,
                'created_at' => '2019-04-23 15:12:29',
            ),
            92 => 
            array (
                'client_id' => 199,
                'user_id' => 607,
                'created_at' => '2019-04-23 15:49:09',
            ),
            93 => 
            array (
                'client_id' => 199,
                'user_id' => 608,
                'created_at' => '2019-04-23 15:55:51',
            ),
            94 => 
            array (
                'client_id' => 199,
                'user_id' => 609,
                'created_at' => '2019-04-23 16:02:22',
            ),
            95 => 
            array (
                'client_id' => 199,
                'user_id' => 610,
                'created_at' => '2019-04-23 19:28:51',
            ),
            96 => 
            array (
                'client_id' => 199,
                'user_id' => 611,
                'created_at' => '2019-04-24 12:59:08',
            ),
            97 => 
            array (
                'client_id' => 199,
                'user_id' => 612,
                'created_at' => '2019-04-24 13:31:42',
            ),
            98 => 
            array (
                'client_id' => 199,
                'user_id' => 613,
                'created_at' => '2019-04-24 13:55:03',
            ),
            99 => 
            array (
                'client_id' => 199,
                'user_id' => 614,
                'created_at' => '2019-04-24 18:00:57',
            ),
            100 => 
            array (
                'client_id' => 199,
                'user_id' => 615,
                'created_at' => '2019-04-24 22:51:43',
            ),
            101 => 
            array (
                'client_id' => 199,
                'user_id' => 616,
                'created_at' => '2019-04-25 10:29:58',
            ),
            102 => 
            array (
                'client_id' => 199,
                'user_id' => 617,
                'created_at' => '2019-04-25 11:21:59',
            ),
            103 => 
            array (
                'client_id' => 199,
                'user_id' => 618,
                'created_at' => '2019-04-25 13:06:14',
            ),
            104 => 
            array (
                'client_id' => 199,
                'user_id' => 619,
                'created_at' => '2019-04-25 13:09:52',
            ),
            105 => 
            array (
                'client_id' => 199,
                'user_id' => 620,
                'created_at' => '2019-04-25 13:17:40',
            ),
            106 => 
            array (
                'client_id' => 199,
                'user_id' => 621,
                'created_at' => '2019-04-25 16:13:32',
            ),
            107 => 
            array (
                'client_id' => 199,
                'user_id' => 622,
                'created_at' => '2019-04-25 16:16:21',
            ),
            108 => 
            array (
                'client_id' => 199,
                'user_id' => 623,
                'created_at' => '2019-04-25 16:56:51',
            ),
            109 => 
            array (
                'client_id' => 199,
                'user_id' => 624,
                'created_at' => '2019-04-25 19:06:31',
            ),
            110 => 
            array (
                'client_id' => 199,
                'user_id' => 625,
                'created_at' => '2019-04-25 19:15:23',
            ),
            111 => 
            array (
                'client_id' => 199,
                'user_id' => 626,
                'created_at' => '2019-04-25 19:31:41',
            ),
            112 => 
            array (
                'client_id' => 199,
                'user_id' => 627,
                'created_at' => '2019-04-25 19:46:47',
            ),
            113 => 
            array (
                'client_id' => 199,
                'user_id' => 628,
                'created_at' => '2019-04-26 11:38:18',
            ),
            114 => 
            array (
                'client_id' => 199,
                'user_id' => 629,
                'created_at' => '2019-04-26 11:42:10',
            ),
            115 => 
            array (
                'client_id' => 199,
                'user_id' => 630,
                'created_at' => '2019-04-26 11:45:58',
            ),
            116 => 
            array (
                'client_id' => 199,
                'user_id' => 631,
                'created_at' => '2019-04-26 12:55:32',
            ),
            117 => 
            array (
                'client_id' => 199,
                'user_id' => 632,
                'created_at' => '2019-04-26 13:03:51',
            ),
            118 => 
            array (
                'client_id' => 199,
                'user_id' => 633,
                'created_at' => '2019-04-26 13:09:26',
            ),
            119 => 
            array (
                'client_id' => 199,
                'user_id' => 634,
                'created_at' => '2019-04-26 13:18:44',
            ),
            120 => 
            array (
                'client_id' => 199,
                'user_id' => 635,
                'created_at' => '2019-04-26 13:27:59',
            ),
            121 => 
            array (
                'client_id' => 199,
                'user_id' => 636,
                'created_at' => '2019-04-26 13:33:13',
            ),
            122 => 
            array (
                'client_id' => 199,
                'user_id' => 637,
                'created_at' => '2019-04-26 13:34:33',
            ),
            123 => 
            array (
                'client_id' => 199,
                'user_id' => 638,
                'created_at' => '2019-04-26 13:44:20',
            ),
            124 => 
            array (
                'client_id' => 199,
                'user_id' => 639,
                'created_at' => '2019-04-26 13:35:42',
            ),
            125 => 
            array (
                'client_id' => 199,
                'user_id' => 640,
                'created_at' => '2019-04-26 13:52:51',
            ),
            126 => 
            array (
                'client_id' => 199,
                'user_id' => 641,
                'created_at' => '2019-04-26 15:12:35',
            ),
            127 => 
            array (
                'client_id' => 199,
                'user_id' => 642,
                'created_at' => '2019-04-26 15:14:30',
            ),
            128 => 
            array (
                'client_id' => 199,
                'user_id' => 643,
                'created_at' => '2019-04-26 15:30:27',
            ),
            129 => 
            array (
                'client_id' => 199,
                'user_id' => 644,
                'created_at' => '2019-04-26 15:33:34',
            ),
            130 => 
            array (
                'client_id' => 199,
                'user_id' => 645,
                'created_at' => '2019-04-26 15:45:55',
            ),
            131 => 
            array (
                'client_id' => 199,
                'user_id' => 646,
                'created_at' => '2019-04-26 15:50:10',
            ),
            132 => 
            array (
                'client_id' => 199,
                'user_id' => 647,
                'created_at' => '2019-04-26 16:28:23',
            ),
            133 => 
            array (
                'client_id' => 199,
                'user_id' => 648,
                'created_at' => '2019-04-26 16:39:33',
            ),
            134 => 
            array (
                'client_id' => 199,
                'user_id' => 649,
                'created_at' => '2019-04-26 16:40:29',
            ),
            135 => 
            array (
                'client_id' => 199,
                'user_id' => 650,
                'created_at' => '2019-04-26 16:42:42',
            ),
            136 => 
            array (
                'client_id' => 199,
                'user_id' => 651,
                'created_at' => '2019-04-26 16:55:12',
            ),
            137 => 
            array (
                'client_id' => 199,
                'user_id' => 652,
                'created_at' => '2019-04-26 16:56:07',
            ),
            138 => 
            array (
                'client_id' => 199,
                'user_id' => 653,
                'created_at' => '2019-04-26 17:53:32',
            ),
            139 => 
            array (
                'client_id' => 199,
                'user_id' => 654,
                'created_at' => '2019-04-26 18:03:58',
            ),
            140 => 
            array (
                'client_id' => 199,
                'user_id' => 655,
                'created_at' => '2019-04-26 18:09:44',
            ),
            141 => 
            array (
                'client_id' => 199,
                'user_id' => 656,
                'created_at' => '2019-04-26 18:11:36',
            ),
            142 => 
            array (
                'client_id' => 199,
                'user_id' => 657,
                'created_at' => '2019-04-26 18:42:40',
            ),
            143 => 
            array (
                'client_id' => 199,
                'user_id' => 658,
                'created_at' => '2019-05-02 11:59:30',
            ),
            144 => 
            array (
                'client_id' => 199,
                'user_id' => 659,
                'created_at' => '2019-05-02 15:54:55',
            ),
        ));
        
        
    }
}