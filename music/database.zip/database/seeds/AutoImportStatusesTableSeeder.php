<?php

use Illuminate\Database\Seeder;

class AutoImportStatusesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_statuses')->delete();
        
        \DB::table('auto_import_statuses')->insert(array (
            0 => 
            array (
                'id' => 1,
                'auto_import_id' => 1,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-25 12:24:25',
                'updated_at' => '2019-01-25 12:24:25',
            ),
            1 => 
            array (
                'id' => 16,
                'auto_import_id' => 47,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 12:53:22',
                'updated_at' => '2019-01-09 12:53:22',
            ),
            2 => 
            array (
                'id' => 18,
                'auto_import_id' => 49,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 13:28:29',
                'updated_at' => '2019-01-09 13:28:29',
            ),
            3 => 
            array (
                'id' => 19,
                'auto_import_id' => 50,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 16:08:14',
                'updated_at' => '2019-01-09 16:08:14',
            ),
            4 => 
            array (
                'id' => 20,
                'auto_import_id' => 51,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 16:39:14',
                'updated_at' => '2019-01-09 16:39:14',
            ),
            5 => 
            array (
                'id' => 21,
                'auto_import_id' => 52,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 16:46:10',
                'updated_at' => '2019-01-09 16:46:10',
            ),
            6 => 
            array (
                'id' => 22,
                'auto_import_id' => 53,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-09 17:06:16',
                'updated_at' => '2019-01-09 17:06:16',
            ),
            7 => 
            array (
                'id' => 23,
                'auto_import_id' => 54,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-14 15:16:45',
                'updated_at' => '2019-01-14 15:16:45',
            ),
            8 => 
            array (
                'id' => 24,
                'auto_import_id' => 55,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-14 15:55:30',
                'updated_at' => '2019-01-14 15:55:30',
            ),
            9 => 
            array (
                'id' => 25,
                'auto_import_id' => 56,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-14 16:11:10',
                'updated_at' => '2019-01-14 16:11:10',
            ),
            10 => 
            array (
                'id' => 26,
                'auto_import_id' => 57,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-17 16:58:44',
                'updated_at' => '2019-01-17 16:58:44',
            ),
            11 => 
            array (
                'id' => 27,
                'auto_import_id' => 58,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-17 17:00:32',
                'updated_at' => '2019-01-17 17:00:32',
            ),
            12 => 
            array (
                'id' => 28,
                'auto_import_id' => 59,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-18 17:52:11',
                'updated_at' => '2019-01-18 17:52:11',
            ),
            13 => 
            array (
                'id' => 30,
                'auto_import_id' => 23,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-25 12:41:56',
                'updated_at' => '2019-01-25 12:41:56',
            ),
            14 => 
            array (
                'id' => 31,
                'auto_import_id' => 24,
                'continuous_failed_count' => 0,
                'created_at' => '2019-01-31 12:28:27',
                'updated_at' => '2019-01-31 12:28:27',
            ),
            15 => 
            array (
                'id' => 36,
                'auto_import_id' => 29,
                'continuous_failed_count' => 0,
                'created_at' => '2019-04-25 16:32:33',
                'updated_at' => '2019-04-25 16:32:33',
            ),
            16 => 
            array (
                'id' => 37,
                'auto_import_id' => 30,
                'continuous_failed_count' => 0,
                'created_at' => '2019-04-25 16:33:40',
                'updated_at' => '2019-04-25 16:33:40',
            ),
        ));
        
        
    }
}