<?php

use Illuminate\Database\Seeder;

class TriggerTagsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('trigger_tags')->delete();
        
        \DB::table('trigger_tags')->insert(array (
            0 => 
            array (
                'tag_id' => 1,
                'auto_import_trigger_id' => 116,
            ),
            1 => 
            array (
                'tag_id' => 2,
                'auto_import_trigger_id' => 116,
            ),
            2 => 
            array (
                'tag_id' => 5,
                'auto_import_trigger_id' => 116,
            ),
            3 => 
            array (
                'tag_id' => 6,
                'auto_import_trigger_id' => 116,
            ),
            4 => 
            array (
                'tag_id' => 7,
                'auto_import_trigger_id' => 116,
            ),
            5 => 
            array (
                'tag_id' => 5,
                'auto_import_trigger_id' => 117,
            ),
            6 => 
            array (
                'tag_id' => 6,
                'auto_import_trigger_id' => 117,
            ),
            7 => 
            array (
                'tag_id' => 7,
                'auto_import_trigger_id' => 117,
            ),
            8 => 
            array (
                'tag_id' => 3,
                'auto_import_trigger_id' => 121,
            ),
            9 => 
            array (
                'tag_id' => 4,
                'auto_import_trigger_id' => 121,
            ),
            10 => 
            array (
                'tag_id' => 3,
                'auto_import_trigger_id' => 122,
            ),
            11 => 
            array (
                'tag_id' => 5,
                'auto_import_trigger_id' => 123,
            ),
            12 => 
            array (
                'tag_id' => 2,
                'auto_import_trigger_id' => 124,
            ),
            13 => 
            array (
                'tag_id' => 1,
                'auto_import_trigger_id' => 124,
            ),
            14 => 
            array (
                'tag_id' => 2,
                'auto_import_trigger_id' => 125,
            ),
            15 => 
            array (
                'tag_id' => 1,
                'auto_import_trigger_id' => 125,
            ),
            16 => 
            array (
                'tag_id' => 34,
                'auto_import_trigger_id' => 127,
            ),
            17 => 
            array (
                'tag_id' => 33,
                'auto_import_trigger_id' => 127,
            ),
            18 => 
            array (
                'tag_id' => 32,
                'auto_import_trigger_id' => 128,
            ),
            19 => 
            array (
                'tag_id' => 31,
                'auto_import_trigger_id' => 128,
            ),
            20 => 
            array (
                'tag_id' => 34,
                'auto_import_trigger_id' => 129,
            ),
            21 => 
            array (
                'tag_id' => 34,
                'auto_import_trigger_id' => 131,
            ),
            22 => 
            array (
                'tag_id' => 33,
                'auto_import_trigger_id' => 131,
            ),
            23 => 
            array (
                'tag_id' => 32,
                'auto_import_trigger_id' => 131,
            ),
            24 => 
            array (
                'tag_id' => 31,
                'auto_import_trigger_id' => 131,
            ),
            25 => 
            array (
                'tag_id' => 33,
                'auto_import_trigger_id' => 132,
            ),
            26 => 
            array (
                'tag_id' => 32,
                'auto_import_trigger_id' => 132,
            ),
            27 => 
            array (
                'tag_id' => 31,
                'auto_import_trigger_id' => 132,
            ),
            28 => 
            array (
                'tag_id' => 33,
                'auto_import_trigger_id' => 133,
            ),
            29 => 
            array (
                'tag_id' => 32,
                'auto_import_trigger_id' => 133,
            ),
        ));
        
        
    }
}