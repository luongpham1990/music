<?php

use Illuminate\Database\Seeder;

class MapDataGroupsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('map_data_groups')->delete();
        
        \DB::table('map_data_groups')->insert(array (
            0 => 
            array (
                'id' => 1,
                'client_id' => 1,
                'position' => 8,
                'name' => 'Điểm 1',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 55,
                'base_color_code' => '#e03d72',
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            1 => 
            array (
                'id' => 2,
                'client_id' => 1,
                'position' => 1,
                'name' => 'Polygon 1',
                'init_display' => 0,
                'map_data_div' => 3,
                'icon_id' => 55,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 17:56:38',
                'updated_at' => '2019-02-25 17:56:38',
            ),
            2 => 
            array (
                'id' => 3,
                'client_id' => 1,
                'position' => 2,
                'name' => 'Điểm 1',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 51,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 17:56:53',
                'updated_at' => '2019-02-25 17:56:53',
            ),
            3 => 
            array (
                'id' => 4,
                'client_id' => 1,
                'position' => 3,
                'name' => 'Đường',
                'init_display' => 0,
                'map_data_div' => 2,
                'icon_id' => 58,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 17:57:45',
                'updated_at' => '2019-02-26 16:00:13',
            ),
            4 => 
            array (
                'id' => 5,
                'client_id' => 1,
                'position' => 4,
                'name' => 'Polygon',
                'init_display' => 0,
                'map_data_div' => 3,
                'icon_id' => 58,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 17:58:48',
                'updated_at' => '2019-02-26 16:30:08',
            ),
            5 => 
            array (
                'id' => 6,
                'client_id' => 1,
                'position' => 5,
                'name' => 'Polygon 2',
                'init_display' => 0,
                'map_data_div' => 3,
                'icon_id' => 59,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 17:59:18',
                'updated_at' => '2019-02-25 17:59:18',
            ),
            6 => 
            array (
                'id' => 8,
                'client_id' => 1,
                'position' => 6,
                'name' => 'Điểm 5',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 60,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 18:11:28',
                'updated_at' => '2019-02-25 18:52:34',
            ),
            7 => 
            array (
                'id' => 9,
                'client_id' => 1,
                'position' => 7,
                'name' => '音声再生」アイコンは、現状では動作しない音声再生',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 55,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-02-25 19:25:53',
                'updated_at' => '2019-02-26 16:35:07',
            ),
            8 => 
            array (
                'id' => 10,
                'client_id' => 199,
                'position' => 1,
                'name' => 'Diem',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 88,
                'base_color_code' => '#ffaf01',
                'created_at' => '2019-03-11 17:38:52',
                'updated_at' => '2019-04-18 15:36:34',
            ),
            9 => 
            array (
                'id' => 11,
                'client_id' => 199,
                'position' => 2,
                'name' => 'Duong',
                'init_display' => 0,
                'map_data_div' => 2,
                'icon_id' => 89,
                'base_color_code' => '#fffc03',
                'created_at' => '2019-03-11 17:39:31',
                'updated_at' => '2019-04-23 16:32:13',
            ),
            10 => 
            array (
                'id' => 12,
                'client_id' => 199,
                'position' => 3,
                'name' => 'Polygon',
                'init_display' => 0,
                'map_data_div' => 3,
                'icon_id' => 90,
                'base_color_code' => '#fffc03',
                'created_at' => '2019-03-11 17:41:57',
                'updated_at' => '2019-04-24 18:38:29',
            ),
            11 => 
            array (
                'id' => 13,
                'client_id' => 202,
                'position' => 1,
                'name' => 'Nhom Diem 1',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 106,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-04-09 18:47:39',
                'updated_at' => '2019-04-09 18:47:39',
            ),
            12 => 
            array (
                'id' => 14,
                'client_id' => 202,
                'position' => 2,
                'name' => 'Nhom diem 2',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 107,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-04-09 18:47:55',
                'updated_at' => '2019-04-09 18:47:55',
            ),
            13 => 
            array (
                'id' => 15,
                'client_id' => 202,
                'position' => 3,
                'name' => 'Nhom Polygol',
                'init_display' => 0,
                'map_data_div' => 3,
                'icon_id' => 111,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-04-09 19:03:42',
                'updated_at' => '2019-04-09 19:03:42',
            ),
            14 => 
            array (
                'id' => 16,
                'client_id' => 199,
                'position' => 4,
                'name' => 'Loai Diem 2',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 87,
                'base_color_code' => '#68447f',
                'created_at' => '2019-04-11 11:52:20',
                'updated_at' => '2019-04-11 12:00:43',
            ),
            15 => 
            array (
                'id' => 17,
                'client_id' => 199,
                'position' => 5,
                'name' => 'Loai diem 3',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 88,
                'base_color_code' => '#e03d72',
                'created_at' => '2019-04-11 12:01:18',
                'updated_at' => '2019-04-23 15:25:08',
            ),
            16 => 
            array (
                'id' => 18,
                'client_id' => 199,
                'position' => 6,
                'name' => 'Loai Duong 2',
                'init_display' => 1,
                'map_data_div' => 2,
                'icon_id' => 89,
                'base_color_code' => '#ff9800',
                'created_at' => '2019-04-11 12:01:45',
                'updated_at' => '2019-04-11 12:01:45',
            ),
            17 => 
            array (
                'id' => 19,
                'client_id' => 199,
                'position' => 7,
                'name' => 'Loai Polygol 2',
                'init_display' => 1,
                'map_data_div' => 3,
                'icon_id' => 90,
                'base_color_code' => '#bbea66',
                'created_at' => '2019-04-11 12:02:10',
                'updated_at' => '2019-04-23 16:32:52',
            ),
            18 => 
            array (
                'id' => 20,
                'client_id' => 199,
                'position' => 8,
                'name' => 'Benh Vien',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 119,
                'base_color_code' => '#ffaf01',
                'created_at' => '2019-04-12 15:45:11',
                'updated_at' => '2019-04-25 13:47:02',
            ),
            19 => 
            array (
                'id' => 21,
                'client_id' => 199,
                'position' => 9,
                'name' => 'Truong Hoc',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 131,
                'base_color_code' => '#27601b',
                'created_at' => '2019-04-12 15:45:59',
                'updated_at' => '2019-04-25 10:31:05',
            ),
            20 => 
            array (
                'id' => 22,
                'client_id' => 199,
                'position' => 10,
                'name' => 'Tram Xang',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 118,
                'base_color_code' => '#ff6201',
                'created_at' => '2019-04-12 15:46:27',
                'updated_at' => '2019-04-12 15:46:27',
            ),
            21 => 
            array (
                'id' => 23,
                'client_id' => 199,
                'position' => 11,
                'name' => 'Nguon nuoc',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 121,
                'base_color_code' => '#a94f7a',
                'created_at' => '2019-04-12 15:49:50',
                'updated_at' => '2019-04-12 15:49:50',
            ),
            22 => 
            array (
                'id' => 24,
                'client_id' => 199,
                'position' => 12,
                'name' => 'Tu Vien',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 122,
                'base_color_code' => '#148ed0',
                'created_at' => '2019-04-12 15:50:24',
                'updated_at' => '2019-04-17 11:12:57',
            ),
            23 => 
            array (
                'id' => 25,
                'client_id' => 199,
                'position' => 13,
                'name' => 'Noi Lanh Nan',
                'init_display' => 1,
                'map_data_div' => 1,
                'icon_id' => 123,
                'base_color_code' => '#fff245',
                'created_at' => '2019-04-12 15:50:40',
                'updated_at' => '2019-04-23 15:26:33',
            ),
            24 => 
            array (
                'id' => 26,
                'client_id' => 199,
                'position' => 14,
                'name' => 'Co so so tan',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 120,
                'base_color_code' => '#fa5eaf',
                'created_at' => '2019-04-12 15:54:14',
                'updated_at' => '2019-04-23 15:59:23',
            ),
            25 => 
            array (
                'id' => 27,
                'client_id' => 199,
                'position' => 15,
                'name' => 'Nha Thuoc',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 133,
                'base_color_code' => '#eb6119',
                'created_at' => '2019-04-17 10:56:36',
                'updated_at' => '2019-04-17 10:56:36',
            ),
            26 => 
            array (
                'id' => 28,
                'client_id' => 199,
                'position' => 16,
                'name' => 'Test map2',
                'init_display' => 0,
                'map_data_div' => 1,
                'icon_id' => 88,
                'base_color_code' => '#ffaf01',
                'created_at' => '2019-04-24 17:49:49',
                'updated_at' => '2019-04-24 17:49:49',
            ),
        ));
        
        
    }
}