<?php

use Illuminate\Database\Seeder;

class MenusTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('menus')->delete();
        
        \DB::table('menus')->insert(array (
            0 => 
            array (
                'id' => 4,
                'client_id' => 1,
                'position' => 15,
                'menu_div' => 1,
                'icon_id' => 2,
                'name' => 'ニュース',
                'created_at' => '2018-11-27 13:15:59',
                'updated_at' => '2018-11-30 16:52:03',
            ),
            1 => 
            array (
                'id' => 5,
                'client_id' => 1,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 4,
                'name' => 'コンテンツ',
                'created_at' => '2018-11-27 13:16:13',
                'updated_at' => '2018-12-05 15:43:45',
            ),
            2 => 
            array (
                'id' => 6,
                'client_id' => 1,
                'position' => 14,
                'menu_div' => 2,
                'icon_id' => 4,
                'name' => 'Gioi Thieu',
                'created_at' => '2018-11-27 13:16:19',
                'updated_at' => '2019-01-28 12:54:22',
            ),
            3 => 
            array (
                'id' => 17,
                'client_id' => 1,
                'position' => 2,
                'menu_div' => 1,
                'icon_id' => 4,
                'name' => 'Menu1',
                'created_at' => '2018-11-28 16:46:33',
                'updated_at' => '2018-12-05 15:43:44',
            ),
            4 => 
            array (
                'id' => 18,
                'client_id' => 1,
                'position' => 12,
                'menu_div' => 1,
                'icon_id' => 5,
                'name' => '820',
                'created_at' => '2018-11-28 16:55:49',
                'updated_at' => '2018-11-30 16:51:56',
            ),
            5 => 
            array (
                'id' => 31,
                'client_id' => 1,
                'position' => 13,
                'menu_div' => 2,
                'icon_id' => 6,
                'name' => 'Trang chu',
                'created_at' => '2018-11-29 17:42:29',
                'updated_at' => '2019-01-28 12:54:08',
            ),
            6 => 
            array (
                'id' => 32,
                'client_id' => 1,
                'position' => 19,
                'menu_div' => 2,
                'icon_id' => 8,
                'name' => 'Tin tuc',
                'created_at' => '2018-11-29 17:42:41',
                'updated_at' => '2019-01-28 12:54:36',
            ),
            7 => 
            array (
                'id' => 45,
                'client_id' => 1,
                'position' => 54,
                'menu_div' => 3,
                'icon_id' => 15,
                'name' => 'Mode Thien Tai',
                'created_at' => '2018-12-04 12:22:43',
                'updated_at' => '2019-01-28 12:55:00',
            ),
            8 => 
            array (
                'id' => 49,
                'client_id' => 72,
                'position' => 1,
                'menu_div' => 0,
                'icon_id' => 22,
                'name' => 'Giới thiệu',
                'created_at' => '2018-12-07 13:25:18',
                'updated_at' => '2018-12-07 13:25:18',
            ),
            9 => 
            array (
                'id' => 52,
                'client_id' => 1,
                'position' => 57,
                'menu_div' => 2,
                'icon_id' => 5,
                'name' => 'Thi Truong',
                'created_at' => '2018-12-07 16:47:43',
                'updated_at' => '2019-01-28 12:55:24',
            ),
            10 => 
            array (
                'id' => 53,
                'client_id' => 72,
                'position' => 3,
                'menu_div' => 1,
                'icon_id' => 26,
                'name' => 'Trang chủ',
                'created_at' => '2018-12-07 16:48:58',
                'updated_at' => '2019-01-30 17:54:35',
            ),
            11 => 
            array (
                'id' => 54,
                'client_id' => 70,
                'position' => 1,
                'menu_div' => 0,
                'icon_id' => 32,
                'name' => 'aaaa',
                'created_at' => '2018-12-07 16:49:03',
                'updated_at' => '2018-12-07 16:49:03',
            ),
            12 => 
            array (
                'id' => 56,
                'client_id' => 72,
                'position' => 5,
                'menu_div' => 1,
                'icon_id' => 21,
                'name' => 'Tin tức',
                'created_at' => '2018-12-07 18:33:20',
                'updated_at' => '2019-01-30 17:54:48',
            ),
            13 => 
            array (
                'id' => 57,
                'client_id' => 72,
                'position' => 8,
                'menu_div' => 1,
                'icon_id' => 25,
                'name' => 'Thời sự',
                'created_at' => '2018-12-07 18:35:00',
                'updated_at' => '2019-01-30 17:55:02',
            ),
            14 => 
            array (
                'id' => 58,
                'client_id' => 72,
                'position' => 9,
                'menu_div' => 1,
                'icon_id' => 30,
                'name' => 'Giáo dục',
                'created_at' => '2018-12-07 18:36:15',
                'updated_at' => '2019-01-30 17:55:31',
            ),
            15 => 
            array (
                'id' => 59,
                'client_id' => 71,
                'position' => 1,
                'menu_div' => 1,
                'icon_id' => 23,
                'name' => 'GioiTHieu',
                'created_at' => '2018-12-10 10:49:21',
                'updated_at' => '2018-12-10 10:55:30',
            ),
            16 => 
            array (
                'id' => 60,
                'client_id' => 71,
                'position' => 2,
                'menu_div' => 1,
                'icon_id' => 36,
                'name' => 'コンテンツ',
                'created_at' => '2018-12-10 10:53:53',
                'updated_at' => '2018-12-10 10:55:38',
            ),
            17 => 
            array (
                'id' => 61,
                'client_id' => 71,
                'position' => 3,
                'menu_div' => 1,
                'icon_id' => 37,
                'name' => 'ビジネ',
                'created_at' => '2018-12-10 10:54:13',
                'updated_at' => '2018-12-10 10:55:48',
            ),
            18 => 
            array (
                'id' => 62,
                'client_id' => 71,
                'position' => 4,
                'menu_div' => 1,
                'icon_id' => 23,
                'name' => 'ssssssssssss',
                'created_at' => '2018-12-10 10:54:23',
                'updated_at' => '2018-12-10 10:55:58',
            ),
            19 => 
            array (
                'id' => 63,
                'client_id' => 71,
                'position' => 5,
                'menu_div' => 1,
                'icon_id' => 35,
                'name' => 'gwqqqqqqqqq',
                'created_at' => '2018-12-10 10:54:31',
                'updated_at' => '2018-12-10 10:56:09',
            ),
            20 => 
            array (
                'id' => 64,
                'client_id' => 71,
                'position' => 6,
                'menu_div' => 2,
                'icon_id' => 36,
                'name' => 'ThienTai',
                'created_at' => '2018-12-10 10:54:38',
                'updated_at' => '2018-12-10 10:56:43',
            ),
            21 => 
            array (
                'id' => 65,
                'client_id' => 71,
                'position' => 7,
                'menu_div' => 0,
                'icon_id' => 37,
                'name' => 'ggwwwwwwwwwww',
                'created_at' => '2018-12-10 10:54:50',
                'updated_at' => '2018-12-10 10:54:50',
            ),
            22 => 
            array (
                'id' => 66,
                'client_id' => 72,
                'position' => 6,
                'menu_div' => 2,
                'icon_id' => 34,
                'name' => 'Thientai',
                'created_at' => '2018-12-10 12:31:12',
                'updated_at' => '2018-12-10 15:20:14',
            ),
            23 => 
            array (
                'id' => 67,
                'client_id' => 72,
                'position' => 7,
                'menu_div' => 0,
                'icon_id' => 22,
                'name' => '妖精妖精妖精妖精妖精',
                'created_at' => '2018-12-10 13:06:26',
                'updated_at' => '2018-12-10 15:20:14',
            ),
            24 => 
            array (
                'id' => 68,
                'client_id' => 72,
                'position' => 10,
                'menu_div' => 0,
                'icon_id' => 20,
                'name' => '億億',
                'created_at' => '2018-12-10 15:19:48',
                'updated_at' => '2018-12-10 15:19:48',
            ),
            25 => 
            array (
                'id' => 69,
                'client_id' => 72,
                'position' => 11,
                'menu_div' => 0,
                'icon_id' => 27,
                'name' => 'thutu',
                'created_at' => '2018-12-10 15:20:35',
                'updated_at' => '2018-12-10 15:20:35',
            ),
            26 => 
            array (
                'id' => 70,
                'client_id' => 77,
                'position' => 1,
                'menu_div' => 2,
                'icon_id' => 40,
                'name' => 'Trang chủ',
                'created_at' => '2019-01-30 18:51:23',
                'updated_at' => '2019-01-30 18:51:23',
            ),
            27 => 
            array (
                'id' => 71,
                'client_id' => 77,
                'position' => 2,
                'menu_div' => 3,
                'icon_id' => 39,
                'name' => 'Mode thiên tai',
                'created_at' => '2019-01-30 18:51:37',
                'updated_at' => '2019-01-30 18:51:37',
            ),
            28 => 
            array (
                'id' => 72,
                'client_id' => 77,
                'position' => 3,
                'menu_div' => 4,
                'icon_id' => 41,
                'name' => 'Mode offline',
                'created_at' => '2019-01-30 18:51:55',
                'updated_at' => '2019-01-30 18:51:55',
            ),
            29 => 
            array (
                'id' => 73,
                'client_id' => 77,
                'position' => 4,
                'menu_div' => 4,
                'icon_id' => 40,
                'name' => 'Mode Offline 2',
                'created_at' => '2019-01-30 18:52:13',
                'updated_at' => '2019-01-30 18:52:43',
            ),
            30 => 
            array (
                'id' => 74,
                'client_id' => 77,
                'position' => 5,
                'menu_div' => 2,
                'icon_id' => 39,
                'name' => 'Giới thiệu',
                'created_at' => '2019-01-30 18:53:47',
                'updated_at' => '2019-01-30 18:53:47',
            ),
            31 => 
            array (
                'id' => 75,
                'client_id' => 77,
                'position' => 6,
                'menu_div' => 2,
                'icon_id' => 42,
                'name' => 'Tin Tức',
                'created_at' => '2019-01-30 18:55:14',
                'updated_at' => '2019-01-30 18:55:14',
            ),
            32 => 
            array (
                'id' => 76,
                'client_id' => 77,
                'position' => 7,
                'menu_div' => 2,
                'icon_id' => 45,
                'name' => 'Giáo dục',
                'created_at' => '2019-01-30 18:55:26',
                'updated_at' => '2019-01-30 18:55:26',
            ),
            33 => 
            array (
                'id' => 77,
                'client_id' => 77,
                'position' => 8,
                'menu_div' => 2,
                'icon_id' => 40,
                'name' => 'Tư vấn',
                'created_at' => '2019-01-30 18:55:39',
                'updated_at' => '2019-01-30 18:55:39',
            ),
            34 => 
            array (
                'id' => 78,
                'client_id' => 77,
                'position' => 9,
                'menu_div' => 4,
                'icon_id' => 43,
                'name' => 'Mode offline 3',
                'created_at' => '2019-01-30 18:58:19',
                'updated_at' => '2019-01-30 18:58:19',
            ),
            35 => 
            array (
                'id' => 79,
                'client_id' => 1,
                'position' => 58,
                'menu_div' => 4,
                'icon_id' => 1,
                'name' => 'VISOR VNC',
                'created_at' => '2019-02-14 18:08:16',
                'updated_at' => '2019-02-14 18:08:16',
            ),
            36 => 
            array (
                'id' => 80,
                'client_id' => 1,
                'position' => 60,
                'menu_div' => 4,
                'icon_id' => 19,
                'name' => 'Menu Offline',
                'created_at' => '2019-03-01 16:36:59',
                'updated_at' => '2019-03-04 11:37:50',
            ),
            37 => 
            array (
                'id' => 81,
                'client_id' => 185,
                'position' => 1,
                'menu_div' => 2,
                'icon_id' => 64,
                'name' => 'Menu1',
                'created_at' => '2019-03-01 18:30:57',
                'updated_at' => '2019-03-01 18:30:57',
            ),
            38 => 
            array (
                'id' => 82,
                'client_id' => 185,
                'position' => 2,
                'menu_div' => 2,
                'icon_id' => 66,
                'name' => 'Menu2',
                'created_at' => '2019-03-01 18:31:06',
                'updated_at' => '2019-03-01 18:31:06',
            ),
            39 => 
            array (
                'id' => 83,
                'client_id' => 185,
                'position' => 3,
                'menu_div' => 2,
                'icon_id' => 67,
                'name' => 'Menu 3',
                'created_at' => '2019-03-01 18:31:15',
                'updated_at' => '2019-03-01 18:31:15',
            ),
            40 => 
            array (
                'id' => 84,
                'client_id' => 185,
                'position' => 4,
                'menu_div' => 2,
                'icon_id' => 68,
                'name' => 'Menu4',
                'created_at' => '2019-03-01 18:31:24',
                'updated_at' => '2019-03-01 18:31:24',
            ),
            41 => 
            array (
                'id' => 85,
                'client_id' => 185,
                'position' => 5,
                'menu_div' => 2,
                'icon_id' => 65,
                'name' => 'Menu5',
                'created_at' => '2019-03-01 18:31:31',
                'updated_at' => '2019-03-01 18:31:31',
            ),
            42 => 
            array (
                'id' => 86,
                'client_id' => 185,
                'position' => 6,
                'menu_div' => 3,
                'icon_id' => 65,
                'name' => 'Mode thiên tai',
                'created_at' => '2019-03-01 18:31:55',
                'updated_at' => '2019-03-01 18:32:29',
            ),
            43 => 
            array (
                'id' => 87,
                'client_id' => 185,
                'position' => 7,
                'menu_div' => 4,
                'icon_id' => 68,
                'name' => 'Menu offline',
                'created_at' => '2019-03-01 18:32:51',
                'updated_at' => '2019-03-01 18:32:51',
            ),
            44 => 
            array (
                'id' => 88,
                'client_id' => 185,
                'position' => 8,
                'menu_div' => 4,
                'icon_id' => 67,
                'name' => 'Menu offline 2',
                'created_at' => '2019-03-01 18:33:05',
                'updated_at' => '2019-03-01 18:33:05',
            ),
            45 => 
            array (
                'id' => 89,
                'client_id' => 1,
                'position' => 10,
                'menu_div' => 2,
                'icon_id' => 8,
                'name' => 'Menu_Batch_Post',
                'created_at' => '2019-03-04 11:37:38',
                'updated_at' => '2019-03-04 11:50:35',
            ),
            46 => 
            array (
                'id' => 90,
                'client_id' => 192,
                'position' => 1,
                'menu_div' => 2,
                'icon_id' => 70,
                'name' => 'Trang chu',
                'created_at' => '2019-03-05 13:04:26',
                'updated_at' => '2019-03-05 13:04:26',
            ),
            47 => 
            array (
                'id' => 91,
                'client_id' => 189,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 71,
                'name' => 'menu test mobile',
                'created_at' => '2019-03-11 12:40:50',
                'updated_at' => '2019-03-11 12:40:50',
            ),
            48 => 
            array (
                'id' => 92,
                'client_id' => 190,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 72,
                'name' => 'test mobile offline mode 2',
                'created_at' => '2019-03-11 12:58:10',
                'updated_at' => '2019-03-11 12:58:10',
            ),
            49 => 
            array (
                'id' => 93,
                'client_id' => 191,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 73,
                'name' => 'test mobile offline webpage 3',
                'created_at' => '2019-03-11 13:15:35',
                'updated_at' => '2019-03-11 13:15:35',
            ),
            50 => 
            array (
                'id' => 94,
                'client_id' => 187,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 74,
                'name' => 'test mobile offline webpage 4',
                'created_at' => '2019-03-11 13:30:00',
                'updated_at' => '2019-03-11 13:30:00',
            ),
            51 => 
            array (
                'id' => 95,
                'client_id' => 194,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 75,
                'name' => 'test mobile offline file 1',
                'created_at' => '2019-03-11 13:41:04',
                'updated_at' => '2019-03-11 13:41:14',
            ),
            52 => 
            array (
                'id' => 96,
                'client_id' => 195,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 76,
                'name' => 'test mobile offline file 2',
                'created_at' => '2019-03-11 13:52:10',
                'updated_at' => '2019-03-11 13:52:18',
            ),
            53 => 
            array (
                'id' => 97,
                'client_id' => 196,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 77,
                'name' => 'test mobile offline file 3',
                'created_at' => '2019-03-11 13:56:13',
                'updated_at' => '2019-03-11 13:56:13',
            ),
            54 => 
            array (
                'id' => 98,
                'client_id' => 197,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 78,
                'name' => 'test mobile offline file 4',
                'created_at' => '2019-03-11 14:00:42',
                'updated_at' => '2019-03-11 14:00:42',
            ),
            55 => 
            array (
                'id' => 99,
                'client_id' => 198,
                'position' => 1,
                'menu_div' => 4,
                'icon_id' => 79,
                'name' => 'test mobile offline file 5',
                'created_at' => '2019-03-11 15:11:48',
                'updated_at' => '2019-03-11 15:11:48',
            ),
            56 => 
            array (
                'id' => 100,
                'client_id' => 199,
                'position' => 1,
                'menu_div' => 2,
                'icon_id' => 80,
                'name' => 'Home page',
                'created_at' => '2019-03-11 16:56:28',
                'updated_at' => '2019-03-11 16:56:28',
            ),
            57 => 
            array (
                'id' => 101,
                'client_id' => 199,
                'position' => 2,
                'menu_div' => 2,
                'icon_id' => 81,
                'name' => 'Introduce',
                'created_at' => '2019-03-11 16:56:45',
                'updated_at' => '2019-03-11 16:56:45',
            ),
            58 => 
            array (
                'id' => 102,
                'client_id' => 199,
                'position' => 3,
                'menu_div' => 2,
                'icon_id' => 83,
                'name' => 'News',
                'created_at' => '2019-03-11 16:57:00',
                'updated_at' => '2019-03-11 16:57:00',
            ),
            59 => 
            array (
                'id' => 103,
                'client_id' => 199,
                'position' => 4,
                'menu_div' => 2,
                'icon_id' => 83,
                'name' => 'Education',
                'created_at' => '2019-03-11 16:57:33',
                'updated_at' => '2019-03-11 16:57:33',
            ),
            60 => 
            array (
                'id' => 104,
                'client_id' => 199,
                'position' => 5,
                'menu_div' => 2,
                'icon_id' => 84,
                'name' => 'Science',
                'created_at' => '2019-03-11 16:57:58',
                'updated_at' => '2019-03-11 16:57:58',
            ),
            61 => 
            array (
                'id' => 105,
                'client_id' => 199,
                'position' => 6,
                'menu_div' => 3,
                'icon_id' => 83,
                'name' => 'Disaster mode',
                'created_at' => '2019-03-11 16:59:03',
                'updated_at' => '2019-03-11 16:59:03',
            ),
            62 => 
            array (
                'id' => 106,
                'client_id' => 199,
                'position' => 7,
                'menu_div' => 4,
                'icon_id' => 85,
                'name' => 'Offline menu',
                'created_at' => '2019-03-11 16:59:19',
                'updated_at' => '2019-03-11 16:59:19',
            ),
        ));
        
        
    }
}