<?php

use Illuminate\Database\Seeder;

class FileBodyStorageFilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('file_body_storage_files')->delete();
        
        \DB::table('file_body_storage_files')->insert(array (
            0 => 
            array (
                'id' => 19,
                'file_id' => 20,
                'lang' => 'en',
                'storage_file_id' => 941,
            ),
            1 => 
            array (
                'id' => 21,
                'file_id' => 22,
                'lang' => 'en',
                'storage_file_id' => 1158,
            ),
            2 => 
            array (
                'id' => 22,
                'file_id' => 22,
                'lang' => 'es',
                'storage_file_id' => 1084,
            ),
            3 => 
            array (
                'id' => 23,
                'file_id' => 23,
                'lang' => 'en',
                'storage_file_id' => 1156,
            ),
            4 => 
            array (
                'id' => 24,
                'file_id' => 23,
                'lang' => 'es',
                'storage_file_id' => 1157,
            ),
            5 => 
            array (
                'id' => 25,
                'file_id' => 24,
                'lang' => 'en',
                'storage_file_id' => 1159,
            ),
            6 => 
            array (
                'id' => 26,
                'file_id' => 24,
                'lang' => 'es',
                'storage_file_id' => 1160,
            ),
            7 => 
            array (
                'id' => 30,
                'file_id' => 26,
                'lang' => 'ja',
                'storage_file_id' => 1251,
            ),
            8 => 
            array (
                'id' => 31,
                'file_id' => 26,
                'lang' => 'en',
                'storage_file_id' => 1252,
            ),
            9 => 
            array (
                'id' => 32,
                'file_id' => 26,
                'lang' => 'ko',
                'storage_file_id' => 1253,
            ),
            10 => 
            array (
                'id' => 33,
                'file_id' => 27,
                'lang' => 'ja',
                'storage_file_id' => 1255,
            ),
            11 => 
            array (
                'id' => 34,
                'file_id' => 27,
                'lang' => 'en',
                'storage_file_id' => 1256,
            ),
            12 => 
            array (
                'id' => 35,
                'file_id' => 27,
                'lang' => 'ko',
                'storage_file_id' => 1257,
            ),
            13 => 
            array (
                'id' => 36,
                'file_id' => 28,
                'lang' => 'ja',
                'storage_file_id' => 1482,
            ),
            14 => 
            array (
                'id' => 37,
                'file_id' => 28,
                'lang' => 'en',
                'storage_file_id' => 1483,
            ),
            15 => 
            array (
                'id' => 38,
                'file_id' => 28,
                'lang' => 'ko',
                'storage_file_id' => 1484,
            ),
            16 => 
            array (
                'id' => 39,
                'file_id' => 29,
                'lang' => 'ja',
                'storage_file_id' => 1269,
            ),
            17 => 
            array (
                'id' => 40,
                'file_id' => 29,
                'lang' => 'en',
                'storage_file_id' => 1270,
            ),
            18 => 
            array (
                'id' => 41,
                'file_id' => 29,
                'lang' => 'ko',
                'storage_file_id' => 1271,
            ),
            19 => 
            array (
                'id' => 42,
                'file_id' => 30,
                'lang' => 'ja',
                'storage_file_id' => 1278,
            ),
            20 => 
            array (
                'id' => 43,
                'file_id' => 30,
                'lang' => 'en',
                'storage_file_id' => 1279,
            ),
            21 => 
            array (
                'id' => 45,
                'file_id' => 32,
                'lang' => 'en',
                'storage_file_id' => 1283,
            ),
            22 => 
            array (
                'id' => 46,
                'file_id' => 32,
                'lang' => 'es',
                'storage_file_id' => 1284,
            ),
            23 => 
            array (
                'id' => 49,
                'file_id' => 34,
                'lang' => 'ja',
                'storage_file_id' => 1392,
            ),
            24 => 
            array (
                'id' => 50,
                'file_id' => 34,
                'lang' => 'en',
                'storage_file_id' => 1393,
            ),
            25 => 
            array (
                'id' => 51,
                'file_id' => 34,
                'lang' => 'ko',
                'storage_file_id' => 1394,
            ),
            26 => 
            array (
                'id' => 52,
                'file_id' => 38,
                'lang' => 'ja',
                'storage_file_id' => 2532,
            ),
            27 => 
            array (
                'id' => 53,
                'file_id' => 38,
                'lang' => 'en',
                'storage_file_id' => 1504,
            ),
            28 => 
            array (
                'id' => 54,
                'file_id' => 38,
                'lang' => 'ko',
                'storage_file_id' => 1505,
            ),
            29 => 
            array (
                'id' => 56,
                'file_id' => 40,
                'lang' => 'ja',
                'storage_file_id' => 2574,
            ),
            30 => 
            array (
                'id' => 57,
                'file_id' => 40,
                'lang' => 'ko',
                'storage_file_id' => 1510,
            ),
            31 => 
            array (
                'id' => 86,
                'file_id' => 72,
                'lang' => 'ja',
                'storage_file_id' => 2257,
            ),
            32 => 
            array (
                'id' => 87,
                'file_id' => 73,
                'lang' => 'ja',
                'storage_file_id' => 2258,
            ),
            33 => 
            array (
                'id' => 88,
                'file_id' => 74,
                'lang' => 'ja',
                'storage_file_id' => 2259,
            ),
            34 => 
            array (
                'id' => 89,
                'file_id' => 75,
                'lang' => 'ja',
                'storage_file_id' => 2260,
            ),
            35 => 
            array (
                'id' => 90,
                'file_id' => 76,
                'lang' => 'ja',
                'storage_file_id' => 2263,
            ),
            36 => 
            array (
                'id' => 91,
                'file_id' => 77,
                'lang' => 'ja',
                'storage_file_id' => 2264,
            ),
            37 => 
            array (
                'id' => 92,
                'file_id' => 78,
                'lang' => 'ja',
                'storage_file_id' => 2265,
            ),
            38 => 
            array (
                'id' => 93,
                'file_id' => 79,
                'lang' => 'ja',
                'storage_file_id' => 2266,
            ),
            39 => 
            array (
                'id' => 94,
                'file_id' => 80,
                'lang' => 'ja',
                'storage_file_id' => 2267,
            ),
            40 => 
            array (
                'id' => 95,
                'file_id' => 81,
                'lang' => 'ja',
                'storage_file_id' => 2268,
            ),
            41 => 
            array (
                'id' => 96,
                'file_id' => 82,
                'lang' => 'ja',
                'storage_file_id' => 2269,
            ),
            42 => 
            array (
                'id' => 97,
                'file_id' => 83,
                'lang' => 'ja',
                'storage_file_id' => 2406,
            ),
            43 => 
            array (
                'id' => 98,
                'file_id' => 40,
                'lang' => 'en',
                'storage_file_id' => 2506,
            ),
            44 => 
            array (
                'id' => 99,
                'file_id' => 84,
                'lang' => 'ja',
                'storage_file_id' => 2507,
            ),
            45 => 
            array (
                'id' => 100,
                'file_id' => 85,
                'lang' => 'ja',
                'storage_file_id' => 2571,
            ),
            46 => 
            array (
                'id' => 101,
                'file_id' => 85,
                'lang' => 'en',
                'storage_file_id' => 2572,
            ),
            47 => 
            array (
                'id' => 102,
                'file_id' => 85,
                'lang' => 'ko',
                'storage_file_id' => 2573,
            ),
        ));
        
        
    }
}