<?php

use Illuminate\Database\Seeder;

class FilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('files')->delete();
        
        \DB::table('files')->insert(array (
            0 => 
            array (
                'id' => 20,
                'content_id' => 175,
                'lang' => 'en',
                'title' => 'file test finish',
            ),
            1 => 
            array (
                'id' => 22,
                'content_id' => 282,
                'lang' => 'en',
            'title' => 'Test title 2(en)',
            ),
            2 => 
            array (
                'id' => 23,
                'content_id' => 283,
                'lang' => 'en',
            'title' => 'Title (en)',
            ),
            3 => 
            array (
                'id' => 24,
                'content_id' => 284,
                'lang' => 'en',
                'title' => 'file 4 en',
            ),
            4 => 
            array (
                'id' => 26,
                'content_id' => 295,
                'lang' => 'ja',
                'title' => 'test offline mobile file 1 - ja',
            ),
            5 => 
            array (
                'id' => 27,
                'content_id' => 296,
                'lang' => 'ja',
                'title' => 'test offline moblie file 2 - ja',
            ),
            6 => 
            array (
                'id' => 28,
                'content_id' => 298,
                'lang' => 'ja',
                'title' => 'test mobile offline file 3 - ja',
            ),
            7 => 
            array (
                'id' => 29,
                'content_id' => 300,
                'lang' => 'ja',
                'title' => 'test offline file 4 -ja',
            ),
            8 => 
            array (
                'id' => 30,
                'content_id' => 303,
                'lang' => 'ja',
                'title' => 'test offline moblie file 5 - ja',
            ),
            9 => 
            array (
                'id' => 32,
                'content_id' => 305,
                'lang' => 'en',
                'title' => 'title file en',
            ),
            10 => 
            array (
                'id' => 34,
                'content_id' => 331,
                'lang' => 'ja',
                'title' => 'content offline 162 - ja - 2',
            ),
            11 => 
            array (
                'id' => 38,
                'content_id' => 362,
                'lang' => 'ja',
                'title' => 'content offline 162 - ja - 4',
            ),
            12 => 
            array (
                'id' => 40,
                'content_id' => 398,
                'lang' => 'ja',
                'title' => 'thu file 1',
            ),
            13 => 
            array (
                'id' => 72,
                'content_id' => 517,
                'lang' => 'ja',
                'title' => 'Doc ja',
            ),
            14 => 
            array (
                'id' => 73,
                'content_id' => 518,
                'lang' => 'ja',
                'title' => 'Docx ja',
            ),
            15 => 
            array (
                'id' => 74,
                'content_id' => 519,
                'lang' => 'ja',
                'title' => 'Xlsx ja',
            ),
            16 => 
            array (
                'id' => 75,
                'content_id' => 520,
                'lang' => 'ja',
                'title' => 'Pptx ja',
            ),
            17 => 
            array (
                'id' => 76,
                'content_id' => 522,
                'lang' => 'ja',
                'title' => 'Ppt ja',
            ),
            18 => 
            array (
                'id' => 77,
                'content_id' => 523,
                'lang' => 'ja',
                'title' => 'Rtf ja',
            ),
            19 => 
            array (
                'id' => 78,
                'content_id' => 524,
                'lang' => 'ja',
                'title' => 'Wav ja',
            ),
            20 => 
            array (
                'id' => 79,
                'content_id' => 525,
                'lang' => 'ja',
                'title' => 'Mp3 ja',
            ),
            21 => 
            array (
                'id' => 80,
                'content_id' => 526,
                'lang' => 'ja',
                'title' => 'Mp4 ja',
            ),
            22 => 
            array (
                'id' => 81,
                'content_id' => 527,
                'lang' => 'ja',
                'title' => 'txt ja',
            ),
            23 => 
            array (
                'id' => 82,
                'content_id' => 528,
                'lang' => 'ja',
                'title' => 'pdf ja',
            ),
            24 => 
            array (
                'id' => 83,
                'content_id' => 570,
                'lang' => 'ja',
                'title' => 'pdf ja',
            ),
            25 => 
            array (
                'id' => 84,
                'content_id' => 599,
                'lang' => 'ja',
                'title' => 'xls',
            ),
            26 => 
            array (
                'id' => 85,
                'content_id' => 629,
                'lang' => 'ja',
                'title' => 'file ja',
            ),
        ));
        
        
    }
}