<?php

use Illuminate\Database\Seeder;

class AutoImportsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_imports')->delete();
        
        \DB::table('auto_imports')->insert(array (
            0 => 
            array (
                'id' => 1,
                'client_id' => 1,
                'status' => 1,
                'name' => 'rffdf',
                'import_div' => 1,
                'note' => 'dfddg',
                'setting_value' => 'gdgdgdg',
                'content_group_id' => 5,
                'created_at' => '2019-01-09 17:53:07',
                'updated_at' => '2019-01-09 17:53:00',
            ),
            1 => 
            array (
                'id' => 3,
                'client_id' => 72,
                'status' => 1,
                'name' => '1',
                'import_div' => 1,
                'note' => '1',
                'setting_value' => '1',
                'content_group_id' => 45,
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            2 => 
            array (
                'id' => 4,
                'client_id' => 70,
                'status' => 1,
                'name' => '1',
                'import_div' => 1,
                'note' => '1',
                'setting_value' => '1',
                'content_group_id' => 2,
                'created_at' => NULL,
                'updated_at' => NULL,
            ),
            3 => 
            array (
                'id' => 8,
                'client_id' => 1,
                'status' => 1,
                'name' => '添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル添付ファイル',
                'import_div' => 1,
                'note' => 'hello',
                'setting_value' => 'Sdd',
                'content_group_id' => 16,
                'created_at' => '2019-01-11 20:00:00',
                'updated_at' => '2019-01-11 20:50:00',
            ),
            4 => 
            array (
                'id' => 9,
                'client_id' => 1,
                'status' => 1,
                'name' => '取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元',
                'import_div' => 1,
                'note' => '取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元
ffds
f

取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元取り込み元
fd
ff',
                'setting_value' => 'grrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrfdffdddddddddddddddđfqr234e234132412423434234322222222222222222222222222222222222222222222222214234e34e34ewwrèkjfkdè89340582984974892745893457u9345u 439ureifrjfdjfdjfdfdff',
                'content_group_id' => 19,
                'created_at' => '2019-01-14 11:46:10',
                'updated_at' => '2019-01-14 19:19:53',
            ),
            5 => 
            array (
                'id' => 10,
                'client_id' => 1,
                'status' => 0,
                'name' => 'Uoc gi la gio mua he',
                'import_div' => 2,
                'note' => '1
2
2',
                'setting_value' => '3e2323223',
                'content_group_id' => 3,
                'created_at' => '2019-01-14 19:22:24',
                'updated_at' => '2019-01-14 19:22:24',
            ),
            6 => 
            array (
                'id' => 12,
                'client_id' => 1,
                'status' => 0,
                'name' => '＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。＊名称は必ず入力してください。',
                'import_div' => 2,
                'note' => 'test auto import
v

test auto import
test auto import
test auto import',
                'setting_value' => '＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。＊取り込みURLは必ず入力してください。',
                'content_group_id' => 24,
                'created_at' => '2019-01-15 10:58:26',
                'updated_at' => '2019-01-15 10:58:26',
            ),
            7 => 
            array (
                'id' => 13,
                'client_id' => 1,
                'status' => 0,
                'name' => '5555',
                'import_div' => 1,
                'note' => 'ew
ưe
e
ư
ưe
ưe
ư
ew
e
ư',
                'setting_value' => 'admin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-api KEY authentication APIadmin.setting-value-ap',
                'content_group_id' => 28,
                'created_at' => '2019-01-15 11:36:03',
                'updated_at' => '2019-01-17 10:42:14',
            ),
            8 => 
            array (
                'id' => 14,
                'client_id' => 1,
                'status' => 1,
                'name' => 'dads',
                'import_div' => 1,
                'note' => 'dsdfsf',
                'setting_value' => 'fdsfdsf',
                'content_group_id' => 16,
                'created_at' => '2019-01-16 20:22:43',
                'updated_at' => '2019-01-17 10:23:36',
            ),
            9 => 
            array (
                'id' => 15,
                'client_id' => 1,
                'status' => 1,
                'name' => '自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み自動取り込み',
                'import_div' => 2,
                'note' => NULL,
                'setting_value' => 'http://bhbhbhbhbhbh',
                'content_group_id' => 2,
                'created_at' => '2019-01-17 11:02:11',
                'updated_at' => '2019-02-14 12:59:35',
            ),
            10 => 
            array (
                'id' => 17,
                'client_id' => 1,
                'status' => 0,
                'name' => 'ádasda',
                'import_div' => 1,
                'note' => 'adasd',
                'setting_value' => 'đâsd',
                'content_group_id' => 3,
                'created_at' => '2019-01-18 13:10:52',
                'updated_at' => '2019-01-18 13:10:52',
            ),
            11 => 
            array (
                'id' => 19,
                'client_id' => 1,
                'status' => 0,
                'name' => 'Htest2',
                'import_div' => 2,
                'note' => 'あsだsd',
                'setting_value' => 'http://添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が添付ファイルには合計容量が',
                'content_group_id' => 4,
                'created_at' => '2019-01-18 19:02:55',
                'updated_at' => '2019-01-21 15:52:33',
            ),
            12 => 
            array (
                'id' => 20,
                'client_id' => 1,
                'status' => 1,
                'name' => 'Menu1',
                'import_div' => 2,
                'note' => 'hahahah',
                'setting_value' => 'http://google.com.vn',
                'content_group_id' => 24,
                'created_at' => '2019-01-22 11:37:13',
                'updated_at' => '2019-01-22 11:37:13',
            ),
            13 => 
            array (
                'id' => 23,
                'client_id' => 1,
                'status' => 1,
                'name' => 'Menu1',
                'import_div' => 1,
                'note' => 'note test data serve

note test data serve
note test data serve',
                'setting_value' => 'http://ffff',
                'content_group_id' => 35,
                'created_at' => '2019-01-25 12:41:56',
                'updated_at' => '2019-02-14 12:58:17',
            ),
            14 => 
            array (
                'id' => 24,
                'client_id' => 1,
                'status' => 1,
                'name' => 'Auto import test finishAuto import test finishAuto import test finishAuto import test finishAuto import test finishAuto import test finish',
                'import_div' => 1,
                'note' => '前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致前方一致',
                'setting_value' => 'http://fffffffffff',
                'content_group_id' => 63,
                'created_at' => '2019-01-31 12:28:27',
                'updated_at' => '2019-02-14 13:00:33',
            ),
            15 => 
            array (
                'id' => 29,
                'client_id' => 199,
                'status' => 1,
                'name' => 'Trang chu',
                'import_div' => 2,
                'note' => 'shhhh',
                'setting_value' => '2.2',
                'content_group_id' => 165,
                'created_at' => '2019-04-25 16:32:33',
                'updated_at' => '2019-04-25 16:32:33',
            ),
            16 => 
            array (
                'id' => 30,
                'client_id' => 199,
                'status' => 1,
                'name' => 'ag',
                'import_div' => 4,
                'note' => 'gggggggg',
                'setting_value' => '2.0',
                'content_group_id' => 151,
                'created_at' => '2019-04-25 16:33:40',
                'updated_at' => '2019-04-25 16:33:40',
            ),
        ));
        
        
    }
}