<?php

use Illuminate\Database\Seeder;

class AutoImportHistoriesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auto_import_histories')->delete();
        
        
        
    }
}