<?php

use Illuminate\Database\Seeder;

class MapBodyStorageFilesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('map_body_storage_files')->delete();
        
        \DB::table('map_body_storage_files')->insert(array (
            0 => 
            array (
                'id' => 1,
                'map_data_id' => 4,
                'lang' => NULL,
                'storage_file_id' => 1426,
            ),
            1 => 
            array (
                'id' => 11,
                'map_data_id' => 28,
                'lang' => NULL,
                'storage_file_id' => 2025,
            ),
            2 => 
            array (
                'id' => 12,
                'map_data_id' => 31,
                'lang' => NULL,
                'storage_file_id' => 2084,
            ),
            3 => 
            array (
                'id' => 13,
                'map_data_id' => 34,
                'lang' => NULL,
                'storage_file_id' => 2298,
            ),
            4 => 
            array (
                'id' => 14,
                'map_data_id' => 40,
                'lang' => NULL,
                'storage_file_id' => 2316,
            ),
            5 => 
            array (
                'id' => 18,
                'map_data_id' => 46,
                'lang' => NULL,
                'storage_file_id' => 2321,
            ),
            6 => 
            array (
                'id' => 20,
                'map_data_id' => 49,
                'lang' => NULL,
                'storage_file_id' => 2325,
            ),
            7 => 
            array (
                'id' => 21,
                'map_data_id' => 50,
                'lang' => NULL,
                'storage_file_id' => 2326,
            ),
            8 => 
            array (
                'id' => 22,
                'map_data_id' => 37,
                'lang' => NULL,
                'storage_file_id' => 2327,
            ),
            9 => 
            array (
                'id' => 25,
                'map_data_id' => 47,
                'lang' => NULL,
                'storage_file_id' => 2338,
            ),
            10 => 
            array (
                'id' => 26,
                'map_data_id' => 54,
                'lang' => NULL,
                'storage_file_id' => 2340,
            ),
            11 => 
            array (
                'id' => 27,
                'map_data_id' => 54,
                'lang' => NULL,
                'storage_file_id' => 2341,
            ),
            12 => 
            array (
                'id' => 28,
                'map_data_id' => 53,
                'lang' => NULL,
                'storage_file_id' => 2345,
            ),
            13 => 
            array (
                'id' => 29,
                'map_data_id' => 53,
                'lang' => NULL,
                'storage_file_id' => 2346,
            ),
            14 => 
            array (
                'id' => 30,
                'map_data_id' => 53,
                'lang' => NULL,
                'storage_file_id' => 2347,
            ),
            15 => 
            array (
                'id' => 31,
                'map_data_id' => 57,
                'lang' => NULL,
                'storage_file_id' => 2351,
            ),
            16 => 
            array (
                'id' => 32,
                'map_data_id' => 57,
                'lang' => NULL,
                'storage_file_id' => 2352,
            ),
            17 => 
            array (
                'id' => 33,
                'map_data_id' => 58,
                'lang' => NULL,
                'storage_file_id' => 2357,
            ),
            18 => 
            array (
                'id' => 34,
                'map_data_id' => 58,
                'lang' => NULL,
                'storage_file_id' => 2358,
            ),
            19 => 
            array (
                'id' => 35,
                'map_data_id' => 58,
                'lang' => NULL,
                'storage_file_id' => 2359,
            ),
            20 => 
            array (
                'id' => 39,
                'map_data_id' => 51,
                'lang' => NULL,
                'storage_file_id' => 2366,
            ),
            21 => 
            array (
                'id' => 40,
                'map_data_id' => 30,
                'lang' => NULL,
                'storage_file_id' => 2367,
            ),
            22 => 
            array (
                'id' => 43,
                'map_data_id' => 59,
                'lang' => NULL,
                'storage_file_id' => 2375,
            ),
            23 => 
            array (
                'id' => 44,
                'map_data_id' => 59,
                'lang' => NULL,
                'storage_file_id' => 2376,
            ),
            24 => 
            array (
                'id' => 45,
                'map_data_id' => 61,
                'lang' => NULL,
                'storage_file_id' => 2383,
            ),
            25 => 
            array (
                'id' => 46,
                'map_data_id' => 61,
                'lang' => NULL,
                'storage_file_id' => 2384,
            ),
            26 => 
            array (
                'id' => 49,
                'map_data_id' => 52,
                'lang' => NULL,
                'storage_file_id' => 2396,
            ),
            27 => 
            array (
                'id' => 50,
                'map_data_id' => 62,
                'lang' => NULL,
                'storage_file_id' => 2399,
            ),
            28 => 
            array (
                'id' => 51,
                'map_data_id' => 62,
                'lang' => NULL,
                'storage_file_id' => 2400,
            ),
            29 => 
            array (
                'id' => 52,
                'map_data_id' => 62,
                'lang' => NULL,
                'storage_file_id' => 2401,
            ),
            30 => 
            array (
                'id' => 53,
                'map_data_id' => 64,
                'lang' => NULL,
                'storage_file_id' => 2403,
            ),
            31 => 
            array (
                'id' => 54,
                'map_data_id' => 65,
                'lang' => NULL,
                'storage_file_id' => 2416,
            ),
            32 => 
            array (
                'id' => 55,
                'map_data_id' => 65,
                'lang' => NULL,
                'storage_file_id' => 2417,
            ),
            33 => 
            array (
                'id' => 56,
                'map_data_id' => 65,
                'lang' => NULL,
                'storage_file_id' => 2418,
            ),
            34 => 
            array (
                'id' => 57,
                'map_data_id' => 66,
                'lang' => NULL,
                'storage_file_id' => 2431,
            ),
            35 => 
            array (
                'id' => 58,
                'map_data_id' => 66,
                'lang' => NULL,
                'storage_file_id' => 2432,
            ),
            36 => 
            array (
                'id' => 59,
                'map_data_id' => 66,
                'lang' => NULL,
                'storage_file_id' => 2433,
            ),
            37 => 
            array (
                'id' => 60,
                'map_data_id' => 67,
                'lang' => NULL,
                'storage_file_id' => 2434,
            ),
            38 => 
            array (
                'id' => 61,
                'map_data_id' => 67,
                'lang' => NULL,
                'storage_file_id' => 2435,
            ),
            39 => 
            array (
                'id' => 62,
                'map_data_id' => 67,
                'lang' => NULL,
                'storage_file_id' => 2436,
            ),
            40 => 
            array (
                'id' => 63,
                'map_data_id' => 67,
                'lang' => NULL,
                'storage_file_id' => 2437,
            ),
            41 => 
            array (
                'id' => 64,
                'map_data_id' => 44,
                'lang' => NULL,
                'storage_file_id' => 2439,
            ),
            42 => 
            array (
                'id' => 65,
                'map_data_id' => 44,
                'lang' => NULL,
                'storage_file_id' => 2440,
            ),
            43 => 
            array (
                'id' => 66,
                'map_data_id' => 44,
                'lang' => NULL,
                'storage_file_id' => 2441,
            ),
            44 => 
            array (
                'id' => 67,
                'map_data_id' => 44,
                'lang' => NULL,
                'storage_file_id' => 2442,
            ),
            45 => 
            array (
                'id' => 68,
                'map_data_id' => 45,
                'lang' => NULL,
                'storage_file_id' => 2443,
            ),
            46 => 
            array (
                'id' => 69,
                'map_data_id' => 45,
                'lang' => NULL,
                'storage_file_id' => 2444,
            ),
            47 => 
            array (
                'id' => 70,
                'map_data_id' => 45,
                'lang' => NULL,
                'storage_file_id' => 2445,
            ),
            48 => 
            array (
                'id' => 71,
                'map_data_id' => 45,
                'lang' => NULL,
                'storage_file_id' => 2446,
            ),
            49 => 
            array (
                'id' => 72,
                'map_data_id' => 41,
                'lang' => NULL,
                'storage_file_id' => 2447,
            ),
            50 => 
            array (
                'id' => 73,
                'map_data_id' => 41,
                'lang' => NULL,
                'storage_file_id' => 2448,
            ),
            51 => 
            array (
                'id' => 74,
                'map_data_id' => 41,
                'lang' => NULL,
                'storage_file_id' => 2449,
            ),
            52 => 
            array (
                'id' => 75,
                'map_data_id' => 70,
                'lang' => NULL,
                'storage_file_id' => 2450,
            ),
            53 => 
            array (
                'id' => 76,
                'map_data_id' => 70,
                'lang' => NULL,
                'storage_file_id' => 2451,
            ),
            54 => 
            array (
                'id' => 77,
                'map_data_id' => 70,
                'lang' => NULL,
                'storage_file_id' => 2452,
            ),
            55 => 
            array (
                'id' => 78,
                'map_data_id' => 70,
                'lang' => NULL,
                'storage_file_id' => 2453,
            ),
            56 => 
            array (
                'id' => 79,
                'map_data_id' => 71,
                'lang' => NULL,
                'storage_file_id' => 2454,
            ),
            57 => 
            array (
                'id' => 80,
                'map_data_id' => 73,
                'lang' => NULL,
                'storage_file_id' => 2455,
            ),
            58 => 
            array (
                'id' => 81,
                'map_data_id' => 73,
                'lang' => NULL,
                'storage_file_id' => 2456,
            ),
            59 => 
            array (
                'id' => 82,
                'map_data_id' => 73,
                'lang' => NULL,
                'storage_file_id' => 2457,
            ),
            60 => 
            array (
                'id' => 83,
                'map_data_id' => 74,
                'lang' => NULL,
                'storage_file_id' => 2468,
            ),
            61 => 
            array (
                'id' => 84,
                'map_data_id' => 74,
                'lang' => NULL,
                'storage_file_id' => 2469,
            ),
            62 => 
            array (
                'id' => 85,
                'map_data_id' => 74,
                'lang' => NULL,
                'storage_file_id' => 2470,
            ),
            63 => 
            array (
                'id' => 86,
                'map_data_id' => 76,
                'lang' => NULL,
                'storage_file_id' => 2471,
            ),
            64 => 
            array (
                'id' => 87,
                'map_data_id' => 68,
                'lang' => NULL,
                'storage_file_id' => 2485,
            ),
            65 => 
            array (
                'id' => 88,
                'map_data_id' => 68,
                'lang' => NULL,
                'storage_file_id' => 2486,
            ),
            66 => 
            array (
                'id' => 89,
                'map_data_id' => 68,
                'lang' => NULL,
                'storage_file_id' => 2487,
            ),
            67 => 
            array (
                'id' => 90,
                'map_data_id' => 68,
                'lang' => NULL,
                'storage_file_id' => 2488,
            ),
            68 => 
            array (
                'id' => 91,
                'map_data_id' => 75,
                'lang' => NULL,
                'storage_file_id' => 2489,
            ),
            69 => 
            array (
                'id' => 92,
                'map_data_id' => 38,
                'lang' => NULL,
                'storage_file_id' => 2490,
            ),
            70 => 
            array (
                'id' => 93,
                'map_data_id' => 38,
                'lang' => NULL,
                'storage_file_id' => 2491,
            ),
            71 => 
            array (
                'id' => 94,
                'map_data_id' => 38,
                'lang' => NULL,
                'storage_file_id' => 2492,
            ),
            72 => 
            array (
                'id' => 95,
                'map_data_id' => 38,
                'lang' => NULL,
                'storage_file_id' => 2493,
            ),
            73 => 
            array (
                'id' => 96,
                'map_data_id' => 39,
                'lang' => NULL,
                'storage_file_id' => 2494,
            ),
            74 => 
            array (
                'id' => 97,
                'map_data_id' => 78,
                'lang' => NULL,
                'storage_file_id' => 2520,
            ),
            75 => 
            array (
                'id' => 98,
                'map_data_id' => 79,
                'lang' => NULL,
                'storage_file_id' => 2521,
            ),
            76 => 
            array (
                'id' => 99,
                'map_data_id' => 79,
                'lang' => NULL,
                'storage_file_id' => 2522,
            ),
            77 => 
            array (
                'id' => 100,
                'map_data_id' => 79,
                'lang' => NULL,
                'storage_file_id' => 2523,
            ),
            78 => 
            array (
                'id' => 101,
                'map_data_id' => 79,
                'lang' => NULL,
                'storage_file_id' => 2524,
            ),
            79 => 
            array (
                'id' => 102,
                'map_data_id' => 79,
                'lang' => NULL,
                'storage_file_id' => 2525,
            ),
            80 => 
            array (
                'id' => 103,
                'map_data_id' => 80,
                'lang' => NULL,
                'storage_file_id' => 2526,
            ),
            81 => 
            array (
                'id' => 104,
                'map_data_id' => 80,
                'lang' => NULL,
                'storage_file_id' => 2527,
            ),
            82 => 
            array (
                'id' => 105,
                'map_data_id' => 80,
                'lang' => NULL,
                'storage_file_id' => 2528,
            ),
            83 => 
            array (
                'id' => 106,
                'map_data_id' => 80,
                'lang' => NULL,
                'storage_file_id' => 2529,
            ),
            84 => 
            array (
                'id' => 107,
                'map_data_id' => 80,
                'lang' => NULL,
                'storage_file_id' => 2530,
            ),
            85 => 
            array (
                'id' => 108,
                'map_data_id' => 80,
                'lang' => NULL,
                'storage_file_id' => 2531,
            ),
            86 => 
            array (
                'id' => 109,
                'map_data_id' => 81,
                'lang' => NULL,
                'storage_file_id' => 2534,
            ),
            87 => 
            array (
                'id' => 110,
                'map_data_id' => 81,
                'lang' => NULL,
                'storage_file_id' => 2535,
            ),
            88 => 
            array (
                'id' => 111,
                'map_data_id' => 81,
                'lang' => NULL,
                'storage_file_id' => 2536,
            ),
            89 => 
            array (
                'id' => 112,
                'map_data_id' => 81,
                'lang' => NULL,
                'storage_file_id' => 2537,
            ),
            90 => 
            array (
                'id' => 113,
                'map_data_id' => 82,
                'lang' => NULL,
                'storage_file_id' => 2554,
            ),
            91 => 
            array (
                'id' => 114,
                'map_data_id' => 82,
                'lang' => NULL,
                'storage_file_id' => 2555,
            ),
            92 => 
            array (
                'id' => 115,
                'map_data_id' => 82,
                'lang' => NULL,
                'storage_file_id' => 2556,
            ),
            93 => 
            array (
                'id' => 116,
                'map_data_id' => 83,
                'lang' => NULL,
                'storage_file_id' => 2557,
            ),
            94 => 
            array (
                'id' => 117,
                'map_data_id' => 83,
                'lang' => NULL,
                'storage_file_id' => 2558,
            ),
            95 => 
            array (
                'id' => 118,
                'map_data_id' => 83,
                'lang' => NULL,
                'storage_file_id' => 2559,
            ),
            96 => 
            array (
                'id' => 119,
                'map_data_id' => 83,
                'lang' => NULL,
                'storage_file_id' => 2560,
            ),
            97 => 
            array (
                'id' => 120,
                'map_data_id' => 84,
                'lang' => NULL,
                'storage_file_id' => 2561,
            ),
            98 => 
            array (
                'id' => 121,
                'map_data_id' => 84,
                'lang' => NULL,
                'storage_file_id' => 2562,
            ),
            99 => 
            array (
                'id' => 122,
                'map_data_id' => 84,
                'lang' => NULL,
                'storage_file_id' => 2563,
            ),
            100 => 
            array (
                'id' => 123,
                'map_data_id' => 87,
                'lang' => NULL,
                'storage_file_id' => 2565,
            ),
            101 => 
            array (
                'id' => 124,
                'map_data_id' => 87,
                'lang' => NULL,
                'storage_file_id' => 2566,
            ),
            102 => 
            array (
                'id' => 125,
                'map_data_id' => 88,
                'lang' => NULL,
                'storage_file_id' => 2568,
            ),
            103 => 
            array (
                'id' => 126,
                'map_data_id' => 88,
                'lang' => NULL,
                'storage_file_id' => 2569,
            ),
            104 => 
            array (
                'id' => 127,
                'map_data_id' => 88,
                'lang' => NULL,
                'storage_file_id' => 2570,
            ),
        ));
        
        
    }
}