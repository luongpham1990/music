<?php

use Illuminate\Database\Seeder;

class TutorialsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('tutorials')->delete();
        
        \DB::table('tutorials')->insert(array (
            0 => 
            array (
                'id' => 2,
                'client_id' => 1,
                'position' => 2,
                'slide_image_id' => 567,
            ),
            1 => 
            array (
                'id' => 3,
                'client_id' => 1,
                'position' => 3,
                'slide_image_id' => 568,
            ),
            2 => 
            array (
                'id' => 4,
                'client_id' => 1,
                'position' => 4,
                'slide_image_id' => 569,
            ),
            3 => 
            array (
                'id' => 5,
                'client_id' => 1,
                'position' => 5,
                'slide_image_id' => 573,
            ),
            4 => 
            array (
                'id' => 6,
                'client_id' => 1,
                'position' => 1,
                'slide_image_id' => 572,
            ),
            5 => 
            array (
                'id' => 7,
                'client_id' => 72,
                'position' => 1,
                'slide_image_id' => 769,
            ),
            6 => 
            array (
                'id' => 8,
                'client_id' => 72,
                'position' => 2,
                'slide_image_id' => 770,
            ),
            7 => 
            array (
                'id' => 9,
                'client_id' => 72,
                'position' => 3,
                'slide_image_id' => 771,
            ),
            8 => 
            array (
                'id' => 10,
                'client_id' => 72,
                'position' => 4,
                'slide_image_id' => 772,
            ),
            9 => 
            array (
                'id' => 11,
                'client_id' => 72,
                'position' => 5,
                'slide_image_id' => 773,
            ),
            10 => 
            array (
                'id' => 12,
                'client_id' => 73,
                'position' => 1,
                'slide_image_id' => 1001,
            ),
            11 => 
            array (
                'id' => 13,
                'client_id' => 182,
                'position' => 1,
                'slide_image_id' => 1003,
            ),
            12 => 
            array (
                'id' => 14,
                'client_id' => 183,
                'position' => 1,
                'slide_image_id' => 1005,
            ),
            13 => 
            array (
                'id' => 15,
                'client_id' => 73,
                'position' => 2,
                'slide_image_id' => 1006,
            ),
            14 => 
            array (
                'id' => 16,
                'client_id' => 73,
                'position' => 3,
                'slide_image_id' => 1007,
            ),
            15 => 
            array (
                'id' => 17,
                'client_id' => 73,
                'position' => 4,
                'slide_image_id' => 1008,
            ),
            16 => 
            array (
                'id' => 18,
                'client_id' => 73,
                'position' => 5,
                'slide_image_id' => 1009,
            ),
            17 => 
            array (
                'id' => 19,
                'client_id' => 183,
                'position' => 2,
                'slide_image_id' => 1010,
            ),
            18 => 
            array (
                'id' => 20,
                'client_id' => 183,
                'position' => 3,
                'slide_image_id' => 1011,
            ),
            19 => 
            array (
                'id' => 21,
                'client_id' => 183,
                'position' => 4,
                'slide_image_id' => 1012,
            ),
            20 => 
            array (
                'id' => 22,
                'client_id' => 184,
                'position' => 1,
                'slide_image_id' => 1014,
            ),
            21 => 
            array (
                'id' => 23,
                'client_id' => 184,
                'position' => 2,
                'slide_image_id' => 1015,
            ),
            22 => 
            array (
                'id' => 24,
                'client_id' => 184,
                'position' => 3,
                'slide_image_id' => 1016,
            ),
            23 => 
            array (
                'id' => 25,
                'client_id' => 184,
                'position' => 4,
                'slide_image_id' => 1017,
            ),
            24 => 
            array (
                'id' => 26,
                'client_id' => 184,
                'position' => 5,
                'slide_image_id' => 1018,
            ),
            25 => 
            array (
                'id' => 27,
                'client_id' => 185,
                'position' => 1,
                'slide_image_id' => 1020,
            ),
            26 => 
            array (
                'id' => 28,
                'client_id' => 185,
                'position' => 2,
                'slide_image_id' => 1021,
            ),
            27 => 
            array (
                'id' => 30,
                'client_id' => 185,
                'position' => 4,
                'slide_image_id' => 1023,
            ),
            28 => 
            array (
                'id' => 32,
                'client_id' => 187,
                'position' => 1,
                'slide_image_id' => 1034,
            ),
            29 => 
            array (
                'id' => 33,
                'client_id' => 187,
                'position' => 2,
                'slide_image_id' => 1035,
            ),
            30 => 
            array (
                'id' => 34,
                'client_id' => 187,
                'position' => 3,
                'slide_image_id' => 1036,
            ),
            31 => 
            array (
                'id' => 35,
                'client_id' => 189,
                'position' => 1,
                'slide_image_id' => 1040,
            ),
            32 => 
            array (
                'id' => 36,
                'client_id' => 189,
                'position' => 2,
                'slide_image_id' => 1041,
            ),
            33 => 
            array (
                'id' => 37,
                'client_id' => 189,
                'position' => 3,
                'slide_image_id' => 1042,
            ),
            34 => 
            array (
                'id' => 38,
                'client_id' => 190,
                'position' => 1,
                'slide_image_id' => 1050,
            ),
            35 => 
            array (
                'id' => 39,
                'client_id' => 190,
                'position' => 2,
                'slide_image_id' => 1051,
            ),
            36 => 
            array (
                'id' => 40,
                'client_id' => 199,
                'position' => 1,
                'slide_image_id' => 1316,
            ),
            37 => 
            array (
                'id' => 41,
                'client_id' => 199,
                'position' => 2,
                'slide_image_id' => 1317,
            ),
            38 => 
            array (
                'id' => 42,
                'client_id' => 199,
                'position' => 3,
                'slide_image_id' => 1318,
            ),
            39 => 
            array (
                'id' => 43,
                'client_id' => 199,
                'position' => 4,
                'slide_image_id' => 1319,
            ),
            40 => 
            array (
                'id' => 44,
                'client_id' => 199,
                'position' => 5,
                'slide_image_id' => 1320,
            ),
            41 => 
            array (
                'id' => 45,
                'client_id' => 198,
                'position' => 1,
                'slide_image_id' => 1358,
            ),
            42 => 
            array (
                'id' => 46,
                'client_id' => 198,
                'position' => 2,
                'slide_image_id' => 1359,
            ),
            43 => 
            array (
                'id' => 47,
                'client_id' => 197,
                'position' => 1,
                'slide_image_id' => 1473,
            ),
            44 => 
            array (
                'id' => 48,
                'client_id' => 197,
                'position' => 2,
                'slide_image_id' => 1474,
            ),
            45 => 
            array (
                'id' => 49,
                'client_id' => 196,
                'position' => 1,
                'slide_image_id' => 1480,
            ),
        ));
        
        
    }
}