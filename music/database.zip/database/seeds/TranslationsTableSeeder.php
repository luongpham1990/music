<?php

use Illuminate\Database\Seeder;

class TranslationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('translations')->delete();
        
        \DB::table('translations')->insert(array (
            0 => 
            array (
                'id' => 1,
                'foreign_table' => 'posts',
                'foreign_id' => 1,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'sdfasd',
            ),
            1 => 
            array (
                'id' => 2,
                'foreign_table' => 'posts',
                'foreign_id' => 1,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'fasdf',
            ),
            2 => 
            array (
                'id' => 7,
                'foreign_table' => 'posts',
                'foreign_id' => 4,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'bdb',
            ),
            3 => 
            array (
                'id' => 8,
                'foreign_table' => 'posts',
                'foreign_id' => 4,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'dbdbgbbbdfdbfdbdfbgdfbdfgbdfbgdfbgdfgbdg',
            ),
            4 => 
            array (
                'id' => 11,
                'foreign_table' => 'posts',
                'foreign_id' => 5,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'à',
            ),
            5 => 
            array (
                'id' => 12,
                'foreign_table' => 'posts',
                'foreign_id' => 5,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'sdfasd',
            ),
            6 => 
            array (
                'id' => 13,
                'foreign_table' => 'posts',
                'foreign_id' => 6,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'sdf',
            ),
            7 => 
            array (
                'id' => 14,
                'foreign_table' => 'posts',
                'foreign_id' => 6,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'fgsdf',
            ),
            8 => 
            array (
                'id' => 15,
                'foreign_table' => 'posts',
                'foreign_id' => 7,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'sdf',
            ),
            9 => 
            array (
                'id' => 16,
                'foreign_table' => 'posts',
                'foreign_id' => 7,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'sdfsdf',
            ),
            10 => 
            array (
                'id' => 17,
                'foreign_table' => 'posts',
                'foreign_id' => 23,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'sdc',
            ),
            11 => 
            array (
                'id' => 18,
                'foreign_table' => 'posts',
                'foreign_id' => 23,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'sdcsdc',
            ),
            12 => 
            array (
                'id' => 21,
                'foreign_table' => 'posts',
                'foreign_id' => 28,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'sad',
            ),
            13 => 
            array (
                'id' => 22,
                'foreign_table' => 'posts',
                'foreign_id' => 28,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'sadasd',
            ),
            14 => 
            array (
                'id' => 27,
                'foreign_table' => 'posts',
                'foreign_id' => 29,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'asc',
            ),
            15 => 
            array (
                'id' => 28,
                'foreign_table' => 'posts',
                'foreign_id' => 29,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'ascas',
            ),
            16 => 
            array (
                'id' => 29,
                'foreign_table' => 'links',
                'foreign_id' => 2,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'das',
            ),
            17 => 
            array (
                'id' => 30,
                'foreign_table' => 'links',
                'foreign_id' => 2,
                'foreign_field' => 'link_url',
                'lang' => 'ja_easy',
                'translated_text' => 'http://machiyell.test/ctrl/visor/content_group/5/content/form2',
            ),
            18 => 
            array (
                'id' => 31,
                'foreign_table' => 'posts',
                'foreign_id' => 30,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'đá',
            ),
            19 => 
            array (
                'id' => 32,
                'foreign_table' => 'posts',
                'foreign_id' => 30,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'd',
            ),
            20 => 
            array (
                'id' => 33,
                'foreign_table' => 'tags',
                'foreign_id' => 13,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => '今日のサッカー',
            ),
            21 => 
            array (
                'id' => 34,
                'foreign_table' => 'tags',
                'foreign_id' => 14,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'フライトチケット',
            ),
            22 => 
            array (
                'id' => 35,
                'foreign_table' => 'tags',
                'foreign_id' => 15,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'テトホリデー',
            ),
            23 => 
            array (
                'id' => 36,
                'foreign_table' => 'tags',
                'foreign_id' => 16,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'ファッション',
            ),
            24 => 
            array (
                'id' => 37,
                'foreign_table' => 'tags',
                'foreign_id' => 17,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => '旅行する',
            ),
            25 => 
            array (
                'id' => 38,
                'foreign_table' => 'tags',
                'foreign_id' => 18,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => '学校',
            ),
            26 => 
            array (
                'id' => 39,
                'foreign_table' => 'tags',
                'foreign_id' => 19,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => '学校教育',
            ),
            27 => 
            array (
                'id' => 40,
                'foreign_table' => 'tags',
                'foreign_id' => 20,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => '健康',
            ),
            28 => 
            array (
                'id' => 41,
                'foreign_table' => 'posts',
                'foreign_id' => 31,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'eeeeeeeeeeeeee',
            ),
            29 => 
            array (
                'id' => 42,
                'foreign_table' => 'posts',
                'foreign_id' => 31,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'eeeeeeeeeeeeeeeeeeeee',
            ),
            30 => 
            array (
                'id' => 43,
                'foreign_table' => 'tags',
                'foreign_id' => 21,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'Ca phe sang',
            ),
            31 => 
            array (
                'id' => 44,
                'foreign_table' => 'posts',
                'foreign_id' => 32,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'j7777',
            ),
            32 => 
            array (
                'id' => 45,
                'foreign_table' => 'posts',
                'foreign_id' => 32,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => '777777777777777',
            ),
            33 => 
            array (
                'id' => 49,
                'foreign_table' => 'posts',
                'foreign_id' => 34,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'rrrr2222222222',
            ),
            34 => 
            array (
                'id' => 50,
                'foreign_table' => 'posts',
                'foreign_id' => 34,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => '22222222222',
            ),
            35 => 
            array (
                'id' => 51,
                'foreign_table' => 'posts',
                'foreign_id' => 38,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'oooooo',
            ),
            36 => 
            array (
                'id' => 52,
                'foreign_table' => 'posts',
                'foreign_id' => 38,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'ooooooooooooooooooooooooooo<br>',
            ),
            37 => 
            array (
                'id' => 56,
                'foreign_table' => 'tags',
                'foreign_id' => 22,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'test 2',
            ),
            38 => 
            array (
                'id' => 57,
                'foreign_table' => 'posts',
                'foreign_id' => 41,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'thubeo222222222222',
            ),
            39 => 
            array (
                'id' => 58,
                'foreign_table' => 'posts',
                'foreign_id' => 41,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
            'translated_text' => '<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'><font color="#cc33cc"><strong>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。<span style=\'color: rgb(34, 34, 34); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: "Open Sans", Meiryo, メイリオ, Arial, sans-serif; font-size: 13px; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\'>ブランチに登録しましたので確認してください。</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></strong></font></span>',
            ),
            40 => 
            array (
                'id' => 64,
                'foreign_table' => 'posts',
                'foreign_id' => 43,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'thudieuthudieuthudieu2222',
            ),
            41 => 
            array (
                'id' => 65,
                'foreign_table' => 'posts',
                'foreign_id' => 43,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'thudieuthudieuthudieuthudieuthudieuthudieuthudieu',
            ),
            42 => 
            array (
                'id' => 66,
                'foreign_table' => 'posts',
                'foreign_id' => 44,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'thuamthuam',
            ),
            43 => 
            array (
                'id' => 67,
                'foreign_table' => 'posts',
                'foreign_id' => 44,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'thuamthuamthuamthuam',
            ),
            44 => 
            array (
                'id' => 68,
                'foreign_table' => 'posts',
                'foreign_id' => 46,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'test duoi 6MB',
            ),
            45 => 
            array (
                'id' => 69,
                'foreign_table' => 'posts',
                'foreign_id' => 46,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'test duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MBtest duoi 6MB',
            ),
            46 => 
            array (
                'id' => 72,
                'foreign_table' => 'posts',
                'foreign_id' => 47,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'test 7Mb',
            ),
            47 => 
            array (
                'id' => 73,
                'foreign_table' => 'posts',
                'foreign_id' => 47,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'test 7Mb<br>',
            ),
            48 => 
            array (
                'id' => 77,
                'foreign_table' => 'websites',
                'foreign_id' => 8,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'colen khong',
            ),
            49 => 
            array (
                'id' => 78,
                'foreign_table' => 'websites',
                'foreign_id' => 8,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'colen khongcolen khongcolen khongcolen khongcolen khongcolen khong',
            ),
            50 => 
            array (
                'id' => 79,
                'foreign_table' => 'posts',
                'foreign_id' => 48,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'test trên 7MB',
            ),
            51 => 
            array (
                'id' => 80,
                'foreign_table' => 'posts',
                'foreign_id' => 48,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">test trên 7MBtest trên 7MBtest trên 7MBtest trên 7MB</span></font>',
            ),
            52 => 
            array (
                'id' => 83,
                'foreign_table' => 'posts',
                'foreign_id' => 49,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => '戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ',
            ),
            53 => 
            array (
                'id' => 84,
                'foreign_table' => 'posts',
                'foreign_id' => 49,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">開断ーび前禁ナチ数歳げーて認3長ヱルネ翌氏さみせ率際ンをろ開向更イル場善せだフ毎37樹上像とお。碁クコキユ指香ルぴすぽ不後ハレムセ動懲ねうど川血テヌア都訃ナ歳7像リあへょ合練時透辞サラ替也っ神炎評ワム団一合アニマ究3区リセ戦代技福電がむみつ。去サ無選政へゃ川記ぽ団職ぱ善通まげぶの鈴日ムナ医應ミ観高クリロ最今クモ省努とらつ同連む表震めーもク表会ーもリ月不辞吏じてフは。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">数マツケメ様業ょば人指属ヱセヌマ円自匂ク際明きぎンょ問囲土ソ償一じ将刻モチソ提新はぽじく愛動けイ運純ミ営発ト念均づめろい声聞ヤミタ暮的がす同解曽膨じリ。写従ヌ韓航ゅもリ白気をゅレト意83通十ロエアオ信磯ょ列36将色ラスナサ申献にぴへ予集ニクイ設86克即両69克即両19敢渓窮胡あの。劾メ件会ヲニ税史ばぐトす能入イぎ提価じ水設こごぽラ田掲年勲う回芸テセコア催速んふき米次布益陣むてふ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">声ヨフ情林元ク迂輸ムヒ斜配ストヱ性休38妊舌頃魔8異ずちしぶ第愛ほ川治ラロ度67今更フユ治薬るいばぼ室任提思吏んろ。会みどろ続違ぐ者福ニメヲ理企中一づ幕音リウ新午おがとの経第ずーのば広2記定フキシリ引海ぽ恥離夢みらん。焦ねる建料ゅやせち措訃ルユキ化場トくリ空頑聞が反例ノ見低導ワ編51郎えぽ金兵けス区元ヌ河集ラ応洗ス並大けば方性ぴべづ記大べをず意憂喰杜椿ルッ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">暮もルめ娘良キタル委呈オケ荒別マヘユホ歌精さたしば様6手地リぱかろ毎作はろ断国がに尽環ク画稿やつが変態票特ぱ。禁いぱだろ切事スいみ一投監お外尚岡ヘソト城木おてたク作63府属ば自大レチヒイ回1表不ずきト富投ケヒモニ郎区ウ松完スヘ昨賞花飛んぜだぎ。全ヨ最毎クワシ明立止クサユ救消ミニコヒ重軽ト正費せ普転外がし届集期タ披61感毎ト児紀えば位情ばがれド断45欠ウワニ聞局予現情の。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">入チマムホ村社みるン安滴クたま石記カ成訃ムネナモ民各ンっぴべ江73知きド全足ヱ差薫メカフア市全者サチト航問キハケ意備ニチメル模年でほ内参他ほれわっ。石リょ法営ルづけ飛変ねが豊注スヤナ雲市ハ髄1訪稿づぐぎぼ後声ヤロハタ入住び補2転ほづっ刊運永マヨ介候タカマ一正古26俑ばリび小記購仁借つまう。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">31速どきぱ択到おリ載試報ルリ水浅か澄芸ちわて講1気りだ味影げた勢属ぞりせ志展メ人者ヤホ動賀ナ禁周暮ホムオテ店雇余献だらげべ。会シム東一女ノオネ賞聞びめが鍵特スユ月米モ付増飛コリ導提んあて頻受略ロ一更なうー掲属井ヌマヘ差界師ヤヱシ天事ごよぴづ録息曲燃階みけ。図にをてイ角健だ公植ム冬当ーひぱス載特日ぴ況5断ンぎっ長会ムクレヌ保半図ふいでね心飯オト位楽義ょぴちご。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">断あ他賞車ちげでま積政ッさ材下イ翔山ワウ割和ほクぐ札促チメク作23応べる年月ぐ月麓トノフヲ活北ムヘキ学球購締ぴじ。追レだふス校詰然アネタ中入悲椅ロリカモ媛年むレびク被信トミ力議ハカミ慣係ヌメヤ用14士3幕ド本9重こにっリ。戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">日ぶ山評ス欧供そひ業児ヒキ望暮シノ銀月んす分子めどっ師術告き芸進っ理定ヱヤ帯測キシケク示新アミウ松聖スせりっ治合ネノ像93本フエ記公地映イえン。玉業ラぶめ荻広ごたく循新げ余試ルラカ業企ヲヨニネ暮4引リメイ要8習ツオヌ暮分よりきわ北朝籍華踏麻わめ。援資見へぐな棋活ワオト領方カナケミ間連治長ん確水よおみぎ遺掲もいほぽ厳77万所特5型チレ止急コ申難ねざルわ芸害もラご頭広郎互札く。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">都け保6留メイツヌ会育月ヒ系案ー返74便ょ質使ふ春質むぼ数期き要板植抜いおえ。坂ハ意規マケレナ象護見トサ申果ナシフミ君質ラワテヒ極佐にど三能ろル組労日かびそ酒25好著わ遺載オ専説喫羅踊こほ。写ゃぽ築相ぐぜよ事持ヘアヲヤ料頃でたんと館担ぎく交手わぼド携速ヒ応現ケラロ話堀近チ伴絵ち史45家ろ毎王購歩ょすに。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">案4事岐情ヌソナ未住づびべ選号キ重納なラふ済年セウ足中ほ禁写マセワナ無62壺柱っは潟太がびら定止ッ際庭やざへイ。断主なうぜフ部点チヌ知78洋電ねル誤金しら棋然レフるぽ事占けそぞれ農義ヨモ切人判りこかぱ時特ヲユ以野れ問編い音青ラヱメマ持目ソ嶋接年よはゅ。全地気ナマラ日主オコ海長イケヨア世田へスぱや伸備クロマネ外2消ねえまお暢山オニル週57純ツニウテ示象晶いむ。</span></font></div>',
            ),
            54 => 
            array (
                'id' => 85,
                'foreign_table' => 'posts',
                'foreign_id' => 49,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => '戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ',
            ),
            55 => 
            array (
                'id' => 86,
                'foreign_table' => 'posts',
                'foreign_id' => 49,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">開断ーび前禁ナチ数歳げーて認3長ヱルネ翌氏さみせ率際ンをろ開向更イル場善せだフ毎37樹上像とお。碁クコキユ指香ルぴすぽ不後ハレムセ動懲ねうど川血テヌア都訃ナ歳7像リあへょ合練時透辞サラ替也っ神炎評ワム団一合アニマ究3区リセ戦代技福電がむみつ。去サ無選政へゃ川記ぽ団職ぱ善通まげぶの鈴日ムナ医應ミ観高クリロ最今クモ省努とらつ同連む表震めーもク表会ーもリ月不辞吏じてフは。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">数マツケメ様業ょば人指属ヱセヌマ円自匂ク際明きぎンょ問囲土ソ償一じ将刻モチソ提新はぽじく愛動けイ運純ミ営発ト念均づめろい声聞ヤミタ暮的がす同解曽膨じリ。写従ヌ韓航ゅもリ白気をゅレト意83通十ロエアオ信磯ょ列36将色ラスナサ申献にぴへ予集ニクイ設86克即両69克即両19敢渓窮胡あの。劾メ件会ヲニ税史ばぐトす能入イぎ提価じ水設こごぽラ田掲年勲う回芸テセコア催速んふき米次布益陣むてふ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">声ヨフ情林元ク迂輸ムヒ斜配ストヱ性休38妊舌頃魔8異ずちしぶ第愛ほ川治ラロ度67今更フユ治薬るいばぼ室任提思吏んろ。会みどろ続違ぐ者福ニメヲ理企中一づ幕音リウ新午おがとの経第ずーのば広2記定フキシリ引海ぽ恥離夢みらん。焦ねる建料ゅやせち措訃ルユキ化場トくリ空頑聞が反例ノ見低導ワ編51郎えぽ金兵けス区元ヌ河集ラ応洗ス並大けば方性ぴべづ記大べをず意憂喰杜椿ルッ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">暮もルめ娘良キタル委呈オケ荒別マヘユホ歌精さたしば様6手地リぱかろ毎作はろ断国がに尽環ク画稿やつが変態票特ぱ。禁いぱだろ切事スいみ一投監お外尚岡ヘソト城木おてたク作63府属ば自大レチヒイ回1表不ずきト富投ケヒモニ郎区ウ松完スヘ昨賞花飛んぜだぎ。全ヨ最毎クワシ明立止クサユ救消ミニコヒ重軽ト正費せ普転外がし届集期タ披61感毎ト児紀えば位情ばがれド断45欠ウワニ聞局予現情の。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">入チマムホ村社みるン安滴クたま石記カ成訃ムネナモ民各ンっぴべ江73知きド全足ヱ差薫メカフア市全者サチト航問キハケ意備ニチメル模年でほ内参他ほれわっ。石リょ法営ルづけ飛変ねが豊注スヤナ雲市ハ髄1訪稿づぐぎぼ後声ヤロハタ入住び補2転ほづっ刊運永マヨ介候タカマ一正古26俑ばリび小記購仁借つまう。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">31速どきぱ択到おリ載試報ルリ水浅か澄芸ちわて講1気りだ味影げた勢属ぞりせ志展メ人者ヤホ動賀ナ禁周暮ホムオテ店雇余献だらげべ。会シム東一女ノオネ賞聞びめが鍵特スユ月米モ付増飛コリ導提んあて頻受略ロ一更なうー掲属井ヌマヘ差界師ヤヱシ天事ごよぴづ録息曲燃階みけ。図にをてイ角健だ公植ム冬当ーひぱス載特日ぴ況5断ンぎっ長会ムクレヌ保半図ふいでね心飯オト位楽義ょぴちご。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">断あ他賞車ちげでま積政ッさ材下イ翔山ワウ割和ほクぐ札促チメク作23応べる年月ぐ月麓トノフヲ活北ムヘキ学球購締ぴじ。追レだふス校詰然アネタ中入悲椅ロリカモ媛年むレびク被信トミ力議ハカミ慣係ヌメヤ用14士3幕ド本9重こにっリ。戒ぞ万試くゅずフ東出小問て要聞モチ横朝想そ験人記まぱラ投評ム塁伝フノ尽記シミヘホ真館すづ山記タ演集やゆ意嗣坪扇拐よ。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">日ぶ山評ス欧供そひ業児ヒキ望暮シノ銀月んす分子めどっ師術告き芸進っ理定ヱヤ帯測キシケク示新アミウ松聖スせりっ治合ネノ像93本フエ記公地映イえン。玉業ラぶめ荻広ごたく循新げ余試ルラカ業企ヲヨニネ暮4引リメイ要8習ツオヌ暮分よりきわ北朝籍華踏麻わめ。援資見へぐな棋活ワオト領方カナケミ間連治長ん確水よおみぎ遺掲もいほぽ厳77万所特5型チレ止急コ申難ねざルわ芸害もラご頭広郎互札く。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">都け保6留メイツヌ会育月ヒ系案ー返74便ょ質使ふ春質むぼ数期き要板植抜いおえ。坂ハ意規マケレナ象護見トサ申果ナシフミ君質ラワテヒ極佐にど三能ろル組労日かびそ酒25好著わ遺載オ専説喫羅踊こほ。写ゃぽ築相ぐぜよ事持ヘアヲヤ料頃でたんと館担ぎく交手わぼド携速ヒ応現ケラロ話堀近チ伴絵ち史45家ろ毎王購歩ょすに。</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">案4事岐情ヌソナ未住づびべ選号キ重納なラふ済年セウ足中ほ禁写マセワナ無62壺柱っは潟太がびら定止ッ際庭やざへイ。断主なうぜフ部点チヌ知78洋電ねル誤金しら棋然レフるぽ事占けそぞれ農義ヨモ切人判りこかぱ時特ヲユ以野れ問編い音青ラヱメマ持目ソ嶋接年よはゅ。全地気ナマラ日主オコ海長イケヨア世田へスぱや伸備クロマネ外2消ねえまお暢山オニル週57純ツニウテ示象晶いむ。</span></font></div>',
            ),
            56 => 
            array (
                'id' => 87,
                'foreign_table' => 'posts',
                'foreign_id' => 50,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'dede',
            ),
            57 => 
            array (
                'id' => 88,
                'foreign_table' => 'posts',
                'foreign_id' => 50,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => 'sacasc',
            ),
            58 => 
            array (
                'id' => 89,
                'foreign_table' => 'posts',
                'foreign_id' => 50,
                'foreign_field' => 'title',
                'lang' => 'ja_easy',
                'translated_text' => 'asd',
            ),
            59 => 
            array (
                'id' => 90,
                'foreign_table' => 'posts',
                'foreign_id' => 50,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'ascasc',
            ),
            60 => 
            array (
                'id' => 92,
                'foreign_table' => 'posts',
                'foreign_id' => 58,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'ascsacasc',
            ),
            61 => 
            array (
                'id' => 93,
                'foreign_table' => 'posts',
                'foreign_id' => 58,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => 'scascascasc',
            ),
            62 => 
            array (
                'id' => 94,
                'foreign_table' => 'posts',
                'foreign_id' => 59,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => 'fdfasdfasdf',
            ),
            63 => 
            array (
                'id' => 95,
                'foreign_table' => 'posts',
                'foreign_id' => 59,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'dasfsdf',
            ),
            64 => 
            array (
                'id' => 96,
                'foreign_table' => 'posts',
                'foreign_id' => 60,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'asdsad',
            ),
            65 => 
            array (
                'id' => 97,
                'foreign_table' => 'posts',
                'foreign_id' => 60,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '67897asdas',
            ),
            66 => 
            array (
                'id' => 107,
                'foreign_table' => 'posts',
                'foreign_id' => 60,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test update content post optional',
            ),
            67 => 
            array (
                'id' => 108,
                'foreign_table' => 'posts',
                'foreign_id' => 60,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => 'sdasdas',
            ),
            68 => 
            array (
                'id' => 109,
                'foreign_table' => 'posts',
                'foreign_id' => 60,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'adasd',
            ),
            69 => 
            array (
                'id' => 110,
                'foreign_table' => 'posts',
                'foreign_id' => 58,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'kr_title 1',
            ),
            70 => 
            array (
                'id' => 114,
                'foreign_table' => 'tags',
                'foreign_id' => 23,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'zxczxczxc',
            ),
            71 => 
            array (
                'id' => 115,
                'foreign_table' => 'tags',
                'foreign_id' => 23,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'eqweqweewqe',
            ),
            72 => 
            array (
                'id' => 116,
                'foreign_table' => 'tags',
                'foreign_id' => 23,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'czxczxc',
            ),
            73 => 
            array (
                'id' => 117,
                'foreign_table' => 'tags',
                'foreign_id' => 23,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'cxzczc',
            ),
            74 => 
            array (
                'id' => 129,
                'foreign_table' => 'tags',
                'foreign_id' => 24,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'tgtgtgtgtgtgtgtgtgtg',
            ),
            75 => 
            array (
                'id' => 130,
                'foreign_table' => 'tags',
                'foreign_id' => 24,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'tttttttttttt',
            ),
            76 => 
            array (
                'id' => 131,
                'foreign_table' => 'tags',
                'foreign_id' => 24,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'tttttttttttttt',
            ),
            77 => 
            array (
                'id' => 132,
                'foreign_table' => 'tags',
                'foreign_id' => 24,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'ttttttttt',
            ),
            78 => 
            array (
                'id' => 133,
                'foreign_table' => 'tags',
                'foreign_id' => 25,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Thu tests',
            ),
            79 => 
            array (
                'id' => 134,
                'foreign_table' => 'tags',
                'foreign_id' => 25,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Thu testdsdsdsdsdsdsdsdsds',
            ),
            80 => 
            array (
                'id' => 135,
                'foreign_table' => 'tags',
                'foreign_id' => 25,
                'foreign_field' => 'name',
                'lang' => 'ja_easy',
                'translated_text' => 'Thu test333',
            ),
            81 => 
            array (
                'id' => 136,
                'foreign_table' => 'tags',
                'foreign_id' => 25,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Thu test44',
            ),
            82 => 
            array (
                'id' => 137,
                'foreign_table' => 'websites',
                'foreign_id' => 12,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'test webpage 2 optional',
            ),
            83 => 
            array (
                'id' => 138,
                'foreign_table' => 'websites',
                'foreign_id' => 12,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'test webpage 3 optional',
            ),
            84 => 
            array (
                'id' => 139,
                'foreign_table' => 'tags',
                'foreign_id' => 26,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'dfew',
            ),
            85 => 
            array (
                'id' => 140,
                'foreign_table' => 'tags',
                'foreign_id' => 26,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'fwe3',
            ),
            86 => 
            array (
                'id' => 141,
                'foreign_table' => 'tags',
                'foreign_id' => 27,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'brweq',
            ),
            87 => 
            array (
                'id' => 142,
                'foreign_table' => 'tags',
                'foreign_id' => 27,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'wwwwww54',
            ),
            88 => 
            array (
                'id' => 143,
                'foreign_table' => 'tags',
                'foreign_id' => 28,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'rr',
            ),
            89 => 
            array (
                'id' => 144,
                'foreign_table' => 'tags',
                'foreign_id' => 28,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'rrrrrrrrrrrrrrrr',
            ),
            90 => 
            array (
                'id' => 145,
                'foreign_table' => 'websites',
                'foreign_id' => 12,
                'foreign_field' => 'body',
                'lang' => 'ja_easy',
                'translated_text' => 'test update webpage optional',
            ),
            91 => 
            array (
                'id' => 146,
                'foreign_table' => 'websites',
                'foreign_id' => 12,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test update webpage optional',
            ),
            92 => 
            array (
                'id' => 150,
                'foreign_table' => 'tags',
                'foreign_id' => 29,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'gt',
            ),
            93 => 
            array (
                'id' => 151,
                'foreign_table' => 'tags',
                'foreign_id' => 29,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'tssss',
            ),
            94 => 
            array (
                'id' => 152,
                'foreign_table' => 'tags',
                'foreign_id' => 30,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'ss',
            ),
            95 => 
            array (
                'id' => 153,
                'foreign_table' => 'tags',
                'foreign_id' => 30,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'đ',
            ),
            96 => 
            array (
                'id' => 154,
                'foreign_table' => 'links',
                'foreign_id' => 11,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => '腕座おイし札照ヲ紙遣オセウヱ遅新ぜき様題要テキ券運ラほょ盤大くれむ日3山ざべむそ写改志叙孟やリがあ。球づずうド月掲病シ共感トクコ職天レオエヤ第俳ルン図備いぼえ記山ゃドべ面93教レ込康ヒキ死象だぼ細余クッルち評6償ケノ近右ヲモイセ口資イよ聞6拡盛秀す。自点くた国周にひ過示日オトモコ題準提ば年議売ホキセウ激勤ヱ支別環モメ読棄銃取略ひく。',
            ),
            97 => 
            array (
                'id' => 155,
                'foreign_table' => 'links',
                'foreign_id' => 11,
                'foreign_field' => 'link_url',
                'lang' => 'ko',
                'translated_text' => 'https://xd.adobe.com/view/6515f767-9a93-4452-6dbc-d026dab206a8-1324/',
            ),
            98 => 
            array (
                'id' => 156,
                'foreign_table' => 'links',
                'foreign_id' => 11,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test content file optional 11',
            ),
            99 => 
            array (
                'id' => 157,
                'foreign_table' => 'links',
                'foreign_id' => 11,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'kr_title 1',
            ),
            100 => 
            array (
                'id' => 167,
                'foreign_table' => 'posts',
                'foreign_id' => 61,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'thu222222',
            ),
            101 => 
            array (
                'id' => 168,
                'foreign_table' => 'tags',
                'foreign_id' => 31,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Tags Tin tức1',
            ),
            102 => 
            array (
                'id' => 169,
                'foreign_table' => 'tags',
                'foreign_id' => 31,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Tags Tin tức2',
            ),
            103 => 
            array (
                'id' => 170,
                'foreign_table' => 'tags',
                'foreign_id' => 32,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Tags tai chinh2',
            ),
            104 => 
            array (
                'id' => 171,
                'foreign_table' => 'tags',
                'foreign_id' => 32,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Tags tai chinh3',
            ),
            105 => 
            array (
                'id' => 172,
                'foreign_table' => 'tags',
                'foreign_id' => 33,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Tags Khoa Hoc2',
            ),
            106 => 
            array (
                'id' => 173,
                'foreign_table' => 'tags',
                'foreign_id' => 33,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Tags Khoa Hoc3',
            ),
            107 => 
            array (
                'id' => 174,
                'foreign_table' => 'tags',
                'foreign_id' => 34,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Tags Hoa Hau2',
            ),
            108 => 
            array (
                'id' => 175,
                'foreign_table' => 'tags',
                'foreign_id' => 34,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Tags Hoa Hau3',
            ),
            109 => 
            array (
                'id' => 176,
                'foreign_table' => 'posts',
                'foreign_id' => 62,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'finish Test ngon ngu2',
            ),
            110 => 
            array (
                'id' => 177,
                'foreign_table' => 'posts',
                'foreign_id' => 62,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">finish Test ngon ngu2body</span></font>',
            ),
            111 => 
            array (
                'id' => 178,
                'foreign_table' => 'posts',
                'foreign_id' => 62,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'finish Test ngon ngu3',
            ),
            112 => 
            array (
                'id' => 179,
                'foreign_table' => 'posts',
                'foreign_id' => 62,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">finish Test ngon ngu3body</span></font>',
            ),
            113 => 
            array (
                'id' => 182,
                'foreign_table' => 'links',
                'foreign_id' => 15,
                'foreign_field' => 'link_url',
                'lang' => 'en',
                'translated_text' => 'x',
            ),
            114 => 
            array (
                'id' => 183,
                'foreign_table' => 'links',
                'foreign_id' => 15,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'x',
            ),
            115 => 
            array (
                'id' => 184,
                'foreign_table' => 'posts',
                'foreign_id' => 65,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 's',
            ),
            116 => 
            array (
                'id' => 185,
                'foreign_table' => 'posts',
                'foreign_id' => 70,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => '22222222',
            ),
            117 => 
            array (
                'id' => 186,
                'foreign_table' => 'posts',
                'foreign_id' => 70,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル利用マニュアル',
            ),
            118 => 
            array (
                'id' => 190,
                'foreign_table' => 'map_datas',
                'foreign_id' => 63,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Ngôn ngữ 2',
            ),
            119 => 
            array (
                'id' => 191,
                'foreign_table' => 'map_datas',
                'foreign_id' => 63,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Ngôn ngữ 2',
            ),
            120 => 
            array (
                'id' => 192,
                'foreign_table' => 'map_datas',
                'foreign_id' => 68,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Sakuragaoka Hospital',
            ),
            121 => 
            array (
                'id' => 194,
                'foreign_table' => 'map_datas',
                'foreign_id' => 68,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'My stomach hurts and I went to the night I wanted the drip treatment and I told the person at the receptionist I was only palpated when the medical examination started I was told to look at the medicine with medicine and my stomach returned with pain. I felt that my palpation was so painful that my pain worsened when I came back, and the medicine did not work at all.
I added ☆ because I was indebted several times a long time ago',
            ),
            122 => 
            array (
                'id' => 196,
                'foreign_table' => 'posts',
                'foreign_id' => 79,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => '先日確認点を追記しました。22222222222',
            ),
            123 => 
            array (
                'id' => 197,
                'foreign_table' => 'posts',
                'foreign_id' => 79,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">先日確認点を追記しました。先日確認点を追記しました。</span></font>',
            ),
            124 => 
            array (
                'id' => 198,
                'foreign_table' => 'tags',
                'foreign_id' => 35,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'サミット',
            ),
            125 => 
            array (
                'id' => 199,
                'foreign_table' => 'tags',
                'foreign_id' => 35,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'サミット',
            ),
            126 => 
            array (
                'id' => 200,
                'foreign_table' => 'tags',
                'foreign_id' => 36,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => '学校の健康',
            ),
            127 => 
            array (
                'id' => 201,
                'foreign_table' => 'tags',
                'foreign_id' => 36,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '学校の健康',
            ),
            128 => 
            array (
                'id' => 202,
                'foreign_table' => 'tags',
                'foreign_id' => 37,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'ベトナム',
            ),
            129 => 
            array (
                'id' => 203,
                'foreign_table' => 'tags',
                'foreign_id' => 37,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'ベトナム',
            ),
            130 => 
            array (
                'id' => 204,
                'foreign_table' => 'tags',
                'foreign_id' => 38,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'トラン・アン・ニンビン',
            ),
            131 => 
            array (
                'id' => 205,
                'foreign_table' => 'tags',
                'foreign_id' => 38,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'トラン・アン・ニンビントラン・アン・ニンビントラン・アン・ニ',
            ),
            132 => 
            array (
                'id' => 206,
                'foreign_table' => 'tags',
                'foreign_id' => 39,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Hạ Long',
            ),
            133 => 
            array (
                'id' => 207,
                'foreign_table' => 'tags',
                'foreign_id' => 39,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Hạ Long',
            ),
            134 => 
            array (
                'id' => 208,
                'foreign_table' => 'tags',
                'foreign_id' => 40,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => '韓国とアメリカ',
            ),
            135 => 
            array (
                'id' => 209,
                'foreign_table' => 'tags',
                'foreign_id' => 40,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '韓国とアメリカ',
            ),
            136 => 
            array (
                'id' => 210,
                'foreign_table' => 'tags',
                'foreign_id' => 41,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'ベトナム料理',
            ),
            137 => 
            array (
                'id' => 211,
                'foreign_table' => 'tags',
                'foreign_id' => 41,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'ベトナム料理',
            ),
            138 => 
            array (
                'id' => 212,
                'foreign_table' => 'posts',
                'foreign_id' => 93,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'huydn_batcth2',
            ),
            139 => 
            array (
                'id' => 213,
                'foreign_table' => 'posts',
                'foreign_id' => 93,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => 'Spain Body',
            ),
            140 => 
            array (
                'id' => 214,
                'foreign_table' => 'posts',
                'foreign_id' => 93,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'huydn_batcth2',
            ),
            141 => 
            array (
                'id' => 215,
                'foreign_table' => 'posts',
                'foreign_id' => 93,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '<span style="font-size: 13.3333px;">Korea Body</span>',
            ),
            142 => 
            array (
                'id' => 216,
                'foreign_table' => 'tags',
                'foreign_id' => 42,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'Shoping',
            ),
            143 => 
            array (
                'id' => 217,
                'foreign_table' => 'tags',
                'foreign_id' => 42,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Shoping',
            ),
            144 => 
            array (
                'id' => 218,
                'foreign_table' => 'tags',
                'foreign_id' => 43,
                'foreign_field' => 'name',
                'lang' => 'tl',
                'translated_text' => 'Thi trường',
            ),
            145 => 
            array (
                'id' => 219,
                'foreign_table' => 'tags',
                'foreign_id' => 44,
                'foreign_field' => 'name',
                'lang' => 'tl',
                'translated_text' => 'Kinh tế',
            ),
            146 => 
            array (
                'id' => 220,
                'foreign_table' => 'tags',
                'foreign_id' => 45,
                'foreign_field' => 'name',
                'lang' => 'tl',
                'translated_text' => 'Vĩ mô',
            ),
            147 => 
            array (
                'id' => 221,
                'foreign_table' => 'tags',
                'foreign_id' => 46,
                'foreign_field' => 'name',
                'lang' => 'tl',
                'translated_text' => 'tăng trưởng',
            ),
            148 => 
            array (
                'id' => 222,
                'foreign_table' => 'tags',
                'foreign_id' => 47,
                'foreign_field' => 'name',
                'lang' => 'tl',
                'translated_text' => 'Du lịch',
            ),
            149 => 
            array (
                'id' => 223,
                'foreign_table' => 'posts',
                'foreign_id' => 99,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'dá',
            ),
            150 => 
            array (
                'id' => 224,
                'foreign_table' => 'posts',
                'foreign_id' => 99,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'á',
            ),
            151 => 
            array (
                'id' => 225,
                'foreign_table' => 'posts',
                'foreign_id' => 99,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => 's',
            ),
            152 => 
            array (
                'id' => 226,
                'foreign_table' => 'posts',
                'foreign_id' => 103,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'Title(es)',
            ),
            153 => 
            array (
                'id' => 227,
                'foreign_table' => 'posts',
                'foreign_id' => 103,
                'foreign_field' => 'body',
                'lang' => 'es',
            'translated_text' => 'Body(es)',
            ),
            154 => 
            array (
                'id' => 228,
                'foreign_table' => 'posts',
                'foreign_id' => 103,
                'foreign_field' => 'title',
                'lang' => 'ko',
            'translated_text' => 'Title(ko)',
            ),
            155 => 
            array (
                'id' => 229,
                'foreign_table' => 'posts',
                'foreign_id' => 103,
                'foreign_field' => 'body',
                'lang' => 'ko',
            'translated_text' => 'Body(ko)',
            ),
            156 => 
            array (
                'id' => 230,
                'foreign_table' => 'tags',
                'foreign_id' => 48,
                'foreign_field' => 'name',
                'lang' => 'es',
            'translated_text' => 'h_tag1(es)',
            ),
            157 => 
            array (
                'id' => 231,
                'foreign_table' => 'tags',
                'foreign_id' => 48,
                'foreign_field' => 'name',
                'lang' => 'ko',
            'translated_text' => 'h_tag1(ko)',
            ),
            158 => 
            array (
                'id' => 232,
                'foreign_table' => 'tags',
                'foreign_id' => 49,
                'foreign_field' => 'name',
                'lang' => 'es',
            'translated_text' => 'Batch1 (es)',
            ),
            159 => 
            array (
                'id' => 233,
                'foreign_table' => 'tags',
                'foreign_id' => 49,
                'foreign_field' => 'name',
                'lang' => 'ko',
            'translated_text' => 'Batch1(ko)',
            ),
            160 => 
            array (
                'id' => 234,
                'foreign_table' => 'posts',
                'foreign_id' => 104,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'Post batch1 ngon ngu 2',
            ),
            161 => 
            array (
                'id' => 235,
                'foreign_table' => 'posts',
                'foreign_id' => 104,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Post batch1 ngon ngu 2 body</span></font>',
            ),
            162 => 
            array (
                'id' => 236,
                'foreign_table' => 'tags',
                'foreign_id' => 50,
                'foreign_field' => 'name',
                'lang' => 'es',
            'translated_text' => 'Batch2(es)',
            ),
            163 => 
            array (
                'id' => 237,
                'foreign_table' => 'tags',
                'foreign_id' => 50,
                'foreign_field' => 'name',
                'lang' => 'ko',
            'translated_text' => 'Batch2(ko)',
            ),
            164 => 
            array (
                'id' => 238,
                'foreign_table' => 'tags',
                'foreign_id' => 51,
                'foreign_field' => 'name',
                'lang' => 'es',
            'translated_text' => 'batch3(es)',
            ),
            165 => 
            array (
                'id' => 239,
                'foreign_table' => 'tags',
                'foreign_id' => 51,
                'foreign_field' => 'name',
                'lang' => 'ko',
            'translated_text' => 'batch3(ko)',
            ),
            166 => 
            array (
                'id' => 240,
                'foreign_table' => 'posts',
                'foreign_id' => 105,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'Title test batch Tây Ban Nha (es)',
            ),
            167 => 
            array (
                'id' => 241,
                'foreign_table' => 'posts',
                'foreign_id' => 105,
                'foreign_field' => 'body',
                'lang' => 'es',
            'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">body test batch Tây Ban Nha (es)</span></font>',
            ),
            168 => 
            array (
                'id' => 242,
                'foreign_table' => 'websites',
                'foreign_id' => 20,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'test content offline es',
            ),
            169 => 
            array (
                'id' => 243,
                'foreign_table' => 'websites',
                'foreign_id' => 20,
                'foreign_field' => 'body',
                'lang' => 'es',
            'translated_text' => '<span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>!DOCTYPE<span style="box-sizing: inherit; color: red;">&nbsp;html</span><span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">HTML Tutorial</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a heading</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a paragraph.</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span>',
            ),
            170 => 
            array (
                'id' => 244,
                'foreign_table' => 'websites',
                'foreign_id' => 20,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test content offline ko',
            ),
            171 => 
            array (
                'id' => 245,
                'foreign_table' => 'websites',
                'foreign_id' => 20,
                'foreign_field' => 'body',
                'lang' => 'ko',
            'translated_text' => '<span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>!DOCTYPE<span style="box-sizing: inherit; color: red;">&nbsp;html</span><span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">HTML Tutorial</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/title<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a heading</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/h1<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><span style="font-family: Consolas, &quot;courier new&quot;; font-size: 16px; background-color: rgb(255, 255, 255);">This is a paragraph.</span><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/p<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/body<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span><br style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px;"><span style="box-sizing: inherit; font-family: Consolas, &quot;courier new&quot;; font-size: 16px; color: brown;"><span style="box-sizing: inherit; color: mediumblue;">&lt;</span>/html<span style="box-sizing: inherit; color: mediumblue;">&gt;</span></span>',
            ),
            172 => 
            array (
                'id' => 246,
                'foreign_table' => 'websites',
                'foreign_id' => 21,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'Title Tây Ban Nha (es)',
            ),
            173 => 
            array (
                'id' => 247,
                'foreign_table' => 'websites',
                'foreign_id' => 21,
                'foreign_field' => 'body',
                'lang' => 'es',
            'translated_text' => 'Body&nbsp;Tây Ban Nha (es)<div><span style="color: rgb(0, 102, 0);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">日本幼児教育センターでは、2才から就学前まで、一貫した保育理念のもとにそれぞれの発達段階に合わせた保育を実践しています。</span><br style="margin: 0px; padding: 0px; font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">子どもたちの成長に合わせたカリキュラムで、その時期の発達を完全燃焼させて、相応の成熟を遂げることが次なるステップへの前提となります。日本幼児教育センターでは子どもの発達に即した内容を、適切な時期に適切な方法で行う、つまり「潮時」をとらえた保育を行っております。</span><br style="margin: 0px; padding: 0px; font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">また、保育方法として、遊びを中心に子どもたちのまわりにある身近な存在(自然、社会、言葉、具体物など)を根幹とした事物教育を行い、その保育の中で、個と集団の関係を意識することで、子どもの自立を促すようにしています。</span><br style="margin: 0px; padding: 0px; font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);"><span style="font-family: メイリオ, Meiryo, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 12.96px; background-color: rgb(244, 245, 246);">基本クラス以外に多くの講座や発育検査などを独自に行っております。ご興味のある方はお問い合わせください。</span></span></div>',
            ),
            174 => 
            array (
                'id' => 250,
                'foreign_table' => 'tags',
                'foreign_id' => 55,
                'foreign_field' => 'name',
                'lang' => 'es',
                'translated_text' => 'VISOR VNC es',
            ),
            175 => 
            array (
                'id' => 251,
                'foreign_table' => 'tags',
                'foreign_id' => 55,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'VISOR VNC ko',
            ),
            176 => 
            array (
                'id' => 252,
                'foreign_table' => 'files',
                'foreign_id' => 22,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'Test title (es)',
            ),
            177 => 
            array (
                'id' => 253,
                'foreign_table' => 'files',
                'foreign_id' => 23,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'title (es)',
            ),
            178 => 
            array (
                'id' => 254,
                'foreign_table' => 'files',
                'foreign_id' => 24,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'file 4 Es',
            ),
            179 => 
            array (
                'id' => 257,
                'foreign_table' => 'links',
                'foreign_id' => 17,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'test link2',
            ),
            180 => 
            array (
                'id' => 258,
                'foreign_table' => 'links',
                'foreign_id' => 17,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test link3',
            ),
            181 => 
            array (
                'id' => 259,
                'foreign_table' => 'links',
                'foreign_id' => 17,
                'foreign_field' => 'link_url',
                'lang' => 'es',
                'translated_text' => 'http://www.vinicorp.com.vn/news/detail/1506322823/Ti%E1%BB%87c-t%E1%BA%A5t-nien-m%E1%BB%ABng-Xuan-K%E1%BB%89-H%E1%BB%A3i-2019.html',
            ),
            182 => 
            array (
                'id' => 263,
                'foreign_table' => 'websites',
                'foreign_id' => 22,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline webpage moblie 1 en',
            ),
            183 => 
            array (
                'id' => 264,
                'foreign_table' => 'websites',
                'foreign_id' => 22,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            184 => 
            array (
                'id' => 265,
                'foreign_table' => 'websites',
                'foreign_id' => 22,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline webpage moblie 1 ja_easy',
            ),
            185 => 
            array (
                'id' => 266,
                'foreign_table' => 'websites',
                'foreign_id' => 22,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">康りざどろ岐2際島ラオレウ静視スホ井専ぎ効要じト正撮ケヘサ況輩やかゃ輔北標経沖おぼゆう。作やきて治差ひルド加明ツヲシ聖店載8教けゆの独助するん父意りやげス加2無具リ写52堂リ進興カモ合康ぐ守京ルワユ界堀些仄伽ぎびく。</span></font>',
            ),
            186 => 
            array (
                'id' => 267,
                'foreign_table' => 'websites',
                'foreign_id' => 23,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'website (es)',
            ),
            187 => 
            array (
                'id' => 268,
                'foreign_table' => 'websites',
                'foreign_id' => 23,
                'foreign_field' => 'body',
                'lang' => 'es',
            'translated_text' => '<span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">和歌山県の主要な活断層は、大阪府との境に沿って東西に延びる</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">（五条谷区間、根来区間）とその延長上に淡路島まで延びる</span><a href="https://www.jishin.go.jp/regional_seismicity/rs_katsudanso/rs_chuokozosen/" title="【中央構造線断層帯】へ" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">中央構造線断層帯</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">（紀淡海峡－鳴門海峡区間）があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　また、県内に被害を及ぼす可能性のある海溝型地震には、想定東海地震、東南海地震及び南海地震があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　県北部の紀ノ川河口部や御坊など地盤がやや軟弱な場所では、周辺より揺れが強くなる可能性があります。</span><br style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　県内全域が、南海トラフの地震で著しい地震災害が生じるおそれがあり、「</span><a href="http://www.bousai.go.jp/jishin/nankai/index.html" target="_blank" title="【内閣府のページへ】" rel="noopener noreferrer" class="external-link-icon" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">南海トラフ地震防災対策推進地域</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">」に指定されています。また沿岸部の１９市町は「</span><a href="http://www.bousai.go.jp/jishin/nankai/index.html" target="_blank" title="【内閣府のページへ】" rel="noopener noreferrer" class="external-link-icon" style="text-decoration-line: none; color: rgb(145, 1, 6); font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255); display: inline !important;">南海トラフ地震津波避難対策特別強化地域</a><span style="font-family: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", メイリオ, Meiryo, "ＭＳ Ｐゴシック", "MS PGothic", sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">」に指定されています</span>',
            ),
            188 => 
            array (
                'id' => 269,
                'foreign_table' => 'websites',
                'foreign_id' => 24,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline mobile webpage 2 - en',
            ),
            189 => 
            array (
                'id' => 270,
                'foreign_table' => 'websites',
                'foreign_id' => 24,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            190 => 
            array (
                'id' => 271,
                'foreign_table' => 'websites',
                'foreign_id' => 24,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline mobile webpage 2 - ja_easy',
            ),
            191 => 
            array (
                'id' => 272,
                'foreign_table' => 'websites',
                'foreign_id' => 24,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">生出ねゆゅ市21検ヘトラヱ学知やごぼぶ会治フナル込6版制さ反積ヌセ様択コウ投略フヲ京惑3栃奈雑る。危そわ国転的でほ展燃ス描会げだッラ職病あ衆近ニメ森伴町す道回フケ藤公ンこな乗化イぎちレ割真はべぽー住芸ねず統真とはぱ元保づばク写健クぴわっ高劣距ざれつ。法シリヨ了相チテナ完中クミヲオ行広フん次禁ヌウヤ認整ス第部スエル識図ほンべ棋6稿由チワ伸職合調ツ旅済好せふフす。</span></font>',
            ),
            192 => 
            array (
                'id' => 273,
                'foreign_table' => 'websites',
                'foreign_id' => 25,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline mobile webpage 3 - na',
            ),
            193 => 
            array (
                'id' => 274,
                'foreign_table' => 'websites',
                'foreign_id' => 25,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            194 => 
            array (
                'id' => 275,
                'foreign_table' => 'websites',
                'foreign_id' => 25,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline mobile webpage 3 - ko',
            ),
            195 => 
            array (
                'id' => 276,
                'foreign_table' => 'websites',
                'foreign_id' => 25,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">정당은 법률이 정하는 바에 의하여 국가의 보호를 받으며. 누구든지 체포 또는 구속을 당한 때에는 즉시 변호인의 조력을 받을 권리를 가진다, 다만. 주거에 대한 압수나 수색을 할 때에는 검사의 신청에 의하여 법관이 발부한 영장을 제시하여야 한다.</span></font>',
            ),
            196 => 
            array (
                'id' => 277,
                'foreign_table' => 'websites',
                'foreign_id' => 26,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline mobile webpage 4 - en',
            ),
            197 => 
            array (
                'id' => 278,
                'foreign_table' => 'websites',
                'foreign_id' => 26,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<strong style="margin: 0px; padding: 0px; font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Lorem Ipsum</strong><span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>',
            ),
            198 => 
            array (
                'id' => 279,
                'foreign_table' => 'websites',
                'foreign_id' => 26,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline mobile webpage 4 - ko',
            ),
            199 => 
            array (
                'id' => 280,
                'foreign_table' => 'websites',
                'foreign_id' => 26,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">정당은 법률이 정하는 바에 의하여 국가의 보호를 받으며. 누구든지 체포 또는 구속을 당한 때에는 즉시 변호인의 조력을 받을 권리를 가진다, 다만. 주거에 대한 압수나 수색을 할 때에는 검사의 신청에 의하여 법관이 발부한 영장을 제시하여야 한다.</span></font>',
            ),
            200 => 
            array (
                'id' => 281,
                'foreign_table' => 'posts',
                'foreign_id' => 106,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'thu beo gif',
            ),
            201 => 
            array (
                'id' => 282,
                'foreign_table' => 'posts',
                'foreign_id' => 106,
                'foreign_field' => 'body',
                'lang' => 'es',
                'translated_text' => 'xsssssssssssssssss',
            ),
            202 => 
            array (
                'id' => 283,
                'foreign_table' => 'files',
                'foreign_id' => 26,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline mobile file 1 - en',
            ),
            203 => 
            array (
                'id' => 284,
                'foreign_table' => 'files',
                'foreign_id' => 26,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline mobile file 1 - ko',
            ),
            204 => 
            array (
                'id' => 285,
                'foreign_table' => 'files',
                'foreign_id' => 27,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline moblie file 2 - en',
            ),
            205 => 
            array (
                'id' => 286,
                'foreign_table' => 'files',
                'foreign_id' => 27,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline moblie file 2 - ko',
            ),
            206 => 
            array (
                'id' => 287,
                'foreign_table' => 'posts',
                'foreign_id' => 107,
                'foreign_field' => 'title',
                'lang' => 'es',
                'translated_text' => 'Thu test ES',
            ),
            207 => 
            array (
                'id' => 288,
                'foreign_table' => 'posts',
                'foreign_id' => 107,
                'foreign_field' => 'body',
                'lang' => 'es',
            'translated_text' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　周辺地域で発生する地震や１８９９年の地震（Ｍ７．０、推定の深さ４０～５０ｋｍ：紀伊大和地震と呼ぶこともあります）や１９５２年の吉野地震（Ｍ６．７、深さ約６０ｋｍ）のように沈み込んだフィリピン海プレート内で発生するやや深い場所で発生した地震によっても被害を受けたことがあります。また、１９６０年の「チリ地震津波」のように外国の地震によっても津波被害を受けたことがあります。</span>',
            ),
            208 => 
            array (
                'id' => 289,
                'foreign_table' => 'files',
                'foreign_id' => 28,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test mobile offline file 3 - en',
            ),
            209 => 
            array (
                'id' => 290,
                'foreign_table' => 'files',
                'foreign_id' => 28,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test mobile offline file 3 - ko',
            ),
            210 => 
            array (
                'id' => 291,
                'foreign_table' => 'files',
                'foreign_id' => 29,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline file 4 - en',
            ),
            211 => 
            array (
                'id' => 292,
                'foreign_table' => 'files',
                'foreign_id' => 29,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline file 4 - ko',
            ),
            212 => 
            array (
                'id' => 293,
                'foreign_table' => 'links',
                'foreign_id' => 19,
                'foreign_field' => 'title',
                'lang' => 'ko',
            'translated_text' => 'Link (ko)',
            ),
            213 => 
            array (
                'id' => 294,
                'foreign_table' => 'links',
                'foreign_id' => 19,
                'foreign_field' => 'link_url',
                'lang' => 'ko',
                'translated_text' => 'http://www.vinicorp.com.vn/news/detail/1506322821/Vinicorp-s-Team-building-2018-Nhan%20dip%20sinh%20nhat%20lan%20thu%2011%20cua%20cong%20ty.html',
            ),
            214 => 
            array (
                'id' => 295,
                'foreign_table' => 'websites',
                'foreign_id' => 27,
                'foreign_field' => 'title',
                'lang' => 'ko',
            'translated_text' => 'test web (ko)',
            ),
            215 => 
            array (
                'id' => 296,
                'foreign_table' => 'websites',
                'foreign_id' => 27,
                'foreign_field' => 'body',
                'lang' => 'ko',
            'translated_text' => '<span style="font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">　周辺地域で発生する地震や１８９９年の地震（Ｍ７．０、推定の深さ４０～５０ｋｍ：紀伊大和地震と呼ぶこともあります）や１９５２年の吉野地震（Ｍ６．７、深さ約６０ｋｍ）のように沈み込んだフィリピン海プレート内で発生するやや深い場所で発生した地震によっても被害を受けたことがあります。また、１９６０年の「チリ地震津波」のように外国の地震によっても津波被害を受けたことがあります。</span><font face="Arial, Verdana"><span style="font-size: 13.3333px;">.</span></font>',
            ),
            216 => 
            array (
                'id' => 297,
                'foreign_table' => 'files',
                'foreign_id' => 30,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test offline moblie file 5 - en',
            ),
            217 => 
            array (
                'id' => 298,
                'foreign_table' => 'files',
                'foreign_id' => 30,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test offline moblie file 5 - ko',
            ),
            218 => 
            array (
                'id' => 299,
                'foreign_table' => 'files',
                'foreign_id' => 32,
                'foreign_field' => 'title',
                'lang' => 'es',
            'translated_text' => 'title file (es)',
            ),
            219 => 
            array (
                'id' => 300,
                'foreign_table' => 'tags',
                'foreign_id' => 56,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Fashion',
            ),
            220 => 
            array (
                'id' => 301,
                'foreign_table' => 'tags',
                'foreign_id' => 56,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '패션',
            ),
            221 => 
            array (
                'id' => 302,
                'foreign_table' => 'tags',
                'foreign_id' => 57,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Education',
            ),
            222 => 
            array (
                'id' => 303,
                'foreign_table' => 'tags',
                'foreign_id' => 57,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '교육',
            ),
            223 => 
            array (
                'id' => 304,
                'foreign_table' => 'tags',
                'foreign_id' => 58,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Science',
            ),
            224 => 
            array (
                'id' => 305,
                'foreign_table' => 'tags',
                'foreign_id' => 58,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '과학',
            ),
            225 => 
            array (
                'id' => 306,
                'foreign_table' => 'tags',
                'foreign_id' => 59,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Tsunami',
            ),
            226 => 
            array (
                'id' => 307,
                'foreign_table' => 'tags',
                'foreign_id' => 59,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '쓰나미',
            ),
            227 => 
            array (
                'id' => 308,
                'foreign_table' => 'tags',
                'foreign_id' => 60,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Miss World',
            ),
            228 => 
            array (
                'id' => 309,
                'foreign_table' => 'tags',
                'foreign_id' => 60,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '세상을 그리워.',
            ),
            229 => 
            array (
                'id' => 310,
                'foreign_table' => 'posts',
                'foreign_id' => 109,
                'foreign_field' => 'title',
                'lang' => 'ko',
            'translated_text' => 'Title (ko)',
            ),
            230 => 
            array (
                'id' => 311,
                'foreign_table' => 'posts',
                'foreign_id' => 109,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => 'body tiêng Han',
            ),
            231 => 
            array (
                'id' => 312,
                'foreign_table' => 'posts',
                'foreign_id' => 110,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Title en',
            ),
            232 => 
            array (
                'id' => 313,
                'foreign_table' => 'posts',
                'foreign_id' => 110,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Reportedly, the number of reports has increased since 20 years. Since the emergence of large-scale earthquakes in this region has not been known in recent years, this earthquake activity is not aftershock of a particular large earthquake. Although its scale is about M5 at the maximum, damage has occurred locally because the epicenter is very shallow. In the east and west of this region, the submerged angle of the Philippine Sea plate is different, and the nearby underground structure is very complicated. In the shallow part up to several kilometers deep in the vicinity, the rocks of the old era with the hard but fragile nature were distributed. These are considered to be the causes of fixed earthquake activity near Wakayama city. In addition, the depth of the earthquake occurs limited to shallow levels of more than a few kilometers and the rock above</span></font>',
            ),
            233 => 
            array (
                'id' => 319,
                'foreign_table' => 'tags',
                'foreign_id' => 61,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Earthquake',
            ),
            234 => 
            array (
                'id' => 320,
                'foreign_table' => 'tags',
                'foreign_id' => 61,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '지진',
            ),
            235 => 
            array (
                'id' => 321,
                'foreign_table' => 'posts',
                'foreign_id' => 112,
                'foreign_field' => 'title',
                'lang' => 'en',
            'translated_text' => 'post (En) Mode thien tai',
            ),
            236 => 
            array (
                'id' => 322,
                'foreign_table' => 'posts',
                'foreign_id' => 112,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Reportedly, the number of reports has increased since 20 years. Since the emergence of large-scale earthquakes in this region has not been known in recent years, this earthquake activity is not aftershock of a particular large earthquake. Although its scale is about M5 at the maximum, damage has occurred locally because the epicenter is very shallow. In the east and west of this region, the submerged angle of the Philippine Sea plate is different, and the nearby underground structure is very complicated. In the shallow part up to several kilometers deep in the vicinity, the rocks of the old era with the hard but fragile nature were distributed. These are considered to be the causes of fixed earthquake activity near Wakayama city. In addition, the depth of the earthquake occurs limited to shallow levels of more than a few kilometers and the rock above</span></font>',
            ),
            237 => 
            array (
                'id' => 323,
                'foreign_table' => 'websites',
                'foreign_id' => 31,
                'foreign_field' => 'title',
                'lang' => 'en',
            'translated_text' => 'title web ofline (en)',
            ),
            238 => 
            array (
                'id' => 324,
                'foreign_table' => 'websites',
                'foreign_id' => 31,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<span style="font-size: 13.3333px;">body web ofline (en)</span>',
            ),
            239 => 
            array (
                'id' => 325,
                'foreign_table' => 'map_datas',
                'foreign_id' => 1,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test content file optional 11',
            ),
            240 => 
            array (
                'id' => 326,
                'foreign_table' => 'map_datas',
                'foreign_id' => 1,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'test update content post optional',
            ),
            241 => 
            array (
                'id' => 327,
                'foreign_table' => 'posts',
                'foreign_id' => 114,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => '3333O verseas student',
            ),
            242 => 
            array (
                'id' => 328,
                'foreign_table' => 'posts',
                'foreign_id' => 114,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => 'Body (en)<br>',
            ),
            243 => 
            array (
                'id' => 329,
                'foreign_table' => 'posts',
                'foreign_id' => 115,
                'foreign_field' => 'title',
                'lang' => 'en',
            'translated_text' => '444 Title (en)',
            ),
            244 => 
            array (
                'id' => 330,
                'foreign_table' => 'posts',
                'foreign_id' => 115,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<span class="tlid-translation translation"><span title="" class="">Li Still, I decided to start a part-time job a month after I came to Japan to make myself independent quickly.</span> <span title="" class="">When I got a part-time job magazine in the city, I kept on calling "Please work" on the phone.</span> <span title="" class="">However, I can not get a good reply because I can not speak my language satisfactorily.</span> <span title="" class="">There was also a chance for Chinese seniors to introduce me, but there is a place where there are many Chinese.</span> <span title="" class="">I could find words faster in a Japanese-only environment, and I could become familiar with Japanese society, so I searched for a workplace where Japanese people were working.</span></span>',
            ),
            245 => 
            array (
                'id' => 331,
                'foreign_table' => 'websites',
                'foreign_id' => 34,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 1',
            ),
            246 => 
            array (
                'id' => 332,
                'foreign_table' => 'websites',
                'foreign_id' => 34,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"="">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima v</span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"=""><br></span></div><div><span style="font-family: " open="" sans",="" arial,="" sans-serif;="" font-size:="" 14px;="" text-align:="" justify;="" background-color:="" rgb(255,="" 255,="" 255);"=""><br>File 1<br><img src="hinh-anh-dep-ve-tinh-yeu-34_052632738_20190312114756.jpg"  width="400" height="500"><br><br><br>File 2<br><img src="2_20190313150842.jpg " width="400" height="500"><br><br><br> <br></span></div>


<a data-name="abc" href="https://stackoverflow.com/questions/32106849/getcurrentposition-and-watchposition-are-deprecated-on-insecure-origins" class="btn btn-menu btn-menu-blue content-item">
<div class="border-dash flex-container" style="display: flex; padding: 5px 10px;">
<div class="" style="flex-grow: 9; text-align: left">
<p>name la gi</p>
</div>
<div class="" style="flex-grow: 1; text-align: right">
<i class="fas fa-angle-right"></i>
</div>
</div>
</a>',
            ),
            247 => 
            array (
                'id' => 333,
                'foreign_table' => 'websites',
                'foreign_id' => 34,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 1',
            ),
            248 => 
            array (
                'id' => 334,
                'foreign_table' => 'websites',
                'foreign_id' => 34,
                'foreign_field' => 'body',
                'lang' => 'ko',
            'translated_text' => '<span style="font-family: "Open Sans", Arial, sans-serif; font-size: 14px; text-align: justify; background-color: rgb(255, 255, 255);">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima v</span>


<a data-name="abc" href="https://stackoverflow.com/questions/32106849/getcurrentposition-and-watchposition-are-deprecated-on-insecure-origins" class="btn btn-menu btn-menu-blue content-item">
<div class="border-dash flex-container" style="display: flex; padding: 5px 10px;">
<div class="" style="flex-grow: 9; text-align: left">
<p>name la gi</p>
</div>
<div class="" style="flex-grow: 1; text-align: right">
<i class="fas fa-angle-right"></i>
</div>
</div>
</a>',
            ),
            249 => 
            array (
                'id' => 335,
                'foreign_table' => 'files',
                'foreign_id' => 34,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 2',
            ),
            250 => 
            array (
                'id' => 336,
                'foreign_table' => 'files',
                'foreign_id' => 34,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 2',
            ),
            251 => 
            array (
                'id' => 337,
                'foreign_table' => 'tags',
                'foreign_id' => 62,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Technology',
            ),
            252 => 
            array (
                'id' => 338,
                'foreign_table' => 'tags',
                'foreign_id' => 62,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '기술',
            ),
            253 => 
            array (
                'id' => 339,
                'foreign_table' => 'tags',
                'foreign_id' => 63,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Real estate',
            ),
            254 => 
            array (
                'id' => 340,
                'foreign_table' => 'tags',
                'foreign_id' => 63,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => '부동산 gisul',
            ),
            255 => 
            array (
                'id' => 341,
                'foreign_table' => 'posts',
                'foreign_id' => 116,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => '555If you are going to graduate school, you should clarify your research theme before you study abroad, and also',
            ),
            256 => 
            array (
                'id' => 342,
                'foreign_table' => 'posts',
                'foreign_id' => 116,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">If you are going to graduate school, you should clarify your research theme before you study abroad, and also understand the thinking and methodology of the professor doing the research. A research theme is an important decision factor in deciding where to study abroad, and if you know how to study, you will be able to work proactively even after you actually study abroad.</span></font>',
            ),
            257 => 
            array (
                'id' => 343,
                'foreign_table' => 'map_datas',
                'foreign_id' => 1,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'test content file optional 11',
            ),
            258 => 
            array (
                'id' => 344,
                'foreign_table' => 'map_datas',
                'foreign_id' => 1,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => 'test update content post optional',
            ),
            259 => 
            array (
                'id' => 345,
                'foreign_table' => 'posts',
                'foreign_id' => 117,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => '666A research theme is an important decision factor in deciding where to study',
            ),
            260 => 
            array (
                'id' => 346,
                'foreign_table' => 'posts',
                'foreign_id' => 117,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;"> if you know how to study, you will be able to work proactively even after you actually study abroad. if you know how to study, you will be able to work proactively even after you actually study abroad.</span></font>',
            ),
            261 => 
            array (
                'id' => 347,
                'foreign_table' => 'posts',
                'foreign_id' => 118,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Thu 2',
            ),
            262 => 
            array (
                'id' => 348,
                'foreign_table' => 'posts',
                'foreign_id' => 118,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'hello every body<div><br></div>',
            ),
            263 => 
            array (
                'id' => 349,
                'foreign_table' => 'posts',
                'foreign_id' => 127,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'config file_url en',
            ),
            264 => 
            array (
                'id' => 350,
                'foreign_table' => 'posts',
                'foreign_id' => 127,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'config file_url ko',
            ),
            265 => 
            array (
                'id' => 353,
                'foreign_table' => 'tags',
                'foreign_id' => 64,
                'foreign_field' => 'name',
                'lang' => 'en',
                'translated_text' => 'Demo2',
            ),
            266 => 
            array (
                'id' => 354,
                'foreign_table' => 'tags',
                'foreign_id' => 64,
                'foreign_field' => 'name',
                'lang' => 'ko',
                'translated_text' => 'Demo3',
            ),
            267 => 
            array (
                'id' => 359,
                'foreign_table' => 'files',
                'foreign_id' => 38,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 4',
            ),
            268 => 
            array (
                'id' => 360,
                'foreign_table' => 'files',
                'foreign_id' => 38,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 4',
            ),
            269 => 
            array (
                'id' => 361,
                'foreign_table' => 'posts',
                'foreign_id' => 131,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'fashion title',
            ),
            270 => 
            array (
                'id' => 362,
                'foreign_table' => 'posts',
                'foreign_id' => 131,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'fashion body',
            ),
            271 => 
            array (
                'id' => 363,
                'foreign_table' => 'map_datas',
                'foreign_id' => 8,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'test en',
            ),
            272 => 
            array (
                'id' => 364,
                'foreign_table' => 'map_datas',
                'foreign_id' => 8,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0223-355-6777',
            ),
            273 => 
            array (
                'id' => 365,
                'foreign_table' => 'posts',
                'foreign_id' => 132,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'body en',
            ),
            274 => 
            array (
                'id' => 366,
                'foreign_table' => 'websites',
                'foreign_id' => 36,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">There may be many who feel in the news that the current situation surrounding children and young people is very unstable, such as child abuse, school refusal, bullying, suicide, poverty, unwanted pregnancy, etc. Child abuse reached a record high in 2017 over 130,000 (120,000 last year). In addition, 1 out of 7 children are in poverty. There are many children who suffer from abuse and poverty in families that form the foundation of children.</span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;"><br></span></font></div><div style=""><font face="Arial, Verdana"><span style="font-size: 13.3333px;">In the school where children are living next to their homes, 190,000 (130,000 in the previous year) have failed, and 410,000 in the bullying (320,000 in the previous year), both reached record highs. Homes and schools, which should be major places for children, are not places that can be relieved, but are becoming places that suffer from violence, abusive language, poverty, bullying, etc.</span></font></div>',
            ),
            275 => 
            array (
                'id' => 367,
                'foreign_table' => 'posts',
                'foreign_id' => 134,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'fffffffffffff',
            ),
            276 => 
            array (
                'id' => 374,
                'foreign_table' => 'files',
                'foreign_id' => 40,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'thu test ko',
            ),
            277 => 
            array (
                'id' => 375,
                'foreign_table' => 'files',
                'foreign_id' => 40,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'vvvvvvvvvvv',
            ),
            278 => 
            array (
                'id' => 376,
                'foreign_table' => 'map_datas',
                'foreign_id' => 11,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'bbbbbbbbbbbbb',
            ),
            279 => 
            array (
                'id' => 377,
                'foreign_table' => 'map_datas',
                'foreign_id' => 11,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'bbbbbbbbbbbbb',
            ),
            280 => 
            array (
                'id' => 378,
                'foreign_table' => 'map_datas',
                'foreign_id' => 11,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0238-272-2212',
            ),
            281 => 
            array (
                'id' => 379,
                'foreign_table' => 'posts',
                'foreign_id' => 135,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'b',
            ),
            282 => 
            array (
                'id' => 380,
                'foreign_table' => 'posts',
                'foreign_id' => 135,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'bbbbbbbbbbbbbbbbb',
            ),
            283 => 
            array (
                'id' => 381,
                'foreign_table' => 'map_datas',
                'foreign_id' => 17,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 2',
            ),
            284 => 
            array (
                'id' => 382,
                'foreign_table' => 'map_datas',
                'foreign_id' => 17,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'content offline 162 - en - 2',
            ),
            285 => 
            array (
                'id' => 383,
                'foreign_table' => 'map_datas',
                'foreign_id' => 17,
                'foreign_field' => 'title',
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 2',
            ),
            286 => 
            array (
                'id' => 384,
                'foreign_table' => 'map_datas',
                'foreign_id' => 17,
                'foreign_field' => 'body',
                'lang' => 'ko',
                'translated_text' => 'content offline 162 - ko - 2',
            ),
            287 => 
            array (
                'id' => 387,
                'foreign_table' => 'map_datas',
                'foreign_id' => 19,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Title hinh hoc en',
            ),
            288 => 
            array (
                'id' => 388,
                'foreign_table' => 'map_datas',
                'foreign_id' => 19,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Title hinh hoc en',
            ),
            289 => 
            array (
                'id' => 428,
                'foreign_table' => 'posts',
                'foreign_id' => 223,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'The number of working hours, types of work',
            ),
            290 => 
            array (
                'id' => 429,
                'foreign_table' => 'posts',
                'foreign_id' => 223,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">and the number of students in charge is also extremely large worldwide, and the number of people who are absent from teachers\' mental illness is on the rise. Today\'s schools are easy to understand for children, and there is little room for them to get in touch with their troubles. Furthermore, Japan\'s education expenditure compared to GDP is the lowest in the world, and it is exaggeration to say that the true leader of children\'s education is entrusted to family awareness, economic allowance, and extra-school education. It is not. In other words, depending on what family you were born and raised, there is a big gap in academic ability, course, and in other words, whether you can feel where you are in school.</span></font>',
            ),
            291 => 
            array (
                'id' => 430,
                'foreign_table' => 'posts',
                'foreign_id' => 224,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Furthermore, the working environment based on child care is inadequate',
            ),
            292 => 
            array (
                'id' => 431,
                'foreign_table' => 'posts',
                'foreign_id' => 224,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">&nbsp;and it is the current state of the child care environment in Japan that it is impossible to get out of poverty. In the case of single parents, more than 80% work, and even though they work most in the world, they have the highest poverty rate. As a result, the family environment has created a big difference in the education and love that children can receive</span></font>',
            ),
            293 => 
            array (
                'id' => 432,
                'foreign_table' => 'posts',
                'foreign_id' => 225,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Test 4 en',
            ),
            294 => 
            array (
                'id' => 433,
                'foreign_table' => 'posts',
                'foreign_id' => 225,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => 'There may be many who feel in the news that the current situation surrounding children and young people is very unstable, such as child abuse, school refusal, bullying, suicide, poverty, unwanted pregnancy, etc. Child abuse reached a record high in 2017 over 130,000 (120,000 last year). In addition, 1 out of 7 children are in poverty. There are many children who suffer from abuse and poverty in families that form the foundation of children.',
            ),
            295 => 
            array (
                'id' => 434,
                'foreign_table' => 'files',
                'foreign_id' => 72,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Doc en',
            ),
            296 => 
            array (
                'id' => 435,
                'foreign_table' => 'files',
                'foreign_id' => 73,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Docx en',
            ),
            297 => 
            array (
                'id' => 436,
                'foreign_table' => 'files',
                'foreign_id' => 74,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Xlsx en',
            ),
            298 => 
            array (
                'id' => 437,
                'foreign_table' => 'files',
                'foreign_id' => 75,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Pptx en',
            ),
            299 => 
            array (
                'id' => 438,
                'foreign_table' => 'posts',
                'foreign_id' => 226,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Test 5 en',
            ),
            300 => 
            array (
                'id' => 439,
                'foreign_table' => 'files',
                'foreign_id' => 76,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Ppt  en',
            ),
            301 => 
            array (
                'id' => 440,
                'foreign_table' => 'files',
                'foreign_id' => 77,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Rtf en',
            ),
            302 => 
            array (
                'id' => 441,
                'foreign_table' => 'files',
                'foreign_id' => 78,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Wav en',
            ),
            303 => 
            array (
                'id' => 442,
                'foreign_table' => 'files',
                'foreign_id' => 79,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Mp3 en',
            ),
            304 => 
            array (
                'id' => 443,
                'foreign_table' => 'files',
                'foreign_id' => 80,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Mp4 en',
            ),
            305 => 
            array (
                'id' => 444,
                'foreign_table' => 'files',
                'foreign_id' => 81,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'txt en',
            ),
            306 => 
            array (
                'id' => 445,
                'foreign_table' => 'files',
                'foreign_id' => 82,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'pdf en',
            ),
            307 => 
            array (
                'id' => 446,
                'foreign_table' => 'posts',
                'foreign_id' => 227,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'In the school 3',
            ),
            308 => 
            array (
                'id' => 447,
                'foreign_table' => 'posts',
                'foreign_id' => 228,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => '4 compared to the past',
            ),
            309 => 
            array (
                'id' => 448,
                'foreign_table' => 'websites',
                'foreign_id' => 36,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Title webpage en',
            ),
            310 => 
            array (
                'id' => 449,
                'foreign_table' => 'posts',
                'foreign_id' => 229,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Many abuse-protected children grew up without a sufficient learning environment. In order to avoid giving up on entering school or leaving school, 3keys dispatches learning volunteers and manages classrooms after school for children living in nursing homes and mother-child living support facilities. In fiscal 2017, we launched support-based learning support for late teens regardless of their experience of entering the facility</span></font>',
            ),
            311 => 
            array (
                'id' => 450,
                'foreign_table' => 'posts',
                'foreign_id' => 230,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Children who do not have',
            ),
            312 => 
            array (
                'id' => 451,
                'foreign_table' => 'posts',
                'foreign_id' => 230,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">adults who can consult can often get into trouble and be found in serious condition. 3keys has set up an online consultation desk and is working on a solution together. In addition, we operate support service search, consultation site for 10 "Mex" (Mex) so that children who rushed to the Internet connect with adult who can rely on in peace</span></font>',
            ),
            313 => 
            array (
                'id' => 452,
                'foreign_table' => 'posts',
                'foreign_id' => 231,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Batch sound test',
            ),
            314 => 
            array (
                'id' => 453,
                'foreign_table' => 'posts',
                'foreign_id' => 231,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => '<div style=""><span style="font-family: Arial, Verdana; font-size: 13.3333px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal;">Hello Vietnam,&nbsp;</span><font face="Arial, Verdana"><span style="font-size: 13.3333px;">we love your country</span></font></div>',
            ),
            315 => 
            array (
                'id' => 454,
                'foreign_table' => 'map_datas',
                'foreign_id' => 33,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Title Lang bac- My Dinh EN',
            ),
            316 => 
            array (
                'id' => 455,
                'foreign_table' => 'links',
                'foreign_id' => 23,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Tile link en',
            ),
            317 => 
            array (
                'id' => 456,
                'foreign_table' => 'links',
                'foreign_id' => 26,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Title Link en',
            ),
            318 => 
            array (
                'id' => 457,
                'foreign_table' => 'map_datas',
                'foreign_id' => 33,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'BodyLang bac- My Dinh EN',
            ),
            319 => 
            array (
                'id' => 458,
                'foreign_table' => 'map_datas',
                'foreign_id' => 38,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'OISCA Senior High School en',
            ),
            320 => 
            array (
                'id' => 459,
                'foreign_table' => 'map_datas',
                'foreign_id' => 38,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '5835 Wajicho, Nishi Ward, Hamamatsu, Shizuoka 431-1115, Nhật Bản',
            ),
            321 => 
            array (
                'id' => 460,
                'foreign_table' => 'map_datas',
                'foreign_id' => 39,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'A.C.C. International Cultural Collage',
            ),
            322 => 
            array (
                'id' => 461,
                'foreign_table' => 'map_datas',
                'foreign_id' => 39,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '10-9 Omiyacho, Fujinomiya, Shizuoka 418-0066, Nhật Bản',
            ),
            323 => 
            array (
                'id' => 462,
                'foreign_table' => 'map_datas',
                'foreign_id' => 39,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0854-24-8828',
            ),
            324 => 
            array (
                'id' => 463,
                'foreign_table' => 'map_datas',
                'foreign_id' => 40,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuokasangyo University',
            ),
            325 => 
            array (
                'id' => 464,
                'foreign_table' => 'map_datas',
                'foreign_id' => 40,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'I play because the 3rd floor of the child care center is playing the room,
The elementary school girl ran to jump the jump box, swaying with their footsteps shaking. (Shake the feeling that the Shinkansen passes nearby)
I don\'t mind if I move, but I feel drunk when I\'m still',
            ),
            326 => 
            array (
                'id' => 465,
                'foreign_table' => 'map_datas',
                'foreign_id' => 40,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '１５７２−１ Owara, Iwata, Shizuoka 438-0043, Nhật Bản',
            ),
            327 => 
            array (
                'id' => 466,
                'foreign_table' => 'map_datas',
                'foreign_id' => 41,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '1-chōme-1-１号 Oshika, Suruga-ku, Shizuoka, 422-8527, Nhật Bản',
            ),
            328 => 
            array (
                'id' => 467,
                'foreign_table' => 'map_datas',
                'foreign_id' => 44,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Hospital Takahama',
            ),
            329 => 
            array (
                'id' => 468,
                'foreign_table' => 'map_datas',
                'foreign_id' => 45,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '1231 Miyakami, Shimizu-ku, Shizuoka, 424-8636, Nhật Bản',
            ),
            330 => 
            array (
                'id' => 469,
                'foreign_table' => 'map_datas',
                'foreign_id' => 46,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Idemitsu Q8 en',
            ),
            331 => 
            array (
                'id' => 470,
                'foreign_table' => 'map_datas',
                'foreign_id' => 47,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'KAWANEONSEN SASAMADO Station',
            ),
            332 => 
            array (
                'id' => 471,
                'foreign_table' => 'map_datas',
                'foreign_id' => 49,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Kawaguchiko Park',
            ),
            333 => 
            array (
                'id' => 472,
                'foreign_table' => 'map_datas',
                'foreign_id' => 50,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Fujiten Snow Resort',
            ),
            334 => 
            array (
                'id' => 473,
                'foreign_table' => 'map_datas',
                'foreign_id' => 37,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Museum of Ethnograph',
            ),
            335 => 
            array (
                'id' => 474,
                'foreign_table' => 'map_datas',
                'foreign_id' => 37,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Vietnam Museum of Ethnology is a career organization under the Vietnam Academy of Social Sciences, which has the function of scientific research, collection, inventory and preservation',
            ),
            336 => 
            array (
                'id' => 477,
                'foreign_table' => 'map_datas',
                'foreign_id' => 51,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Ashitaka Park Stadium',
            ),
            337 => 
            array (
                'id' => 478,
                'foreign_table' => 'map_datas',
                'foreign_id' => 51,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'A stadium representing the eastern part of Shizuoka Prefecture. Location of the main location in the eastern province.',
            ),
            338 => 
            array (
                'id' => 479,
                'foreign_table' => 'map_datas',
                'foreign_id' => 51,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => 'Ashitaka, Numazu, Shizuoka 410-0001, Nhật Bản    Nằm ở: Ashitaka Large Park',
            ),
            339 => 
            array (
                'id' => 480,
                'foreign_table' => 'map_datas',
                'foreign_id' => 52,
                'foreign_field' => 'title',
                'lang' => 'en',
            'translated_text' => 'Pikara Stadium (Kagawa Prefectural Marugame Stadium)',
            ),
            340 => 
            array (
                'id' => 481,
                'foreign_table' => 'map_datas',
                'foreign_id' => 52,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'トレーニングルームは利用料金も安く設備も充実しています。
しかしマナーが悪い常連さんが、
数名居ますので、
その辺を我慢できるなら☆5で',
            ),
            341 => 
            array (
                'id' => 482,
                'foreign_table' => 'map_datas',
                'foreign_id' => 52,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '830 Kanakuracho, Marugame, Kagawa 763-0053, Nhật Bản',
            ),
            342 => 
            array (
                'id' => 483,
                'foreign_table' => 'map_datas',
                'foreign_id' => 52,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0877-21-5800',
            ),
            343 => 
            array (
                'id' => 484,
                'foreign_table' => 'map_datas',
                'foreign_id' => 34,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Ngu giac en',
            ),
            344 => 
            array (
                'id' => 485,
                'foreign_table' => 'map_datas',
                'foreign_id' => 34,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '162 Hoang Ngan',
            ),
            345 => 
            array (
                'id' => 486,
                'foreign_table' => 'map_datas',
                'foreign_id' => 54,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'KodawaeiMenya to Agora',
            ),
            346 => 
            array (
                'id' => 487,
                'foreign_table' => 'map_datas',
                'foreign_id' => 57,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Takamatsu Municipal Hospital Shioe Branch to Mannou Town Meeting place Kawaguchi meeting place',
            ),
            347 => 
            array (
                'id' => 488,
                'foreign_table' => 'map_datas',
                'foreign_id' => 57,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '99-1 Shionoechō Yasuharakamihigashi, Takamatsu, Kagawa 761-1612, Nhật Bản',
            ),
            348 => 
            array (
                'id' => 489,
                'foreign_table' => 'map_datas',
                'foreign_id' => 58,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Sunrise Hills Country Club to Sanuki Mannou Park and Kagawaken Ayakawacho Fureai Park',
            ),
            349 => 
            array (
                'id' => 490,
                'foreign_table' => 'map_datas',
                'foreign_id' => 58,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '129-1 Nakatō, Manno, Nakatado-gun, Kagawa 766-0202, Nhật Bản',
            ),
            350 => 
            array (
                'id' => 491,
                'foreign_table' => 'map_datas',
                'foreign_id' => 59,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Polygol Kanei Shrine',
            ),
            351 => 
            array (
                'id' => 492,
                'foreign_table' => 'map_datas',
                'foreign_id' => 59,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '1413 Kōnanchō Yusa, Takamatsu, Kagawa 761-1402, Nhật Bản',
            ),
            352 => 
            array (
                'id' => 493,
                'foreign_table' => 'map_datas',
                'foreign_id' => 61,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '99-1 Shionoechō Yasuharakamihigashi, Takamatsu, Kagawa 761-1612, Nhật Bản',
            ),
            353 => 
            array (
                'id' => 494,
                'foreign_table' => 'map_datas',
                'foreign_id' => 62,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Sunrise Hills Country Club to Takamatsu Gold Country Club',
            ),
            354 => 
            array (
                'id' => 495,
                'foreign_table' => 'map_datas',
                'foreign_id' => 62,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => 'Kō-甲2327 Shionoechō Kaminishi, Takamatsu, Kagawa 761-1613, Nhật Bản',
            ),
            355 => 
            array (
                'id' => 496,
                'foreign_table' => 'map_datas',
                'foreign_id' => 63,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Ōtaki-Ōkawa Prefectural Natural Park',
            ),
            356 => 
            array (
                'id' => 497,
                'foreign_table' => 'map_datas',
                'foreign_id' => 63,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '087-893-0345',
            ),
            357 => 
            array (
                'id' => 498,
                'foreign_table' => 'map_datas',
                'foreign_id' => 64,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Ōtaki-Ōkawa Prefectural Natural Park',
            ),
            358 => 
            array (
                'id' => 499,
                'foreign_table' => 'map_datas',
                'foreign_id' => 65,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'PlygolMiyazaki',
            ),
            359 => 
            array (
                'id' => 500,
                'foreign_table' => 'map_datas',
                'foreign_id' => 65,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Tsuno Choritsu Tsunominami Elementary School',
            ),
            360 => 
            array (
                'id' => 501,
                'foreign_table' => 'map_datas',
                'foreign_id' => 65,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '１０７３ Kawakita, Tsuno, Koyu-gun, Miyazaki 889-1201, Nhật Bản',
            ),
            361 => 
            array (
                'id' => 502,
                'foreign_table' => 'map_datas',
                'foreign_id' => 65,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0983-25-0023',
            ),
            362 => 
            array (
                'id' => 503,
                'foreign_table' => 'posts',
                'foreign_id' => 236,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'hello Viet Nam',
            ),
            363 => 
            array (
                'id' => 506,
                'foreign_table' => 'map_datas',
                'foreign_id' => 66,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Tokyo Metropolitan Town Hall',
            ),
            364 => 
            array (
                'id' => 507,
                'foreign_table' => 'map_datas',
                'foreign_id' => 66,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'A town of liars. We ask for change of address notice of oldness and tax payment many times, and when we send out, reply does not reach even if it comes until after. I will never go on a trip.',
            ),
            365 => 
            array (
                'id' => 508,
                'foreign_table' => 'map_datas',
                'foreign_id' => 66,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '４８７４番地−２ Kawakita, Tsuno, Koyu-gun, Miyazaki 889-1201, Nhật Bản',
            ),
            366 => 
            array (
                'id' => 509,
                'foreign_table' => 'map_datas',
                'foreign_id' => 66,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0983-25-5710',
            ),
            367 => 
            array (
                'id' => 510,
                'foreign_table' => 'map_datas',
                'foreign_id' => 67,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Toyo Tire & Rubber Co., Ltd. Tire Testing Office Office',
            ),
            368 => 
            array (
                'id' => 511,
                'foreign_table' => 'map_datas',
                'foreign_id' => 67,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => 'A town of liars. It is delicious when I asked for the address change notice of the oldness and tax payment many times and sent it out. The taste is very similar to the taste I had eaten somewhere (nearly Kurume famous store). Was it trained there? What a place. The noodles are fine and the firmness of the noodles is usually firm. It may be close to Hakata. Cirche also Toro Toro ... everything is as close to a ○ ○ house. It\'s similar in taste but it\'s a shop I want to visit again',
            ),
            369 => 
            array (
                'id' => 512,
                'foreign_table' => 'map_datas',
                'foreign_id' => 67,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => 'Shinden-2318 Kawakita, Tsuno, Koyu-gun, Miyazaki 889-1201, Nhật Bản',
            ),
            370 => 
            array (
                'id' => 513,
                'foreign_table' => 'map_datas',
                'foreign_id' => 67,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0983-25-0310',
            ),
            371 => 
            array (
                'id' => 514,
                'foreign_table' => 'map_datas',
                'foreign_id' => 44,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'We went to abdominal CT examination by introduction from family doctor
Doctor in charge (Tuesday 3 visits) Even once I saw my face, I was a doctor on my computer
Please enter information from
I felt very bad! !
Tell the heart that it doesn\'t always take a hospital here
But it was unpleasant',
            ),
            372 => 
            array (
                'id' => 515,
                'foreign_table' => 'map_datas',
                'foreign_id' => 44,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '3 Chome-2-2-11 Hiedacho, Takahama, Aichi 444-1321, Nhật Bản',
            ),
            373 => 
            array (
                'id' => 516,
                'foreign_table' => 'map_datas',
                'foreign_id' => 51,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '028-222-566',
            ),
            374 => 
            array (
                'id' => 517,
                'foreign_table' => 'map_datas',
                'foreign_id' => 45,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka Municipal Shimizu Hospital',
            ),
            375 => 
            array (
                'id' => 518,
                'foreign_table' => 'map_datas',
                'foreign_id' => 45,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '097-3823-222',
            ),
            376 => 
            array (
                'id' => 519,
                'foreign_table' => 'map_datas',
                'foreign_id' => 41,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka Saiseikai General Hospital',
            ),
            377 => 
            array (
                'id' => 520,
                'foreign_table' => 'map_datas',
                'foreign_id' => 41,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'My husband complained of ureteral stone symptoms at night, and I called this one with an emergency.
Though I was not an on-duty doctor, I was not able to see a doctor, but it was very polite that a telephone-enabled man contacted a nurse many times or worried and called out over the phone. It was a great response despite the night time by giving us the phone number of the hospital where the on-duty doctor is and giving advice.
As we have not had a medical examination, it is evaluation for correspondence of night receptionist.',
            ),
            378 => 
            array (
                'id' => 521,
                'foreign_table' => 'map_datas',
                'foreign_id' => 41,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0986-221-8181',
            ),
            379 => 
            array (
                'id' => 522,
                'foreign_table' => 'map_datas',
                'foreign_id' => 68,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Sakuragaoka Hospital',
            ),
            380 => 
            array (
                'id' => 523,
                'foreign_table' => 'map_datas',
                'foreign_id' => 69,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka Institute of Epilepsy and Neurological Disorders',
            ),
            381 => 
            array (
                'id' => 524,
                'foreign_table' => 'map_datas',
                'foreign_id' => 69,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Everybody writes, but I have also been hospitalized and have been hospitalized again some years later.
The teacher is very good, but the quality of the nurse is not good.
The words are bad and the attitude is tight. 
It can not be said that she is smiling and empowered for the patient.',
            ),
            382 => 
            array (
                'id' => 525,
                'foreign_table' => 'map_datas',
                'foreign_id' => 69,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '886 Urushiyama, Aoi-ku, Shizuoka, 420-8688, Nhật Bản',
            ),
            383 => 
            array (
                'id' => 526,
                'foreign_table' => 'map_datas',
                'foreign_id' => 69,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '032-2277-5466',
            ),
            384 => 
            array (
                'id' => 527,
                'foreign_table' => 'map_datas',
                'foreign_id' => 45,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Fuji seen from the 11th floor is a very magnificent and wonderful view.
I will be healing Mt. F
uji while drinking a rose.
It was fine and nice without clouds.',
            ),
            385 => 
            array (
                'id' => 528,
                'foreign_table' => 'map_datas',
                'foreign_id' => 70,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Tokoha University Shizuoka Sena Campus',
            ),
            386 => 
            array (
                'id' => 529,
                'foreign_table' => 'map_datas',
                'foreign_id' => 70,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'I heard that it was a university open to the community, and it is like a free space, but it is a mysterious place that is noted when playing.
University is a day off and no one is using it',
            ),
            387 => 
            array (
                'id' => 530,
                'foreign_table' => 'map_datas',
                'foreign_id' => 70,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '1-chōme-22-1 Sena, Aoi-ku, Shizuoka, 420-0911, Nhật Bản',
            ),
            388 => 
            array (
                'id' => 531,
                'foreign_table' => 'map_datas',
                'foreign_id' => 70,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '054-263-1125',
            ),
            389 => 
            array (
                'id' => 532,
                'foreign_table' => 'map_datas',
                'foreign_id' => 71,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka Prefectural Psychiatric Medical Center',
            ),
            390 => 
            array (
                'id' => 533,
                'foreign_table' => 'map_datas',
                'foreign_id' => 30,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Title Guom Lake en',
            ),
            391 => 
            array (
                'id' => 534,
                'foreign_table' => 'map_datas',
                'foreign_id' => 30,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '1-8 Le thai To, Hang Trong, Ha Noi, Viet Nam',
            ),
            392 => 
            array (
                'id' => 535,
                'foreign_table' => 'map_datas',
                'foreign_id' => 30,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '028-2828-9999',
            ),
            393 => 
            array (
                'id' => 536,
                'foreign_table' => 'map_datas',
                'foreign_id' => 72,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Minaminakatanikubo Community Center',
            ),
            394 => 
            array (
                'id' => 537,
                'foreign_table' => 'map_datas',
                'foreign_id' => 73,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Nippon Express Co., Ltd. Shizuoka Airlines Branch Shizuoka Freight Center',
            ),
            395 => 
            array (
                'id' => 538,
                'foreign_table' => 'map_datas',
                'foreign_id' => 73,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '8-7 Ryūtsū Center, Aoi-ku, Shizuoka, 420-0922, Nhật Bản',
            ),
            396 => 
            array (
                'id' => 539,
                'foreign_table' => 'map_datas',
                'foreign_id' => 73,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0827-111-291',
            ),
            397 => 
            array (
                'id' => 544,
                'foreign_table' => 'map_datas',
                'foreign_id' => 74,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka City Mizumi Elementary School',
            ),
            398 => 
            array (
                'id' => 545,
                'foreign_table' => 'map_datas',
                'foreign_id' => 74,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Specified Non-Profit Activities Promotion Act In accordance with Article 2.
we have refused to give lectures on the purpose of supporting and developing specific religious and political principles',
            ),
            399 => 
            array (
                'id' => 546,
                'foreign_table' => 'map_datas',
                'foreign_id' => 74,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '１０４０−３ Mizumiiro, Aoi-ku, Shizuoka, 421-1313, Nhật Bản',
            ),
            400 => 
            array (
                'id' => 547,
                'foreign_table' => 'map_datas',
                'foreign_id' => 74,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '092-282-8913',
            ),
            401 => 
            array (
                'id' => 548,
                'foreign_table' => 'map_datas',
                'foreign_id' => 75,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka Aoi Hospital',
            ),
            402 => 
            array (
                'id' => 549,
                'foreign_table' => 'map_datas',
                'foreign_id' => 75,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '0787-287-999',
            ),
            403 => 
            array (
                'id' => 550,
                'foreign_table' => 'map_datas',
                'foreign_id' => 76,
                'foreign_field' => 'title',
                'lang' => 'en',
                'translated_text' => 'Shizuoka Municipal Shimizu Hospital',
            ),
            404 => 
            array (
                'id' => 551,
                'foreign_table' => 'map_datas',
                'foreign_id' => 76,
                'foreign_field' => 'body',
                'lang' => 'en',
                'translated_text' => 'Mother is introduced to suspicion of dementia, and visited our forgotten department.
Dementia test, MRI and other necessary examinations, and it is reported that Mr. Hata, who is the leading person here, whether it is FTD or not, let\'s go for a slow examination.',
            ),
            405 => 
            array (
                'id' => 552,
                'foreign_table' => 'map_datas',
                'foreign_id' => 76,
                'foreign_field' => 'address',
                'lang' => 'en',
                'translated_text' => '1231 Miyakami, Shimizu-ku, Shizuoka, 424-8636, Nhật Bản',
            ),
            406 => 
            array (
                'id' => 553,
                'foreign_table' => 'map_datas',
                'foreign_id' => 76,
                'foreign_field' => 'tel',
                'lang' => 'en',
                'translated_text' => '054-336-1111',
            ),
            407 => 
            array (
                'id' => 554,
                'foreign_table' => 'websites',
                'foreign_id' => 44,
                'foreign_field' => 'body',
                'lang' => 'en',
            'translated_text' => '1) Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally.<br>2) The situation on the day of the lecture may be introduced as an activity report of our group on the website or Facebook etc. If you do not want to introduce, please tell us in advance. In addition, we will publish the participant\'s face and personal name in an unidentifiable form unless prior approval is given.<br>3) The lecture fee will be paid to the corporation. Please do not deduct, etc. for withholding tax. In addition, it will be bank transfer in principle. Please consult us in case of cash payment. In principle, no invoices for lecture fees are issued. If necessary, please request one month prior to the issue date. In addition, the invoice will be issued in principle pdf.<br>',
        ),
        408 => 
        array (
            'id' => 555,
            'foreign_table' => 'websites',
            'foreign_id' => 45,
            'foreign_field' => 'title',
            'lang' => 'en',
            'translated_text' => 'Title webpage en',
        ),
        409 => 
        array (
            'id' => 556,
            'foreign_table' => 'websites',
            'foreign_id' => 45,
            'foreign_field' => 'body',
            'lang' => 'en',
        'translated_text' => '4) Since the content of the lecture conveys the current situation of the child, we have refused to record the content of the lecture and to disclose the content of the day without permission. In the case of what is assumed to be public, it is necessary to consider the contents etc. in advance, so please be sure to confirm in advance. In addition, when posting the state of the lecture on the HP etc. of your organization, I will make sure to confirm the contents. Please note that we may ask you to correct the contents of the publication.<br>5) The projection data will be brought by USB on the day. In principle, we do not pre-send data. I hope that you understand from the perspective of personal information protection etc.<br>6) Meeting time and break up time should be within 45 minutes before and after the lecture time. We run the organization with a small number of people, and I hope you understand.<br>7) Please refrain from forwarding and disclosing the contents of the lecture without permission from the viewpoint of personal information protection. If you wish, please consult in advance',
    ),
    410 => 
    array (
        'id' => 557,
        'foreign_table' => 'websites',
        'foreign_id' => 45,
        'foreign_field' => 'body',
        'lang' => 'ko',
        'translated_text' => '어머니가 치매의 혐의로 소개되고 여기 건망증과 수진.<br>치매 테스트, MRI 등 필요한 검사를 FTD이든 여기의 제일 인자 인 밭 씨로부터 전해져 천천히 진단 갑시다라는 것에.',
    ),
    411 => 
    array (
        'id' => 561,
        'foreign_table' => 'websites',
        'foreign_id' => 47,
        'foreign_field' => 'body',
        'lang' => 'en',
    'translated_text' => '1) Specified Non-Profit Activities Promotion Act In accordance with 
Article 2, we have refused to give lectures on the purpose of supporting
and developing specific religious and political principles. Please note
that even if the purpose is not clearly stated, the decision may be 
refused internally.<br>2) The situation on the day of the lecture may be
introduced as an activity report of our group on the website or 
Facebook etc. If you do not want to introduce, please tell us in 
advance. In addition, we will publish the participant\'s face and 
personal name in an unidentifiable form unless prior approval is given.<br>3)
The lecture fee will be paid to the corporation. Please do not deduct, 
etc. for withholding tax. In addition, it will be bank transfer in 
principle. Please consult us in case of cash payment. In principle, no 
invoices for lecture fees are issued. If necessary, please request one 
month prior to the issue date. In addition, the invoice will be issued 
in principle pdf.',
),
412 => 
array (
'id' => 563,
'foreign_table' => 'map_datas',
'foreign_id' => 75,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally',
),
413 => 
array (
'id' => 564,
'foreign_table' => 'websites',
'foreign_id' => 49,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Webpage4 en',
),
414 => 
array (
'id' => 565,
'foreign_table' => 'websites',
'foreign_id' => 49,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">1) Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally.</span></font>',
),
415 => 
array (
'id' => 566,
'foreign_table' => 'map_datas',
'foreign_id' => 77,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'The situation on the day of the lecture may be introduced as an activity report of our group on the website or Facebook etc. If you do not want to introduce, please tell us in advance. In addition, we will publish the participant\'s face and personal name in an unidentifiable form unless prior approval is given',
),
416 => 
array (
'id' => 567,
'foreign_table' => 'map_datas',
'foreign_id' => 77,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '1039 Kuzukawa, Kakegawa, Shizuoka 436-0074, Nhật Bản',
),
417 => 
array (
'id' => 568,
'foreign_table' => 'map_datas',
'foreign_id' => 78,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Kakegawa City Hall Health and Welfare Department Health Prevention Division, Health Planning, Maternal and Child Health, Adult Health Care Section',
),
418 => 
array (
'id' => 569,
'foreign_table' => 'map_datas',
'foreign_id' => 78,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'Some were friendly and others were phone-friendly.
That person was said clerical.
I was worried at the time of the first person and I called once, but I think that one can understand humanity with one phone call',
),
419 => 
array (
'id' => 570,
'foreign_table' => 'map_datas',
'foreign_id' => 78,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '9-28 Goshobara, Kakegawa, Shizuoka 436-0068, Nhật Bản',
),
420 => 
array (
'id' => 571,
'foreign_table' => 'map_datas',
'foreign_id' => 77,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Kakegawa City East Junior High School',
),
421 => 
array (
'id' => 572,
'foreign_table' => 'map_datas',
'foreign_id' => 79,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Kakegawa City Hall Health and Welfare Department Health Prevention Division, Health Planning, Maternal and Child Health, Adult Health Care Section to Kakegawa City East Junior High School',
),
422 => 
array (
'id' => 573,
'foreign_table' => 'map_datas',
'foreign_id' => 79,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '1039 Kuzukawa, Kakegawa, Shizuoka 436-0074, Nhật Bản',
),
423 => 
array (
'id' => 574,
'foreign_table' => 'map_datas',
'foreign_id' => 79,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '0537-22-5158',
),
424 => 
array (
'id' => 575,
'foreign_table' => 'map_datas',
'foreign_id' => 80,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Kakegawa City East Junior High School to Shizuoka Aoi Hospital',
),
425 => 
array (
'id' => 576,
'foreign_table' => 'map_datas',
'foreign_id' => 80,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'Specified Non-Profit Activities Promotion Act In accordance with Article 2, we have refused to give lectures on the purpose of supporting and developing specific religious and political principles. Please note that even if the purpose is not clearly stated, the decision may be refused internally',
),
426 => 
array (
'id' => 577,
'foreign_table' => 'map_datas',
'foreign_id' => 80,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '9-28 Goshobara, Kakegawa, Shizuoka 436-0068, Nhật Bản',
),
427 => 
array (
'id' => 578,
'foreign_table' => 'map_datas',
'foreign_id' => 81,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Miki-no-Sato Country Club to Kakegawa Green Hill Country Club to Ikoi no Hiroba Station to Shibata City General Hospital',
),
428 => 
array (
'id' => 579,
'foreign_table' => 'map_datas',
'foreign_id' => 81,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'It is quite interesting to read the golf course ゴ ル フ green which can be enjoyed with the back of the horse
There is a place where there is a poultry house in the IN course near the IN course, but I endure patience (lol)
In the evening, the sun was so tight that the tee shot lost sight of the destination and did not know the pin.
I would like to come again',
),
429 => 
array (
'id' => 580,
'foreign_table' => 'map_datas',
'foreign_id' => 81,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '1000 Terashima, Kakegawa, Shizuoka 436-0106, Nhật Bản',
),
430 => 
array (
'id' => 581,
'foreign_table' => 'tags',
'foreign_id' => 69,
'foreign_field' => 'name',
'lang' => 'en',
'translated_text' => 'Tag1',
),
431 => 
array (
'id' => 582,
'foreign_table' => 'tags',
'foreign_id' => 70,
'foreign_field' => 'name',
'lang' => 'en',
'translated_text' => 'Tag2',
),
432 => 
array (
'id' => 583,
'foreign_table' => 'tags',
'foreign_id' => 71,
'foreign_field' => 'name',
'lang' => 'en',
'translated_text' => 'Tag3',
),
433 => 
array (
'id' => 584,
'foreign_table' => 'map_datas',
'foreign_id' => 82,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Numazu City Harato Elementary School to Numazu City Ehime Junior High School to Numazu City Sawada Elementary School',
),
434 => 
array (
'id' => 585,
'foreign_table' => 'map_datas',
'foreign_id' => 82,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'In the evening, the sun was so tight that the tee shot lost sight of the destination and did not know the pin.
I would like to come again',
),
435 => 
array (
'id' => 586,
'foreign_table' => 'map_datas',
'foreign_id' => 82,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '715 Nakasawada, Numazu, Shizuoka 410-0006, Nhật Bản',
),
436 => 
array (
'id' => 587,
'foreign_table' => 'map_datas',
'foreign_id' => 82,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '097-3823-222',
),
437 => 
array (
'id' => 588,
'foreign_table' => 'map_datas',
'foreign_id' => 83,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Numazu City Katahama Junior High School to Numazu City Fifth Junior High School to National Hospital Organization Shizuoka Medical Center to Shizuoka Prefectural Numazu Industrial High School',
),
438 => 
array (
'id' => 589,
'foreign_table' => 'map_datas',
'foreign_id' => 83,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'I have a job in my hand. In the current era, it is important to have no problem with cultural sciences. Qualifications in technology are important in order to be comfortable.',
),
439 => 
array (
'id' => 590,
'foreign_table' => 'map_datas',
'foreign_id' => 83,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => 'Nhật Bản, 〒410-0822 Shizuoka, Numazu, 下香貫八重１２９−１',
),
440 => 
array (
'id' => 591,
'foreign_table' => 'map_datas',
'foreign_id' => 83,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '054-336-1111',
),
441 => 
array (
'id' => 592,
'foreign_table' => 'map_datas',
'foreign_id' => 84,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Numazu City Katahama Junior High School to Numazu City Fifth Elementary School',
),
442 => 
array (
'id' => 593,
'foreign_table' => 'map_datas',
'foreign_id' => 84,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '9-1 Yoneyamacho, Numazu, Shizuoka 410-0046, Nhật Bản',
),
443 => 
array (
'id' => 594,
'foreign_table' => 'map_datas',
'foreign_id' => 84,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '055-921-0355',
),
444 => 
array (
'id' => 595,
'foreign_table' => 'map_datas',
'foreign_id' => 85,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Eastern Driving School to Numazu City Baseball Stadium',
),
445 => 
array (
'id' => 596,
'foreign_table' => 'map_datas',
'foreign_id' => 85,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '17-1 Kotobukicho, Numazu, Shizuoka 410-0053, Nhật Bản',
),
446 => 
array (
'id' => 597,
'foreign_table' => 'map_datas',
'foreign_id' => 85,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '055-922-7200',
),
447 => 
array (
'id' => 598,
'foreign_table' => 'map_datas',
'foreign_id' => 86,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Harada Dental Clinic',
),
448 => 
array (
'id' => 599,
'foreign_table' => 'map_datas',
'foreign_id' => 68,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '7-2 Kyoeicho, Numazu, Shizuoka 410-0064, Nhật Bản',
),
449 => 
array (
'id' => 600,
'foreign_table' => 'map_datas',
'foreign_id' => 68,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '055-924-0500',
),
450 => 
array (
'id' => 601,
'foreign_table' => 'map_datas',
'foreign_id' => 86,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'Harada Dental Clinic3333',
),
451 => 
array (
'id' => 602,
'foreign_table' => 'map_datas',
'foreign_id' => 86,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => '7-2 Kyōeichō, Numazu, Shizuoka 410-0064, Nhật Bản, Hello',
),
452 => 
array (
'id' => 603,
'foreign_table' => 'map_datas',
'foreign_id' => 86,
'foreign_field' => 'tel',
'lang' => 'en',
'translated_text' => '0271-7171-889',
),
453 => 
array (
'id' => 604,
'foreign_table' => 'files',
'foreign_id' => 85,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'File en',
),
454 => 
array (
'id' => 605,
'foreign_table' => 'files',
'foreign_id' => 85,
'foreign_field' => 'title',
'lang' => 'ko',
'translated_text' => 'file ko',
),
455 => 
array (
'id' => 606,
'foreign_table' => 'map_datas',
'foreign_id' => 48,
'foreign_field' => 'title',
'lang' => 'en',
'translated_text' => 'Fujikawaguchiko',
),
456 => 
array (
'id' => 607,
'foreign_table' => 'map_datas',
'foreign_id' => 48,
'foreign_field' => 'body',
'lang' => 'en',
'translated_text' => 'Fujikawaguchiko',
),
457 => 
array (
'id' => 608,
'foreign_table' => 'map_datas',
'foreign_id' => 48,
'foreign_field' => 'address',
'lang' => 'en',
'translated_text' => 'Minamitsuru District, Yamanashi Nhat Ban',
),
458 => 
array (
'id' => 609,
'foreign_table' => 'tags',
'foreign_id' => 72,
'foreign_field' => 'name',
'lang' => 'en',
'translated_text' => 'Song than1',
),
459 => 
array (
'id' => 610,
'foreign_table' => 'tags',
'foreign_id' => 72,
'foreign_field' => 'name',
'lang' => 'ko',
'translated_text' => 'Song than1',
),
));
        
        
    }
}