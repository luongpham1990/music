<?php

use Illuminate\Database\Seeder;

class ClientsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('clients')->delete();
        
        \DB::table('clients')->insert(array (
            0 => 
            array (
                'id' => 1,
                'client_code' => 'visor',
                'client_name' => 'VISOR',
                'client_status' => 1,
                'service_name' => 'バイザー連絡網',
                'created_at' => '2018-11-27 12:35:02',
                'updated_at' => '2018-11-27 12:35:02',
            ),
            1 => 
            array (
                'id' => 37,
                'client_code' => 'vnc1',
                'client_name' => 'vinicorp',
                'client_status' => 1,
                'service_name' => 'service1',
                'created_at' => '2018-11-28 13:08:30',
                'updated_at' => '2018-11-28 13:08:30',
            ),
            2 => 
            array (
                'id' => 38,
                'client_code' => 'vnc2',
                'client_name' => 'vnc2',
                'client_status' => 3,
                'service_name' => 'dasd',
                'created_at' => '2018-11-29 17:24:41',
                'updated_at' => '2018-11-29 17:24:41',
            ),
            3 => 
            array (
                'id' => 39,
                'client_code' => 'vnc4',
                'client_name' => 'vnc4',
                'client_status' => 1,
                'service_name' => 'svvnc4',
                'created_at' => '2018-11-30 13:06:24',
                'updated_at' => '2018-11-30 13:06:24',
            ),
            4 => 
            array (
                'id' => 40,
                'client_code' => 'vnc5',
                'client_name' => 'vnc5',
                'client_status' => 1,
                'service_name' => 'vnc5',
                'created_at' => '2018-11-30 13:21:07',
                'updated_at' => '2018-11-30 13:21:07',
            ),
            5 => 
            array (
                'id' => 41,
                'client_code' => 'hfhggdf',
                'client_name' => 'gfdfg',
                'client_status' => 9,
                'service_name' => 'gdgdfg',
                'created_at' => '2018-11-30 13:43:27',
                'updated_at' => '2018-11-30 13:43:27',
            ),
            6 => 
            array (
                'id' => 42,
                'client_code' => 'jrrrrrrrrrrrrrrr',
                'client_name' => '多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧',
                'client_status' => 1,
                'service_name' => '多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言語一覧多言',
                'created_at' => '2018-11-30 15:29:48',
                'updated_at' => '2018-12-05 16:02:38',
            ),
            7 => 
            array (
                'id' => 43,
                'client_code' => 'vncvncvncvncvncvncvncvncvncvncvncvncvncv',
                'client_name' => 'ログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくだ',
                'client_status' => 3,
                'service_name' => 'ログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくださいログインIDは必ず入力してくだ',
                'created_at' => '2018-12-05 16:00:46',
                'updated_at' => '2018-12-05 16:02:02',
            ),
            8 => 
            array (
                'id' => 44,
                'client_code' => '111111111',
                'client_name' => '2客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのは',
                'client_status' => 1,
                'service_name' => '3客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのはうれしい顧客と知り合うのは',
                'created_at' => '2018-12-05 16:03:32',
                'updated_at' => '2018-12-05 16:03:32',
            ),
            9 => 
            array (
                'id' => 45,
                'client_code' => 'tung',
                'client_name' => 'tung',
                'client_status' => 2,
                'service_name' => 'hotel',
                'created_at' => '2018-12-05 18:45:40',
                'updated_at' => '2018-12-05 18:45:40',
            ),
            10 => 
            array (
                'id' => 47,
                'client_code' => '000000000000002',
                'client_name' => 'Tiênnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn',
                'client_status' => 1,
                'service_name' => 'cdddddddddddddđaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
                'created_at' => '2018-12-06 18:58:22',
                'updated_at' => '2018-12-06 18:58:22',
            ),
            11 => 
            array (
                'id' => 48,
                'client_code' => 'vvvvveqqqqqq',
                'client_name' => 'qqqqqqqqqqqqqqqqq',
                'client_status' => 1,
                'service_name' => 'ffffffffffffffffff',
                'created_at' => '2018-12-06 18:58:57',
                'updated_at' => '2018-12-06 18:58:57',
            ),
            12 => 
            array (
                'id' => 49,
                'client_code' => 'linh',
                'client_name' => 'linh',
                'client_status' => 1,
                'service_name' => 'http://it-machiyell.test/mgr/auth/login',
                'created_at' => '2018-12-06 18:59:16',
                'updated_at' => '2018-12-06 18:59:16',
            ),
            13 => 
            array (
                'id' => 50,
                'client_code' => 'thao',
                'client_name' => 'thao',
                'client_status' => 1,
                'service_name' => 'thao',
                'created_at' => '2018-12-06 18:59:29',
                'updated_at' => '2018-12-06 18:59:29',
            ),
            14 => 
            array (
                'id' => 51,
                'client_code' => 'thong',
                'client_name' => 'thong',
                'client_status' => 1,
                'service_name' => 'thong',
                'created_at' => '2018-12-06 18:59:48',
                'updated_at' => '2018-12-06 18:59:48',
            ),
            15 => 
            array (
                'id' => 52,
                'client_code' => 'csssssssssssssss',
                'client_name' => 'sssssssssssss',
                'client_status' => 1,
                'service_name' => 'ssssssssssssssss',
                'created_at' => '2018-12-06 19:00:40',
                'updated_at' => '2018-12-06 19:00:40',
            ),
            16 => 
            array (
                'id' => 53,
                'client_code' => 'vietnam',
                'client_name' => 'vietnam',
                'client_status' => 1,
                'service_name' => 'vietnam',
                'created_at' => '2018-12-06 19:00:52',
                'updated_at' => '2018-12-06 19:00:52',
            ),
            17 => 
            array (
                'id' => 56,
                'client_code' => 'tygq',
                'client_name' => 'hhhhhhhhhh',
                'client_status' => 1,
                'service_name' => 'hhhhhhhhhhhhhh',
                'created_at' => '2018-12-06 19:05:16',
                'updated_at' => '2018-12-06 19:05:16',
            ),
            18 => 
            array (
                'id' => 70,
                'client_code' => 'demo',
                'client_name' => 'demo',
                'client_status' => 3,
                'service_name' => 'demo',
                'created_at' => '2018-12-06 19:14:25',
                'updated_at' => '2018-12-06 19:14:25',
            ),
            19 => 
            array (
                'id' => 71,
                'client_code' => 'Dangchuanbi',
                'client_name' => 'Đang chuẩn bị222',
                'client_status' => 2,
                'service_name' => 'Đang chuẩn bị',
                'created_at' => '2018-12-06 19:15:41',
                'updated_at' => '2018-12-06 19:22:48',
            ),
            20 => 
            array (
                'id' => 72,
                'client_code' => 'thuntm',
                'client_name' => 'thuntm',
                'client_status' => 1,
                'service_name' => 'Dịch vụ',
                'created_at' => '2018-12-07 10:21:12',
                'updated_at' => '2018-12-07 10:35:18',
            ),
            21 => 
            array (
                'id' => 73,
                'client_code' => 'test',
                'client_name' => 'test',
                'client_status' => 1,
                'service_name' => 'test',
                'created_at' => '2018-12-10 11:56:05',
                'updated_at' => '2018-12-10 11:56:05',
            ),
            22 => 
            array (
                'id' => 74,
                'client_code' => '0002',
                'client_name' => 'コレクション',
                'client_status' => 1,
                'service_name' => 'コレクションコレクション',
                'created_at' => '2018-12-10 12:47:04',
                'updated_at' => '2018-12-10 12:47:04',
            ),
            23 => 
            array (
                'id' => 75,
                'client_code' => 'ID001',
                'client_name' => '妖精',
                'client_status' => 1,
                'service_name' => '妖精',
                'created_at' => '2018-12-10 12:51:38',
                'updated_at' => '2018-12-10 12:51:38',
            ),
            24 => 
            array (
                'id' => 76,
                'client_code' => 'TC001',
                'client_name' => 'Thubeo',
                'client_status' => 1,
                'service_name' => 'Thubeo',
                'created_at' => '2018-12-10 13:49:46',
                'updated_at' => '2018-12-10 13:49:46',
            ),
            25 => 
            array (
                'id' => 77,
                'client_code' => 'TC002',
                'client_name' => 'Tungvd',
                'client_status' => 1,
                'service_name' => 'Tungvd',
                'created_at' => '2018-12-10 13:57:28',
                'updated_at' => '2018-12-10 13:57:28',
            ),
            26 => 
            array (
                'id' => 78,
                'client_code' => 'TesterTesterTesterTesterTesterTesterTest',
                'client_name' => 'TesterTesterTesterTesterTesterTesterTestTesterTesterTesterTesterTesterTesterTestTesterTesterTesterTe',
                'client_status' => 9,
                'service_name' => 'Review code for branch feature-route-languageReview code for branch feature-route-languageReview cod',
                'created_at' => '2018-12-10 15:45:30',
                'updated_at' => '2018-12-11 13:01:07',
            ),
            27 => 
            array (
                'id' => 79,
                'client_code' => 'hieudu',
                'client_name' => 'ducathegioi',
                'client_status' => 2,
                'service_name' => 'ducathegioinayhaha',
                'created_at' => '2018-12-10 18:26:25',
                'updated_at' => '2018-12-10 18:26:25',
            ),
            28 => 
            array (
                'id' => 80,
                'client_code' => 'nosplash',
                'client_name' => 'ducathegioi',
                'client_status' => 2,
                'service_name' => 'ducathegioinayhaha',
                'created_at' => '2018-12-10 18:26:25',
                'updated_at' => '2018-12-10 18:26:25',
            ),
            29 => 
            array (
                'id' => 181,
                'client_code' => 'no_app_setting',
                'client_name' => 'ducathegioi',
                'client_status' => 2,
                'service_name' => 'ducathegioinayhaha',
                'created_at' => '2018-12-10 18:26:25',
                'updated_at' => '2018-12-10 18:26:25',
            ),
            30 => 
            array (
                'id' => 182,
                'client_code' => 'khachhang',
                'client_name' => 'Thang',
                'client_status' => 2,
                'service_name' => 'Spa',
                'created_at' => '2019-03-01 16:58:37',
                'updated_at' => '2019-03-01 16:58:37',
            ),
            31 => 
            array (
                'id' => 183,
                'client_code' => 'LanAnh',
                'client_name' => 'Lan',
                'client_status' => 1,
                'service_name' => 'KhachSan',
                'created_at' => '2019-03-01 17:09:17',
                'updated_at' => '2019-03-01 17:09:17',
            ),
            32 => 
            array (
                'id' => 184,
                'client_code' => 'thang3',
                'client_name' => 'thang3',
                'client_status' => 1,
                'service_name' => 'thang3',
                'created_at' => '2019-03-01 17:16:50',
                'updated_at' => '2019-03-01 17:16:50',
            ),
            33 => 
            array (
                'id' => 185,
                'client_code' => 'Quang',
                'client_name' => 'Quang',
                'client_status' => 1,
                'service_name' => 'Hotel',
                'created_at' => '2019-03-01 18:00:59',
                'updated_at' => '2019-03-01 18:00:59',
            ),
            34 => 
            array (
                'id' => 186,
                'client_code' => 'eqwewq',
                'client_name' => 'eqweqw',
                'client_status' => 3,
                'service_name' => 'zxczcxzc',
                'created_at' => '2019-03-01 18:04:35',
                'updated_at' => '2019-03-01 18:04:35',
            ),
            35 => 
            array (
                'id' => 187,
                'client_code' => 'luongtest',
                'client_name' => 'luongtest',
                'client_status' => 2,
                'service_name' => 'etetet',
                'created_at' => '2019-03-01 18:24:12',
                'updated_at' => '2019-03-01 18:24:12',
            ),
            36 => 
            array (
                'id' => 188,
                'client_code' => 'tetetasdsadasdasdww',
                'client_name' => 'etete11111',
                'client_status' => 2,
                'service_name' => 'etetet',
                'created_at' => '2019-03-01 18:29:49',
                'updated_at' => '2019-03-01 18:39:31',
            ),
            37 => 
            array (
                'id' => 189,
                'client_code' => 'luongtest1',
                'client_name' => 'luongtest1',
                'client_status' => 1,
                'service_name' => 'luongtest1',
                'created_at' => '2019-03-01 18:33:11',
                'updated_at' => '2019-03-12 10:48:53',
            ),
            38 => 
            array (
                'id' => 190,
                'client_code' => 'luongtest2',
                'client_name' => 'luongtest2',
                'client_status' => 1,
                'service_name' => 'luongtest2',
                'created_at' => '2019-03-01 18:59:44',
                'updated_at' => '2019-03-11 12:50:55',
            ),
            39 => 
            array (
                'id' => 191,
                'client_code' => 'luongtest3',
                'client_name' => 'luongtest3',
                'client_status' => 1,
                'service_name' => 'etetet',
                'created_at' => '2019-03-01 19:33:25',
                'updated_at' => '2019-03-01 19:33:25',
            ),
            40 => 
            array (
                'id' => 192,
                'client_code' => 'son',
                'client_name' => 'son',
                'client_status' => 1,
                'service_name' => 'Dịch vụ',
                'created_at' => '2019-03-05 13:03:04',
                'updated_at' => '2019-03-05 13:03:04',
            ),
            41 => 
            array (
                'id' => 193,
                'client_code' => 'tetetclient_setting',
                'client_name' => 'tetet client_setting',
                'client_status' => 1,
                'service_name' => 'tetet client_setting',
                'created_at' => '2019-03-06 16:56:30',
                'updated_at' => '2019-03-06 16:56:30',
            ),
            42 => 
            array (
                'id' => 194,
                'client_code' => 'luongtest4',
                'client_name' => 'luongtest4',
                'client_status' => 2,
                'service_name' => 'luongtest4',
                'created_at' => '2019-03-11 13:40:07',
                'updated_at' => '2019-03-11 15:30:34',
            ),
            43 => 
            array (
                'id' => 195,
                'client_code' => 'luongtest5',
                'client_name' => 'luongtest5',
                'client_status' => 1,
                'service_name' => 'luongtest5',
                'created_at' => '2019-03-11 13:51:29',
                'updated_at' => '2019-03-11 13:51:29',
            ),
            44 => 
            array (
                'id' => 196,
                'client_code' => 'luongtest6',
                'client_name' => 'luongtest6',
                'client_status' => 1,
                'service_name' => 'luongtest6',
                'created_at' => '2019-03-11 13:55:19',
                'updated_at' => '2019-03-11 13:55:19',
            ),
            45 => 
            array (
                'id' => 197,
                'client_code' => 'luongtest7',
                'client_name' => 'luongtest7',
                'client_status' => 1,
                'service_name' => 'luongtest7',
                'created_at' => '2019-03-11 13:59:53',
                'updated_at' => '2019-03-11 13:59:53',
            ),
            46 => 
            array (
                'id' => 198,
                'client_code' => 'luongtest8',
                'client_name' => 'luongtest8',
                'client_status' => 1,
                'service_name' => 'luongtest8',
                'created_at' => '2019-03-11 15:10:21',
                'updated_at' => '2019-03-11 15:10:21',
            ),
            47 => 
            array (
                'id' => 199,
                'client_code' => 'vinicorp',
                'client_name' => 'vinicorp',
                'client_status' => 1,
                'service_name' => 'Computer',
                'created_at' => '2019-03-11 16:52:23',
                'updated_at' => '2019-03-11 16:52:23',
            ),
            48 => 
            array (
                'id' => 205,
                'client_code' => 'Thuntmm',
                'client_name' => 'ThuLibero',
                'client_status' => 1,
                'service_name' => 'Dịch vụ',
                'created_at' => '2019-04-10 12:29:07',
                'updated_at' => '2019-04-10 12:29:07',
            ),
            49 => 
            array (
                'id' => 206,
                'client_code' => 'demo1',
                'client_name' => 'demo',
                'client_status' => 1,
                'service_name' => 'demo',
                'created_at' => '2019-04-10 12:31:12',
                'updated_at' => '2019-04-10 12:31:12',
            ),
            50 => 
            array (
                'id' => 207,
                'client_code' => 'hieu_hieu',
                'client_name' => 'hieuhieu',
                'client_status' => 1,
                'service_name' => 'hieuhieu',
                'created_at' => '2019-04-10 13:02:30',
                'updated_at' => '2019-04-10 13:02:30',
            ),
        ));
        
        
    }
}