<?php

use Illuminate\Database\Seeder;

class ClientLanguagesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('client_languages')->delete();
        
        \DB::table('client_languages')->insert(array (
            0 => 
            array (
                'id' => 750,
                'client_id' => 2,
                'lang' => 'ko',
                'position' => 13,
            ),
            1 => 
            array (
                'id' => 763,
                'client_id' => 71,
                'lang' => 'ja',
                'position' => 1,
            ),
            2 => 
            array (
                'id' => 764,
                'client_id' => 71,
                'lang' => 'en',
                'position' => 2,
            ),
            3 => 
            array (
                'id' => 765,
                'client_id' => 71,
                'lang' => 'ko',
                'position' => 3,
            ),
            4 => 
            array (
                'id' => 766,
                'client_id' => 71,
                'lang' => 'zh',
                'position' => 4,
            ),
            5 => 
            array (
                'id' => 767,
                'client_id' => 71,
                'lang' => 'pt',
                'position' => 5,
            ),
            6 => 
            array (
                'id' => 768,
                'client_id' => 71,
                'lang' => 'es',
                'position' => 6,
            ),
            7 => 
            array (
                'id' => 770,
                'client_id' => 72,
                'lang' => 'ja',
                'position' => 9,
            ),
            8 => 
            array (
                'id' => 771,
                'client_id' => 72,
                'lang' => 'en',
                'position' => 13,
            ),
            9 => 
            array (
                'id' => 772,
                'client_id' => 77,
                'lang' => 'ja',
                'position' => 1,
            ),
            10 => 
            array (
                'id' => 773,
                'client_id' => 77,
                'lang' => 'en',
                'position' => 3,
            ),
            11 => 
            array (
                'id' => 778,
                'client_id' => 78,
                'lang' => 'en',
                'position' => 4,
            ),
            12 => 
            array (
                'id' => 780,
                'client_id' => 78,
                'lang' => 'es',
                'position' => 2,
            ),
            13 => 
            array (
                'id' => 781,
                'client_id' => 78,
                'lang' => 'tl',
                'position' => 3,
            ),
            14 => 
            array (
                'id' => 782,
                'client_id' => 78,
                'lang' => 'zh',
                'position' => 6,
            ),
            15 => 
            array (
                'id' => 783,
                'client_id' => 78,
                'lang' => 'pt',
                'position' => 5,
            ),
            16 => 
            array (
                'id' => 789,
                'client_id' => 1,
                'lang' => 'es',
                'position' => 6,
            ),
            17 => 
            array (
                'id' => 791,
                'client_id' => 79,
                'lang' => 'en',
                'position' => 2,
            ),
            18 => 
            array (
                'id' => 792,
                'client_id' => 79,
                'lang' => 'ko',
                'position' => 3,
            ),
            19 => 
            array (
                'id' => 793,
                'client_id' => 79,
                'lang' => 'zh',
                'position' => 4,
            ),
            20 => 
            array (
                'id' => 795,
                'client_id' => 2,
                'lang' => 'zh',
                'position' => 15,
            ),
            21 => 
            array (
                'id' => 796,
                'client_id' => 2,
                'lang' => 'tl',
                'position' => 16,
            ),
            22 => 
            array (
                'id' => 798,
                'client_id' => 70,
                'lang' => 'ja',
                'position' => 1,
            ),
            23 => 
            array (
                'id' => 799,
                'client_id' => 70,
                'lang' => 'ko',
                'position' => 2,
            ),
            24 => 
            array (
                'id' => 800,
                'client_id' => 70,
                'lang' => 'zh',
                'position' => 3,
            ),
            25 => 
            array (
                'id' => 801,
                'client_id' => 70,
                'lang' => 'es',
                'position' => 4,
            ),
            26 => 
            array (
                'id' => 802,
                'client_id' => 1,
                'lang' => 'en',
                'position' => 7,
            ),
            27 => 
            array (
                'id' => 803,
                'client_id' => 1,
                'lang' => 'ko',
                'position' => 9,
            ),
            28 => 
            array (
                'id' => 804,
                'client_id' => 182,
                'lang' => 'ja',
                'position' => 1,
            ),
            29 => 
            array (
                'id' => 805,
                'client_id' => 182,
                'lang' => 'en',
                'position' => 2,
            ),
            30 => 
            array (
                'id' => 806,
                'client_id' => 183,
                'lang' => 'ja',
                'position' => 1,
            ),
            31 => 
            array (
                'id' => 807,
                'client_id' => 184,
                'lang' => 'ja',
                'position' => 1,
            ),
            32 => 
            array (
                'id' => 808,
                'client_id' => 185,
                'lang' => 'ja',
                'position' => 2,
            ),
            33 => 
            array (
                'id' => 809,
                'client_id' => 186,
                'lang' => 'ja',
                'position' => 1,
            ),
            34 => 
            array (
                'id' => 812,
                'client_id' => 185,
                'lang' => 'tl',
                'position' => 4,
            ),
            35 => 
            array (
                'id' => 813,
                'client_id' => 187,
                'lang' => 'ja',
                'position' => 1,
            ),
            36 => 
            array (
                'id' => 814,
                'client_id' => 188,
                'lang' => 'ja',
                'position' => 1,
            ),
            37 => 
            array (
                'id' => 815,
                'client_id' => 189,
                'lang' => 'ja',
                'position' => 1,
            ),
            38 => 
            array (
                'id' => 816,
                'client_id' => 190,
                'lang' => 'ja',
                'position' => 1,
            ),
            39 => 
            array (
                'id' => 817,
                'client_id' => 191,
                'lang' => 'ja',
                'position' => 1,
            ),
            40 => 
            array (
                'id' => 818,
                'client_id' => 192,
                'lang' => 'ja',
                'position' => 1,
            ),
            41 => 
            array (
                'id' => 819,
                'client_id' => 193,
                'lang' => 'ja',
                'position' => 1,
            ),
            42 => 
            array (
                'id' => 820,
                'client_id' => 189,
                'lang' => 'en',
                'position' => 2,
            ),
            43 => 
            array (
                'id' => 821,
                'client_id' => 189,
                'lang' => 'ko',
                'position' => 3,
            ),
            44 => 
            array (
                'id' => 822,
                'client_id' => 190,
                'lang' => 'en',
                'position' => 2,
            ),
            45 => 
            array (
                'id' => 823,
                'client_id' => 190,
                'lang' => 'ko',
                'position' => 3,
            ),
            46 => 
            array (
                'id' => 824,
                'client_id' => 191,
                'lang' => 'en',
                'position' => 2,
            ),
            47 => 
            array (
                'id' => 825,
                'client_id' => 191,
                'lang' => 'ko',
                'position' => 3,
            ),
            48 => 
            array (
                'id' => 826,
                'client_id' => 187,
                'lang' => 'en',
                'position' => 2,
            ),
            49 => 
            array (
                'id' => 827,
                'client_id' => 187,
                'lang' => 'ko',
                'position' => 3,
            ),
            50 => 
            array (
                'id' => 828,
                'client_id' => 194,
                'lang' => 'ja',
                'position' => 1,
            ),
            51 => 
            array (
                'id' => 829,
                'client_id' => 194,
                'lang' => 'en',
                'position' => 2,
            ),
            52 => 
            array (
                'id' => 830,
                'client_id' => 194,
                'lang' => 'ko',
                'position' => 3,
            ),
            53 => 
            array (
                'id' => 831,
                'client_id' => 195,
                'lang' => 'ja',
                'position' => 1,
            ),
            54 => 
            array (
                'id' => 832,
                'client_id' => 195,
                'lang' => 'en',
                'position' => 2,
            ),
            55 => 
            array (
                'id' => 833,
                'client_id' => 195,
                'lang' => 'ko',
                'position' => 3,
            ),
            56 => 
            array (
                'id' => 834,
                'client_id' => 196,
                'lang' => 'ja',
                'position' => 1,
            ),
            57 => 
            array (
                'id' => 835,
                'client_id' => 196,
                'lang' => 'en',
                'position' => 2,
            ),
            58 => 
            array (
                'id' => 836,
                'client_id' => 196,
                'lang' => 'ko',
                'position' => 3,
            ),
            59 => 
            array (
                'id' => 837,
                'client_id' => 197,
                'lang' => 'ja',
                'position' => 1,
            ),
            60 => 
            array (
                'id' => 838,
                'client_id' => 197,
                'lang' => 'en',
                'position' => 2,
            ),
            61 => 
            array (
                'id' => 839,
                'client_id' => 197,
                'lang' => 'ko',
                'position' => 3,
            ),
            62 => 
            array (
                'id' => 840,
                'client_id' => 198,
                'lang' => 'ja',
                'position' => 1,
            ),
            63 => 
            array (
                'id' => 841,
                'client_id' => 198,
                'lang' => 'en',
                'position' => 2,
            ),
            64 => 
            array (
                'id' => 842,
                'client_id' => 198,
                'lang' => 'ko',
                'position' => 3,
            ),
            65 => 
            array (
                'id' => 843,
                'client_id' => 199,
                'lang' => 'ja',
                'position' => 1,
            ),
            66 => 
            array (
                'id' => 844,
                'client_id' => 199,
                'lang' => 'en',
                'position' => 2,
            ),
            67 => 
            array (
                'id' => 856,
                'client_id' => 205,
                'lang' => 'ja',
                'position' => 1,
            ),
            68 => 
            array (
                'id' => 857,
                'client_id' => 206,
                'lang' => 'ja',
                'position' => 1,
            ),
            69 => 
            array (
                'id' => 858,
                'client_id' => 207,
                'lang' => 'ja',
                'position' => 1,
            ),
            70 => 
            array (
                'id' => 859,
                'client_id' => 199,
                'lang' => 'ko',
                'position' => 3,
            ),
        ));
        
        
    }
}