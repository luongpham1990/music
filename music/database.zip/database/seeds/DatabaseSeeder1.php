<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(AccountSeeder::class);
        $this->call(DevelopmentInitialSeeder::class);
        $this->call(AccessSummariesTableSeeder::class);
        $this->call(AccountsTableSeeder::class);
        $this->call(AgreementsTableSeeder::class);
        $this->call(AnnouncementsTableSeeder::class);
        $this->call(AppSettingsTableSeeder::class);
        $this->call(AutoImportHistoriesTableSeeder::class);
        $this->call(AutoImportMessagesTableSeeder::class);
        $this->call(AutoImportsTableSeeder::class);
        $this->call(AutoImportStatusesTableSeeder::class);
        $this->call(AutoImportTriggersTableSeeder::class);
        $this->call(AutoNotificationsTableSeeder::class);
        $this->call(ClientLanguagesTableSeeder::class);
        $this->call(ClientsTableSeeder::class);
        $this->call(ClientSettingsTableSeeder::class);
        $this->call(ContentGroupsTableSeeder::class);
        $this->call(ContentsTableSeeder::class);
        $this->call(FileBodyStorageFilesTableSeeder::class);
        $this->call(FilesTableSeeder::class);
        $this->call(IconsTableSeeder::class);
        $this->call(LinksTableSeeder::class);
        $this->call(MapBodyStorageFilesTableSeeder::class);
        $this->call(MapDataColorsTableSeeder::class);
        $this->call(MapDataGroupsTableSeeder::class);
        $this->call(MapDatasTableSeeder::class);
        $this->call(MenusTableSeeder::class);
        $this->call(NotificationBodiesTableSeeder::class);
        $this->call(NotificationsTableSeeder::class);
        $this->call(NotificationTagTableSeeder::class);
        $this->call(NotificationUsersTableSeeder::class);
        $this->call(OperatorsTableSeeder::class);
        $this->call(PostBodyStorageFilesTableSeeder::class);
        $this->call(PostsTableSeeder::class);
        $this->call(PostSpeechesTableSeeder::class);
        $this->call(StorageFilesTableSeeder::class);
        $this->call(SubscribesTableSeeder::class);
        $this->call(TaggingsTableSeeder::class);
        $this->call(TagGroupsTableSeeder::class);
        $this->call(TagsTableSeeder::class);
        $this->call(ThumbnailsTableSeeder::class);
        $this->call(TranslationReplacementsTableSeeder::class);
        $this->call(TranslationReplacementTemplatesTableSeeder::class);
        $this->call(TranslationsTableSeeder::class);
        $this->call(TriggerTagsTableSeeder::class);
        $this->call(TutorialsTableSeeder::class);
        $this->call(UsersTableSeeder::class);
        $this->call(WeathersTableSeeder::class);
        $this->call(WeatherSpeechesTableSeeder::class);
        $this->call(WebsiteBodyStorageFilesTableSeeder::class);
        $this->call(WebsitesTableSeeder::class);
    }
}
