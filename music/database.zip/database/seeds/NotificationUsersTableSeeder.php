<?php

use Illuminate\Database\Seeder;

class NotificationUsersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('notification_users')->delete();
        
        \DB::table('notification_users')->insert(array (
            0 => 
            array (
                'id' => 1,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'created_at' => '2019-03-04 16:00:11',
                'updated_at' => '2019-03-04 16:00:11',
            ),
            1 => 
            array (
                'id' => 2,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'created_at' => '2019-03-04 16:08:36',
                'updated_at' => '2019-03-04 16:08:36',
            ),
            2 => 
            array (
                'id' => 3,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'created_at' => '2019-03-04 16:01:29',
                'updated_at' => '2019-03-04 16:01:29',
            ),
            3 => 
            array (
                'id' => 4,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'created_at' => '2019-03-04 16:03:03',
                'updated_at' => '2019-03-04 16:03:03',
            ),
            4 => 
            array (
                'id' => 5,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'created_at' => '2019-03-04 16:16:08',
                'updated_at' => '2019-03-04 16:16:08',
            ),
            5 => 
            array (
                'id' => 6,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380"]',
                'created_at' => '2019-03-04 16:16:55',
                'updated_at' => '2019-03-04 16:16:55',
            ),
            6 => 
            array (
                'id' => 7,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385"]',
                'created_at' => '2019-03-04 17:02:07',
                'updated_at' => '2019-03-04 17:02:07',
            ),
            7 => 
            array (
                'id' => 8,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385"]',
                'created_at' => '2019-03-04 17:03:06',
                'updated_at' => '2019-03-04 17:03:06',
            ),
            8 => 
            array (
                'id' => 9,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385"]',
                'created_at' => '2019-03-04 17:04:07',
                'updated_at' => '2019-03-04 17:04:07',
            ),
            9 => 
            array (
                'id' => 10,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'created_at' => '2019-03-04 17:12:10',
                'updated_at' => '2019-03-04 17:12:10',
            ),
            10 => 
            array (
                'id' => 11,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'created_at' => '2019-03-04 17:12:37',
                'updated_at' => '2019-03-04 17:12:37',
            ),
            11 => 
            array (
                'id' => 12,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'created_at' => '2019-03-04 17:13:02',
                'updated_at' => '2019-03-04 17:13:02',
            ),
            12 => 
            array (
                'id' => 13,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'created_at' => '2019-03-04 17:13:36',
                'updated_at' => '2019-03-04 17:13:36',
            ),
            13 => 
            array (
                'id' => 14,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'created_at' => '2019-03-04 17:14:10',
                'updated_at' => '2019-03-04 17:14:10',
            ),
            14 => 
            array (
                'id' => 15,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4"]',
                'created_at' => '2019-03-04 17:15:29',
                'updated_at' => '2019-03-04 17:15:29',
            ),
            15 => 
            array (
                'id' => 16,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:17:46',
                'updated_at' => '2019-03-04 17:17:46',
            ),
            16 => 
            array (
                'id' => 17,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:18:17',
                'updated_at' => '2019-03-04 17:18:17',
            ),
            17 => 
            array (
                'id' => 18,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:18:42',
                'updated_at' => '2019-03-04 17:18:42',
            ),
            18 => 
            array (
                'id' => 19,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:20:34',
                'updated_at' => '2019-03-04 17:20:34',
            ),
            19 => 
            array (
                'id' => 20,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:20:58',
                'updated_at' => '2019-03-04 17:20:58',
            ),
            20 => 
            array (
                'id' => 21,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:21:33',
                'updated_at' => '2019-03-04 17:21:33',
            ),
            21 => 
            array (
                'id' => 22,
                'notification_id' => 45,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abea9025-71dd-336c-a0a8-b10a17b8051b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4bbfa62e-e16c-32c1-9678-f2b3d2353844","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/78193a12-dbc2-3b29-8e49-8c9b53331222"]',
                'created_at' => '2019-03-04 17:45:05',
                'updated_at' => '2019-03-04 17:45:05',
            ),
            22 => 
            array (
                'id' => 23,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-04 17:45:06',
                'updated_at' => '2019-03-04 17:45:06',
            ),
            23 => 
            array (
                'id' => 24,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:02:40',
                'updated_at' => '2019-03-04 18:02:40',
            ),
            24 => 
            array (
                'id' => 25,
                'notification_id' => 45,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/abea9025-71dd-336c-a0a8-b10a17b8051b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4bbfa62e-e16c-32c1-9678-f2b3d2353844","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/78193a12-dbc2-3b29-8e49-8c9b53331222"]',
                'created_at' => '2019-03-04 18:03:13',
                'updated_at' => '2019-03-04 18:03:13',
            ),
            25 => 
            array (
                'id' => 26,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:03:14',
                'updated_at' => '2019-03-04 18:03:14',
            ),
            26 => 
            array (
                'id' => 27,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:04:16',
                'updated_at' => '2019-03-04 18:04:16',
            ),
            27 => 
            array (
                'id' => 28,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:05:21',
                'updated_at' => '2019-03-04 18:05:21',
            ),
            28 => 
            array (
                'id' => 29,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:06:45',
                'updated_at' => '2019-03-04 18:06:45',
            ),
            29 => 
            array (
                'id' => 30,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:08:08',
                'updated_at' => '2019-03-04 18:08:08',
            ),
            30 => 
            array (
                'id' => 31,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:08:46',
                'updated_at' => '2019-03-04 18:08:46',
            ),
            31 => 
            array (
                'id' => 32,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:09:26',
                'updated_at' => '2019-03-04 18:09:26',
            ),
            32 => 
            array (
                'id' => 33,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:13:04',
                'updated_at' => '2019-03-04 18:13:04',
            ),
            33 => 
            array (
                'id' => 34,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:14:05',
                'updated_at' => '2019-03-04 18:14:05',
            ),
            34 => 
            array (
                'id' => 35,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:14:38',
                'updated_at' => '2019-03-04 18:14:38',
            ),
            35 => 
            array (
                'id' => 36,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:15:54',
                'updated_at' => '2019-03-04 18:15:54',
            ),
            36 => 
            array (
                'id' => 37,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:54:06',
                'updated_at' => '2019-03-04 18:54:06',
            ),
            37 => 
            array (
                'id' => 38,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 18:54:29',
                'updated_at' => '2019-03-04 18:54:29',
            ),
            38 => 
            array (
                'id' => 39,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 19:02:35',
                'updated_at' => '2019-03-04 19:02:35',
            ),
            39 => 
            array (
                'id' => 40,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-04 19:05:09',
                'updated_at' => '2019-03-04 19:05:09',
            ),
            40 => 
            array (
                'id' => 41,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-04 19:05:47',
                'updated_at' => '2019-03-04 19:05:47',
            ),
            41 => 
            array (
                'id' => 42,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-04 19:14:35',
                'updated_at' => '2019-03-04 19:14:35',
            ),
            42 => 
            array (
                'id' => 43,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-04 19:19:42',
                'updated_at' => '2019-03-04 19:19:42',
            ),
            43 => 
            array (
                'id' => 44,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-04 19:21:58',
                'updated_at' => '2019-03-04 19:21:58',
            ),
            44 => 
            array (
                'id' => 45,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-04 19:25:50',
                'updated_at' => '2019-03-04 19:25:50',
            ),
            45 => 
            array (
                'id' => 46,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-04 19:31:14',
                'updated_at' => '2019-03-04 19:31:14',
            ),
            46 => 
            array (
                'id' => 47,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-04 19:36:21',
                'updated_at' => '2019-03-04 19:36:21',
            ),
            47 => 
            array (
                'id' => 48,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 10:56:18',
                'updated_at' => '2019-03-05 10:56:18',
            ),
            48 => 
            array (
                'id' => 49,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 10:59:49',
                'updated_at' => '2019-03-05 10:59:49',
            ),
            49 => 
            array (
                'id' => 50,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 11:33:39',
                'updated_at' => '2019-03-05 11:33:39',
            ),
            50 => 
            array (
                'id' => 51,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 11:48:52',
                'updated_at' => '2019-03-05 11:48:52',
            ),
            51 => 
            array (
                'id' => 52,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 12:56:17',
                'updated_at' => '2019-03-05 12:56:17',
            ),
            52 => 
            array (
                'id' => 53,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 12:56:23',
                'updated_at' => '2019-03-05 12:56:23',
            ),
            53 => 
            array (
                'id' => 54,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-05 12:56:25',
                'updated_at' => '2019-03-05 12:56:25',
            ),
            54 => 
            array (
                'id' => 55,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 13:14:14',
                'updated_at' => '2019-03-05 13:14:14',
            ),
            55 => 
            array (
                'id' => 56,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 13:14:20',
                'updated_at' => '2019-03-05 13:14:20',
            ),
            56 => 
            array (
                'id' => 57,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c99125f3-b1ea-380b-b7a7-9034b113e687","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-05 13:14:21',
                'updated_at' => '2019-03-05 13:14:21',
            ),
            57 => 
            array (
                'id' => 58,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 15:08:58',
                'updated_at' => '2019-03-05 15:08:58',
            ),
            58 => 
            array (
                'id' => 59,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 15:09:03',
                'updated_at' => '2019-03-05 15:09:03',
            ),
            59 => 
            array (
                'id' => 60,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-05 15:09:05',
                'updated_at' => '2019-03-05 15:09:05',
            ),
            60 => 
            array (
                'id' => 61,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 15:16:25',
                'updated_at' => '2019-03-05 15:16:25',
            ),
            61 => 
            array (
                'id' => 62,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eb39ac6a-4302-3d4a-bb46-ed8f6701b9b0"]',
                'created_at' => '2019-03-05 15:16:30',
                'updated_at' => '2019-03-05 15:16:30',
            ),
            62 => 
            array (
                'id' => 63,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec"]',
                'created_at' => '2019-03-05 17:34:35',
                'updated_at' => '2019-03-05 17:34:35',
            ),
            63 => 
            array (
                'id' => 64,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:30:35',
                'updated_at' => '2019-03-06 15:30:35',
            ),
            64 => 
            array (
                'id' => 65,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:32:15',
                'updated_at' => '2019-03-06 15:32:15',
            ),
            65 => 
            array (
                'id' => 66,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:35:17',
                'updated_at' => '2019-03-06 15:35:17',
            ),
            66 => 
            array (
                'id' => 67,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:37:30',
                'updated_at' => '2019-03-06 15:37:30',
            ),
            67 => 
            array (
                'id' => 68,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:42:20',
                'updated_at' => '2019-03-06 15:42:20',
            ),
            68 => 
            array (
                'id' => 69,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:44:05',
                'updated_at' => '2019-03-06 15:44:05',
            ),
            69 => 
            array (
                'id' => 70,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:44:12',
                'updated_at' => '2019-03-06 15:44:12',
            ),
            70 => 
            array (
                'id' => 71,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-06 15:44:15',
                'updated_at' => '2019-03-06 15:44:15',
            ),
            71 => 
            array (
                'id' => 72,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:45:15',
                'updated_at' => '2019-03-06 15:45:15',
            ),
            72 => 
            array (
                'id' => 73,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:45:22',
                'updated_at' => '2019-03-06 15:45:22',
            ),
            73 => 
            array (
                'id' => 74,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-06 15:45:25',
                'updated_at' => '2019-03-06 15:45:25',
            ),
            74 => 
            array (
                'id' => 75,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:46:43',
                'updated_at' => '2019-03-06 15:46:43',
            ),
            75 => 
            array (
                'id' => 76,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:46:50',
                'updated_at' => '2019-03-06 15:46:50',
            ),
            76 => 
            array (
                'id' => 77,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-06 15:46:53',
                'updated_at' => '2019-03-06 15:46:53',
            ),
            77 => 
            array (
                'id' => 78,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:48:02',
                'updated_at' => '2019-03-06 15:48:02',
            ),
            78 => 
            array (
                'id' => 79,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:48:09',
                'updated_at' => '2019-03-06 15:48:09',
            ),
            79 => 
            array (
                'id' => 80,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128"]',
                'created_at' => '2019-03-06 15:48:12',
                'updated_at' => '2019-03-06 15:48:12',
            ),
            80 => 
            array (
                'id' => 81,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:48:57',
                'updated_at' => '2019-03-06 15:48:57',
            ),
            81 => 
            array (
                'id' => 82,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:49:02',
                'updated_at' => '2019-03-06 15:49:02',
            ),
            82 => 
            array (
                'id' => 83,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:49:04',
                'updated_at' => '2019-03-06 15:49:04',
            ),
            83 => 
            array (
                'id' => 84,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:51:41',
                'updated_at' => '2019-03-06 15:51:41',
            ),
            84 => 
            array (
                'id' => 85,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:51:46',
                'updated_at' => '2019-03-06 15:51:46',
            ),
            85 => 
            array (
                'id' => 86,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:51:48',
                'updated_at' => '2019-03-06 15:51:48',
            ),
            86 => 
            array (
                'id' => 87,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:52:52',
                'updated_at' => '2019-03-06 15:52:52',
            ),
            87 => 
            array (
                'id' => 88,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:52:57',
                'updated_at' => '2019-03-06 15:52:57',
            ),
            88 => 
            array (
                'id' => 89,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:52:59',
                'updated_at' => '2019-03-06 15:52:59',
            ),
            89 => 
            array (
                'id' => 90,
                'notification_id' => 50,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:54:22',
                'updated_at' => '2019-03-06 15:54:22',
            ),
            90 => 
            array (
                'id' => 91,
                'notification_id' => 51,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f5cf9ec4-820a-30ac-8ce8-b5ab61b80471","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/8063b6b6-06c9-3d36-9de5-30aa995a1cbe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/fcb67b7a-c7eb-37eb-a1f0-63fbe61dacdc","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/28749e7c-58f6-3754-b365-2558c3e1b380","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/d94baa49-3cae-3267-a263-7c46aa152385","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/51e56934-bb15-3478-8ced-de97ea5920c4","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/893d7685-d51b-359f-a3d3-2ea546188bec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:54:28',
                'updated_at' => '2019-03-06 15:54:28',
            ),
            91 => 
            array (
                'id' => 92,
                'notification_id' => 52,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ec48e015-9828-3f16-ae38-cd4cf31d1128","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/02498231-62f0-300e-8423-5e044ea3aef4"]',
                'created_at' => '2019-03-06 15:54:30',
                'updated_at' => '2019-03-06 15:54:30',
            ),
            92 => 
            array (
                'id' => 93,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16"]',
                'created_at' => '2019-03-12 12:33:56',
                'updated_at' => '2019-03-12 12:33:56',
            ),
            93 => 
            array (
                'id' => 94,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a"]',
                'created_at' => '2019-03-12 12:39:36',
                'updated_at' => '2019-03-12 12:39:36',
            ),
            94 => 
            array (
                'id' => 95,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:13:43',
                'updated_at' => '2019-03-12 13:13:43',
            ),
            95 => 
            array (
                'id' => 96,
                'notification_id' => 62,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:13:46',
                'updated_at' => '2019-03-12 13:13:46',
            ),
            96 => 
            array (
                'id' => 97,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:24:07',
                'updated_at' => '2019-03-12 13:24:07',
            ),
            97 => 
            array (
                'id' => 98,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:26:21',
                'updated_at' => '2019-03-12 13:26:21',
            ),
            98 => 
            array (
                'id' => 99,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:28:10',
                'updated_at' => '2019-03-12 13:28:10',
            ),
            99 => 
            array (
                'id' => 100,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:28:47',
                'updated_at' => '2019-03-12 13:28:47',
            ),
            100 => 
            array (
                'id' => 101,
                'notification_id' => 61,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7"]',
                'created_at' => '2019-03-12 13:38:14',
                'updated_at' => '2019-03-12 13:38:14',
            ),
            101 => 
            array (
                'id' => 102,
                'notification_id' => 63,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886"]',
                'created_at' => '2019-03-13 13:06:31',
                'updated_at' => '2019-03-13 13:06:31',
            ),
            102 => 
            array (
                'id' => 103,
                'notification_id' => 64,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886"]',
                'created_at' => '2019-03-13 13:06:34',
                'updated_at' => '2019-03-13 13:06:34',
            ),
            103 => 
            array (
                'id' => 104,
                'notification_id' => 65,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886"]',
                'created_at' => '2019-03-13 13:06:37',
                'updated_at' => '2019-03-13 13:06:37',
            ),
            104 => 
            array (
                'id' => 105,
                'notification_id' => 67,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'created_at' => '2019-03-13 13:06:39',
                'updated_at' => '2019-03-13 13:06:39',
            ),
            105 => 
            array (
                'id' => 106,
                'notification_id' => 68,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'created_at' => '2019-03-13 13:06:41',
                'updated_at' => '2019-03-13 13:06:41',
            ),
            106 => 
            array (
                'id' => 107,
                'notification_id' => 67,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'created_at' => '2019-03-13 13:08:31',
                'updated_at' => '2019-03-13 13:08:31',
            ),
            107 => 
            array (
                'id' => 108,
                'notification_id' => 68,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0"]',
                'created_at' => '2019-03-13 13:08:33',
                'updated_at' => '2019-03-13 13:08:33',
            ),
            108 => 
            array (
                'id' => 109,
                'notification_id' => 69,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5"]',
                'created_at' => '2019-03-13 13:42:50',
                'updated_at' => '2019-03-13 13:42:50',
            ),
            109 => 
            array (
                'id' => 110,
                'notification_id' => 69,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5"]',
                'created_at' => '2019-03-13 13:45:59',
                'updated_at' => '2019-03-13 13:45:59',
            ),
            110 => 
            array (
                'id' => 111,
                'notification_id' => 69,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5"]',
                'created_at' => '2019-03-13 13:47:19',
                'updated_at' => '2019-03-13 13:47:19',
            ),
            111 => 
            array (
                'id' => 112,
                'notification_id' => 71,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-19 18:30:33',
                'updated_at' => '2019-03-19 18:30:33',
            ),
            112 => 
            array (
                'id' => 113,
                'notification_id' => 72,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/02eedfa9-0681-33aa-b00b-7377119aa387"]',
                'created_at' => '2019-03-19 18:30:41',
                'updated_at' => '2019-03-19 18:30:41',
            ),
            113 => 
            array (
                'id' => 114,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-19 18:30:50',
                'updated_at' => '2019-03-19 18:30:50',
            ),
            114 => 
            array (
                'id' => 115,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-19 18:35:01',
                'updated_at' => '2019-03-19 18:35:01',
            ),
            115 => 
            array (
                'id' => 116,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-19 18:36:23',
                'updated_at' => '2019-03-19 18:36:23',
            ),
            116 => 
            array (
                'id' => 117,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-19 18:40:24',
                'updated_at' => '2019-03-19 18:40:24',
            ),
            117 => 
            array (
                'id' => 118,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-19 18:47:22',
                'updated_at' => '2019-03-19 18:47:22',
            ),
            118 => 
            array (
                'id' => 119,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ac211b1e-5b73-31a8-954c-aaa38784ad0d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-20 10:52:27',
                'updated_at' => '2019-03-20 10:52:27',
            ),
            119 => 
            array (
                'id' => 120,
                'notification_id' => 72,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ac211b1e-5b73-31a8-954c-aaa38784ad0d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/02eedfa9-0681-33aa-b00b-7377119aa387"]',
                'created_at' => '2019-03-20 10:58:39',
                'updated_at' => '2019-03-20 10:58:39',
            ),
            120 => 
            array (
                'id' => 121,
                'notification_id' => 73,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/87ed9a2f-b7a9-381b-aac6-19fc7fb8ad57","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/410fd2d0-aee0-354e-b91b-8fc0a7e93fe6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0a53af53-2802-3e74-8cac-0d65f7dc4271","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/f3998d89-9bd8-3cb8-802d-44d2dab073ae","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ac211b1e-5b73-31a8-954c-aaa38784ad0d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/3338b9dd-bc7c-332b-8114-f3b73e8ce730","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/089dc3e5-bee6-3385-aa0c-687bd93c34fb"]',
                'created_at' => '2019-03-20 10:58:48',
                'updated_at' => '2019-03-20 10:58:48',
            ),
            121 => 
            array (
                'id' => 122,
                'notification_id' => 86,
                'notified_users' => '[357,359,372,377,390,391,395,361,355,388,389]',
                'created_at' => '2019-03-28 16:03:00',
                'updated_at' => '2019-03-28 16:03:00',
            ),
            122 => 
            array (
                'id' => 123,
                'notification_id' => 86,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cc7375b7-db2f-3cc3-8dd5-9f9108480db8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b45f9a81-6486-3be3-a127-b89082bbc7dd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b05abef6-57e5-3ab0-9269-a9b71467b367","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/da81b261-4204-3c7b-8a60-d72bf83b1391","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/f04984b3-d026-3ba0-a2d7-58a360faa65e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6e7b765c-b099-31d5-8477-20b06476a2ac","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/cecaaa52-6370-31ba-baf5-4f137f4f5af6","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2a369bfe-2518-37d3-afd2-ae325b316d38","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/3d215c98-74df-32d9-bf2d-fb0376fa8878","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/22a1f127-136e-325d-b1ed-721857c806bd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bcdd12ca-5e07-3d67-87e2-0645a413fe6c","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/2cdeb7d3-e8ca-3e24-9835-c3634fde18c3"]',
                'created_at' => '2019-03-28 16:27:02',
                'updated_at' => '2019-03-28 16:27:02',
            ),
            123 => 
            array (
                'id' => 124,
                'notification_id' => 82,
                'notified_users' => '[357,359,361,372,377,390,391,395,397,355,388,389]',
                'created_at' => '2019-03-29 16:45:07',
                'updated_at' => '2019-03-29 16:45:07',
            ),
            124 => 
            array (
                'id' => 125,
                'notification_id' => 75,
                'notified_users' => '[361,357,416]',
                'created_at' => '2019-04-02 13:28:09',
                'updated_at' => '2019-04-02 13:28:09',
            ),
            125 => 
            array (
                'id' => 126,
                'notification_id' => 87,
                'notified_users' => '[]',
                'created_at' => '2019-04-02 13:28:11',
                'updated_at' => '2019-04-02 13:28:11',
            ),
            126 => 
            array (
                'id' => 127,
                'notification_id' => 88,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,418,361,355]',
                'created_at' => '2019-04-02 13:39:11',
                'updated_at' => '2019-04-02 13:39:11',
            ),
            127 => 
            array (
                'id' => 128,
                'notification_id' => 89,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,418,419,355,388,389]',
                'created_at' => '2019-04-02 13:44:13',
                'updated_at' => '2019-04-02 13:44:13',
            ),
            128 => 
            array (
                'id' => 129,
                'notification_id' => 90,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,418,419,361,355,388,389]',
                'created_at' => '2019-04-02 13:59:12',
                'updated_at' => '2019-04-02 13:59:12',
            ),
            129 => 
            array (
                'id' => 130,
                'notification_id' => 91,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,418,419,361,355,388,389]',
                'created_at' => '2019-04-02 13:59:21',
                'updated_at' => '2019-04-02 13:59:21',
            ),
            130 => 
            array (
                'id' => 131,
                'notification_id' => 92,
                'notified_users' => '[357,359,372,377,390,391,397,402,411,416,419,423,424,361,355]',
                'created_at' => '2019-04-02 18:23:14',
                'updated_at' => '2019-04-02 18:23:14',
            ),
            131 => 
            array (
                'id' => 132,
                'notification_id' => 93,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,424,436,437,355,388,389]',
                'created_at' => '2019-04-03 12:49:13',
                'updated_at' => '2019-04-03 12:49:13',
            ),
            132 => 
            array (
                'id' => 133,
                'notification_id' => 94,
                'notified_users' => '[355,357,388,389,411,419,436,437]',
                'created_at' => '2019-04-03 13:00:07',
                'updated_at' => '2019-04-03 13:00:07',
            ),
            133 => 
            array (
                'id' => 134,
                'notification_id' => 95,
                'notified_users' => '[355,357,388,389,411,419,436,437]',
                'created_at' => '2019-04-03 13:06:05',
                'updated_at' => '2019-04-03 13:06:05',
            ),
            134 => 
            array (
                'id' => 135,
                'notification_id' => 96,
                'notified_users' => '[355,357,388,389,411,419,436,437]',
                'created_at' => '2019-04-03 13:20:05',
                'updated_at' => '2019-04-03 13:20:05',
            ),
            135 => 
            array (
                'id' => 136,
                'notification_id' => 96,
                'notified_users' => '[355,357,388,389,411,419,437,438,439]',
                'created_at' => '2019-04-03 13:41:05',
                'updated_at' => '2019-04-03 13:41:05',
            ),
            136 => 
            array (
                'id' => 137,
                'notification_id' => 102,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,424,443,444,446,447,361]',
                'created_at' => '2019-04-03 16:09:13',
                'updated_at' => '2019-04-03 16:09:13',
            ),
            137 => 
            array (
                'id' => 138,
                'notification_id' => 103,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,424,443,444,446,447,361]',
                'created_at' => '2019-04-03 16:12:11',
                'updated_at' => '2019-04-03 16:12:11',
            ),
            138 => 
            array (
                'id' => 139,
                'notification_id' => 104,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,444,446,447]',
                'created_at' => '2019-04-03 16:36:08',
                'updated_at' => '2019-04-03 16:36:08',
            ),
            139 => 
            array (
                'id' => 140,
                'notification_id' => 105,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 17:01:10',
                'updated_at' => '2019-04-03 17:01:10',
            ),
            140 => 
            array (
                'id' => 141,
                'notification_id' => 106,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 17:36:17',
                'updated_at' => '2019-04-03 17:36:17',
            ),
            141 => 
            array (
                'id' => 142,
                'notification_id' => 107,
                'notified_users' => '[355,357,388,389,411,419,438,444,448]',
                'created_at' => '2019-04-03 17:44:07',
                'updated_at' => '2019-04-03 17:44:07',
            ),
            142 => 
            array (
                'id' => 143,
                'notification_id' => 108,
                'notified_users' => '[355,357,388,389,411,419,438,444,448]',
                'created_at' => '2019-04-03 17:47:07',
                'updated_at' => '2019-04-03 17:47:07',
            ),
            143 => 
            array (
                'id' => 144,
                'notification_id' => 109,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,444,446,447,449,355,388,389,438,448]',
                'created_at' => '2019-04-03 18:04:12',
                'updated_at' => '2019-04-03 18:04:12',
            ),
            144 => 
            array (
                'id' => 145,
                'notification_id' => 110,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 18:10:10',
                'updated_at' => '2019-04-03 18:10:10',
            ),
            145 => 
            array (
                'id' => 146,
                'notification_id' => 111,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-03 18:12:08',
                'updated_at' => '2019-04-03 18:12:08',
            ),
            146 => 
            array (
                'id' => 147,
                'notification_id' => 112,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-03 18:12:14',
                'updated_at' => '2019-04-03 18:12:14',
            ),
            147 => 
            array (
                'id' => 148,
                'notification_id' => 113,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,444,446,447,449,355,388,389,438,448]',
                'created_at' => '2019-04-03 18:12:18',
                'updated_at' => '2019-04-03 18:12:18',
            ),
            148 => 
            array (
                'id' => 149,
                'notification_id' => 114,
                'notified_users' => '[355,357,388,389,411,419,438,444,448,359,372,377,423,449]',
                'created_at' => '2019-04-03 18:15:07',
                'updated_at' => '2019-04-03 18:15:07',
            ),
            149 => 
            array (
                'id' => 150,
                'notification_id' => 115,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-03 18:20:10',
                'updated_at' => '2019-04-03 18:20:10',
            ),
            150 => 
            array (
                'id' => 151,
                'notification_id' => 116,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 18:33:09',
                'updated_at' => '2019-04-03 18:33:09',
            ),
            151 => 
            array (
                'id' => 152,
                'notification_id' => 117,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 18:40:12',
                'updated_at' => '2019-04-03 18:40:12',
            ),
            152 => 
            array (
                'id' => 153,
                'notification_id' => 117,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 18:50:23',
                'updated_at' => '2019-04-03 18:50:23',
            ),
            153 => 
            array (
                'id' => 154,
                'notification_id' => 117,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,361,447]',
                'created_at' => '2019-04-03 18:54:10',
                'updated_at' => '2019-04-03 18:54:10',
            ),
            154 => 
            array (
                'id' => 155,
                'notification_id' => 118,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,444,446,449,450,361,447]',
                'created_at' => '2019-04-03 18:56:10',
                'updated_at' => '2019-04-03 18:56:10',
            ),
            155 => 
            array (
                'id' => 156,
                'notification_id' => 105,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,361,447,454]',
                'created_at' => '2019-04-04 11:19:10',
                'updated_at' => '2019-04-04 11:19:10',
            ),
            156 => 
            array (
                'id' => 157,
                'notification_id' => 115,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,361,447,454,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:20:15',
                'updated_at' => '2019-04-04 11:20:15',
            ),
            157 => 
            array (
                'id' => 158,
                'notification_id' => 119,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,455,361,447,454,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:26:15',
                'updated_at' => '2019-04-04 11:26:15',
            ),
            158 => 
            array (
                'id' => 159,
                'notification_id' => 119,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,455,459,361,447,454,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:30:14',
                'updated_at' => '2019-04-04 11:30:14',
            ),
            159 => 
            array (
                'id' => 160,
                'notification_id' => 71,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:36:16',
                'updated_at' => '2019-04-04 11:36:16',
            ),
            160 => 
            array (
                'id' => 161,
                'notification_id' => 120,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:37:09',
                'updated_at' => '2019-04-04 11:37:09',
            ),
            161 => 
            array (
                'id' => 162,
                'notification_id' => 121,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:38:09',
                'updated_at' => '2019-04-04 11:38:09',
            ),
            162 => 
            array (
                'id' => 163,
                'notification_id' => 122,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:38:15',
                'updated_at' => '2019-04-04 11:38:15',
            ),
            163 => 
            array (
                'id' => 164,
                'notification_id' => 123,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,455,459,361,447,355,388,389,438,448]',
                'created_at' => '2019-04-04 11:39:09',
                'updated_at' => '2019-04-04 11:39:09',
            ),
            164 => 
            array (
                'id' => 165,
                'notification_id' => 124,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,464,361,447]',
                'created_at' => '2019-04-04 11:49:09',
                'updated_at' => '2019-04-04 11:49:09',
            ),
            165 => 
            array (
                'id' => 166,
                'notification_id' => 125,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'created_at' => '2019-04-04 11:50:06',
                'updated_at' => '2019-04-04 11:50:06',
            ),
            166 => 
            array (
                'id' => 167,
                'notification_id' => 126,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'created_at' => '2019-04-04 11:50:08',
                'updated_at' => '2019-04-04 11:50:08',
            ),
            167 => 
            array (
                'id' => 168,
                'notification_id' => 127,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'created_at' => '2019-04-04 11:58:07',
                'updated_at' => '2019-04-04 11:58:07',
            ),
            168 => 
            array (
                'id' => 169,
                'notification_id' => 128,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'created_at' => '2019-04-04 12:02:07',
                'updated_at' => '2019-04-04 12:02:07',
            ),
            169 => 
            array (
                'id' => 170,
                'notification_id' => 129,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'created_at' => '2019-04-04 12:34:06',
                'updated_at' => '2019-04-04 12:34:06',
            ),
            170 => 
            array (
                'id' => 171,
                'notification_id' => 130,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465]',
                'created_at' => '2019-04-04 12:36:06',
                'updated_at' => '2019-04-04 12:36:06',
            ),
            171 => 
            array (
                'id' => 172,
                'notification_id' => 131,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'created_at' => '2019-04-04 12:39:05',
                'updated_at' => '2019-04-04 12:39:05',
            ),
            172 => 
            array (
                'id' => 173,
                'notification_id' => 132,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'created_at' => '2019-04-04 13:07:06',
                'updated_at' => '2019-04-04 13:07:06',
            ),
            173 => 
            array (
                'id' => 174,
                'notification_id' => 133,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'created_at' => '2019-04-04 13:08:05',
                'updated_at' => '2019-04-04 13:08:05',
            ),
            174 => 
            array (
                'id' => 175,
                'notification_id' => 134,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'created_at' => '2019-04-04 13:10:08',
                'updated_at' => '2019-04-04 13:10:08',
            ),
            175 => 
            array (
                'id' => 176,
                'notification_id' => 135,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'created_at' => '2019-04-04 13:12:08',
                'updated_at' => '2019-04-04 13:12:08',
            ),
            176 => 
            array (
                'id' => 177,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,464,465,466]',
                'created_at' => '2019-04-04 13:18:08',
                'updated_at' => '2019-04-04 13:18:08',
            ),
            177 => 
            array (
                'id' => 178,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:19:14',
                'updated_at' => '2019-04-04 18:19:14',
            ),
            178 => 
            array (
                'id' => 179,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:19:26',
                'updated_at' => '2019-04-04 18:19:26',
            ),
            179 => 
            array (
                'id' => 180,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:22:15',
                'updated_at' => '2019-04-04 18:22:15',
            ),
            180 => 
            array (
                'id' => 181,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,469]',
                'created_at' => '2019-04-04 18:32:06',
                'updated_at' => '2019-04-04 18:32:06',
            ),
            181 => 
            array (
                'id' => 182,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:32:18',
                'updated_at' => '2019-04-04 18:32:18',
            ),
            182 => 
            array (
                'id' => 183,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:32:29',
                'updated_at' => '2019-04-04 18:32:29',
            ),
            183 => 
            array (
                'id' => 184,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:32:42',
                'updated_at' => '2019-04-04 18:32:42',
            ),
            184 => 
            array (
                'id' => 185,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,469]',
                'created_at' => '2019-04-04 18:34:05',
                'updated_at' => '2019-04-04 18:34:05',
            ),
            185 => 
            array (
                'id' => 186,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:34:18',
                'updated_at' => '2019-04-04 18:34:18',
            ),
            186 => 
            array (
                'id' => 187,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:34:31',
                'updated_at' => '2019-04-04 18:34:31',
            ),
            187 => 
            array (
                'id' => 188,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,469,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:34:43',
                'updated_at' => '2019-04-04 18:34:43',
            ),
            188 => 
            array (
                'id' => 189,
                'notification_id' => 128,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,470]',
                'created_at' => '2019-04-04 18:48:06',
                'updated_at' => '2019-04-04 18:48:06',
            ),
            189 => 
            array (
                'id' => 190,
                'notification_id' => 136,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,470]',
                'created_at' => '2019-04-04 18:48:08',
                'updated_at' => '2019-04-04 18:48:08',
            ),
            190 => 
            array (
                'id' => 191,
                'notification_id' => 137,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:50:18',
                'updated_at' => '2019-04-04 18:50:18',
            ),
            191 => 
            array (
                'id' => 192,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:50:31',
                'updated_at' => '2019-04-04 18:50:31',
            ),
            192 => 
            array (
                'id' => 193,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:50:44',
                'updated_at' => '2019-04-04 18:50:44',
            ),
            193 => 
            array (
                'id' => 194,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:52:18',
                'updated_at' => '2019-04-04 18:52:18',
            ),
            194 => 
            array (
                'id' => 195,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:52:30',
                'updated_at' => '2019-04-04 18:52:30',
            ),
            195 => 
            array (
                'id' => 196,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:52:43',
                'updated_at' => '2019-04-04 18:52:43',
            ),
            196 => 
            array (
                'id' => 197,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:58:18',
                'updated_at' => '2019-04-04 18:58:18',
            ),
            197 => 
            array (
                'id' => 198,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 18:58:31',
                'updated_at' => '2019-04-04 18:58:31',
            ),
            198 => 
            array (
                'id' => 199,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:01:18',
                'updated_at' => '2019-04-04 19:01:18',
            ),
            199 => 
            array (
                'id' => 200,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:01:30',
                'updated_at' => '2019-04-04 19:01:30',
            ),
            200 => 
            array (
                'id' => 201,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:02:16',
                'updated_at' => '2019-04-04 19:02:16',
            ),
            201 => 
            array (
                'id' => 202,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:02:29',
                'updated_at' => '2019-04-04 19:02:29',
            ),
            202 => 
            array (
                'id' => 203,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:06:15',
                'updated_at' => '2019-04-04 19:06:15',
            ),
            203 => 
            array (
                'id' => 204,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:06:28',
                'updated_at' => '2019-04-04 19:06:28',
            ),
            204 => 
            array (
                'id' => 205,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:06:40',
                'updated_at' => '2019-04-04 19:06:40',
            ),
            205 => 
            array (
                'id' => 206,
                'notification_id' => 138,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:12:19',
                'updated_at' => '2019-04-04 19:12:19',
            ),
            206 => 
            array (
                'id' => 207,
                'notification_id' => 139,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:12:31',
                'updated_at' => '2019-04-04 19:12:31',
            ),
            207 => 
            array (
                'id' => 208,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:12:44',
                'updated_at' => '2019-04-04 19:12:44',
            ),
            208 => 
            array (
                'id' => 209,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:12:57',
                'updated_at' => '2019-04-04 19:12:57',
            ),
            209 => 
            array (
                'id' => 210,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:13:10',
                'updated_at' => '2019-04-04 19:13:10',
            ),
            210 => 
            array (
                'id' => 211,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:19:16',
                'updated_at' => '2019-04-04 19:19:16',
            ),
            211 => 
            array (
                'id' => 212,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:19:29',
                'updated_at' => '2019-04-04 19:19:29',
            ),
            212 => 
            array (
                'id' => 213,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-04 19:19:41',
                'updated_at' => '2019-04-04 19:19:41',
            ),
            213 => 
            array (
                'id' => 214,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,470,361,447,465,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 10:53:16',
                'updated_at' => '2019-04-05 10:53:16',
            ),
            214 => 
            array (
                'id' => 215,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:03:17',
                'updated_at' => '2019-04-05 13:03:17',
            ),
            215 => 
            array (
                'id' => 216,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,361,447,465,477,478,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:03:31',
                'updated_at' => '2019-04-05 13:03:31',
            ),
            216 => 
            array (
                'id' => 217,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:03:44',
                'updated_at' => '2019-04-05 13:03:44',
            ),
            217 => 
            array (
                'id' => 218,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:03:57',
                'updated_at' => '2019-04-05 13:03:57',
            ),
            218 => 
            array (
                'id' => 219,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:05:17',
                'updated_at' => '2019-04-05 13:05:17',
            ),
            219 => 
            array (
                'id' => 220,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:05:30',
                'updated_at' => '2019-04-05 13:05:30',
            ),
            220 => 
            array (
                'id' => 221,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:05:43',
                'updated_at' => '2019-04-05 13:05:43',
            ),
            221 => 
            array (
                'id' => 222,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:07:16',
                'updated_at' => '2019-04-05 13:07:16',
            ),
            222 => 
            array (
                'id' => 223,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:07:29',
                'updated_at' => '2019-04-05 13:07:29',
            ),
            223 => 
            array (
                'id' => 224,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:07:43',
                'updated_at' => '2019-04-05 13:07:43',
            ),
            224 => 
            array (
                'id' => 225,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:09:17',
                'updated_at' => '2019-04-05 13:09:17',
            ),
            225 => 
            array (
                'id' => 226,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:09:30',
                'updated_at' => '2019-04-05 13:09:30',
            ),
            226 => 
            array (
                'id' => 227,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:09:43',
                'updated_at' => '2019-04-05 13:09:43',
            ),
            227 => 
            array (
                'id' => 228,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:11:16',
                'updated_at' => '2019-04-05 13:11:16',
            ),
            228 => 
            array (
                'id' => 229,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:11:30',
                'updated_at' => '2019-04-05 13:11:30',
            ),
            229 => 
            array (
                'id' => 230,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,477,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:11:43',
                'updated_at' => '2019-04-05 13:11:43',
            ),
            230 => 
            array (
                'id' => 231,
                'notification_id' => 140,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:43:19',
                'updated_at' => '2019-04-05 13:43:19',
            ),
            231 => 
            array (
                'id' => 232,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:43:35',
                'updated_at' => '2019-04-05 13:43:35',
            ),
            232 => 
            array (
                'id' => 233,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:43:49',
                'updated_at' => '2019-04-05 13:43:49',
            ),
            233 => 
            array (
                'id' => 234,
                'notification_id' => 146,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:43:57',
                'updated_at' => '2019-04-05 13:43:57',
            ),
            234 => 
            array (
                'id' => 235,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:50:19',
                'updated_at' => '2019-04-05 13:50:19',
            ),
            235 => 
            array (
                'id' => 236,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:50:33',
                'updated_at' => '2019-04-05 13:50:33',
            ),
            236 => 
            array (
                'id' => 237,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,478,361,447,465,476,477,480,481,355,388,389,438,448,468]',
                'created_at' => '2019-04-05 13:50:47',
                'updated_at' => '2019-04-05 13:50:47',
            ),
            237 => 
            array (
                'id' => 238,
                'notification_id' => 147,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,478,480,481]',
                'created_at' => '2019-04-05 13:50:49',
                'updated_at' => '2019-04-05 13:50:49',
            ),
            238 => 
            array (
                'id' => 239,
                'notification_id' => 141,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'created_at' => '2019-04-05 16:24:19',
                'updated_at' => '2019-04-05 16:24:19',
            ),
            239 => 
            array (
                'id' => 240,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'created_at' => '2019-04-05 16:24:34',
                'updated_at' => '2019-04-05 16:24:34',
            ),
            240 => 
            array (
                'id' => 241,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'created_at' => '2019-04-05 16:24:48',
                'updated_at' => '2019-04-05 16:24:48',
            ),
            241 => 
            array (
                'id' => 242,
                'notification_id' => 142,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'created_at' => '2019-04-05 16:32:18',
                'updated_at' => '2019-04-05 16:32:18',
            ),
            242 => 
            array (
                'id' => 243,
                'notification_id' => 143,
                'notified_users' => '[357,359,372,377,390,391,397,399,402,411,416,419,423,443,446,449,450,454,459,466,484,361,447,465,476,477,480,481,355,388,389,438,448,468,482]',
                'created_at' => '2019-04-05 16:32:32',
                'updated_at' => '2019-04-05 16:32:32',
            ),
            243 => 
            array (
                'id' => 244,
                'notification_id' => 148,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'created_at' => '2019-04-05 16:39:07',
                'updated_at' => '2019-04-05 16:39:07',
            ),
            244 => 
            array (
                'id' => 245,
                'notification_id' => 149,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'created_at' => '2019-04-05 16:39:11',
                'updated_at' => '2019-04-05 16:39:11',
            ),
            245 => 
            array (
                'id' => 246,
                'notification_id' => 150,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'created_at' => '2019-04-05 16:39:13',
                'updated_at' => '2019-04-05 16:39:13',
            ),
            246 => 
            array (
                'id' => 247,
                'notification_id' => 151,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'created_at' => '2019-04-05 16:41:05',
                'updated_at' => '2019-04-05 16:41:05',
            ),
            247 => 
            array (
                'id' => 248,
                'notification_id' => 152,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484]',
                'created_at' => '2019-04-05 16:41:07',
                'updated_at' => '2019-04-05 16:41:07',
            ),
            248 => 
            array (
                'id' => 249,
                'notification_id' => 153,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484,485,493]',
                'created_at' => '2019-04-05 20:13:21',
                'updated_at' => '2019-04-05 20:13:21',
            ),
            249 => 
            array (
                'id' => 250,
                'notification_id' => 154,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484,485,493]',
                'created_at' => '2019-04-05 20:15:14',
                'updated_at' => '2019-04-05 20:15:14',
            ),
            250 => 
            array (
                'id' => 251,
                'notification_id' => 155,
                'notified_users' => '[357,359,361,372,377,390,391,397,411,416,419,423,443,446,447,449,450,454,459,465,466,476,477,480,481,484,485,493]',
                'created_at' => '2019-04-05 20:18:07',
                'updated_at' => '2019-04-05 20:18:07',
            ),
            251 => 
            array (
                'id' => 252,
                'notification_id' => 156,
                'notified_users' => '[196,209,212,213,224,227,239,524,223,241,261,264]',
                'created_at' => '2019-04-10 13:46:07',
                'updated_at' => '2019-04-10 13:46:07',
            ),
            252 => 
            array (
                'id' => 253,
                'notification_id' => 157,
                'notified_users' => '[196,209,212,213,224,227,239,529,530,223,241,261,264]',
                'created_at' => '2019-04-10 15:16:10',
                'updated_at' => '2019-04-10 15:16:10',
            ),
            253 => 
            array (
                'id' => 254,
                'notification_id' => 158,
                'notified_users' => '[196,209,212,213,224,227,239,529,530,261,264]',
                'created_at' => '2019-04-10 15:24:08',
                'updated_at' => '2019-04-10 15:24:08',
            ),
            254 => 
            array (
                'id' => 255,
                'notification_id' => 159,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'created_at' => '2019-04-10 15:57:11',
                'updated_at' => '2019-04-10 15:57:11',
            ),
            255 => 
            array (
                'id' => 256,
                'notification_id' => 157,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,223,241,261,264]',
                'created_at' => '2019-04-10 15:58:09',
                'updated_at' => '2019-04-10 15:58:09',
            ),
            256 => 
            array (
                'id' => 257,
                'notification_id' => 158,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'created_at' => '2019-04-10 15:58:13',
                'updated_at' => '2019-04-10 15:58:13',
            ),
            257 => 
            array (
                'id' => 258,
                'notification_id' => 159,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'created_at' => '2019-04-10 15:58:19',
                'updated_at' => '2019-04-10 15:58:19',
            ),
            258 => 
            array (
                'id' => 259,
                'notification_id' => 160,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,223,241,261,264]',
                'created_at' => '2019-04-10 15:59:10',
                'updated_at' => '2019-04-10 15:59:10',
            ),
            259 => 
            array (
                'id' => 260,
                'notification_id' => 161,
                'notified_users' => '[196,209,212,213,224,227,239,530,531,533,261,264]',
                'created_at' => '2019-04-10 16:02:10',
                'updated_at' => '2019-04-10 16:02:10',
            ),
            260 => 
            array (
                'id' => 261,
                'notification_id' => 160,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a56d6a0f-1221-3e3a-b941-579b37d2b886","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/79180712-6e49-3df9-a44d-449e4ddf8ff5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'created_at' => '2019-04-16 13:26:13',
                'updated_at' => '2019-04-16 13:26:13',
            ),
            261 => 
            array (
                'id' => 262,
                'notification_id' => 161,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'created_at' => '2019-04-16 13:26:21',
                'updated_at' => '2019-04-16 13:26:21',
            ),
            262 => 
            array (
                'id' => 263,
                'notification_id' => 163,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 15:42:13',
                'updated_at' => '2019-04-16 15:42:13',
            ),
            263 => 
            array (
                'id' => 264,
                'notification_id' => 161,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'created_at' => '2019-04-16 15:44:11',
                'updated_at' => '2019-04-16 15:44:11',
            ),
            264 => 
            array (
                'id' => 265,
                'notification_id' => 163,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 15:44:20',
                'updated_at' => '2019-04-16 15:44:20',
            ),
            265 => 
            array (
                'id' => 266,
                'notification_id' => 164,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 15:46:13',
                'updated_at' => '2019-04-16 15:46:13',
            ),
            266 => 
            array (
                'id' => 267,
                'notification_id' => 165,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 16:03:12',
                'updated_at' => '2019-04-16 16:03:12',
            ),
            267 => 
            array (
                'id' => 268,
                'notification_id' => 166,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'created_at' => '2019-04-16 16:07:12',
                'updated_at' => '2019-04-16 16:07:12',
            ),
            268 => 
            array (
                'id' => 269,
                'notification_id' => 167,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 16:24:11',
                'updated_at' => '2019-04-16 16:24:11',
            ),
            269 => 
            array (
                'id' => 270,
                'notification_id' => 168,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 16:39:13',
                'updated_at' => '2019-04-16 16:39:13',
            ),
            270 => 
            array (
                'id' => 271,
                'notification_id' => 169,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 16:43:11',
                'updated_at' => '2019-04-16 16:43:11',
            ),
            271 => 
            array (
                'id' => 272,
                'notification_id' => 170,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 16:58:12',
                'updated_at' => '2019-04-16 16:58:12',
            ),
            272 => 
            array (
                'id' => 273,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b"]',
                'created_at' => '2019-04-16 17:22:12',
                'updated_at' => '2019-04-16 17:22:12',
            ),
            273 => 
            array (
                'id' => 274,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'created_at' => '2019-04-16 18:11:13',
                'updated_at' => '2019-04-16 18:11:13',
            ),
            274 => 
            array (
                'id' => 275,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e"]',
                'created_at' => '2019-04-19 19:20:15',
                'updated_at' => '2019-04-19 19:20:15',
            ),
            275 => 
            array (
                'id' => 276,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a"]',
                'created_at' => '2019-04-19 19:20:28',
                'updated_at' => '2019-04-19 19:20:28',
            ),
            276 => 
            array (
                'id' => 277,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208"]',
                'created_at' => '2019-04-22 17:31:16',
                'updated_at' => '2019-04-22 17:31:16',
            ),
            277 => 
            array (
                'id' => 278,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e"]',
                'created_at' => '2019-04-22 17:31:30',
                'updated_at' => '2019-04-22 17:31:30',
            ),
            278 => 
            array (
                'id' => 279,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208"]',
                'created_at' => '2019-04-22 17:32:16',
                'updated_at' => '2019-04-22 17:32:16',
            ),
            279 => 
            array (
                'id' => 280,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e"]',
                'created_at' => '2019-04-22 17:32:31',
                'updated_at' => '2019-04-22 17:32:31',
            ),
            280 => 
            array (
                'id' => 281,
                'notification_id' => 171,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208"]',
                'created_at' => '2019-04-22 17:39:17',
                'updated_at' => '2019-04-22 17:39:17',
            ),
            281 => 
            array (
                'id' => 282,
                'notification_id' => 172,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b834ec7b-145c-3edc-86c5-75afc9c69208","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e"]',
                'created_at' => '2019-04-22 17:39:32',
                'updated_at' => '2019-04-22 17:39:32',
            ),
            282 => 
            array (
                'id' => 283,
                'notification_id' => 174,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-04-26 15:34:25',
                'updated_at' => '2019-04-26 15:34:25',
            ),
            283 => 
            array (
                'id' => 284,
                'notification_id' => 177,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-04-26 15:58:26',
                'updated_at' => '2019-04-26 15:58:26',
            ),
            284 => 
            array (
                'id' => 285,
                'notification_id' => 178,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-04-26 16:05:27',
                'updated_at' => '2019-04-26 16:05:27',
            ),
            285 => 
            array (
                'id' => 286,
                'notification_id' => 180,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-04-26 17:58:17',
                'updated_at' => '2019-04-26 17:58:17',
            ),
            286 => 
            array (
                'id' => 287,
                'notification_id' => 181,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7"]',
                'created_at' => '2019-04-26 18:05:16',
                'updated_at' => '2019-04-26 18:05:16',
            ),
            287 => 
            array (
                'id' => 288,
                'notification_id' => 184,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7"]',
                'created_at' => '2019-04-26 18:41:13',
                'updated_at' => '2019-04-26 18:41:13',
            ),
            288 => 
            array (
                'id' => 289,
                'notification_id' => 186,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-04-26 19:09:24',
                'updated_at' => '2019-04-26 19:09:24',
            ),
            289 => 
            array (
                'id' => 290,
                'notification_id' => 188,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-05-02 12:05:28',
                'updated_at' => '2019-05-02 12:05:28',
            ),
            290 => 
            array (
                'id' => 291,
                'notification_id' => 189,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e2ed4223-2861-3091-afde-21fc76991e16","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bdaf56f3-18eb-387d-8f7a-545f53b2617d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/30475d6b-c056-33c4-9768-6174fce4f888","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/758adbb8-550c-3beb-b864-af322b336dd2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-05-02 13:20:27',
                'updated_at' => '2019-05-02 13:20:27',
            ),
            291 => 
            array (
                'id' => 292,
                'notification_id' => 192,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-05-02 15:08:15',
                'updated_at' => '2019-05-02 15:08:15',
            ),
            292 => 
            array (
                'id' => 293,
                'notification_id' => 191,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5"]',
                'created_at' => '2019-05-02 15:10:07',
                'updated_at' => '2019-05-02 15:10:07',
            ),
            293 => 
            array (
                'id' => 294,
                'notification_id' => 193,
                'notified_users' => '["arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ca9228fa-e49e-33af-b000-f873d506e86a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/927af441-f0b7-3461-b8e9-5f8dcd2283d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/b0bb2b68-2846-3023-88ce-4d6e3ea21b3f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/04e52c2c-8e68-32df-9002-bd797d204d1f","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/eeb24ed9-aaf8-37e7-aa73-c24ba597c7e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/40e238d2-7ae0-3b38-9edc-d4cd50d2f6d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a78a605e-495b-36ea-bd90-6ca49c65e19b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/de955e1d-f0d6-391a-b876-e9df4d140630","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/67b16ca3-80eb-30c3-90c9-eed5c1b25982","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/5a46a422-31f7-3ee5-a8e6-ee56ec0450d2","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/0fc5e1ed-7d51-363a-a67d-65345b823f0b","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/9620482f-2c4b-33e1-abda-255db6c808e0","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/ad0d9ec6-fc6d-3ccb-b2db-4a6be3d8681f","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/8198ad86-9533-37af-bf9d-1a9f9e88e1df","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/33007218-3164-3fc9-b8bf-bfeec5c8e1cd","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/39fbf9a5-4c05-36a6-ba42-c0b909081ff7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/bc890afb-8902-3495-914a-8038ffd21adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4fc57c61-14a6-3c22-923c-86f18391de1e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/1da3f9a9-5891-3b94-9f7c-b65b480bebf7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/98e6d91d-39cb-32fc-a8df-2885fc9e5f69","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c47d5958-b8ee-3602-b610-7e31a65d33f2","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/7ee57b64-33c4-3c78-a70b-c819fc65d6ce","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/252060fd-3f80-3a0b-96ef-49fbe3007adf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/a3c278ea-b73d-3e05-8436-698a70adb5bf","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/dbe531e6-22d8-3b65-9be1-8de6eb6b8bc1","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/50800c75-c9c3-360c-bf5f-5747b3052748","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c8e40544-f0e8-33cc-91f0-b864b113756d","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/79a7fef0-3f4b-351c-8c58-b074681b6fb8","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/81604f72-2791-3518-9de2-ee5b8b812e08","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/deade0f7-272e-3758-b71c-8f498279a0ec","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6919e777-0949-3014-b9f6-dfa5ada96a48","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/2c3a97c9-40e5-3eee-aa5e-c966c3fbe5d7","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4322a144-7f56-3607-bbd3-41885ce48165","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/e5896d56-1c0e-328d-bebe-d70b6dcab8c5","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/c31cbbf9-a177-3a59-abbc-511442669c3a","arn:aws:sns:us-east-1:046602778425:endpoint\\/GCM\\/Machiyell-Android-VNC\\/c9a9ec61-485c-35d3-8915-2ffca249977a","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4be5e243-e694-3e0e-b172-204b1a1f20fe","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/e5fdf8c9-2151-3b32-a4e2-16114bcf57ff","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/6bae2309-016f-32b0-82ef-a8ad9d613603","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/134a02ec-4517-304f-abd4-3dfbfda1979e","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/ea8bbe8f-f1b6-3dd5-ba63-6fdb9985e3db","arn:aws:sns:us-east-1:046602778425:endpoint\\/APNS_SANDBOX\\/Machiyell-iOS\\/4380af26-d20d-3600-8e92-b41069247b57"]',
                'created_at' => '2019-05-02 16:35:15',
                'updated_at' => '2019-05-02 16:35:15',
            ),
        ));
        
        
    }
}