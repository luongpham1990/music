<?php

use Illuminate\Database\Seeder;

class LinksTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('links')->delete();
        
        \DB::table('links')->insert(array (
            0 => 
            array (
                'id' => 1,
                'content_id' => 3,
                'lang' => 'en',
                'title' => 'hello',
                'link_url' => 'https://machiyell.test/ctrl/visor/content_group/1/content',
            ),
            1 => 
            array (
                'id' => 2,
                'content_id' => 91,
                'lang' => 'es',
                'title' => 'dsadsadgffgf',
                'link_url' => 'http://machiyell.test/ctrl/visor/content_group/5/content/form1',
            ),
            2 => 
            array (
                'id' => 11,
                'content_id' => 164,
                'lang' => 'en',
                'title' => 'test content file optional 11',
                'link_url' => 'https://xd.adobe.com/view/6515f767-9a93-4452-6dbc-d026dab206a8-1324/',
            ),
            3 => 
            array (
                'id' => 14,
                'content_id' => 174,
                'lang' => 'en',
                'title' => 'Tet Ky Hoi',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322823/Ti%E1%BB%87c-t%E1%BA%A5t-nien-m%E1%BB%ABng-Xuan-K%E1%BB%89-H%E1%BB%A3i-2019.html',
            ),
            4 => 
            array (
                'id' => 15,
                'content_id' => 180,
                'lang' => 'es',
                'title' => 'ja_title',
                'link_url' => 'https://stackoverflow.com/questions/3081021/how-to-get-the-center-of-a-polygon-in-google-maps-v3',
            ),
            5 => 
            array (
                'id' => 17,
                'content_id' => 286,
                'lang' => 'en',
                'title' => 'test link1',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322822/Du-l%E1%BB%8Bch-he-t%E1%BA%A1i-Da-N%E1%BA%B5ng-2018.html',
            ),
            6 => 
            array (
                'id' => 19,
                'content_id' => 301,
                'lang' => 'en',
                'title' => 'Link es',
                'link_url' => 'http://www.vinicorp.com.vn/news/detail/1506322822/Du-l%E1%BB%8Bch-he-t%E1%BA%A1i-Da-N%E1%BA%B5ng-2018.html',
            ),
            7 => 
            array (
                'id' => 23,
                'content_id' => 392,
                'lang' => 'ja',
                'title' => 'beee',
                'link_url' => 'http://vinigate.com.vn/pm/projects/visor-intl/issues',
            ),
            8 => 
            array (
                'id' => 26,
                'content_id' => 539,
                'lang' => 'ja',
                'title' => 'Title link ja',
                'link_url' => 'http://192.168.52.162/usr/vinicorp/menu/100/content_group/109/map_data_group/83D3C0A9-D4D0-4F2A-853F-18A8726C34F7__RO0HwnarZSuHOMNpmsXjRx26sS2tsvmz7sQEWGxKXyJLEszD20AHVVIzF6du4t6EVfz7JNCiTmRd3x9blmcxbeI7vji8dKEsoDoS',
            ),
        ));
        
        
    }
}