<?php

use Illuminate\Database\Seeder;

class TaggingsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('taggings')->delete();
        
        \DB::table('taggings')->insert(array (
            0 => 
            array (
                'tag_id' => 2,
                'content_id' => 85,
                'created_at' => '2019-01-11 20:04:10',
            ),
            1 => 
            array (
                'tag_id' => 1,
                'content_id' => 92,
                'created_at' => '2019-01-16 12:19:44',
            ),
            2 => 
            array (
                'tag_id' => 2,
                'content_id' => 93,
                'created_at' => '2019-01-29 10:14:53',
            ),
            3 => 
            array (
                'tag_id' => 16,
                'content_id' => 93,
                'created_at' => '2019-01-29 10:14:53',
            ),
            4 => 
            array (
                'tag_id' => 1,
                'content_id' => 98,
                'created_at' => '2019-01-29 13:02:22',
            ),
            5 => 
            array (
                'tag_id' => 2,
                'content_id' => 98,
                'created_at' => '2019-01-29 13:02:22',
            ),
            6 => 
            array (
                'tag_id' => 2,
                'content_id' => 102,
                'created_at' => '2019-01-29 13:38:20',
            ),
            7 => 
            array (
                'tag_id' => 17,
                'content_id' => 102,
                'created_at' => '2019-01-29 13:38:20',
            ),
            8 => 
            array (
                'tag_id' => 18,
                'content_id' => 102,
                'created_at' => '2019-01-29 13:38:20',
            ),
            9 => 
            array (
                'tag_id' => 1,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            10 => 
            array (
                'tag_id' => 2,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            11 => 
            array (
                'tag_id' => 7,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            12 => 
            array (
                'tag_id' => 17,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            13 => 
            array (
                'tag_id' => 18,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            14 => 
            array (
                'tag_id' => 19,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            15 => 
            array (
                'tag_id' => 20,
                'content_id' => 108,
                'created_at' => '2019-01-29 16:40:44',
            ),
            16 => 
            array (
                'tag_id' => 2,
                'content_id' => 116,
                'created_at' => '2019-01-30 10:41:36',
            ),
            17 => 
            array (
                'tag_id' => 5,
                'content_id' => 116,
                'created_at' => '2019-01-30 10:41:36',
            ),
            18 => 
            array (
                'tag_id' => 1,
                'content_id' => 117,
                'created_at' => '2019-01-30 10:43:55',
            ),
            19 => 
            array (
                'tag_id' => 2,
                'content_id' => 117,
                'created_at' => '2019-01-30 10:43:55',
            ),
            20 => 
            array (
                'tag_id' => 18,
                'content_id' => 117,
                'created_at' => '2019-01-30 10:43:55',
            ),
            21 => 
            array (
                'tag_id' => 20,
                'content_id' => 117,
                'created_at' => '2019-01-30 10:43:55',
            ),
            22 => 
            array (
                'tag_id' => 1,
                'content_id' => 119,
                'created_at' => '2019-01-30 11:10:10',
            ),
            23 => 
            array (
                'tag_id' => 7,
                'content_id' => 119,
                'created_at' => '2019-01-30 11:10:10',
            ),
            24 => 
            array (
                'tag_id' => 16,
                'content_id' => 119,
                'created_at' => '2019-01-30 11:10:10',
            ),
            25 => 
            array (
                'tag_id' => 17,
                'content_id' => 119,
                'created_at' => '2019-01-30 11:10:10',
            ),
            26 => 
            array (
                'tag_id' => 1,
                'content_id' => 120,
                'created_at' => '2019-01-30 11:17:47',
            ),
            27 => 
            array (
                'tag_id' => 6,
                'content_id' => 120,
                'created_at' => '2019-01-30 11:17:47',
            ),
            28 => 
            array (
                'tag_id' => 18,
                'content_id' => 120,
                'created_at' => '2019-01-30 11:17:47',
            ),
            29 => 
            array (
                'tag_id' => 19,
                'content_id' => 120,
                'created_at' => '2019-01-30 11:17:47',
            ),
            30 => 
            array (
                'tag_id' => 1,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            31 => 
            array (
                'tag_id' => 2,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            32 => 
            array (
                'tag_id' => 5,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            33 => 
            array (
                'tag_id' => 13,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            34 => 
            array (
                'tag_id' => 14,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            35 => 
            array (
                'tag_id' => 16,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            36 => 
            array (
                'tag_id' => 18,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            37 => 
            array (
                'tag_id' => 20,
                'content_id' => 126,
                'created_at' => '2019-01-30 15:32:55',
            ),
            38 => 
            array (
                'tag_id' => 34,
                'content_id' => 170,
                'created_at' => '2019-02-13 13:02:48',
            ),
            39 => 
            array (
                'tag_id' => 33,
                'content_id' => 170,
                'created_at' => '2019-02-13 13:02:48',
            ),
            40 => 
            array (
                'tag_id' => 32,
                'content_id' => 170,
                'created_at' => '2019-02-13 13:02:48',
            ),
            41 => 
            array (
                'tag_id' => 31,
                'content_id' => 170,
                'created_at' => '2019-02-13 13:02:48',
            ),
            42 => 
            array (
                'tag_id' => 34,
                'content_id' => 172,
                'created_at' => '2019-02-13 13:34:09',
            ),
            43 => 
            array (
                'tag_id' => 33,
                'content_id' => 172,
                'created_at' => '2019-02-13 13:34:09',
            ),
            44 => 
            array (
                'tag_id' => 34,
                'content_id' => 182,
                'created_at' => '2019-02-13 19:14:53',
            ),
            45 => 
            array (
                'tag_id' => 34,
                'content_id' => 184,
                'created_at' => '2019-02-13 19:19:23',
            ),
            46 => 
            array (
                'tag_id' => 34,
                'content_id' => 185,
                'created_at' => '2019-02-13 19:35:53',
            ),
            47 => 
            array (
                'tag_id' => 34,
                'content_id' => 186,
                'created_at' => '2019-02-14 11:27:39',
            ),
            48 => 
            array (
                'tag_id' => 33,
                'content_id' => 186,
                'created_at' => '2019-02-14 11:27:39',
            ),
            49 => 
            array (
                'tag_id' => 32,
                'content_id' => 186,
                'created_at' => '2019-02-14 11:27:39',
            ),
            50 => 
            array (
                'tag_id' => 31,
                'content_id' => 186,
                'created_at' => '2019-02-14 11:27:39',
            ),
            51 => 
            array (
                'tag_id' => 33,
                'content_id' => 187,
                'created_at' => '2019-02-14 11:32:20',
            ),
            52 => 
            array (
                'tag_id' => 64,
                'content_id' => 514,
                'created_at' => '2019-04-10 13:27:37',
            ),
            53 => 
            array (
                'tag_id' => 62,
                'content_id' => 514,
                'created_at' => '2019-04-10 13:27:37',
            ),
            54 => 
            array (
                'tag_id' => 56,
                'content_id' => 514,
                'created_at' => '2019-04-10 13:27:37',
            ),
            55 => 
            array (
                'tag_id' => 63,
                'content_id' => 514,
                'created_at' => '2019-04-10 13:27:37',
            ),
            56 => 
            array (
                'tag_id' => 64,
                'content_id' => 515,
                'created_at' => '2019-04-10 13:33:39',
            ),
            57 => 
            array (
                'tag_id' => 62,
                'content_id' => 515,
                'created_at' => '2019-04-10 13:33:39',
            ),
            58 => 
            array (
                'tag_id' => 56,
                'content_id' => 515,
                'created_at' => '2019-04-10 13:33:39',
            ),
            59 => 
            array (
                'tag_id' => 63,
                'content_id' => 515,
                'created_at' => '2019-04-10 13:33:39',
            ),
            60 => 
            array (
                'tag_id' => 64,
                'content_id' => 516,
                'created_at' => '2019-04-10 13:34:44',
            ),
            61 => 
            array (
                'tag_id' => 62,
                'content_id' => 516,
                'created_at' => '2019-04-10 13:34:44',
            ),
            62 => 
            array (
                'tag_id' => 56,
                'content_id' => 516,
                'created_at' => '2019-04-10 13:34:44',
            ),
            63 => 
            array (
                'tag_id' => 63,
                'content_id' => 516,
                'created_at' => '2019-04-10 13:34:44',
            ),
            64 => 
            array (
                'tag_id' => 60,
                'content_id' => 516,
                'created_at' => '2019-04-10 13:34:44',
            ),
            65 => 
            array (
                'tag_id' => 64,
                'content_id' => 521,
                'created_at' => '2019-04-10 13:45:58',
            ),
            66 => 
            array (
                'tag_id' => 62,
                'content_id' => 521,
                'created_at' => '2019-04-10 13:45:58',
            ),
            67 => 
            array (
                'tag_id' => 56,
                'content_id' => 521,
                'created_at' => '2019-04-10 13:45:58',
            ),
            68 => 
            array (
                'tag_id' => 63,
                'content_id' => 521,
                'created_at' => '2019-04-10 13:45:58',
            ),
            69 => 
            array (
                'tag_id' => 64,
                'content_id' => 529,
                'created_at' => '2019-04-10 15:15:18',
            ),
            70 => 
            array (
                'tag_id' => 62,
                'content_id' => 529,
                'created_at' => '2019-04-10 15:15:18',
            ),
            71 => 
            array (
                'tag_id' => 56,
                'content_id' => 529,
                'created_at' => '2019-04-10 15:15:18',
            ),
            72 => 
            array (
                'tag_id' => 63,
                'content_id' => 529,
                'created_at' => '2019-04-10 15:15:18',
            ),
            73 => 
            array (
                'tag_id' => 64,
                'content_id' => 530,
                'created_at' => '2019-04-10 15:23:27',
            ),
            74 => 
            array (
                'tag_id' => 62,
                'content_id' => 530,
                'created_at' => '2019-04-10 15:23:27',
            ),
            75 => 
            array (
                'tag_id' => 56,
                'content_id' => 530,
                'created_at' => '2019-04-10 15:23:27',
            ),
            76 => 
            array (
                'tag_id' => 64,
                'content_id' => 531,
                'created_at' => '2019-04-10 15:56:55',
            ),
            77 => 
            array (
                'tag_id' => 62,
                'content_id' => 531,
                'created_at' => '2019-04-10 15:56:55',
            ),
            78 => 
            array (
                'tag_id' => 56,
                'content_id' => 531,
                'created_at' => '2019-04-10 15:56:55',
            ),
            79 => 
            array (
                'tag_id' => 64,
                'content_id' => 532,
                'created_at' => '2019-04-10 15:58:44',
            ),
            80 => 
            array (
                'tag_id' => 62,
                'content_id' => 532,
                'created_at' => '2019-04-10 15:58:44',
            ),
            81 => 
            array (
                'tag_id' => 56,
                'content_id' => 532,
                'created_at' => '2019-04-10 15:58:44',
            ),
            82 => 
            array (
                'tag_id' => 63,
                'content_id' => 532,
                'created_at' => '2019-04-10 15:58:44',
            ),
            83 => 
            array (
                'tag_id' => 64,
                'content_id' => 533,
                'created_at' => '2019-04-10 16:01:44',
            ),
            84 => 
            array (
                'tag_id' => 62,
                'content_id' => 533,
                'created_at' => '2019-04-10 16:01:44',
            ),
            85 => 
            array (
                'tag_id' => 56,
                'content_id' => 533,
                'created_at' => '2019-04-10 16:01:44',
            ),
            86 => 
            array (
                'tag_id' => 64,
                'content_id' => 540,
                'created_at' => '2019-04-11 13:28:46',
            ),
            87 => 
            array (
                'tag_id' => 62,
                'content_id' => 568,
                'created_at' => '2019-04-16 15:41:51',
            ),
            88 => 
            array (
                'tag_id' => 56,
                'content_id' => 568,
                'created_at' => '2019-04-16 15:41:51',
            ),
            89 => 
            array (
                'tag_id' => 62,
                'content_id' => 569,
                'created_at' => '2019-04-16 15:45:59',
            ),
            90 => 
            array (
                'tag_id' => 56,
                'content_id' => 569,
                'created_at' => '2019-04-16 15:45:59',
            ),
            91 => 
            array (
                'tag_id' => 62,
                'content_id' => 571,
                'created_at' => '2019-04-16 16:03:02',
            ),
            92 => 
            array (
                'tag_id' => 56,
                'content_id' => 571,
                'created_at' => '2019-04-16 16:03:02',
            ),
            93 => 
            array (
                'tag_id' => 64,
                'content_id' => 572,
                'created_at' => '2019-04-16 16:06:18',
            ),
            94 => 
            array (
                'tag_id' => 62,
                'content_id' => 572,
                'created_at' => '2019-04-16 16:06:18',
            ),
            95 => 
            array (
                'tag_id' => 56,
                'content_id' => 572,
                'created_at' => '2019-04-16 16:06:18',
            ),
            96 => 
            array (
                'tag_id' => 62,
                'content_id' => 573,
                'created_at' => '2019-04-16 16:23:06',
            ),
            97 => 
            array (
                'tag_id' => 56,
                'content_id' => 573,
                'created_at' => '2019-04-16 16:23:06',
            ),
            98 => 
            array (
                'tag_id' => 62,
                'content_id' => 574,
                'created_at' => '2019-04-16 16:38:12',
            ),
            99 => 
            array (
                'tag_id' => 56,
                'content_id' => 574,
                'created_at' => '2019-04-16 16:38:12',
            ),
            100 => 
            array (
                'tag_id' => 62,
                'content_id' => 575,
                'created_at' => '2019-04-16 16:42:31',
            ),
            101 => 
            array (
                'tag_id' => 56,
                'content_id' => 575,
                'created_at' => '2019-04-16 16:42:31',
            ),
            102 => 
            array (
                'tag_id' => 62,
                'content_id' => 576,
                'created_at' => '2019-04-16 16:57:15',
            ),
            103 => 
            array (
                'tag_id' => 56,
                'content_id' => 576,
                'created_at' => '2019-04-16 16:57:15',
            ),
            104 => 
            array (
                'tag_id' => 62,
                'content_id' => 577,
                'created_at' => '2019-04-16 17:21:20',
            ),
            105 => 
            array (
                'tag_id' => 56,
                'content_id' => 577,
                'created_at' => '2019-04-16 17:21:20',
            ),
            106 => 
            array (
                'tag_id' => 69,
                'content_id' => 605,
                'created_at' => '2019-04-22 19:20:04',
            ),
            107 => 
            array (
                'tag_id' => 70,
                'content_id' => 605,
                'created_at' => '2019-04-22 19:20:04',
            ),
            108 => 
            array (
                'tag_id' => 69,
                'content_id' => 606,
                'created_at' => '2019-04-22 19:20:19',
            ),
            109 => 
            array (
                'tag_id' => 70,
                'content_id' => 606,
                'created_at' => '2019-04-22 19:20:19',
            ),
            110 => 
            array (
                'tag_id' => 71,
                'content_id' => 606,
                'created_at' => '2019-04-22 19:20:19',
            ),
            111 => 
            array (
                'tag_id' => 69,
                'content_id' => 607,
                'created_at' => '2019-04-22 19:20:28',
            ),
            112 => 
            array (
                'tag_id' => 70,
                'content_id' => 607,
                'created_at' => '2019-04-22 19:20:28',
            ),
            113 => 
            array (
                'tag_id' => 71,
                'content_id' => 607,
                'created_at' => '2019-04-22 19:20:28',
            ),
            114 => 
            array (
                'tag_id' => 69,
                'content_id' => 608,
                'created_at' => '2019-04-22 19:20:37',
            ),
            115 => 
            array (
                'tag_id' => 70,
                'content_id' => 608,
                'created_at' => '2019-04-22 19:20:37',
            ),
            116 => 
            array (
                'tag_id' => 71,
                'content_id' => 608,
                'created_at' => '2019-04-22 19:20:37',
            ),
            117 => 
            array (
                'tag_id' => 69,
                'content_id' => 609,
                'created_at' => '2019-04-22 19:20:47',
            ),
            118 => 
            array (
                'tag_id' => 70,
                'content_id' => 609,
                'created_at' => '2019-04-22 19:20:47',
            ),
            119 => 
            array (
                'tag_id' => 71,
                'content_id' => 609,
                'created_at' => '2019-04-22 19:20:47',
            ),
            120 => 
            array (
                'tag_id' => 69,
                'content_id' => 610,
                'created_at' => '2019-04-22 19:20:56',
            ),
            121 => 
            array (
                'tag_id' => 70,
                'content_id' => 610,
                'created_at' => '2019-04-22 19:20:56',
            ),
            122 => 
            array (
                'tag_id' => 69,
                'content_id' => 611,
                'created_at' => '2019-04-22 19:21:08',
            ),
            123 => 
            array (
                'tag_id' => 70,
                'content_id' => 611,
                'created_at' => '2019-04-22 19:21:08',
            ),
            124 => 
            array (
                'tag_id' => 71,
                'content_id' => 611,
                'created_at' => '2019-04-22 19:21:08',
            ),
            125 => 
            array (
                'tag_id' => 69,
                'content_id' => 612,
                'created_at' => '2019-04-22 19:21:16',
            ),
            126 => 
            array (
                'tag_id' => 70,
                'content_id' => 612,
                'created_at' => '2019-04-22 19:21:16',
            ),
            127 => 
            array (
                'tag_id' => 71,
                'content_id' => 612,
                'created_at' => '2019-04-22 19:21:16',
            ),
            128 => 
            array (
                'tag_id' => 70,
                'content_id' => 613,
                'created_at' => '2019-04-22 19:21:25',
            ),
            129 => 
            array (
                'tag_id' => 71,
                'content_id' => 613,
                'created_at' => '2019-04-22 19:21:25',
            ),
            130 => 
            array (
                'tag_id' => 69,
                'content_id' => 614,
                'created_at' => '2019-04-22 19:21:39',
            ),
            131 => 
            array (
                'tag_id' => 70,
                'content_id' => 614,
                'created_at' => '2019-04-22 19:21:39',
            ),
            132 => 
            array (
                'tag_id' => 71,
                'content_id' => 614,
                'created_at' => '2019-04-22 19:21:39',
            ),
            133 => 
            array (
                'tag_id' => 69,
                'content_id' => 615,
                'created_at' => '2019-04-22 19:21:48',
            ),
            134 => 
            array (
                'tag_id' => 70,
                'content_id' => 615,
                'created_at' => '2019-04-22 19:21:48',
            ),
            135 => 
            array (
                'tag_id' => 71,
                'content_id' => 615,
                'created_at' => '2019-04-22 19:21:48',
            ),
            136 => 
            array (
                'tag_id' => 69,
                'content_id' => 616,
                'created_at' => '2019-04-22 19:21:58',
            ),
            137 => 
            array (
                'tag_id' => 70,
                'content_id' => 616,
                'created_at' => '2019-04-22 19:21:58',
            ),
            138 => 
            array (
                'tag_id' => 69,
                'content_id' => 617,
                'created_at' => '2019-04-22 19:22:39',
            ),
            139 => 
            array (
                'tag_id' => 70,
                'content_id' => 617,
                'created_at' => '2019-04-22 19:22:39',
            ),
            140 => 
            array (
                'tag_id' => 69,
                'content_id' => 618,
                'created_at' => '2019-04-22 19:23:09',
            ),
            141 => 
            array (
                'tag_id' => 70,
                'content_id' => 618,
                'created_at' => '2019-04-22 19:23:09',
            ),
            142 => 
            array (
                'tag_id' => 71,
                'content_id' => 618,
                'created_at' => '2019-04-22 19:23:09',
            ),
            143 => 
            array (
                'tag_id' => 69,
                'content_id' => 619,
                'created_at' => '2019-04-22 19:27:08',
            ),
            144 => 
            array (
                'tag_id' => 70,
                'content_id' => 619,
                'created_at' => '2019-04-22 19:27:08',
            ),
            145 => 
            array (
                'tag_id' => 71,
                'content_id' => 619,
                'created_at' => '2019-04-22 19:27:08',
            ),
            146 => 
            array (
                'tag_id' => 69,
                'content_id' => 620,
                'created_at' => '2019-04-22 19:27:32',
            ),
            147 => 
            array (
                'tag_id' => 70,
                'content_id' => 620,
                'created_at' => '2019-04-22 19:27:32',
            ),
            148 => 
            array (
                'tag_id' => 64,
                'content_id' => 632,
                'created_at' => '2019-04-26 15:33:55',
            ),
            149 => 
            array (
                'tag_id' => 62,
                'content_id' => 632,
                'created_at' => '2019-04-26 15:33:55',
            ),
            150 => 
            array (
                'tag_id' => 69,
                'content_id' => 633,
                'created_at' => '2019-04-26 15:36:08',
            ),
            151 => 
            array (
                'tag_id' => 64,
                'content_id' => 637,
                'created_at' => '2019-04-26 15:57:05',
            ),
            152 => 
            array (
                'tag_id' => 62,
                'content_id' => 637,
                'created_at' => '2019-04-26 15:57:05',
            ),
            153 => 
            array (
                'tag_id' => 64,
                'content_id' => 636,
                'created_at' => '2019-04-26 16:18:57',
            ),
            154 => 
            array (
                'tag_id' => 62,
                'content_id' => 636,
                'created_at' => '2019-04-26 16:18:57',
            ),
            155 => 
            array (
                'tag_id' => 56,
                'content_id' => 636,
                'created_at' => '2019-04-26 16:18:57',
            ),
            156 => 
            array (
                'tag_id' => 64,
                'content_id' => 652,
                'created_at' => '2019-05-02 11:56:37',
            ),
            157 => 
            array (
                'tag_id' => 62,
                'content_id' => 652,
                'created_at' => '2019-05-02 11:56:37',
            ),
            158 => 
            array (
                'tag_id' => 64,
                'content_id' => 653,
                'created_at' => '2019-05-02 13:18:23',
            ),
            159 => 
            array (
                'tag_id' => 62,
                'content_id' => 653,
                'created_at' => '2019-05-02 13:18:23',
            ),
            160 => 
            array (
                'tag_id' => 56,
                'content_id' => 653,
                'created_at' => '2019-05-02 13:18:23',
            ),
            161 => 
            array (
                'tag_id' => 69,
                'content_id' => 654,
                'created_at' => '2019-05-02 13:45:45',
            ),
            162 => 
            array (
                'tag_id' => 64,
                'content_id' => 655,
                'created_at' => '2019-05-02 15:06:02',
            ),
            163 => 
            array (
                'tag_id' => 64,
                'content_id' => 656,
                'created_at' => '2019-05-02 15:07:46',
            ),
            164 => 
            array (
                'tag_id' => 62,
                'content_id' => 656,
                'created_at' => '2019-05-02 15:07:46',
            ),
            165 => 
            array (
                'tag_id' => 64,
                'content_id' => 657,
                'created_at' => '2019-05-02 16:34:23',
            ),
            166 => 
            array (
                'tag_id' => 62,
                'content_id' => 657,
                'created_at' => '2019-05-02 16:34:23',
            ),
        ));
        
        
    }
}