<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->increments('id',true);
            $table->string('last_name', 255);
            $table->string('first_name', 255);
            $table->string('password', 255);
            $table->tinyInteger('level')->default(0);
            $table->string('picture', 255);
            $table->string('email', 255)->unique();
            $table->tinyInteger('first_log')->default(0);
            $table->date('birthday');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
